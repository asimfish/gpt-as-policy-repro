# 运行手册

## 当前运行入口（2026-10-07）

有效主实验RoboDojo100/100、50对完成并整组验收，原面板99/100另行保留；layout5补齐已经按用户续推进授权实施，不再沿原无效layout4重复物理回合。RoboLab74/100、35对，尚余26条与最终联合验收。
当前RoboLab单元为`gpt-policy-robolab-parallel-v5.service`，原v4 disabled/inactive，三条已证明未启动物理的保留槽由v5自行释放。新回合工作区固定使用第二本地SSD：`/data/liyufeng/agentic_robot_runtime/gpt_policy_repro_20260914`。冻结v2资格、首完整失败及max3规则不变，禁止补跑完整原生失败、审计缺口或不确定SSH启动。
`gpt-policy-robolab-policy-health.timer`每10分钟运行一次safeduo Python3.11文字连接探测；不调用回合服务，使用原登录、固定gpt-6-astra/xhigh、无fallback。`robolab_policy_health.json`verified且不超过900秒才允许新启动。失败只保留待运行任务，不能据探测失败自动更换登录、模型、重试代次或结束活跃物理回合。
`robolab_queue_scheduler_v5_manifest.json`绑定新增队列/监督器/启动护栏和原文件；任何哈希变动须新版本，不原地修正历史源码。`remote_launch_attempted=true`在唯一SSH启动前持久化；true或缺字段的未知启动不能凭远端暂时无文件释放。历史三条重建元数据明确标注metadata_reconstructed，不是原监督器结果，不伪造原归档，也不计原生完整。
发布、原归档恢复、私有冷归档及最终验收计时器继续；整体保持`full_reproduction_complete=false`。最新证明目录`publication_checks/launch_recovery_20261007`，决定见`ROBOLAB_LAUNCH_GUARD_ADR.md`。

## 历史运行入口（2026-10-05，保留决策过程）

主实验继续 `gpt-policy-all-pairs-v5.service`，发布继续 `gpt-policy-report-progress.timer`。
2026-10-05 13:18 UTC已启动v6边界handover，当前第五次layout4 Hybrid不被中断。
检查`queue_handover_20261005_v6.json`：仅switched_at_physical_episode_boundary表示已切换
`gpt-policy-all-pairs-v6.service`。新单元启用后旧v5禁用，资格、原审计、执行入口与冻结案例不变。
v6对身份一致、明确原生无效的完整尝试单独限制3次，之后状态native_invalid_requires_repair，
不会继续用基础设施预算重复同一原生演示失败；有效完整失败和审计缺口优先级不变。
当前99/100；layout4无模型保持诊断也在432步失败，1600步仍排除。原因与建议见
ROBODOJO_NATIVE_LAYOUT_DIAGNOSIS.md。补用原面板预冻结layout5的方案尚未启用，不能自行修改fixtures或旧成绩。
主实验后续尝试的π服务和仿真就绪等待均为1200秒（旧600秒曾被NAS加载耗尽）；
原生步数、完整审计、控制器输入与12小时看护不变。invalid_native_layout仍不计分，完整失败仍保留。
RoboLab 已在2026-10-04 17:40 UTC的控制器/归档边界切到 `gpt-policy-robolab-two-methods-v2.service`，
当前新版服务enabled且运行；旧验证服务disabled，完成的一次性接管unit禁用自启动。
检查 `robolab_queue_handover_20261005.json` 判断是否已经切换，不能只看新服务文件存在。
v2源码、SHA256及修复后有上限的重试决定见 `robolab_queue_scheduler_v2_manifest.json`。
完整终止和资格函数与v1相同，旧完整失败及旧审计缺口仍保留，不能挑选后续成功。

`gpt-policy-robolab-archive-recovery.timer`每10分钟恢复最早的原生完整回合：
`python3 infra/recover_robolab_archives.py`（实验目录内）。仅补传已停止数据并运行原完整审计。
归档允许服务退出后留下的ready元数据，但必须有STOP、所有原PID及进程组均消失的只读证明；
证明存入远端归档manifest和本机receipt，不改原services.json。未通过完整审计的回合不计分。
归档前原子封存remote_archive_manifest.json；同一静止源清单变化时保留原清单并拒绝传输。
remote_archive_transfer.json列出owner_pid、阶段及每组传输/重试状态，verified仅表示归档字节，不表示成绩。
总表robolab_archive_recovery.json额外给出完整plan、active及summary；旧v1 results字段兼容。
每个归档调用用独立/tmp锁互斥，每个rsync建立独立进程组；重试前清理全部非僵尸成员。
仅结束超时父进程会留下仍可写入partial文件的receiver，不能作为安全重试边界；清理失败则停止该组重试。
归档按已冻结manifest分为4组互不重叠文件列表，以NUL分隔路径；每组1200秒/次、最多3次，
已完成组不重复传输。最终所有文件尺寸及SHA256仍必须一致；并行仅缓解已观察到的单流速度差异。
未来仿真使用已核验2228文件的完整资产目录，远端管理器按原显存门槛选择空闲独立GPU。
当前回合使用已有运行环境直到原生结束；不会重连或重放不确定动作。

发布器 `report_publication_transaction.json` 绑定本轮自有暂存的HEAD、Git索引树和路径。
提交中断后可在完全匹配时恢复；任何并发用户暂存变化仍拒绝提交。
遗留index.lock只可在确认原Git写入进程及文件持有者均退出后保存为诊断证据，不能盲删。
恢复记录见 `publication_checks/recovery_20261005`，最新线上事实见 `online_publication.json`。

报告的无效布局排除必须与原生资格一致：`status=invalid_native_layout`、
`valid_for_success_rate=false`、native success/score均null且冻结身份匹配时，保留为未计分尝试。
不能把该尝试加入有效完整候选并永久挡住有效重试；有效完整失败及审计缺口仍挡住任何后续结果。
原因标签已补齐，34项站点回归通过；修改仅在报告，不改原生评估器或冻结队列。

后续RoboLab监督器在远端停止确认后、慢归档开始前调用`copy_stopped_controller_output`：
先原子保存原result.json字节，再复制控制器输出，runtime_db/runtime_logs仍留私有工作区。
结果标记已存在却与静止源不同会拒绝覆盖；复制中断仍让冻结队列看到最早原生完整回合并标成audit_failed，
不创建新的物理替代回合。attempt/active的controller_finished与artifact_phase在归档前写出。
当前旧监督器不重启，新入口仅后续新进程加载；完整资格仍须原归档与动作审计通过。

`gpt-policy-final-verification.timer`已enabled，每10分钟检查两套冻结矩阵。
在项目根目录可手工执行：
`/home/liyufeng/miniforge3/envs/safeduo/bin/python experiments/gpt_policy_repro_20260914/infra/verify_reproduction_completion.py`。
程序只读实验与站点，使用既有发布锁，发布进行中则延后，不连接模型/物理RPC。
`full_reproduction_verification.json`在覆盖不足时明确给出pending_native_episodes与剩余项；
不能仅根据摘要100或复制行判断完成。两套各100回合、各50对后才进行完整归档/hash扫描：
保留所有历史中最早有效原生结果、有效完整失败与审计缺口；逐文件重核原审计输入，
RoboLab再核整份静止远端manifest/receipt。每段原传感视频必须包含step_id+1帧，
公开视频全段解码通过、视频/审计/证据/海报以及报告和基建包共807个公开文件逐字节核对，
对应发布提交CI成功后才能置full_reproduction_complete=true。
整个最终扫描可耗时数小时；进度中的active与verified_native_episodes可见，失败仍保持未完成。
成功证明同时保存在`final_verification/<commit>/certificate.json`；同一提交已有证明时保留原验收时间，
后续计时器不会用新时间冒充重验结果。证明是该提交在finished_utc时的验收，不保证未来文件不会改变。
当前只是新验收器已部署和两条停止原回合复核，不代表200回合已经完成。

## 2026-10-02启动与RPC诊断历史

主队列：`gpt-policy-all-pairs-v5.service`；主板自动发布：`gpt-policy-report-progress.timer`（每 10 分钟）。
在项目根目录设置 session bus 后，可用 `systemctl --user status` 和 `journalctl --user -u <服务名>` 检查。
v5 冻结脚本 SHA256 记录在 `queue_scheduler_v5_manifest.json`；不要直接修改运行中的冻结快照。

RoboLab 首个原版 Hybrid（当前因 RPC 传输中断已归档）：`gpt-policy-robolab-hybrid-first.service`，任务 BlocksInBinTask / seed 0。
`infra/run_robolab_hybrid_remote.py` 在本机运行原控制器；`run_mainskill_robolab_hybrid_services.py`
在远端启动自己的原生仿真与原版 identified π0.5 服务器。本机 /tmp 保存每次独立 SQLite 状态；
完成后归档控制器和远端原生轨迹到 `robolab_gpt_campaign/`。100000 次决策上限高于该任务原生
2250 控制步时域，不能把 RoboLab 的 max-decisions=0 当作无限制（它会在第一次决策停止）。

实时证据：`robolab_gpt_active.json`；私有前缀审计：
`python3 infra/snapshot_robolab_gpt_prefix.py --decisions 2`（在实验目录运行）。
前缀只获取所选决策实际需要的原生chunk/回执，不复制随后增长的未来动作；继承该attempt的SSH cipher，传输预算1200秒。
传输中断时，可用 `--resume-snapshot <原快照目录名>` 只读补传同一快照，不重取模型决策、不连接RPC。
前缀审计永远 `complete_episode=false`，不得进入成功率分母。停止只通过该服务的正常 SIGTERM
与唯一 attempt STOP 标记，清理自己的进程组；不重连重试不确定的动作 ACK。

Direct 补充接口已经实现：`infra/run_robolab_direct_controller.py`、`robolab_direct_tools.py`
与 `robolab_direct_server.py`；接口回归及真实完整 EEF 动作链路均已通过。
`gpt-policy-robolab-direct-first.service` 前两次尝试均在首条动作 ACK 前发生 SSH 通道中断；
10:45 UTC 第三次字节边界诊断与关闭QoS对照均证实WAN数据交付失败。
Direct `direct_20261002T111156Z_BlocksInBinTask_seed0` 已原生成功并完整审计：986步、198决策、π调用0。
正式 RoboLab SSH 连接固定 `--ssh-cipher aes128-gcm@openssh.com`；host key 校验仍开启，
不改模型、提示、动作、种子或原生时域。纯 echo 默认 cipher 重现失败两次，AES-GCM45种包长通过。
原版 Hybrid 留有 105 动作 / 7 决策的已核对前缀；三个尝试都不计分。
旧300秒归档只传回902个动作块而缺终止文件，验证门正确拒绝；补传同一2184文件归档并逐文件
SHA256核对后，原完整审计通过，不重跑物理回合。归档修复见 ROBOLAB_ARCHIVE_DIAGNOSIS.md。
后续回合采用 `infra/archive_robolab_attempt.py`：1200秒/次、至多3次只读补传、固定实验cipher、
完整远端manifest核对。手工恢复命令（在实验目录运行）：
`python3 infra/archive_robolab_attempt.py <原attempt名>`；随后运行原完整审计。
`gpt-policy-robolab-validated-campaign.service` 已于17:48 UTC完成首例两方法完整验证，并自动进入
`queue_robolab_two_methods_v1_20261002.py`；哈希见 robolab_queue_scheduler_v1_manifest.json。
首个原版Hybrid hybrid_20261002T155347Z_BlocksInBinTask_seed0 原生成功1269步/94决策，
学生1204、修改20、EEF接管45步；1525文件完整归档核验与原完整动作审计均通过。
当前全量队列继续BlocksInBinTask seed1 Hybrid；首组Direct/Hybrid已配齐，仍只完成补充2/100项。
门控状态 robolab_validation_gate.json；全队列状态 robolab_gpt_queue_state.json。任何前缀/中断/审计
缺失都不能开启全队列。重启验证门时保留最早完整Hybrid，不重复物理回合；中断重试有上限。
attempt.json 的controller_finished/action_audit_pending只是控制器退出时的记录；后续完整资格
以complete_action_audit.json和全队列审计结果为准，不能把进程退出或旧attempt标记当作成绩。
验证服务现在 `Restart=on-failure`、60秒后恢复，15分钟最多3次启动；同一首例Hybrid基础设施
尝试最多3次。完整回合审计失败时保留原回合并要求检查，不能借重启新跑或替换结果。
安装模板和本机unit已同步并通过systemd-analyze校验；daemon-reload未重启当前控制器。
诊断证据 ROBOLAB_RPC_DIAGNOSIS.md、ROBOLAB_ARCHIVE_DIAGNOSIS.md。

### 本机 SSD 容量维护

本机/tmp与NAS的SQLite兼容性不同：活动回合始终使用本机/tmp中的新工作区。
`gpt-policy-robolab-workspace-offload.timer`每10分钟运行一次
`infra/offload_robolab_workspaces.py --limit 2`。仅处理已退出、完整原生审计通过且远端归档已核验
的自有回合；当前active、仍存在的控制器/worker进程、审计缺失或身份/hash改变时保留本机数据。
整个已封存工作区（包括数据库、日志）先复制到`private_runtime_archives/<attempt>/workspace`，
所有文件尺寸/SHA256相同后才释放本机重复副本，旧/tmp路径保留追溯链接。新回合不会复用这些
冷归档SQLite。冷归档位于公开报告与基建包的导出范围之外。
维护状态`runtime_storage_maintenance.json`，每个归档的`receipt.json`保留全文件manifest。
本机文件必须由当前用户所有；CIFS目标显示NAS挂载uid，目标采用固定路径、拒绝链接/特殊文件和
完整尺寸/hash核验。拷贝或链接建立失败时保留源文件；rename/link边界中断可继续恢复。
2026-10-02首组完整回合共3396文件/1819664646字节已核验归档，活动seed1工作区仍在本机；
原两条完整动作审计另行重核，结果见publication_checks/runtime_storage_20261002。

RoboDojo本机Codex状态也采用同一文件保全事务：
`gpt-policy-robodojo-state-offload.timer`每10分钟执行`offload_robodojo_codex_states.py --limit 2`。
程序先核对v5冻结调度器SHA256，再只加载已核验的源字节，以其原完整审计资格函数判定候选回合。
迁移对象仅为launch.json记录的`/tmp/gpt-policy-codex-state.<8位随机名>`，SQLite与logs必须在
该同一目录；仍存在的worker、任何其他活worker使用的状态目录、资格失败或元数据改变均保留。
私有归档名为`private_runtime_archives/robodojo_<run>__<method>/workspace`；状态账本为
`robodojo_storage_maintenance.json`。首批两个封存状态341698280字节完整核验后释放重复副本，
同一v5资格重核仍通过；活动主实验状态目录仍在本机。模型认证保持由原CLI配置读取。

诊断 `run_robolab_rpc_probe.py` 只测试原生 hold/EEF 求解 RPC，明确 `benchmark_eligible=false`，
不能把它或 Hybrid、独立 π0.5 回合当作 Direct。后面的旧日期记录用于追溯，
以本节、GOAL.md 和最新 online_publication.json 为当前事实。

## π0.5 对照

```bash
source infra/env.sh
python3 infra/run_batch_student.py \
  --cases fixtures/cases --output student_native_campaign \
  --sim-wrapper infra/run_sim_server.sh --policy-wrapper infra/run_pi05_server.sh \
  --checkpoint "$PI05_CHECKPOINT" --eval-manifest fixtures/evaluation_manifest.json \
  --limit 50 --skip-completed --max-decisions 0 --base-port 19400
```

这条命令只测官方 π0.5，不调用 GPT。每个案例使用全新策略服务和不可复用的 attempt 目录。

## 原版 GPT Direct / hybrid

用户已于 2026-09-16 授权使用当前 Codex CLI 的 GPT-6 Astra。设置 ROLLOUT_USE_CURRENT_CODEX_HOME=1，复用其现有登录态；认证只由 CLI 自身读取，不复制或输出 auth.json。然后启动 sim 与 policy 服务，把 `infra/run_original_controller.sh` 的 `gpt_only` 或 `pi05_plus_gpt` 作为唯一控制器。它调用仓库原版 `hybrid_rollout.robodojo.skill.run`，使用持久 app-server thread、原始 GATE prompt 和 `GPTOnlyTools`/`RoboDojoTools`。启用当前登录态时无需独立账号；未启用该授权模式时，脚本才要求独立配置。

## RoboLab

RoboLab 仿真器要求自己的 IsaacLab/IsaacSim 版本和环境。当前使用 `fixtures/robolab_two_methods_frozen.json`：10 任务 × 5 种子 × Direct/Hybrid，共 100 项。旧 `robolab_campaign.json` 的五方法清单仅历史追溯，禁止据此扩大当前队列。历史公开表没有提供全部初态。

## 诊断

```bash
python3 infra/campaign_status.py student_native_campaign
python3 infra/build_reproduction_report.py .
python3 infra/render_dashboard.py .
```

不要用 TCP 连接做 sim readiness probe：RoboDojo 服务只有一个 RPC client 槽，探测会消耗真实会话。遇到错误时查看对应 `sim_server.log`，批处理会检测渲染初始化错误、提前退出、超时并清理自己的进程组。

## 持久顺序调度

本机已启动 transient user service `gpt-policy-prefix15-campaign.service`，执行 `infra/run_student_queue.sh`。它使用独立队列锁，等待正在运行的 campaign 结束；GPU0 空闲显存达到 20000 MiB 后，每次运行 1 个未完成案例，最多调度 50 次。每条结束后更新报告、dashboard 与状态文件；出现非完整原生结果或基础设施错误时退出，不无限重试。此服务仅覆盖 `pi05_prefix15`，不代表 GPT 或完整 chunk-50 基线。重启机器后需重新启动。

在没有 session bus 环境变量的 shell 中先设置（只影响当前 shell）：

```bash
export XDG_RUNTIME_DIR="/run/user/$(id -u)"
export DBUS_SESSION_BUS_ADDRESS="unix:path=$XDG_RUNTIME_DIR/bus"
systemctl --user status gpt-policy-prefix15-campaign.service
```

队列日志为 `student_queue.log`。停止命令为 `systemctl --user stop gpt-policy-prefix15-campaign.service`；检查失败日志并修复后可用 `systemctl --user restart gpt-policy-prefix15-campaign.service` 恢复。停止运行中的服务可能留下不完整 attempt，不能计为失败样本。服务不会停止其他用户进程。

`--limit` 现在表示跳过已完成案例后，本批实际选择的待跑数量。参数 `--limit 1 --skip-completed` 会选择下一个待跑案例，不再因前 1 个案例已经完成而空跑。

原生 reset 若明确给出 `status=invalid_native_layout`、`error_type=UnStableError` 且 `complete=false`、`valid_for_success_rate=false`，队列保留 attempt 并排除该案例，继续下一个。此状态不计为成功、失败或原生完成；`--skip-completed` 同时跳过这些已确认无效的案例。其他 reset/执行/基础设施错误仍停下检查。

A100 端实际渲染进展与配置对照见 `mainskill/render_diagnostics.md`。源码 tarball 的 Git LFS 指针不是 USD 资产；不能省略资产下载与校验。

### mainskill RoboLab π0.5 完整回合（依赖就绪后自动启动）

- `infra/bootstrap_mainskill_openpi.sh`：单独的 `venvs/openpi-robolab` 环境，固定 OpenPI 的 `uv.lock --frozen --no-dev`，与 IsaacSim 环境分离。环境/下载缓存放数据盘。
- `infra/transfer_checkpoint_chunks.py`：在本机运行，4 MiB SSH 分块，3 个对象并发；每块 SHA256 校验、断点恢复，最终按已验证的官方 manifest 校验每个文件。全部完成才原子写远端 `transfer_verification.json`。不得同时运行旧 rsync 传输服务。
- `infra/serve_robolab_pi05.py`：仅监听远端 localhost，握手含 checkpoint manifest hash、源 URI、配置名及动作长度。
- `infra/run_mainskill_robolab_pi05.sh`：在 mainskill 运行，最多等待依赖 12 小时，检查 GPU 0 至少 50 GiB 空闲后，启动上述模型服务器和 BlocksInBinTask seed 0 完整回合。仅清理其启动的进程组；原生结束证据、每次预测、视频保存在 `mainskill_robolab_pi05/<UTC>/`。fresh reset 单列，不当作正式配对结果。
- 2026-09-15 部署时 GitHub 拉取固定 LeRobot commit 连续 TLS/连接失败；从本机获取 `0cf864870cf29f4738d3ade893e6fd13fbd7cdb5` 的 shallow Git 数据，同步至远端 uv Git 缓存。未修改依赖版本。Git LFS 的测试数据不用于包安装。
- 本机最终瓶子案例 GPU 0 出现原生 PhysX 显存分配失败，尝试已保留并排除。队列支持 `CAMPAIGN_GPU=1` 使显存门槛检查、CUDA 设备和渲染设备一致；不终止其他项目进程。

### RoboDojo chunk-50 执行对照

`infra/run_chunk50_control.sh` 持有实验锁，等待 GPU 1 至少 20 GiB 空闲，启动一条 bottles l0 的新回合，结果写入 `chunk50_control/`。`run_batch_student.py --method pi05_chunk50` 选择独立执行器：一次模型推理的 50 个动作顺序切为 15+15+15+5 个 RPC 控制步，原生结束后立即停止；不在分片之间重新推理或重复执行失败回执的动作。输出单独汇总为 `pi05_chunk50`，不混入 prefix-15；首回合仍需通过原生执行和结果审核才扩展全部案例。

prefix-15 队列已于 2026-09-15 09:10 UTC 审计完成，不需继续重跑；逐案例覆盖记录见 `prefix15_cohort_audit.json`。49 原生结束 / 48 可计分 / 10 成功，另外两例为原生无效布局。最后一例先在 GPU 0 OOM、在 GPU 1 成功运行至 700 步原生时限，该回合任务未成功；OOM 尝试单独保留。

### A100 离线 OpenPI 环境与初态核验

运行时依赖由固定 `upstream/openpi-robolab/uv.lock` 解析；`download_openpi_wheels.py` 生成 SHA256 清单，`transfer_checkpoint_chunks.py --checkpoint openpi-wheels` 传输并复核。通过 `install_mainskill_offline_wheels.sh` 按 requirements 中的包名和版本离线安装，随后 `bootstrap_mainskill_openpi.sh` 执行冻结源码构建。不要按 wheel 路径安装运行包，否则会产生 direct_url 元数据并使冻结同步重新下载注册表包。构建工具另由 `download_openpi_build_wheels.py` 固定版本与 SHA256，位于 openpi-build-wheels；两个镜像目录都传入 --find-links。

RoboLab 官方服务器只允许每进程一个 fresh episode，明确禁止 restore/rollback。配对实验须为每个方法启动新进程，使用同一 task/seed 并审计初始物理状态。`ROBO_LAB_RECORD_SCENE_STATE=1` 开启记录。当前仅验证 BlocksInBinTask seed 0 的两次新进程初态 SHA 完全相同；不能外推其余任务或轨迹确定性。新版 IsaacLab 的空 gripper 状态可忽略，非空 gripper 与未知状态族会拒绝，避免遗漏控制状态。

上游 `gemma_pytorch.py` 在运行时导入 pytest，但它属于开发依赖。bootstrap 在冻结 runtime 同步后，仅补装同一 uv.lock 中的 pytest 8.3.5 / iniconfig 2.1.0 / pluggy 1.6.0；三者 wheel SHA 与锁文件一致。PaliGemma tokenizer 从官方 GCS 下载，本机已有副本与新下载一致，远端复核 SHA `8986bb4f423f07f8c7f70d0dbe3526fb2316056c17bae71b1ea975e77a168fc6`。

### 远端脚本发布与全任务场景验证

使用 `python3 infra/deploy_mainskill_script.py <文件名.sh或.py>` 发布本项目 infra 脚本。工具在远端进行语法校验后原子替换并保持权限；禁止直接覆盖正在运行的 Bash 脚本 inode。

`ROBO_LAB_TASK` / `ROBO_LAB_SEED` 传递到服务器和策略客户端。任务文件映射为 `fixtures/robolab_task_files.json`。`validate_mainskill_robolab_scenes.py` 在全量资产标记通过后，以 GPU4、port19700、seed0 逐任务启动新进程，记录 reset/render 状态；成功或失败都保留且不自动重复，不计作策略实验。

## 2026-09-16 Direct / Hybrid 控制器启动验收

当前只推进 GPT Direct 与 π0.5 + GPT；其他模型和独立基线不再自动运行。

本机 Codex 0.153.4 原生工具预检最初因 NAS 上 SQLite 初始化失败，改为本机 /tmp 私有状态目录后通过初始化；随后发现基础 PATH 没有 python，加入 ROBO_PYTHON 所在目录后原生 command/exec 成功（计算输出56）。infra/run_original_controller.sh 已修正这两个部署问题，未修改上游控制器与提示词。状态目录会记录在控制器 launch.json 中；需长期保存时归档到NAS，不直接在NAS运行SQLite。

两方法均通过原版 CodexPolicy 的 initialize → thread/start 握手，固定 gpt-6-astra/xhigh。Direct工具为 robodojo_start/robodojo_act；Hybrid工具为 robodojo_start/pi05_infer/robodojo_execute。证据：controller_preflight_20260916/method_protocol_result.json。预检使用无凭据、不可联网推理的本地占位提供商；model_turns=0，simulator_connections=0，不能据此宣称模型可用或任务完成。

fixtures/main_campaign.json 的50对案例已核对：两方法的case与identity字段完全一致，所有本地布局文件SHA256匹配。证据：controller_preflight_20260916/paired_panel_audit.json。这是清单与资产配对验证，实际运行仍须审计重置状态。

下一步：用户提供已授权实验模型配置路径/服务信息，完成真实模型调用，然后启动第一对原生回合。ROLLOUT_ISOLATED_CODEX_HOME、ROLLOUT_AUTH_PROFILE、GPT_POLICY_API_KEY、OPENAI_API_KEY、OPENAI_BASE_URL当前均未设置；占位预检配置不能用于正式实验。

## 2026-09-16 用户授权当前 Codex CLI，启动两方法首对实验

用户明确要求“直接自己开codex cli的gpt 6 astra”，覆盖此前独立账号限制。复用当前CLI认证，不复制或输出auth.json。ROLLOUT_USE_CURRENT_CODEX_HOME=1显式启用；上游codex_a只作为provider=openai路由标签，不表示历史论文账号。报告模型固定gpt-6-astra/xhigh。

真实codex exec探针成功返回ASTRA_CONNECTION_OK，输入16092tokens、输出8tokens；证据astra_live_probe_20260916/events.jsonl。随后原版CodexPolicy在当前登录态成功创建线程。run_original_controller.sh三项授权/Direct无student/Hybrid参数回归通过，全INFRA套件38通过。

infra/run_gpt_pair.py依次启动Direct及Hybrid，同一个冻结arrange_largest_number__random__g0__l0布局，原生上限1050步、max_decisions=0。仅Hybrid启动π0.5。每条任务新进程，保留原始提示/模型交互/轨迹/回执；完成后仍需独立审计才能计分。12小时墙钟watchdog只算基础设施中断，不算原生失败。

第一启动20260916T091119Z在模型响应前发生连接超时：systemd未继承终端代理，实际机器人动态工具调用0。停止并保留attempt与network_diagnosis.json；新启动20260916T091342Z显式加载0600代理EnvironmentFile。活动service见active_gpt_pair_service.json，日志gpt_pair_queue.log，原生结果位于gpt_pair_campaign。不可自动重试不确定的动作ACK。

GPT后端缺口已解决；下一步是观察真实工具调用、首条动作及完整原生结束，审计初态、模型身份和动作，再扩展50对案例。不要恢复已取消的Cosmos/DreamZero或独立π0.5全量基线。


## 2026-10-06 独立有效面板补齐

按上次具体补齐提案之后用户“继续推进”执行layout5两方法的新原生回合；原面板及所有原结果保留。`infra/robodojo_valid_cohort.py`固定原100个方法fixture哈希、原60面板、零模型诊断与唯一整对替换；先校验再发布不可变选择指针。补齐队列`infra/run_robodojo_valid_supplement.py`复用冻结v6资格函数和同一物理执行锁，独立写`robodojo_valid_queue_state.json`。首次有效完整失败及审计缺口不能用新物理回合替代；单方法最多3条基础设施尝试。

原v5→v6已于2026-10-05T14:28:01.696574UTC在物理回合边界切换。原面板99/100、49对；RoboLab21/100、6对，原归档积压为零。最终验收针对所选有效50对及RoboLab50对；另验保留的原面板回合，两个RoboDojo面板互有重叠，不能相加当作独立样本。补齐运行、独立在线报告和最终全量验收尚未完成。


2026-10-06补齐执行进展：独立清单SHA256为d0b76047a1f570f964b6987550538982f49182ba321a07c568f7ba1d2c7473cd。`gpt-policy-robodojo-supplement-v2.service`已enabled并于22:43:13UTC启动；Direct layout5新物理回合运行中，Hybrid随后执行。真实构建与页面验证：原面板99/100、49对，独立有效面板98/100、49对，RoboLab21/100、6对；桌面与390px手机验证通过，两面板筛选、深链接与完整视频实际播放均通过。已停止回合的自动私有状态转存已支持新增案例，仍执行同一哈希固定的v5完整资格检查并拒绝活动worker；六项回归通过。验收器16项回归通过，当前记录pending_native_episodes，不生成完成证书。页面及新基建包的线上精确字节验证另行记录，尚未完成时不得声称发布完成。


2026-10-06发布验收完成：提交419ca6f17982d498194dc5661de263c6d2183bdb，GitHub Pages工作流37385101951成功；14个网页/JSON/资源/包的提交字节与线上SHA全部匹配。原面板99/100、独立有效面板98/100（两者均49对，互有重叠），RoboLab21/100、6对。新页面为https://asimfish.github.io/gpt-as-policy-repro/gpt-methods-valid.html 。基建包`deliverables/infrastructure_bundle_20261006T065300Z.tar.gz`含832个文件，SHA256=5f5b05d2cf1296556f22c3c637aa17c52b87da7fc36ccd3caf878ce26a1c79c4；公开下载后逐个核对832成员和7个核心源码/冻结清单，全部通过。旧基建包与全部原回合保留。发布、归档、磁盘维护与最终验收timer恢复运行；layout5两方法补齐服务和RoboLab v2队列持续执行。全量验收仍为pending_native_episodes/full_reproduction_complete=false。证据目录publication_checks/valid_cohort_20261006。


2026-10-06 RoboLab有界并行推进：在不改写冻结100条身份、原模型/prompt/原生时域和首次完整失败/审计缺口规则的前提下，实现最多3个独立原生回合。设计与两种方案权衡见ROBOLAB_PARALLEL_ADR.md；v3直接装载SHA固定的v2资格/选择函数，原v2、原监督器与服务源码不改写。独立锁、端口、GPU预约、Linux boot/start身份、先持久化后单次启动及不确定ACK保留预约均有回归；退出只排空已启动回合。22项相关基建测试、40项报告测试和16项最终验收边界测试通过。远端新管理器已原子部署且读回SHA=18a33b59f78b6effefcb7b839beabcfd92575cdbce931fbeef69f435ed0cfefe。`gpt-policy-robolab-parallel-handover-20261006.service`已enabled，当前等待v2回合物理/清理/归档锁释放，尚未启动并行模型回合。报告已实现多个活动回合的脱敏进度，运行中回合不计入成绩。证据publication_checks/parallel_queue_20261006；调度源码及冻结SHA见robolab_queue_scheduler_v3_manifest.json。

本轮独立再核验ClutterPumpkin seed3 Hybrid原生失败1350步、seed4 Hybrid成功871步、seed0 Direct成功766步共4303份原审计输入、整份原归档及原视频逐步帧数，全部通过，失败保持。全量结果仍为有效RoboDojo98/100、49/50对，原面板99/100、49/50对，RoboLab21/100、6/50对；full_reproduction_complete=false。并行队列切换与新版报告/包发布应分别核对实际运行、提交和在线字节证据，不能以部署准备当作回合完成。


2026-10-06有界并行基建发布验收：源码提交e00aa7430d22122c2a3efd789435bca368084927，实际网页提交1fdd2e2865a07c54ff9db34a2dcd3daeb625135f，Pages CI37392587664成功；14个公开文件精确字节核验完成，本地与线上桌面/390px手机检查均通过，原面板99、有效面板98及RoboLab21条回放/JSON分别一致、页面错误为零。新不可变基建包deliverables/infrastructure_bundle_20261006T081000Z.tar.gz含844文件、938483字节、SHA256=26fe9bd81285ff00db5e3b2e3a8513845e5306d6d233053f2b3596156f897cb8；公开下载后逐个成员复核通过，包含新ADR、v3清单、部署凭证及去私有环境的服务模板。此前832文件包与全部原回合保留。证据publication_checks/parallel_queue_20261006/checkpoint.json。切换服务仍在等当前原生回合/清理/归档边界，不能宣称已运行三个并行回合；完整实验验收保持pending_native_episodes/full_reproduction_complete=false。


## 2026-10-06 08:18 UTC：有效RoboDojo整组核验完成，RoboLab三路运行

有效RoboDojo100/100、50/50对全部动作审计；Direct13/50成功、Hybrid21/50成功，原生完整失败计入分母。另保留原面板99/100、49/50对及无效布局记录；新增layout5 Direct1578步成功、Hybrid531步失败均完整保留。

只读里程碑门对100条所选回合与保留原Direct layout4共101条原证据、153167项输入SHA、原始和导出视频完整解码、404份线上文件及精确提交9e054661422661bad45cc366533e09e82d075daf的CI37429128858成功完成核验。50对原布局记录和机器人proprio指纹匹配；不声称完整物理环境逐位相等。证书publication_checks/robodojo_completed_20261006/certificate.json仅证明此组，full_reproduction_complete=false。只读核验曾因CIFS读取等待中断，保留17条已核实证据并校验绑定后恢复；共享资格/最终验收脚本哈希不变，未调用模型或重置仿真。

RoboLab48/100、23/50对，归档积压零；v3已在旧回合/清理/归档边界完成切换，三个真实worker的所属进程、ready与独立GPU预约已核对。新增25条并行回合16637项原输入与串行边界回合2267项（合计26条/18904项），整份原归档和原视频逐步帧数均独立复核通过。线上桌面/390px手机验证无页面错误。当前继续剩余RoboLab52条；所选200回合及保留原回合的最终全量验收仍pending_native_episodes。


2026-10-06 08:22 UTC交付验收：提交a67cfc7187f1981b5b5d3c590b1fdb048addf0c1，Pages CI37435364490成功，14个公开文件精确字节一致。基建包deliverables/infrastructure_bundle_20261006T082000Z.tar.gz含851文件、983162字节，SHA256=0917f686b2a08c3d0fbfb546beff00ebe3e2b9a806966b886b911df315bc0fd6；公开下载逐成员核对通过，RoboDojo里程碑证书原件一致，旧包保留。新增Direct ReorientRedMug seed0完整成功760步，1993份原输入、整份原归档及原视频逐步帧数再核验通过；本轮新增原证据合计27条/20897项。最终联合验收已刷新为所选RoboDojo100/50对、RoboLab48/23对，pending_native_episodes/full_reproduction_complete=false；三个原生worker继续执行，全部维护timer活动。详细证据publication_checks/robodojo_completed_20261006/checkpoint.json。


## 2026-10-06 14:41 UTC：清理状态恢复与新增25回合整证据核验

RoboLab由48推进至73/100、35/50对。上次发布提交a67cfc7187f1981b5b5d3c590b1fdb048addf0c1以后新增25条原生完整回合，13613项原审计输入、全部原归档文件/manifest/receipt、每步原视频帧数、原始与导出视频完整解码及100份公开文件精确SHA通过；所有新增所选结果均是最早有效原生完整回合，完整失败保留。提交ed1aa1ed3f1e981352c0c12e51a3573df52d380c的CI37479633067成功；35对70份原initial_scene记录与审计及报告绑定，配对state_sha256相同，scope仍非完整checkpoint或历史初态等价。

Direct ReorientRedMug seed4原监督器因归档锁EAGAIN退出，另一只读归档进程后来封存成功；attempt.json未同步已验证标记导致固定v3 reconcile长期保留slot1。因果证据及红/绿回归见publication_checks/cleanup_recovery_20261006。新reconcile_robolab_cleanup.py仅在固定身份/lease一致、本机supervisor/controller/tunnel及进程组退出、fresh远端所属进程/组退出、完整审计与整份原封存归档1759文件/221677340字节验证后，更新派生归档字段，保存原attempt字节；不写lease、不改原生结果、不复制认证、不调用模型/仿真、不重放动作。归档错误与793步原成功均保持，原结果/审计/manifest/receipt SHA不变。恢复维护服务回写标记后，原队列14:34:26 UTC自行释放slot1并启动新CannedFood seed0 Direct；三路执行恢复。13项新增、2项原恢复、16项原并行/切换回归均通过，原冻结v3五份源码SHA不变。归档服务已实际重新运行，verified73/requires_repair0/pending0。

有效RoboDojo仍100/100、50对，原面板99/100、49对另留；RoboLab剩余27回合由现有队列继续。整体验收false，等待全部200条及保留原回合的最终全量验收。新包与页面发布须另核对提交、CI、HTTP字节与公开成员，不能以本地准备代替上线。


## 2026-10-06 14:59 UTC：后续回合转用第二块本地SSD

系统ext4盘可用空间从14:25的9.3GiB降至14:45约5.9GiB，全部73个已审计停止工作区已按原字节验证转存NAS。另一块本地ext4 SSD约867GiB可用；选项与边界见ROBOLAB_LOCAL_STORAGE_ADR.md。新v4仅将后续新回合local_workspace配置为固定私有目录/data/liyufeng/agentic_robot_runtime/gpt_policy_repro_20260914，不搬移活动SQLite，不修改原控制器/原prompt/模型/原生时域/GPU/端口/资格规则。原v3两入口、远端管理器、v2 Oracle与全部原结果保留且SHA不变；v4 JSON清单robolab_queue_scheduler_v4_manifest.json绑定完整新源码与原出处。

第二SSD实际SQLite WAL和双独立连接读写成功，零模型/仿真调用；7项存储根拒绝边界、7项原停止工作区维护与14项原并行预约/接管测试在v4上通过。原选取与清理的7个函数AST一致。只停止旧协调PID，三个原生监督器、控制器、SSH隧道及工作目录在切换前后boot/start身份保持，动作进度不回退；v4已enabled并接管同一flock和durable leases。首次启动被公开模板的EnvironmentFile占位路径阻挡，ExecStart未执行；复用既有部署环境后启动正常，未复制认证。v3服务disable，源码和单元保留，v4服务活动。

原三回合仍使用/tmp；下一原生回合才创建新SSD工作区，尚未观察到新盘实际模型回合，不能将预检等同于回合完成。归档维护已支持两个明确根，仍要求停止/完整审计/每文件SHA与NAS保留，拒绝任意外部路径。证据publication_checks/local_ssd_20261006。剩余RoboLab由队列继续，整体验收false。


2026-10-06 15:12 UTC最终本轮交付检查：提交f8f54b668155af9153f1ca5749093496feed18dc的Pages CI37484663997成功，14份网页/数据/包精确字节一致；公开包deliverables/infrastructure_bundle_20261006T150154Z.tar.gz含869文件、1016908字节，SHA256=7996f09c46ad8f0246c686efb2f82f6e060b85ce50b4a2ae8432050fd702b855；公开下载逐成员及新增原生核验证书、v4清单、接管证明字节一致。原860、851及更早包保留。线上桌面/390px手机筛选、深链接、真实Direct/Hybrid视频播放无错误；原99、有效100、RoboLab73/35对分开一致。64次相关边界/兼容/公开包检查执行通过，不代替完整实验。终验刷新为RoboDojo100/50对、RoboLab73/35对，pending_native_episodes/full_reproduction_complete=false。v4三worker实际控制计数497/399/140，身份均存活，当前仍为原/tmp目录；新盘实际模型回合尚待自然释放槽位后观察。原归档verified73/repair0/pending0；全部维护timer活动。证据publication_checks/local_ssd_20261006/checkpoint.json。
