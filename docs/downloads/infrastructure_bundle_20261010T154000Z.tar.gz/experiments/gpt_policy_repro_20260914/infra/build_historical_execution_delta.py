"""Update historical execution while retaining an exactly verified native baseline.

The native 200-run comparison comes from the prior CI/HTTP/member-verified Git
blob, not a newly asserted raw scan. All unchanged source documents and the
sealed preservation receipt are checked. The only changed data subtree is the
historical execution panel, whose copied gates and original-source bindings are
revalidated by the current report loader. A separate delta receipt records reuse.
"""
import argparse
import copy
import fcntl
import hashlib
import json
from pathlib import Path
import subprocess
import sys

from stage_historical_workers import ART
from run_historical_cohort import new_json, read, utc

ROOT=ART.parents[1];REPO=ROOT/'gpt-policy-report-site';Q=ART/'publication_checks/historical_resume_20261010'
BASE_COMMIT='cce63bcb0bec77efd2d586aa3193d8848f3e1a08'


def digest(data):return hashlib.sha256(data).hexdigest()


def validate_parent(data,delivery,statistics):
    if (delivery.get('verified') is not True or delivery.get('commit')!=BASE_COMMIT
            or digest(data)!=delivery['comparison_sha256'] or statistics['comparison_sha256']!=digest(data)
            or statistics.get('verified') is not True or statistics.get('complete_native_episodes')!=200
            or len(statistics['files_sha256'])!=900):
        raise ValueError('Prior delivered baseline or its 900-input binding differs')
    value=json.loads(data)
    if (value['independent_evaluation_complete'] is not True or value['historical_equivalence_verified'] is not False
            or value['native_completion_sha256']!=delivery['certificate_sha256']):
        raise ValueError('Prior native/historical completion boundary differs')
    return value


def unchanged_baseline(before,after):
    left=copy.deepcopy(before);right=copy.deepcopy(after)
    for value in (left,right):value['historical_worker_fidelity'].pop('original_version_execution')
    if left!=right:raise ValueError('A protected native or historical-source statistic changed')


def validate_reuse(data,delivery,statistics,baseline,baseline_statistics,commit):
    if (delivery.get('verified') is not True or delivery.get('commit')!=commit
            or delivery.get('comparison_sha256')!=digest(data)
            or statistics.get('verified') is not True or statistics.get('comparison_sha256')!=digest(data)
            or statistics.get('complete_native_episodes')!=200
            or statistics.get('files_sha256')!=baseline_statistics['files_sha256']
            or statistics.get('original_source_files')!=baseline_statistics['original_source_files']
            or delivery.get('certificate_sha256')!=baseline['native_completion_sha256']):
        raise ValueError('Current delivered snapshot does not preserve the verified native baseline')
    value=json.loads(data)
    unchanged_baseline(baseline,value)
    return value


def evidence_path(art,name):
    relative=Path(name)
    if relative.is_absolute() or '..' in relative.parts:
        raise ValueError('Evidence path must be relative and remain in publication_checks')
    path=art/relative
    if path.resolve()!=path.absolute() or not path.resolve().is_relative_to((art/'publication_checks').resolve()):
        raise ValueError('Evidence path leaves publication_checks or follows a symlink')
    return path


def prepare(out):
    """Create a new immutable delta; earlier delta and baseline receipts survive."""
    out=evidence_path(ART,str(out.absolute().relative_to(ART)))
    if out.exists():raise ValueError('Choose a fresh snapshot directory; prior deltas are immutable')
    sys.path.insert(0,str(REPO/'tools'))
    from blog_comparison import load_historical_execution,validate_worker_fidelity,render,verify_public
    from render_gpt_progress import render as render_progress
    old=subprocess.check_output(['git','-C',str(REPO),'show',BASE_COMMIT+':docs/data/blog-comparison.json'])
    delivery=read(ART/'publication_checks/historical_cohort_20261010/public_bundle_verified.json')
    stats_path=ART/'publication_checks/blog_alignment_20261008/statistics_audit.json'
    current_stats=stats_path.read_bytes();statistics=json.loads(current_stats)
    baseline_path=Q/'prior_statistics_audit.json'
    prior_stats=baseline_path.read_bytes() if baseline_path.exists() else current_stats
    baseline_statistics=json.loads(prior_stats)
    before=validate_parent(old,delivery,baseline_statistics)
    commit=subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip()
    current=subprocess.check_output(['git','-C',str(REPO),'show',commit+':docs/data/blog-comparison.json'])
    if (REPO/'docs/data/blog-comparison.json').read_bytes()!=current:
        raise ValueError('Existing comparison is not the current delivered Git blob')
    previous_delivery_path=Q/'public_bundle_verified.json'
    previous_delivery_bytes=previous_delivery_path.read_bytes()
    validate_reuse(current,json.loads(previous_delivery_bytes),statistics,before,baseline_statistics,commit)
    preserved=read(Q/'preserved_native_evidence.json')
    assert preserved['verified'] is True and preserved['native_original_audit_proofs_unchanged']==201
    assert preserved['native_public_assets_unchanged']==804
    assert digest((ART/'full_reproduction_verification.json').read_bytes())==before['native_completion_sha256']==preserved['certificate_sha256']
    original=ART/'publication_checks/blog_alignment_20261008'
    for name,expected in baseline_statistics['original_source_files'].items():assert digest((original/name).read_bytes())==expected
    worker=ART/'publication_checks/worker_fidelity_20261008'
    for name,expected in before['historical_worker_fidelity']['evidence_sha256'].items():assert digest((worker/name).read_bytes())==expected
    recount=ART/'publication_checks/historical_protocol_20261008/original_record_recount.json'
    assert digest(recount.read_bytes())==before['original_record_recovery']['original_record_recount_sha256']
    after=copy.deepcopy(before)
    after['historical_worker_fidelity']['original_version_execution']=load_historical_execution(ART)
    validate_worker_fidelity(after['historical_worker_fidelity']);unchanged_baseline(before,after)
    unchanged_baseline(json.loads(current),after)
    data=(json.dumps(after,ensure_ascii=False,indent=2)+'\n').encode()
    out.mkdir(parents=True,exist_ok=False)
    # Keep the original verified baseline bytes, including their exact digest.
    if not baseline_path.exists():
        baseline_path.write_bytes(prior_stats)
    for name,payload in [('previous_public_delivery.json',previous_delivery_bytes),('previous_statistics_audit.json',current_stats)]:
        with (out/name).open('xb') as stream:stream.write(payload)
        (out/name).chmod(0o444)
    receipt=dict(schema='gpt_policy_historical_execution_delta.v1',verified=True,verified_utc=utc(),
        parent_published_commit=BASE_COMMIT,parent_comparison_sha256=digest(old),comparison_sha256=digest(data),
        parent_statistics_audit_sha256=digest(prior_stats),protected_comparison_subtrees_unchanged=True,
        previous_published_commit=commit,previous_comparison_sha256=digest(current),
        previous_public_delivery_sha256=digest(previous_delivery_bytes),previous_statistics_audit_sha256=digest(current_stats),
        prior_native_statistics_inputs_reused=900,prior_native_episodes_preserved=200,
        new_execution_gate_inputs_verified=True,model_calls=0,simulator_steps=0,
        scope='The immutable baseline and current CI/HTTP/member-verified delivery bind unchanged native statistics. '
              'Only original_version_execution replaced with current SHA-bound copied episode gates. '
              'No repeat raw scan of the unchanged worker observations claimed.',
        historical_protocol_equivalence=False,full_blog_reproduction_complete=False)
    gate=out/'execution_delta_gate.json';new_json(gate,receipt)
    statistics.update(comparison_sha256=digest(data),parent_statistics_audit_sha256=digest(prior_stats),
        parent_published_comparison_commit=BASE_COMMIT,unchanged_native_statistics_reused=True,
        parent_statistics_audit_path=str(baseline_path.relative_to(ART)),
        execution_delta_gate_path=str(gate.relative_to(ART)),execution_delta_gate_sha256=digest(gate.read_bytes()))
    temporary=stats_path.with_suffix('.tmp');temporary.write_text(json.dumps(statistics,indent=2)+'\n');temporary.replace(stats_path)
    (REPO/'docs/data/blog-comparison.json').write_bytes(data)
    (REPO/'docs/blog-comparison.html').write_text(render(after))
    render_progress(REPO/'docs');render_progress(REPO/'docs',valid=True,update_board=False)
    verify_public(REPO/'docs')
    print(json.dumps({k:receipt[k] for k in ('verified','protected_comparison_subtrees_unchanged','prior_native_statistics_inputs_reused','comparison_sha256')}),flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True,help='Fresh immutable delta directory within publication_checks')
    args=parser.parse_args()
    with Path('/tmp/gpt-policy-report-publish.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX);prepare(args.output)


if __name__=='__main__':main()
