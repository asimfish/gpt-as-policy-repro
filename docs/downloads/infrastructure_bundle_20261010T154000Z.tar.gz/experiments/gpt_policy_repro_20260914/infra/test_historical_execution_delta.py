"""An execution-only update cannot change already delivered benchmark statistics."""
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from build_historical_execution_delta import validate_parent,validate_reuse,evidence_path,unchanged_baseline,BASE_COMMIT


class HistoricalExecutionDeltaTests(unittest.TestCase):
    def fixture(self):
        value=dict(independent_evaluation_complete=True,historical_equivalence_verified=False,native_completion_sha256='certificate',
                   robodojo={'successes':13},historical_worker_fidelity={'core':{'value':1},'original_version_execution':{'old':True}})
        data=json.dumps(value).encode();sha=hashlib.sha256(data).hexdigest()
        delivery=dict(verified=True,commit=BASE_COMMIT,comparison_sha256=sha,certificate_sha256='certificate')
        stats=dict(verified=True,complete_native_episodes=200,comparison_sha256=sha,files_sha256={str(i):'hash' for i in range(900)})
        return value,data,delivery,stats

    def test_verified_parent_and_execution_only_change_are_accepted(self):
        value,data,delivery,stats=self.fixture();self.assertEqual(validate_parent(data,delivery,stats),value)
        changed=copy.deepcopy(value);changed['historical_worker_fidelity']['original_version_execution']={'new':True}
        unchanged_baseline(value,changed)

    def test_wrong_parent_or_tampered_blob_is_rejected(self):
        _,data,delivery,stats=self.fixture()
        with self.assertRaises(ValueError):validate_parent(data+b' ',delivery,stats)
        delivery['commit']='another'
        with self.assertRaises(ValueError):validate_parent(data,delivery,stats)

    def test_native_or_worker_statistics_cannot_change(self):
        value,_,_,_=self.fixture()
        for changed in (copy.deepcopy(value),copy.deepcopy(value)):
            if changed==value:changed['robodojo']['successes']=14
            with self.assertRaises(ValueError):unchanged_baseline(value,changed)
        changed=copy.deepcopy(value);changed['historical_worker_fidelity']['core']['value']=2
        with self.assertRaises(ValueError):unchanged_baseline(value,changed)

    def reuse_fixture(self):
        value,_,_,baseline=self.fixture()
        current=copy.deepcopy(value)
        current['historical_worker_fidelity']['original_version_execution']={'second_snapshot':True}
        data=json.dumps(current).encode();stats=copy.deepcopy(baseline)
        stats['comparison_sha256']=hashlib.sha256(data).hexdigest()
        baseline['original_source_files']=stats['original_source_files']={'source.json':'fixed'}
        delivery={'verified':True,'commit':'delivered','comparison_sha256':stats['comparison_sha256'],'certificate_sha256':'certificate'}
        return value,baseline,data,stats,delivery

    def test_later_delivered_snapshot_reuses_the_same_native_baseline(self):
        value,baseline,data,stats,delivery=self.reuse_fixture()
        self.assertEqual(validate_reuse(data,delivery,stats,value,baseline,'delivered'),json.loads(data))

    def test_a_changed_input_or_source_hash_cannot_be_reused(self):
        value,baseline,data,stats,delivery=self.reuse_fixture()
        for field in ('files_sha256','original_source_files'):
            changed=copy.deepcopy(stats);changed[field][next(iter(changed[field]))]='tampered'
            with self.assertRaises(ValueError):validate_reuse(data,delivery,changed,value,baseline,'delivered')

    def test_stale_delivery_and_wrong_comparison_bytes_are_rejected(self):
        value,baseline,data,stats,delivery=self.reuse_fixture()
        with self.assertRaises(ValueError):validate_reuse(data,delivery,stats,value,baseline,'newer')
        with self.assertRaises(ValueError):validate_reuse(data+b' ',delivery,stats,value,baseline,'delivered')

    def test_protected_statistics_cannot_change_between_updates(self):
        value,baseline,data,stats,delivery=self.reuse_fixture()
        changed=json.loads(data);changed['robodojo']['successes']=14;data=json.dumps(changed).encode()
        delivery['comparison_sha256']=stats['comparison_sha256']=hashlib.sha256(data).hexdigest()
        with self.assertRaises(ValueError):validate_reuse(data,delivery,stats,value,baseline,'delivered')

    def test_versioned_evidence_paths_are_bounded_to_publication_checks(self):
        with tempfile.TemporaryDirectory() as directory:
            art=Path(directory)
            self.assertEqual(evidence_path(art,'publication_checks/update/delta.json'),art/'publication_checks/update/delta.json')
            for path in ('../escape.json','infra/file.json','/tmp/escape.json','publication_checks/../escape.json'):
                with self.assertRaises(ValueError):evidence_path(art,path)


if __name__=='__main__':unittest.main()
