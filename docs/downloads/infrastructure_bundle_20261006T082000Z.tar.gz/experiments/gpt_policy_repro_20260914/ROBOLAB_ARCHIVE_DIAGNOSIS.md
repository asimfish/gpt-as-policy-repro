# RoboLab 完整回合归档超时修复（2026-10-02）

状态：FIXED。影响成功回合归档与计分门控，不是物理控制、模型或动作审计算法故障。

`direct_20261002T111156Z_BlocksInBinTask_seed0` 于13:25 UTC原生成功结束：986控制步、198次决策、π0.5调用0。旧归档在300秒后超时，本机仅有902个原生动作块，缺初态、198个决策回执及终止摘要。验证门在 `audit_robolab_gpt_actions.py` 的单一初态目录断言处拒绝计分；该拒绝正确。

远端自己的仿真服务已经 stopped；同一 episode 仍保存986个动作块、198个决策回执、初态和完整原生终止摘要。通过只读 rsync 断点补传270397002字节、2184个文件，不连接RPC、不reset、不调用模型、不重放物理动作。所有文件与远端SHA256逐一一致；证据为该attempt下 `remote_archive_manifest.json`、`remote_archive_receipt.json`。旧超时记录保留在attempt.json，恢复另行记录。

在同一归档重跑原完整审计后通过：198个已接受模型请求均绑定同一真实GPT-6 Astra/xhigh线程、工具事件与原生决策回执，986个EEF动作及前后观测逐段一致，原生 terminated=true、truncated=false、success=true。完整证明 `complete_action_audit.json`。没有放宽原审计条件，也没有重跑物理实验。

修复：`archive_robolab_attempt.py` 固定核对自己的attempt路径，仅允许已退出启动/运行状态的远端服务归档；使用该attempt固定的AES-GCM SSH传输、1200秒每次传输预算、最多三次只读补传、逐文件尺寸与SHA256验证。拒绝路径越界和符号链接。新控制器记录归档验证结果并保存归档代码快照。归档故障不产生成功率样本，也不会触发物理动作重试。

验证门可在同一完整回合上补传归档；重启时保留最早原生完整Hybrid（包括失败），不新跑一个成功结果替换它。三次中断后要求检查，不能无限发起新物理实验。

回归证据：原始审计命令 RED（初态缺失）→补传同一归档后GREEN（986动作/198决策/完整原生成功）；归档回归覆盖缺文件、同尺寸篡改、路径越界与符号链接；门控回归覆盖保留首个完整失败和中断上限。相关后端28项测试、19子测试通过。完整动作审计不独立重算IK/物理，历史Direct实现和原始初态仍未公开；不宣称历史实验完全等价。

## 2026-10-05：归档超时子进程与恢复进度（2026-10-04T18:02:36.994638+00:00）

Direct BlocksInBinTask seed2的旧传输返回成功后，完整尺寸门拒绝chunk_00836.npz：
本机81912字节，原远端259884字节；远端SHA256为72c00bd9477bff716b92539380c20e8f9870fb6b7f9bec358aa1cc1f964c3548。
旧父rsync超时后，sender/receiver仍在日志里退出，下一尝试已经开始。隔离的本机进程/FIFO复现
确认subprocess.run(timeout)只结束父进程，子进程还可以写入“late partial”。这与旧完整文件被残余receiver覆盖的故障机制一致，
不是原生动作或成绩错误。复现和远端尺寸证据见publication_checks/remediation_20261005。

run_rsync现在为每次只读传输建立独立进程组，无论超时、失败还是正常退出都清理自己的组；
确认所有非僵尸成员退出后才允许重试。清理不能完成时抛出RuntimeError停止该组重试，不能放任旧写入者并行覆盖。
传输前原远端manifest已原子保存；后续若静止源清单变化则拒绝覆盖原封存清单。
remote_archive_transfer.json保存获取清单、传输、分组重试、验证与失败阶段；成功传输字节仅是归档进度，
只有全文件尺寸/SHA256一致后才生成verified receipt，完整成绩仍要求原动作审计。
每attempt使用独立本机/tmp锁，第二个恢复调用不能覆盖活动传输的状态。
恢复总表保持原v1 results字段，额外保存全部最早原生完整回合计划、active阶段与verified/requires_repair/pending计数。

同一seed2原回合的2217文件/276371285字节现已补齐核验；原完整动作审计通过：1001步、201决策、π调用0，
保留原生成功。本机RoboLab增至6/100、3/50配对，仍有7个最早完整原回合待审计归档。
当前真实归档正在运行的旧恢复进程保留，新的进度逻辑由后续恢复轮次加载。
53项RoboLab回归通过；12项归档/恢复重点检查覆盖真实rsync、进程/FIFO清理、并发锁、同清单中断续传和保留最早完整失败。

接管已于2026-10-04T17:40:18.002267+00:00在原控制器/归档锁边界完成，v2 service enabled且正在运行。
旧验证service disabled，已完成的一次性接管unit禁用自启动。上一条BlockStackingSpecifiedOrderTask seed2 Direct
已原生成功502步/101决策，仍待原归档与完整审计，不计入当前6项。
新Hybrid BlocksInBinTask seed3已ready并真实执行，policy GPU4与sim GPU6相互独立；
实际simulator_argv含完整资产目录，管理器源SHA与本机bbf6a636...完全一致。
