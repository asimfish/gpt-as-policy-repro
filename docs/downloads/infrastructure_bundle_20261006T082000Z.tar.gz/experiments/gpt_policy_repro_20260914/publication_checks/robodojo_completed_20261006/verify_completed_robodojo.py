"""Read-only milestone gate. This never certifies the unfinished joint evaluation."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import fcntl
import argparse
import hashlib
import importlib
import json
import os
from pathlib import Path
import subprocess
import sys

ART = Path(__file__).resolve().parents[2]
ROOT = ART.parents[1]
REPO = ROOT/'gpt-policy-report-site'
OUT = Path(__file__).resolve().parent
sys.path[:0] = [str(ART/'infra'), str(REPO/'tools')]
import verify_reproduction_completion as gate
from robolab_parallel_state import atomic_json


def committed(commit, name):
    return json.loads(subprocess.check_output(['git','-C',str(REPO),'show',commit+':docs/'+name],timeout=60))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--resume',action='store_true')
    args=parser.parse_args()
    OUT.mkdir(parents=True,exist_ok=True)
    with (OUT/'verification.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        expected,_=gate.frozen_inputs(ART)
        publication=gate.read(ART/'online_publication.json')
        saved=gate.read(OUT/'state.json') if args.resume else None
        commit=saved['published_commit'] if saved else publication['commit']
        gate.require(publication['status']=='published_and_http_verified','Verified publication required')
        name='data/gpt-methods-valid-progress.json'
        document=committed(commit,name)
        raw=subprocess.check_output(['git','-C',str(REPO),'show',commit+':docs/'+name],timeout=60)
        if saved:
            gate.require(gate.read(OUT/'selected_snapshot.json')==document,'Resume snapshot differs from original committed cohort')
            latest=committed(publication['commit'],name)
            gate.require(all(latest[k]==document[k] for k in ('cases','episodes','summary','cohort')),'Completed cohort changed during resume')
        else:
            row=next(r for r in publication['files'] if r['file']==name)
            gate.require(row['matches'] is True and row['http_status']==200 and
                row['local_sha256']==row['online_sha256']==hashlib.sha256(raw).hexdigest(),'Publication does not bind committed cohort')
            gate.require(publication['gpt_valid_summary']==document['summary'],'Published summary differs')
        coverage=gate.matrix(document,expected['robodojo'])
        gate.require(coverage['complete_method_runs']==100 and coverage['completed_pairs']==50,'Incomplete selected cohort')
        original=committed(commit,'data/gpt-methods-progress.json')
        shared={(e['case_id'],e['method']):e for e in document['episodes']}
        retained=[]
        for e in original['episodes']:
            key=e['case_id'],e['method']
            if key in shared:
                gate.require(shared[key]==e,'Original shared outcome changed')
            else:
                gate.require(e['case_id']=='imitate_sorting_sequence__standard__g0__l4','Unexpected dropped original outcome')
                retained.append(e)
        gate.require(len(original['episodes'])==99 and len(retained)==1,'Original panel no longer preserved')
        first=gate.first_native_runs(ART/'gpt_pair_campaign',True)
        tools={'dojo':importlib.import_module('build_gpt_site')}
        ci=gate.verify_ci(commit)
        state=dict(schema='robodojo_valid50_milestone_gate.v1',status='verifying',
            full_reproduction_complete=False,cohort_verified=False,published_commit=commit,
            started_utc=datetime.now(timezone.utc).isoformat(),coverage=coverage,
            summary=document['summary'],original_panel_preserved=True,exact_commit_ci=ci,
            verified_selected_episodes=0,verified_retained_original_episodes=0,
            original_proofs=[],public_files=[])
        completed=set()
        if saved:
            gate.require(saved['schema']==state['schema'] and saved['coverage']==coverage and not saved['cohort_verified'],'Invalid resume state')
            selected={(e['case_id'],e['method']):e for e in [*document['episodes'],*retained]}
            for proof in saved['original_proofs']:
                key=proof['case_id'],proof['method'];e=selected[key]
                gate.require(key not in completed and proof['run_id']==e['run_id'] and proof['success']==e['success'] and proof['control_steps']==e['control_steps'],'Resume proof identity changed')
                run=ART/'gpt_pair_campaign'/e['run_id']/e['method']
                gate.require(gate.digest(run/'complete_action_audit.json')==proof['audit_sha256'] and proof['original_video_sha256']==e['source_video_sha256'],'Sealed original proof changed')
                completed.add(key)
            gate.require(len(saved['public_files'])==4*len(completed),'Incomplete resumed public evidence')
            for row in saved['public_files']:
                gate.require(gate.digest(gate.relative(REPO/'docs',row['path']))==row['sha256'],'Previously verified public artifact changed')
            state.update(original_proofs=saved['original_proofs'],public_files=saved['public_files'],
                verified_selected_episodes=saved['verified_selected_episodes'],
                verified_retained_original_episodes=saved['verified_retained_original_episodes'],
                resumed_verified_episodes=len(completed),previous_started_utc=saved['started_utc'])
        atomic_json(OUT/'state.json',state)
        atomic_json(OUT/'selected_snapshot.json',document)
        def one(e, retained_original=False):
            phase_path=Path('/tmp')/('gpt-policy-robodojo-milestone-'+str(os.getpid())+'-'+e['id']+'.json')
            def phase(value):
                atomic_json(phase_path,dict(case_id=e['case_id'],method=e['method'],phase=value,
                    observed_utc=datetime.now(timezone.utc).isoformat()))
            print(json.dumps(dict(case_start=e['case_id'],method=e['method'])),flush=True)
            run=ART/'gpt_pair_campaign'/e['run_id']/e['method']
            gate.require(first[(e['case_id'],e['method'])]==run,'Later attempt replaced first native outcome')
            identity=e['identity'] if retained_original else expected['robodojo'][e['case_id']]
            phase('checking_original_audit_inputs')
            proof=gate.verify_original(run,e,identity,True,tools)
            gate.require(gate.read(REPO/'docs'/e['evidence'])==e,'Public episode evidence changed')
            for field,hash_field in [('audit','audit_sha256'),('video','video_sha256')]:
                gate.require(gate.digest(REPO/'docs'/e[field])==e[hash_field],'Public media or audit changed')
            # Decode both the original sensor movie and the exported complete movie.
            for movie in [run/'sim/sensors.mp4',REPO/'docs'/e['video']]:
                phase('decoding_original_movie' if movie==run/'sim/sensors.mp4' else 'decoding_exported_movie')
                subprocess.run(['ffmpeg','-nostdin','-v','error','-xerror','-threads','2',
                    '-i',str(movie),'-f','null','-'],check=True,timeout=300,
                    stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            files=[]
            for field in ('evidence','audit','video','poster'):
                phase('verifying_public_'+field)
                files.append(gate.verify_http(REPO/'docs',e[field],commit))
            phase('verified')
            return dict(case_id=e['case_id'],method=e['method'],success=e['success'],
                control_steps=e['control_steps'],retained_original=retained_original,**proof),files
        pool=ThreadPoolExecutor(max_workers=2)
        futures=[]
        try:
            futures=[pool.submit(one,e,False) for e in document['episodes'] if (e['case_id'],e['method']) not in completed]
            futures += [pool.submit(one,e,True) for e in retained if (e['case_id'],e['method']) not in completed]
            for future in as_completed(futures):
                proof,files=future.result()
                state['original_proofs'].append(proof);state['public_files'].extend(files)
                name='verified_retained_original_episodes' if proof['retained_original'] else 'verified_selected_episodes'
                state[name]+=1
                state['updated_utc']=datetime.now(timezone.utc).isoformat()
                atomic_json(OUT/'state.json',state)
                if state['verified_selected_episodes']%10==0:
                    print(json.dumps(dict(verified_selected=state['verified_selected_episodes'],retained=state['verified_retained_original_episodes'])),flush=True)
            state.update(status='cohort_verified_full_reproduction_pending',cohort_verified=True,
                full_reproduction_complete=False,audit_inputs=sum(p['audit_inputs'] for p in state['original_proofs']),
                original_and_exported_videos_fully_decoded=True,finished_utc=datetime.now(timezone.utc).isoformat())
            atomic_json(OUT/'state.json',state)
            atomic_json(OUT/'certificate.json',state)
            print(json.dumps(dict(status=state['status'],selected=100,retained=1,
                audit_inputs=state['audit_inputs'],http_files=len(state['public_files']),commit=commit)),flush=True)
        except BaseException as error:
            state.update(status='verification_failed',cohort_verified=False,error_type=type(error).__name__)
            atomic_json(OUT/'state.json',state)
            print(json.dumps(dict(status='verification_failed',error_type=type(error).__name__,error=str(error))),flush=True)
            for future in futures:future.cancel()
            raise
        finally:
            pool.shutdown(wait=True,cancel_futures=True)


if __name__=='__main__':
    os.environ.update(HTTPS_PROXY='http://127.0.0.1:7897',https_proxy='http://127.0.0.1:7897')
    main()
