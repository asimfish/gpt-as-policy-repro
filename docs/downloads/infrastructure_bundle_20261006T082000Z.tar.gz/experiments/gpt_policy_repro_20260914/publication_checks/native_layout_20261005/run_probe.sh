#!/usr/bin/env bash
set -euo pipefail
source /mnt/nas/data/lyf/agentic_robot/experiments/gpt_policy_repro_20260914/infra/env.sh
probe_root=/mnt/nas/data/lyf/agentic_robot/experiments/gpt_policy_repro_20260914/publication_checks/native_layout_20261005
probe_seed="${1:?seed}"
probe_port="${2:?port}"
probe_output="$probe_root/hold_seed${probe_seed}"
probe_case="${3:-$REPRO_ROOT/experiments/gpt_policy_repro_20260914/fixtures/cases/mix__imitate_sorting_sequence__standard__g0__l${probe_seed}.json}"
mkdir "$probe_output"
export CUDA_VISIBLE_DEVICES=0 SIM_GPU=0
probe_free=$(nvidia-smi -i 0 --query-gpu=memory.free --format=csv,noheader,nounits)
test "$probe_free" -ge 15000
cd "$ROBO_ROOT"
"$ROBO_PYTHON" "$probe_root/probe_server.py" --task imitate_sorting_sequence \
  --output "$probe_output/sim" --port "$probe_port" --eval-seed 0 \
  --eval-manifest "$REPRO_ROOT/experiments/gpt_policy_repro_20260914/fixtures/evaluation_manifest.json" \
  --case-file "$probe_case" \
  --kit_args="--/renderer/multiGpu/enabled=false --/renderer/multiGpu/autoEnable=false --/renderer/activeGpu=0" \
  >"$probe_output/server.log" 2>&1 &
probe_pid=$!
trap 'kill -TERM "$probe_pid" 2>/dev/null || true; wait "$probe_pid" 2>/dev/null || true' EXIT
probe_deadline=$((SECONDS+1200))
until /usr/bin/grep -q '"event": "ready"' "$probe_output/server.log"; do
  kill -0 "$probe_pid"
  test "$SECONDS" -lt "$probe_deadline"
  sleep 2
done
"$ROBO_PYTHON" "$probe_root/probe_client.py" "$probe_output" "$probe_port" "$probe_seed"
# Completed physical data is already sealed. Bound Isaac's shutdown separately.
probe_close_deadline=$((SECONDS+45))
while kill -0 "$probe_pid" 2>/dev/null; do
  if test "$SECONDS" -ge "$probe_close_deadline"; then
    kill -TERM "$probe_pid" 2>/dev/null || true
    sleep 5
    kill -KILL "$probe_pid" 2>/dev/null || true
    wait "$probe_pid" 2>/dev/null || true
    exit 0
  fi
  sleep 1
done
wait "$probe_pid"
