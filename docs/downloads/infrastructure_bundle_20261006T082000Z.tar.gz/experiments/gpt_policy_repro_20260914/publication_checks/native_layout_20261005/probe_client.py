"""Native-horizon hold probe; no model, policy, benchmark outcome, or action replay."""
import json
from pathlib import Path
import sys
import time
import numpy as np
from hybrid_rollout.robodojo.robodojo_server.protocol import RPCClient

output, port, seed = Path(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
client = RPCClient('127.0.0.1', port, timeout=300)
try:
    reset = client.request('reset', seed=seed, source='diagnostic_hold',
                           policy_version='diagnostic_no_model_no_policy')
    episode, step = reset['episode_id'], 0
    obs = client.request('teacher_observation', episode_id=episode, step_id=step)
    action = obs['states'].copy()
    horizon = reset['metadata']['max_episode_steps']
    started = time.monotonic()
    while step < horizon:
        result = client.request('chunk_step', episode_id=episode, step_id=step,
                                actions=np.repeat(action[None, :], min(15, horizon-step), axis=0))
        step = result['step_id']
        terminal = result['steps'][-1]
        state = dict(benchmark_eligible=False, model_calls=0, policy_calls=0,
                     case_id=f'imitate_sorting_sequence__standard__g0__l{seed}',
                     native_control_step=step, native_horizon=horizon,
                     wall_seconds=time.monotonic()-started,
                     terminated=terminal['terminated'], truncated=terminal['truncated'])
        (output/'diagnostic_progress.json').write_text(json.dumps(state, indent=2)+'\n')
        print(json.dumps(state), flush=True)
        if terminal['terminated'] or terminal['truncated']:
            break
finally:
    client.close()
