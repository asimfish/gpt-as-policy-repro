"""Diagnostic-only observer of native support validation; never a benchmark run."""
from hybrid_rollout.robodojo.robodojo_server.session import RoboDojoSession
from hybrid_rollout.robodojo.io import write_json

original_reset = RoboDojoSession.reset


def observed_reset(self, *args, **kwargs):
    result = original_reset(self, *args, **kwargs)
    env = self.env
    original_check = env.check_support_arm_stable

    def observed_check(env_idx):
        before = env.support_checked[env_idx]
        result = original_check(env_idx=env_idx)
        if not before and env.support_checked[env_idx]:
            manager = env.reward_manager
            checks = {f'aim{i}': float(manager.call_func_parser(
                manager.is_A_in_B(label_A=f'aim{i}', label_B='basket1'), env_idx))
                for i in range(5)}
            write_json(self.output/'support_validation.json', dict(
                benchmark_eligible=False, model_calls=0,
                native_control_step=env.take_action_cnt[env_idx],
                support_actions_remaining=len(env.support_arm_action[env_idx]),
                support_queries=env.query_support_times[env_idx],
                aim_in_basket1=checks, unstable=env_idx in env.unstable_envs,
                scope='Read-only predicates after the unchanged original native validation'))
        return result

    env.check_support_arm_stable = observed_check
    return result


RoboDojoSession.reset = observed_reset
from hybrid_rollout.robodojo.robodojo_server.server import main
main()
