"""Partial copies and same-size corruption must never become verified archives."""
import hashlib
import json
import os
from pathlib import Path
import signal
import tempfile
import subprocess
import sys
import threading
import unittest
from unittest.mock import patch
import archive_robolab_attempt as archive
from archive_robolab_attempt import verify_archive, REMOTE_MANIFEST


class ArchiveIntegrity(unittest.TestCase):
    def manifest(self, name='episode/initial_scene.json', data=b'known bytes'):
        return dict(schema='gpt_policy_robolab_remote_archive.v1',
                    cleanup=dict(source='recorded_cleanup',finished_utc='sealed'),
                    files={name:dict(size=len(data), sha256=hashlib.sha256(data).hexdigest())})

    def attempt(self, root):
        path=root/'direct_test';path.mkdir()
        (path/'attempt.json').write_text(json.dumps(dict(attempt=path.name,
            remote_output=archive.REMOTE_CAMPAIGN+'/'+path.name,ssh_cipher='aes128-gcm@openssh.com')))
        return path

    def test_interrupted_transfer_preserves_seal_and_failed_progress_without_receipt(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=self.attempt(Path(tmp));manifest=self.manifest()
            partial=path/'remote/episode/initial_scene.json';partial.parent.mkdir(parents=True);partial.write_bytes(b'part')
            remote=subprocess.CompletedProcess([],0,stdout=json.dumps(manifest))
            with patch.object(archive.subprocess,'run',return_value=remote), \
                 patch.object(archive,'transfer_archive',side_effect=subprocess.TimeoutExpired('rsync',1200)):
                with self.assertRaises(subprocess.TimeoutExpired):archive.archive_attempt(path)
            self.assertEqual(json.loads((path/'remote_archive_manifest.json').read_text()),manifest)
            state=json.loads((path/'remote_archive_transfer.json').read_text())
            self.assertEqual(state['phase'],'failed')
            self.assertEqual(state['error_type'],'TimeoutExpired')
            self.assertFalse(state['verified'])
            self.assertFalse((path/'remote_archive_receipt.json').exists())
            self.assertEqual(partial.read_bytes(),b'part')
            seal=(path/'remote_archive_manifest.json').read_bytes()
            source=Path(tmp)/'source';file=source/'episode/initial_scene.json';file.parent.mkdir(parents=True);file.write_bytes(b'known bytes')
            real_run=subprocess.run;real_transfer=archive.transfer_archive
            def run(command,**kwargs):
                return real_run(command,**kwargs) if command[0]=='rsync' else remote
            def copy(source_ignored,target,manifest,ssh,progress=None):
                return real_transfer(str(source)+'/',target,manifest,ssh,progress)
            with patch.object(archive.subprocess,'run',side_effect=run),patch.object(archive,'transfer_archive',side_effect=copy):
                receipt=archive.archive_attempt(path)
            self.assertEqual((path/'remote_archive_manifest.json').read_bytes(),seal)
            self.assertEqual(partial.read_bytes(),b'known bytes')
            self.assertTrue(receipt['verified']);self.assertEqual(receipt['files'],1)
            state=json.loads((path/'remote_archive_transfer.json').read_text())
            self.assertEqual(state['phase'],'verified');self.assertTrue(state['verified'])
            self.assertEqual(state['transferred_files'],1)
            self.assertNotIn('error_type',state)

    def test_changed_stopped_manifest_is_rejected_before_copy(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=self.attempt(Path(tmp));old=self.manifest();changed=self.manifest(data=b'other bytes')
            seal=path/'remote_archive_manifest.json';seal.write_text(json.dumps(old))
            original=seal.read_bytes()
            remote=subprocess.CompletedProcess([],0,stdout=json.dumps(changed))
            with patch.object(archive.subprocess,'run',return_value=remote),patch.object(archive,'transfer_archive') as transfer:
                with self.assertRaisesRegex(ValueError,'manifest changed'):archive.archive_attempt(path)
            self.assertEqual(seal.read_bytes(),original)
            transfer.assert_not_called()
            self.assertFalse((path/'remote_archive_receipt.json').exists())

    def test_concurrent_caller_cannot_replace_active_transfer_state(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=self.attempt(Path(tmp));manifest=self.manifest();entered=threading.Event();release=threading.Event();errors=[]
            remote=subprocess.CompletedProcess([],0,stdout=json.dumps(manifest))
            def transfer(source,target,manifest,ssh,progress=None):
                entered.set()
                if not release.wait(5):raise TimeoutError('Test transfer was not released')
                file=target/'episode/initial_scene.json';file.parent.mkdir(parents=True,exist_ok=True);file.write_bytes(b'known bytes')
                return 1
            def run():
                try:archive.archive_attempt(path)
                except BaseException as error:errors.append(error)
            with patch.object(archive.subprocess,'run',return_value=remote),patch.object(archive,'transfer_archive',side_effect=transfer):
                thread=threading.Thread(target=run);thread.start()
                try:
                    self.assertTrue(entered.wait(5),'First transfer never started')
                    before=(path/'remote_archive_transfer.json').read_bytes()
                    with self.assertRaises(BlockingIOError):archive.archive_attempt(path)
                    self.assertEqual((path/'remote_archive_transfer.json').read_bytes(),before)
                finally:
                    release.set();thread.join(5)
                self.assertFalse(thread.is_alive());self.assertEqual(errors,[])
            self.assertTrue(json.loads((path/'remote_archive_receipt.json').read_text())['verified'])

    def test_timeout_failure_and_success_leave_no_receiver_that_can_write_late(self):
        for mode in ['timeout','1','0']:
            with self.subTest(mode=mode),tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp);fifo=root/'release';os.mkfifo(fifo);info=root/'child.json';late=root/'late_write'
                child="import json,os,sys;from pathlib import Path;fd=os.open(sys.argv[1],os.O_RDWR);p=Path(sys.argv[2]);t=p.with_suffix('.tmp');t.write_text(json.dumps(dict(pid=os.getpid(),pgrp=os.getpgrp())));t.replace(p);os.read(fd,1);Path(sys.argv[3]).write_bytes(b'late partial')"
                parent="import subprocess,sys,time;from pathlib import Path;p=subprocess.Popen([sys.executable,'-c',sys.argv[1],*sys.argv[2:5]]);\nwhile not Path(sys.argv[3]).exists():time.sleep(.01)\nif sys.argv[5]=='timeout':p.wait()\nelse:sys.exit(int(sys.argv[5]))"
                command=[sys.executable,'-c',parent,child,str(fifo),str(info),str(late),mode]
                try:
                    if mode=='timeout':
                        with self.assertRaises(subprocess.TimeoutExpired):archive.run_rsync(command,timeout=1)
                    elif mode=='1':
                        with self.assertRaises(subprocess.CalledProcessError):archive.run_rsync(command,timeout=5)
                    else:archive.run_rsync(command,timeout=5)
                    self.assertTrue(info.exists(),'Owned child did not reach the synchronized wait')
                    ids=json.loads(info.read_text())
                    self.assertEqual(archive.live_process_group(ids['pgrp']),[])
                    self.assertFalse(late.exists())
                finally:
                    if info.exists():
                        ids=json.loads(info.read_text())
                        try:os.killpg(ids['pgrp'],signal.SIGKILL)
                        except ProcessLookupError:pass

    def test_resumed_exact_bytes_pass_and_missing_or_corrupt_bytes_fail(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); path = root/'episode/initial_scene.json'
            with self.assertRaises(AssertionError):verify_archive(root, self.manifest())
            path.parent.mkdir();path.write_bytes(b'known bytes')
            self.assertTrue(verify_archive(root, self.manifest())['verified'])
            path.write_bytes(b'other bytes')
            with self.assertRaisesRegex(AssertionError, 'bytes differ'):verify_archive(root, self.manifest())

    def test_path_escape_and_symlinks_are_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for name in ('../outside', '/tmp/outside', 'episode/../outside'):
                with self.subTest(name=name), self.assertRaises(AssertionError):verify_archive(root, self.manifest(name))
            (root/'real').write_bytes(b'known bytes');(root/'alias').symlink_to(root/'real')
            with self.assertRaises(AssertionError):verify_archive(root, self.manifest('alias'))

    def test_live_or_unflushed_recorder_cannot_be_archived(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            for state in (dict(status='starting'),dict(status='ready'),dict(status='service_failed'),dict(status='stopped',finished_utc='sealed')):
                with self.subTest(state=state):
                    (root/'services.json').write_text(json.dumps(state))
                    result=subprocess.run([sys.executable,'-c',REMOTE_MANIFEST,str(root)],capture_output=True,text=True)
                    if state.get('finished_utc'):
                        self.assertEqual(result.returncode,0)
                        self.assertTrue(verify_archive(root,json.loads(result.stdout))['verified'])
                    else:self.assertNotEqual(result.returncode,0)

    def test_dead_owner_with_stop_request_recovers_stale_ready_metadata(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)/'attempt';root.mkdir();proc=Path(tmp)/'proc';proc.mkdir()
            (root/'STOP').touch()
            state=dict(status='ready',attempt=root.name,manager_pid=101,simulator_pid=102)
            guard=archive.cleanup_guard(root,state,proc)
            self.assertEqual(guard['source'],'dead_owner_after_stop')
            self.assertEqual(state['status'],'ready')
            (proc/'102').mkdir()
            with self.assertRaisesRegex(AssertionError,'alive'):
                archive.cleanup_guard(root,state,proc)

    def test_surviving_process_group_blocks_recovery_and_stop_is_required(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)/'attempt';root.mkdir();proc=Path(tmp)/'proc';proc.mkdir()
            state=dict(status='ready',attempt=root.name,manager_pid=101,simulator_pid=102)
            with self.assertRaises(AssertionError):archive.cleanup_guard(root,state,proc)
            (root/'STOP').touch();child=proc/'103';child.mkdir()
            (child/'stat').write_text('103 (owned child) S 1 102 102 0')
            with self.assertRaisesRegex(AssertionError,'group'):
                archive.cleanup_guard(root,state,proc)

    def test_parallel_file_lists_copy_exact_bytes_and_never_overlap(self):
        with tempfile.TemporaryDirectory() as tmp:
            source=Path(tmp)/'source';target=Path(tmp)/'target';source.mkdir();target.mkdir()
            files={}
            for i,name in enumerate(['scene/initial.json','scene/chunk0.npz','scene/chunk1.npz','scene/receipts/000.json','scene/odd name\n.json']):
                data=bytes([i])*((i+1)*1024);p=source/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
                files[name]=dict(size=len(data),sha256=hashlib.sha256(data).hexdigest())
            manifest=dict(schema='gpt_policy_robolab_remote_archive.v1',files=files)
            groups=archive.partitions(manifest);flat=[name for group in groups for name in group]
            self.assertEqual(set(flat),set(files));self.assertEqual(len(flat),len(set(flat)))
            events=[]
            self.assertEqual(archive.transfer_archive(str(source)+'/',target,manifest,['ssh'],progress=events.append),4)
            self.assertTrue(archive.verify_archive(target,manifest)['verified'])
            completed=[event for event in events if event['status']=='transferred']
            self.assertEqual({event['worker'] for event in completed},set(range(4)))
            self.assertEqual(sum(event['files'] for event in completed),len(files))
            self.assertEqual(sum(event['bytes'] for event in completed),sum(row['size'] for row in files.values()))
            for bad in ['../escape','/absolute','scene/../escape']:
                with self.assertRaises(AssertionError):archive.partitions(self.manifest(bad))


if __name__ == '__main__':unittest.main()
