import json
from pathlib import Path
import tempfile
import unittest
import run_mainskill_robolab_hybrid_services as services


class PreflightTests(unittest.TestCase):
    def test_busy_preferred_gpu_uses_available_separate_pair(self):
        self.assertEqual(services.select_gpus({0:22000,2:60000,4:65000,6:8000},6,0,'pi05_plus_gpt'),(2,4))
        self.assertEqual(services.select_gpus({0:65000,6:22000},6,0,'pi05_plus_gpt'),(6,0))

    def test_insufficient_resources_wait_without_reusing_one_gpu(self):
        with self.assertRaises(RuntimeError):services.select_gpus({0:65000,6:8000},6,0,'pi05_plus_gpt')
        self.assertEqual(services.select_gpus({0:65000,6:8000},6,0,'gpt_only'),(0,None))

    def test_full_verified_asset_root_is_required(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);target=root/'upstream/RoboLab-ad45-full-assets';target.mkdir(parents=True)
            with self.assertRaises(AssertionError):services.verified_asset_root(root)
            marker=dict(verified=True,source_commit='ad45d4f974725d020f82c2b0d77d78533aeba2b3',files=2228)
            (target/'assets_verification.json').write_text(json.dumps(marker))
            self.assertEqual(services.verified_asset_root(root),target)
            marker['source_commit']='different';(target/'assets_verification.json').write_text(json.dumps(marker))
            with self.assertRaises(AssertionError):services.verified_asset_root(root)


if __name__=='__main__':unittest.main()
