"""Switch the owned RoboLab queue only after the complete controller/archive lock boundary."""
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess


def main():
    source=Path(__file__).resolve().parents[1]
    manifest=json.loads((source/'robolab_queue_scheduler_v2_manifest.json').read_text())
    snapshot=source/'infra'/manifest['file']
    old='gpt-policy-robolab-validated-campaign.service'
    new='gpt-policy-robolab-two-methods-v2.service'
    env=dict(os.environ,XDG_RUNTIME_DIR='/run/user/1007',DBUS_SESSION_BUS_ADDRESS='unix:path=/run/user/1007/bus')
    def persist(status):
        path=source/'robolab_queue_handover_20261005.json';temp=path.with_suffix('.tmp')
        temp.write_text(json.dumps(dict(status=status,old_unit=old,new_unit=new,
            source_sha256=manifest['sha256'],observed_utc=datetime.now(timezone.utc).isoformat()),indent=2)+'\n');temp.replace(path)
    persist('waiting_for_current_controller_and_archive_boundary')
    with open('/tmp/gpt-policy-robolab-hybrid-controller.lock','a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        assert snapshot.name=='queue_robolab_two_methods_v2_20261005.py'
        assert hashlib.sha256(snapshot.read_bytes()).hexdigest()==manifest['sha256']
        subprocess.run(['systemctl','--user','stop',old],check=True,env=env)
        subprocess.run(['systemctl','--user','disable',old],check=True,env=env)
        subprocess.run(['systemctl','--user','enable',new],check=True,env=env)
        subprocess.run(['systemctl','--user','start',new],check=True,env=env)
        persist('switched_at_controller_and_archive_boundary')


if __name__=='__main__':main()
