"""Own one fresh RoboLab simulator and identified upstream pi05 server on mainskill."""
import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import time

ROOT = Path('/home/dataset-assist-0/liyufeng/agentic_robot')
ARTIFACTS = ROOT / 'experiments/gpt_policy_repro_20260914'
RUNTIME = Path('/home/batchcom/gpt-policy-runtime')


def write(path, data):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(data, indent=2)+'\n')
    temp.replace(path)


def ready(log):
    if not log.is_file():
        return False
    # Only the server's own completed startup event counts; no physical RPC probe.
    with log.open(errors='replace') as stream:
        return any(line.startswith('{') and '"event": "ready"' in line for line in stream)


def select_gpus(free, sim_gpu, policy_gpu, method):
    """Keep preferred devices when possible; never stop another GPU owner."""
    if method == 'pi05_plus_gpt':
        policies = [i for i in free if free[i] >= 40000]
        policies.sort(key=lambda i: (i != policy_gpu, -free[i], i))
        for policy in policies:
            sims = [i for i in free if i != policy and free[i] >= 15000]
            sims.sort(key=lambda i: (i != sim_gpu, -free[i], i))
            if sims:
                return sims[0], policy
    else:
        sims = [i for i in free if free[i] >= 15000]
        sims.sort(key=lambda i: (i != sim_gpu, -free[i], i))
        if sims:
            return sims[0], None
    raise RuntimeError('Separate GPUs with sufficient free memory required; no other jobs will be stopped')


def verified_asset_root(root):
    target = root/'upstream/RoboLab-ad45-full-assets'
    marker_path = target/'assets_verification.json'
    assert marker_path.is_file(), 'Verified full RoboLab assets required'
    marker = json.loads(marker_path.read_text())
    assert marker.get('verified') is True and marker.get('files') == 2228
    assert marker.get('source_commit') == 'ad45d4f974725d020f82c2b0d77d78533aeba2b3'
    return target


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--attempt', required=True)
    parser.add_argument('--task', required=True)
    parser.add_argument('--method', choices=('pi05_plus_gpt','gpt_only'), default='pi05_plus_gpt')
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--sim-port', type=int, default=20600)
    parser.add_argument('--policy-port', type=int, default=20610)
    parser.add_argument('--policy-gpu', type=int, default=0)
    parser.add_argument('--sim-gpu', type=int, default=6)
    args = parser.parse_args()
    prefix = 'hybrid_' if args.method=='pi05_plus_gpt' else 'direct_'
    if Path(args.attempt).name != args.attempt or not args.attempt.startswith(prefix):
        raise ValueError('Attempt must be a fresh hybrid campaign directory name')
    tasks = json.loads((ARTIFACTS/'fixtures/robolab_task_files.json').read_text())['tasks']
    task_relative = tasks[args.task]
    output = ARTIFACTS/'robolab_gpt_campaign'/args.attempt
    output.mkdir(parents=True, exist_ok=False)
    with Path('/tmp/gpt-policy-robolab-hybrid-services.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for port in (args.sim_port, args.policy_port):
            with socket.socket() as sock:
                sock.bind(('127.0.0.1', port))
        inventory = subprocess.check_output(['nvidia-smi', '--query-gpu=index,memory.free',
            '--format=csv,noheader,nounits'], text=True)
        free = {int(row.split(',')[0]): int(row.split(',')[1]) for row in inventory.splitlines()}
        args.sim_gpu, selected_policy = select_gpus(free,args.sim_gpu,args.policy_gpu,args.method)
        if selected_policy is not None:
            args.policy_gpu = selected_policy
        asset_root = verified_asset_root(ROOT)
        (output/'gpu_before.csv').write_text(inventory)
        root_env = os.environ.copy()
        root_env.update(PYTHONPATH=str(ROOT/'gpt-as-policy')+':'+str(ROOT/'upstream/openpi-robolab/packages/openpi-client/src'),
            CUDA_MPS_PIPE_DIRECTORY='/tmp/gpt-policy-robolab-no-mps-'+str(os.getpid()),
            OMP_NUM_THREADS='4', OPENBLAS_NUM_THREADS='4')
        checkpoint = ROOT/'upstream/checkpoints/pi05_droid_jointpos'
        policy_args = [str(ROOT/'venvs/openpi-robolab/bin/python'), '-m',
            'hybrid_rollout.robolab.pi05_server.server', '--checkpoint', str(checkpoint),
            '--port', str(args.policy_port), '--identity-output', str(output/'policy_identity.json')]
        policy_env = dict(root_env, CUDA_VISIBLE_DEVICES=str(args.policy_gpu),
            XLA_PYTHON_CLIENT_PREALLOCATE='false')
        sim_env = dict(root_env, CUDA_VISIBLE_DEVICES=str(args.sim_gpu), SIM_GPU=str(args.sim_gpu),
            ROBO_LAB_ROOT=str(asset_root),
            ROBO_LAB_PYTHON=str(RUNTIME/'robolab51/bin/python'),
            ROBO_LAB_TASK_FILE=str(asset_root/task_relative),
            ROBO_LAB_RECORD_SCENE_STATE='1', VK_ICD_FILENAMES='/etc/vulkan/icd.d/nvidia_icd.json',
            XDG_RUNTIME_DIR=str(RUNTIME/'xdg/runtime'), XDG_CACHE_HOME=str(RUNTIME/'xdg/cache'),
            XDG_DATA_HOME=str(RUNTIME/'xdg/data'), XDG_CONFIG_HOME=str(RUNTIME/'xdg/config'),
            MPLCONFIGDIR=str(RUNTIME/'matplotlib'), OMNI_KIT_ACCEPT_EULA='Y')
        sim_env['PYTHONPATH'] += ':'+sim_env['ROBO_LAB_ROOT']
        sim_wrapper='robolab_instrumented_server.py' if args.method=='pi05_plus_gpt' else 'robolab_direct_server.py'
        sim_args = [sim_env['ROBO_LAB_PYTHON'],str(ARTIFACTS/'infra'/sim_wrapper),
            '--task',args.task,'--task-file',sim_env['ROBO_LAB_TASK_FILE'],
            '--output',str(output/'sim'),'--port',str(args.sim_port),'--seed',str(args.seed),
            '--record-scene-state',f'--kit_args=--/renderer/multiGpu/enabled=false --/renderer/multiGpu/autoEnable=false --/renderer/activeGpu={args.sim_gpu}']
        sources = {}
        for path in sorted((ROOT/'gpt-as-policy/hybrid_rollout/robolab').rglob('*')):
            if path.is_file() and path.suffix in ('.py', '.md', '.json', '.sh'):
                sources[str(path.relative_to(ROOT))] = hashlib.sha256(path.read_bytes()).hexdigest()
        for name in {'run_mainskill_robolab_hybrid_services.py',sim_wrapper,'robolab_instrumented_server.py'}:
            path=ARTIFACTS/'infra'/name
            sources[str(path.relative_to(ROOT))]=hashlib.sha256(path.read_bytes()).hexdigest()
        record = dict(schema='gpt_policy_robolab_services.v1', attempt=args.attempt,
            method=args.method, task=args.task, seed=args.seed, manager_pid=os.getpid(),
            status='starting', started_utc=datetime.now(timezone.utc).isoformat(),
            policy_argv=policy_args if args.method=='pi05_plus_gpt' else None, simulator_argv=sim_args,
            policy_gpu=args.policy_gpu, sim_gpu=args.sim_gpu, source_sha256=sources)
        processes, logs = [], []
        stopped = False
        def terminate(*_):
            nonlocal stopped
            stopped = True
        signal.signal(signal.SIGTERM, terminate)
        signal.signal(signal.SIGINT, terminate)
        try:
            jobs=[('simulator',sim_args,sim_env)]
            if args.method=='pi05_plus_gpt':jobs.insert(0,('policy',policy_args,policy_env))
            for name, argv, env in jobs:
                log = (output/(name+'.log')).open('w')
                logs.append(log)
                proc = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=log,
                    stderr=subprocess.STDOUT, start_new_session=True)
                processes.append(proc)
                record[name+'_pid'] = proc.pid
            write(output/'services.json', record)
            deadline = time.monotonic()+900
            while not stopped and not (output/'STOP').exists():
                codes = [p.poll() for p in processes]
                if any(code is not None for code in codes):
                    record.update(status='service_failed', exit_codes=codes)
                    break
                if record['status'] == 'starting':
                    if (args.method=='gpt_only' or (output/'policy_identity.json').exists()) and ready(output/'simulator.log'):
                        record.update(status='ready', ready_utc=datetime.now(timezone.utc).isoformat())
                        write(output/'services.json', record)
                    elif time.monotonic() >= deadline:
                        record.update(status='startup_timeout')
                        break
                time.sleep(2)
        finally:
            # Terminate only process groups started by this manager.
            for proc in processes:
                if proc.poll() is None:
                    os.killpg(proc.pid, signal.SIGTERM)
            for proc in processes:
                try:
                    proc.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid, signal.SIGKILL)
                    proc.wait(timeout=10)
            for log in logs:
                log.close()
            if record['status'] in ('starting', 'ready'):
                record['status'] = 'stopped'
            record['finished_utc'] = datetime.now(timezone.utc).isoformat()
            write(output/'services.json', record)
        return 0 if record['status'] == 'stopped' else 1


if __name__ == '__main__':
    raise SystemExit(main())
