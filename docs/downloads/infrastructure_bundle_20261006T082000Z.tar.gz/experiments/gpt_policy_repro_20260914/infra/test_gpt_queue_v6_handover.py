import builtins
import fcntl
import hashlib
import json
from pathlib import Path
import tempfile
import threading
import time
import unittest
from unittest.mock import patch
import handover_gpt_queue_v6 as handover


class BoundaryHandoverTests(unittest.TestCase):
    def test_no_stop_before_current_episode_releases_its_lock(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp);infra = root/'infra';infra.mkdir()
            for name in ('old.py', 'new.py'):(infra/name).write_text(name)
            (root/'queue_scheduler_v6_manifest.json').write_text(json.dumps(dict(
                file='new.py',sha256=hashlib.sha256((infra/'new.py').read_bytes()).hexdigest(),
                parent_file='old.py',parent_sha256=hashlib.sha256((infra/'old.py').read_bytes()).hexdigest())))
            lock = root/'lock';commands=[];errors=[];real_open=builtins.open
            def routed(path,*args,**kwargs):
                return real_open(lock if path=='/tmp/gpt-policy-all-pairs.lock' else path,*args,**kwargs)
            def control(args,**kwargs):
                with real_open(lock,'a') as observer:
                    with self.assertRaises(BlockingIOError):fcntl.flock(observer,fcntl.LOCK_EX|fcntl.LOCK_NB)
                commands.append(args[2:])
            def run():
                try:handover.main()
                except BaseException as error:errors.append(error)
            with real_open(lock,'a') as owner:
                fcntl.flock(owner,fcntl.LOCK_EX)
                with patch.object(handover,'__file__',str(infra/'handover_gpt_queue_v6.py')), \
                     patch('builtins.open',routed),patch.object(handover.subprocess,'run',side_effect=control):
                    worker=threading.Thread(target=run);worker.start()
                    deadline=time.monotonic()+3
                    while not (root/'queue_handover_20261005_v6.json').exists() and time.monotonic()<deadline:time.sleep(.01)
                    self.assertEqual(commands,[])
                    fcntl.flock(owner,fcntl.LOCK_UN);worker.join(timeout=3)
                    self.assertFalse(worker.is_alive());self.assertEqual(errors,[])
            self.assertEqual([r[0] for r in commands],['stop','disable','enable','start'])
            self.assertEqual(json.loads((root/'queue_handover_20261005_v6.json').read_text())['status'],
                             'switched_at_physical_episode_boundary')


if __name__=='__main__':unittest.main()
