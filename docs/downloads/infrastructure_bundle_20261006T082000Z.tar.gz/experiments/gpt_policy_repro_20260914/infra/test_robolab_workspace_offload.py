"""No unique, active, unaudited, or mismatched workspace bytes may be removed."""
import json
from pathlib import Path
import os
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from offload_robolab_workspaces import offload, digest, inventory, write


class WorkspaceOffload(unittest.TestCase):
    def fixture(self, root):
        run = root / 'campaign/direct_20261002T111156Z_BlocksInBinTask_seed0'
        tmp = root / 'local'
        cold = root / 'private'
        tmp.mkdir(); cold.mkdir(); run.mkdir(parents=True)
        source = tmp / ('gpt-policy-robolab-' + run.name)
        source.mkdir()
        result = dict(complete=True, terminated=True, truncated=False, success=True, step_id=5, decisions=1)
        worker = dict(pid=None)
        files = {'rollout/result.json':result, 'rollout/run.json':dict(seed=0),
                 'rollout/codex_workspace/worker.json':worker}
        for name, value in files.items():
            path = run / name; path.parent.mkdir(parents=True, exist_ok=True); write(path, value)
        write(run/'attempt.json',dict(attempt=run.name,local_workspace=str(source),
              finished_utc='sealed',method='gpt_only'))
        write(run/'remote_archive_receipt.json',dict(verified=True))
        write(run/'complete_action_audit.json',dict(verified=True,complete_episode=True,
              scope='complete_native_episode',method='gpt_only',native_actions=5,decisions=1,
              terminal={k:result[k] for k in ('success','terminated','truncated')},
              files_sha256={name:digest(run/name) for name in files}))
        (source/'frames').mkdir();(source/'frames/image.png').write_bytes(b'image evidence')
        (source/'runtime_db').mkdir();(source/'runtime_db/state.sqlite').write_bytes(b'private stopped database')
        return run, tmp, cold, source

    def test_exact_all_bytes_retained_and_old_paths_work(self):
        with tempfile.TemporaryDirectory() as directory:
            run,tmp,cold,source=self.fixture(Path(directory));before=inventory(source)
            result=offload(run,{},cold,tmp)
            self.assertEqual(result['status'],'offloaded');self.assertTrue(source.is_symlink())
            self.assertEqual(inventory(cold/run.name/'workspace'),before)
            self.assertEqual((source/'runtime_db/state.sqlite').read_bytes(),b'private stopped database')
            self.assertEqual(offload(run,{},cold,tmp)['status'],'already_offloaded')
            self.assertFalse((tmp/(source.name+'.offload-pending')).exists())

    def test_complete_native_failure_is_retained_too(self):
        with tempfile.TemporaryDirectory() as directory:
            run,tmp,cold,source=self.fixture(Path(directory))
            result=json.loads((run/'rollout/result.json').read_text())
            result.update(success=False,terminated=False,truncated=True)
            write(run/'rollout/result.json',result)
            proof=json.loads((run/'complete_action_audit.json').read_text())
            proof['terminal']={k:result[k] for k in ('success','terminated','truncated')}
            proof['files_sha256']['rollout/result.json']=digest(run/'rollout/result.json')
            write(run/'complete_action_audit.json',proof)
            self.assertEqual(offload(run,{},cold,tmp)['status'],'offloaded')
            self.assertEqual((source/'frames/image.png').read_bytes(),b'image evidence')

    def test_nas_uid_mapping_does_not_weaken_local_ownership(self):
        with tempfile.TemporaryDirectory() as directory:
            run,tmp,cold,source=self.fixture(Path(directory))
            original=Path.lstat
            def mapped(path):
                value=original(path)
                if path.is_relative_to(cold):
                    return SimpleNamespace(st_mode=value.st_mode,st_size=value.st_size,st_uid=-1)
                return value
            with patch.object(Path,'lstat',autospec=True,side_effect=mapped):
                self.assertEqual(offload(run,{},cold,tmp)['status'],'offloaded')
        with tempfile.TemporaryDirectory() as directory:
            run,tmp,cold,source=self.fixture(Path(directory))
            original=Path.lstat
            def wrong_owner(path):
                value=original(path)
                if path.is_relative_to(source):
                    return SimpleNamespace(st_mode=value.st_mode,st_size=value.st_size,st_uid=-1)
                return value
            with patch.object(Path,'lstat',autospec=True,side_effect=wrong_owner):
                with self.assertRaisesRegex(AssertionError,'Local workspace ownership'):offload(run,{},cold,tmp)
            self.assertFalse(source.is_symlink())

    def test_active_live_process_and_incomplete_audit_preserve_source(self):
        for defect in ('active','process','audit','corrupt'):
            with self.subTest(defect=defect),tempfile.TemporaryDirectory() as directory:
                run,tmp,cold,source=self.fixture(Path(directory));active={}
                if defect=='active':active['attempt']=run.name
                if defect=='process':
                    record=json.loads((run/'attempt.json').read_text());record['controller_pid']=os.getpid();write(run/'attempt.json',record)
                if defect=='audit':
                    proof=json.loads((run/'complete_action_audit.json').read_text());proof['complete_episode']=False;write(run/'complete_action_audit.json',proof)
                if defect=='corrupt':(run/'rollout/result.json').write_text('{}')
                with self.assertRaises((AssertionError,KeyError)):offload(run,active,cold,tmp)
                self.assertFalse(source.is_symlink());self.assertEqual((source/'frames/image.png').read_bytes(),b'image evidence')

    def test_links_and_unknown_workspace_paths_are_rejected(self):
        for defect in ('source_link','destination_link','wrong_path'):
            with self.subTest(defect=defect),tempfile.TemporaryDirectory() as directory:
                root=Path(directory);run,tmp,cold,source=self.fixture(root)
                if defect=='source_link':(source/'alias').symlink_to(source/'frames/image.png')
                if defect=='destination_link':
                    (cold/run.name).mkdir();outside=root/'outside';outside.mkdir();(cold/run.name/'workspace').symlink_to(outside)
                if defect=='wrong_path':
                    record=json.loads((run/'attempt.json').read_text());record['local_workspace']=str(root/'outside');write(run/'attempt.json',record)
                with self.assertRaises(AssertionError):offload(run,{},cold,tmp)
                self.assertFalse(source.is_symlink())

    def test_bad_copy_and_failed_link_never_remove_source(self):
        for defect in ('copy','link'):
            with self.subTest(defect=defect),tempfile.TemporaryDirectory() as directory:
                run,tmp,cold,source=self.fixture(Path(directory))
                if defect=='copy':
                    with patch('offload_robolab_workspaces.shutil.copytree'):
                        with self.assertRaises(AssertionError):offload(run,{},cold,tmp)
                else:
                    with patch.object(Path,'symlink_to',side_effect=OSError('link creation interrupted')):
                        with self.assertRaises(OSError):offload(run,{},cold,tmp)
                self.assertFalse(source.is_symlink());self.assertEqual((source/'frames/image.png').read_bytes(),b'image evidence')

    def test_interrupted_rename_and_duplicate_removal_can_resume(self):
        for interrupted in ('rename','remove'):
            with self.subTest(interrupted=interrupted),tempfile.TemporaryDirectory() as directory:
                run,tmp,cold,source=self.fixture(Path(directory))
                with patch('offload_robolab_workspaces.shutil.rmtree',side_effect=OSError('cleanup interrupted')):
                    with self.assertRaises(OSError):offload(run,{},cold,tmp)
                if interrupted=='rename':source.unlink()
                self.assertIn(offload(run,{},cold,tmp)['status'],('offloaded','already_offloaded'))
                self.assertTrue(source.is_symlink());self.assertFalse((tmp/(source.name+'.offload-pending')).exists())
                self.assertEqual((source/'runtime_db/state.sqlite').read_bytes(),b'private stopped database')


if __name__=='__main__':unittest.main()
