"""A stopped native result remains discoverable if copying or remote archiving fails."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from run_robolab_hybrid_remote import copy_stopped_controller_output
from queue_robolab_two_methods_v2_20261005 import classify


class ControllerCheckpoint(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.workspace, self.output = self.root/'workspace', self.root/'attempt'
        (self.workspace/'rollout').mkdir(parents=True)
        self.output.mkdir()
        self.raw = b'{"complete":true,"terminated":false,"truncated":true,"success":false}\n'
        (self.workspace/'rollout/result.json').write_bytes(self.raw)
        (self.workspace/'rollout/history.json').write_text('[{"native_step":3}]\n')
        (self.workspace/'rollout/runtime_db').mkdir()
        (self.workspace/'rollout/runtime_db/state.db').write_bytes(b'private runtime')

    def test_terminal_marker_is_visible_before_an_interrupted_copy(self):
        with patch('run_robolab_hybrid_remote.shutil.copytree', side_effect=OSError('interrupted copy')):
            with self.assertRaises(OSError):
                copy_stopped_controller_output(self.workspace, self.output)
        self.assertEqual((self.output/'rollout/result.json').read_bytes(), self.raw)
        row = dict(task='BlocksInBinTask', seed=0, method='gpt_only')
        def incomplete_audit(*_):
            raise AssertionError('audit incomplete')
        status = classify(row, [(self.output, dict(started_utc='2026-10-05T00:00:00Z'))],
            qualifier=incomplete_audit)
        self.assertEqual(status['status'], 'audit_failed')
        self.assertNotEqual(status['status'], 'pending')

    def test_same_stopped_source_can_finish_copy_after_interruption(self):
        with patch('run_robolab_hybrid_remote.shutil.copytree', side_effect=OSError('interrupted copy')):
            with self.assertRaises(OSError):
                copy_stopped_controller_output(self.workspace, self.output)
        copy_stopped_controller_output(self.workspace, self.output)
        self.assertEqual((self.output/'rollout/result.json').read_bytes(), self.raw)
        self.assertEqual((self.output/'rollout/history.json').read_bytes(),
            (self.workspace/'rollout/history.json').read_bytes())
        self.assertFalse((self.output/'rollout/runtime_db').exists())

    def test_changed_terminal_source_cannot_replace_original_failure(self):
        copy_stopped_controller_output(self.workspace, self.output)
        (self.workspace/'rollout/result.json').write_text(json.dumps(dict(complete=True,
            terminated=True, truncated=False, success=True)))
        with self.assertRaisesRegex(ValueError, 'original stopped controller result'):
            copy_stopped_controller_output(self.workspace, self.output)
        self.assertEqual((self.output/'rollout/result.json').read_bytes(), self.raw)

    def test_incomplete_marker_cannot_close_the_native_campaign(self):
        (self.workspace/'rollout/result.json').write_text('{"complete":false,"terminated":false,"truncated":false}\n')
        copy_stopped_controller_output(self.workspace, self.output)
        row = dict(task='BlocksInBinTask', seed=0, method='gpt_only')
        status = classify(row, [(self.output, dict(started_utc='2026-10-05T00:00:00Z'))])
        self.assertEqual(status['status'], 'pending')


if __name__ == '__main__':
    unittest.main()
