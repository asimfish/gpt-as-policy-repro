import json
from pathlib import Path
import shutil
import tempfile
import unittest

import robodojo_valid_cohort as cohort

ART = Path(__file__).resolve().parents[1]


class FrozenSelection(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        shutil.copytree(ART / 'fixtures/cases', self.root / 'fixtures/cases')
        shutil.copyfile(ART / 'fixtures/evaluation_manifest.json', self.root / 'fixtures/evaluation_manifest.json')
        base = self.root / cohort.DIAG
        base.mkdir(parents=True)
        shutil.copyfile(ART / cohort.DIAG / 'replacement_proposal.json', base / 'replacement_proposal.json')
        for seed in (4, 5):
            for name in ('diagnostic_integrity.json', 'sim/support_validation.json',
                         'sim/evaluation_outcome.json', 'sim/resolved_config.json'):
                target = base / f'hold_seed{seed}' / name
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(ART / cohort.DIAG / f'hold_seed{seed}' / name, target)
        cohort.freeze(self.root)

    def mutate_manifest(self, update):
        path = self.root / cohort.MANIFEST
        d = json.loads(path.read_text()); update(d)
        path.write_text(json.dumps(d))
        pointer = self.root / cohort.POINTER
        p = json.loads(pointer.read_text()); p['manifest_sha256'] = cohort.sha(path)
        pointer.write_text(json.dumps(p))

    def test_only_prefrozen_whole_pair_is_selected_and_original_is_retained(self):
        doc = cohort.validate(self.root)
        original = {p.stem for p in (self.root / 'fixtures/cases').glob('gpt__*.json')}
        selected = {'gpt__' + c['case_id'] for c in doc['cases']}
        self.assertEqual(original - selected, {'gpt__' + cohort.REMOVED})
        self.assertEqual(selected - original, {'gpt__' + cohort.ADDED})
        self.assertTrue((self.root / 'fixtures/cases' / ('gpt__' + cohort.REMOVED + '.json')).is_file())
        self.assertEqual(cohort.freeze(self.root), doc)

    def test_original_drift_rejected(self):
        p = next((self.root / 'fixtures/cases').glob('gpt__*.json'))
        p.write_text(p.read_text() + ' ')
        with self.assertRaises(AssertionError): cohort.validate(self.root)

    def test_diagnostic_drift_rejected(self):
        p = self.root / cohort.DIAG / 'hold_seed5/sim/support_validation.json'
        d = json.loads(p.read_text()); d['unstable'] = True; p.write_text(json.dumps(d))
        with self.assertRaises(AssertionError): cohort.validate(self.root)

    def test_refreezing_later_winner_identity_rejected(self):
        self.mutate_manifest(lambda d: d['cases'][-1].update(layout_id=7))
        with self.assertRaises(AssertionError): cohort.validate(self.root)

    def test_unsafe_path_or_symlink_rejected(self):
        self.mutate_manifest(lambda d: d.update(fixture_dir='../cases'))
        with self.assertRaises(AssertionError): cohort.validate(self.root)
        p = self.root / cohort.CASE_DIR / ('gpt__' + cohort.ADDED + '.json')
        data = p.read_text(); p.unlink()
        outside = self.root / 'external.json'; outside.write_text(data); p.symlink_to(outside)
        with self.assertRaises(AssertionError): cohort.local(self.root, cohort.CASE_DIR + '/' + p.name)


if __name__ == '__main__': unittest.main()
