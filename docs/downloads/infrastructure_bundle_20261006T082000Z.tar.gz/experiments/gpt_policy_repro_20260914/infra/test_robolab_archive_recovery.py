"""Recovery status must show all original terminals before a slow transfer blocks."""
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

import recover_robolab_archives as recovery


class RecoveryProgress(unittest.TestCase):
    def prepare(self,root):
        rows=[dict(task='Task',seed=0,method='gpt_only'),dict(task='Task',seed=1,method='gpt_only')]
        fixtures=root/'fixtures';fixtures.mkdir()
        (fixtures/'robolab_two_methods_frozen.json').write_text(json.dumps({'entries':rows}))
        campaign=root/'robolab_gpt_campaign';campaign.mkdir()
        paths=[]
        for name,identity,started,success in [('direct_first_failure',rows[0],'2026-10-01T00:00:00+00:00',False),
                ('direct_later_success',rows[0],'2026-10-02T00:00:00+00:00',True),
                ('direct_other_case',rows[1],'2026-10-01T01:00:00+00:00',True)]:
            path=campaign/name;rollout=path/'rollout';rollout.mkdir(parents=True)
            (path/'attempt.json').write_text(json.dumps(dict(identity,attempt=name,started_utc=started)))
            (rollout/'result.json').write_text(json.dumps(dict(complete=True,terminated=True,truncated=False,success=success,step_id=5,decisions=1)))
            paths.append(path)
        (paths[2]/'complete_action_audit.json').write_text('{}')
        return paths

    def run_main(self,root,archive):
        real_path=Path
        def isolated_path(value):
            return root/'recovery.lock' if str(value)=='/tmp/gpt-policy-robolab-archive-recovery.lock' else real_path(value)
        def qualified(path,row):return json.loads((path/'rollout/result.json').read_text())
        with patch.object(recovery,'ARTIFACTS',root),patch.object(recovery,'Path',side_effect=isolated_path), \
             patch.object(recovery,'archive_attempt',side_effect=archive),patch.object(recovery,'qualified',side_effect=qualified):
            recovery.main()

    def test_full_plan_and_active_attempt_persist_before_wait_and_first_failure_is_retained(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);paths=self.prepare(root);observed=[]
            def archive(path):
                state=json.loads((root/'robolab_archive_recovery.json').read_text())
                self.assertEqual(state['planned_native_episodes'],2)
                self.assertEqual([row['attempt'] for row in state['plan']],[paths[0].name,paths[2].name])
                self.assertEqual(state['active']['attempt'],paths[0].name)
                self.assertEqual(state['active']['phase'],'archive')
                self.assertEqual(state['summary'],{'verified':0,'requires_repair':0,'pending':2})
                observed.append(path.name)
            self.run_main(root,archive)
            state=json.loads((root/'robolab_archive_recovery.json').read_text())
            self.assertEqual(observed,[paths[0].name])
            self.assertIsNone(state['active'])
            self.assertEqual(state['summary'],{'verified':2,'requires_repair':0,'pending':0})
            self.assertFalse(state['results'][0]['success'])
            self.assertEqual(state['phase'],'finished')

    def test_transfer_failure_is_recorded_and_other_original_cases_are_still_audited(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);paths=self.prepare(root)
            def archive(path):raise subprocess.TimeoutExpired('rsync',1200)
            self.run_main(root,archive)
            state=json.loads((root/'robolab_archive_recovery.json').read_text())
            self.assertEqual([row['attempt'] for row in state['results']],[paths[0].name,paths[2].name])
            self.assertEqual(state['results'][0]['status'],'preserved_requires_repair')
            self.assertEqual(state['results'][0]['error_type'],'TimeoutExpired')
            self.assertEqual(state['results'][1]['status'],'verified')
            self.assertEqual(state['summary'],{'verified':1,'requires_repair':1,'pending':0})
            self.assertIsNone(state['active'])


if __name__=='__main__':unittest.main()
