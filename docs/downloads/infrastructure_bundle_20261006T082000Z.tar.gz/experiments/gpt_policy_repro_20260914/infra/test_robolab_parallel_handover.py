import builtins
import fcntl
import hashlib
import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch

import handover_robolab_parallel_v3 as handover


class BoundaryTests(unittest.TestCase):
    def fixture(self,root):
        (root/'infra').mkdir();(root/'fixtures').mkdir()
        script=root/'infra/run_mainskill_robolab_services_v3_20261006.py';script.write_text('reviewed')
        frozen=root/'fixtures/robolab_two_methods_frozen.json';frozen.write_text('frozen')
        sha=hashlib.sha256(script.read_bytes()).hexdigest()
        (root/'robolab_queue_scheduler_v3_manifest.json').write_text(json.dumps(dict(
            files_sha256={script.name:sha},frozen_sha256=hashlib.sha256(frozen.read_bytes()).hexdigest())))
        (root/'robolab_parallel_deployment_receipt.json').write_text(json.dumps(dict(verified=True,sha256=sha)))
        return script

    def test_no_stop_or_start_before_native_cleanup_archive_boundary(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);self.fixture(root);lock_path=root/'owner.lock'
            commands=[];errors=[];ready=threading.Event();real_open=builtins.open
            original_write=handover.atomic_json
            def write(path,value):
                original_write(path,value)
                if value['status'].startswith('waiting'):ready.set()
            def routed(path,*args,**kwargs):
                return real_open(lock_path if path=='/tmp/gpt-policy-robolab-hybrid-controller.lock' else path,*args,**kwargs)
            def systemctl(argv,**kwargs):
                with real_open(lock_path,'a') as probe:
                    with self.assertRaises(BlockingIOError):fcntl.flock(probe,fcntl.LOCK_EX|fcntl.LOCK_NB)
                commands.append(argv[2:])
            def run():
                try:handover.main()
                except BaseException as error:errors.append(error)
            with real_open(lock_path,'a') as owner:
                fcntl.flock(owner,fcntl.LOCK_EX)
                with patch.object(handover,'ARTIFACTS',root),patch.object(handover,'atomic_json',side_effect=write),patch('builtins.open',side_effect=routed),patch.object(handover.subprocess,'run',side_effect=systemctl):
                    thread=threading.Thread(target=run);thread.start()
                    self.assertTrue(ready.wait(3));self.assertEqual(commands,[])
                    fcntl.flock(owner,fcntl.LOCK_UN);thread.join(3)
                    self.assertFalse(thread.is_alive());self.assertEqual(errors,[])
            self.assertEqual([v[0] for v in commands],['stop','disable','enable','start'])
            self.assertEqual(json.loads((root/'robolab_parallel_handover_20261006.json').read_text())['status'],'switched_at_controller_and_archive_boundary')

    def test_source_or_deployment_drift_blocks_all_systemctl_calls(self):
        for drift in ('source','deployment','frozen'):
            with self.subTest(drift=drift),tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp);script=self.fixture(root)
                if drift=='source':script.write_text('changed')
                elif drift=='deployment':(root/'robolab_parallel_deployment_receipt.json').write_text(json.dumps(dict(verified=True,sha256='other')))
                else:(root/'fixtures/robolab_two_methods_frozen.json').write_text('changed')
                with patch.object(handover,'ARTIFACTS',root),patch.object(handover.subprocess,'run') as mutate:
                    with self.assertRaises(ValueError):handover.main()
                    mutate.assert_not_called()


if __name__=='__main__':unittest.main()
