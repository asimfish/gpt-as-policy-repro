import builtins
import fcntl
import hashlib
import json
from pathlib import Path
import tempfile
import threading
import time
import unittest
from unittest.mock import patch
import handover_robolab_queue as handover


class HandoverTests(unittest.TestCase):
    def test_stop_waits_until_controller_and_archive_owner_releases_lock(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);infra=root/'infra';infra.mkdir()
            snapshot=infra/'queue_robolab_two_methods_v2_20261005.py';snapshot.write_text('tested source')
            (root/'robolab_queue_scheduler_v2_manifest.json').write_text(json.dumps(dict(file=snapshot.name,sha256=hashlib.sha256(snapshot.read_bytes()).hexdigest())))
            lock_path=root/'controller.lock';commands=[];errors=[];real_open=builtins.open
            def routed_open(path,*args,**kwargs):
                return real_open(lock_path if path=='/tmp/gpt-policy-robolab-hybrid-controller.lock' else path,*args,**kwargs)
            def control(args,**kwargs):
                with real_open(lock_path,'a') as probe:
                    with self.assertRaises(BlockingIOError):fcntl.flock(probe,fcntl.LOCK_EX|fcntl.LOCK_NB)
                commands.append(args[2:]);return None
            def run():
                try:handover.main()
                except BaseException as e:errors.append(e)
            with real_open(lock_path,'a') as owner:
                fcntl.flock(owner,fcntl.LOCK_EX)
                with patch.object(handover,'__file__',str(infra/'handover_robolab_queue.py')),patch('builtins.open',routed_open),patch.object(handover.subprocess,'run',side_effect=control):
                    worker=threading.Thread(target=run);worker.start()
                    deadline=time.monotonic()+3
                    while not (root/'robolab_queue_handover_20261005.json').exists() and time.monotonic()<deadline:time.sleep(.01)
                    self.assertEqual(commands,[])
                    fcntl.flock(owner,fcntl.LOCK_UN);worker.join(timeout=3)
                    self.assertFalse(worker.is_alive());self.assertEqual(errors,[])
            self.assertEqual([c[0] for c in commands],['stop','disable','enable','start'])
            self.assertEqual(json.loads((root/'robolab_queue_handover_20261005.json').read_text())['status'],'switched_at_controller_and_archive_boundary')


if __name__=='__main__':unittest.main()
