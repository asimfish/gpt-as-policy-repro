"""Archive idle RoboDojo SQLite/log state after the pinned v5 audit qualification."""
import argparse
from datetime import datetime, timezone
import fcntl
from pathlib import Path
import re
import json
from offload_robolab_workspaces import digest, read, write, offload_directory, ARTIFACTS

METHODS = ('gpt_only', 'pi05_plus_gpt')
STATE_NAME = re.compile(r'gpt-policy-codex-state\.[A-Za-z0-9]{8}')


def load_qualifier():
    script = ARTIFACTS/'infra/run_all_gpt_pairs_v5_20261002.py'
    payload = script.read_bytes()
    manifest = read(ARTIFACTS/'queue_scheduler_v5_manifest.json')
    import hashlib
    value = hashlib.sha256(payload).hexdigest()
    assert value == manifest['source_sha256'], 'Frozen qualifier source changed'
    namespace = dict(__file__=str(script),__name__='gpt_policy_pinned_qualifier')
    # Execute the exact verified bytes, not a second read or an import cache.
    exec(compile(payload,str(script),'exec'),namespace)
    original = namespace['terminal']
    if (ARTIFACTS/'fixtures/robodojo_active_cohort.json').is_file():
        from robodojo_valid_cohort import validate
        selection = validate(ARTIFACTS)
        selected = dict(__file__=str(script), __name__='gpt_policy_pinned_valid_qualifier')
        exec(compile(payload, str(script), 'exec'), selected)
        selected['CASES'] = ARTIFACTS/selection['fixture_dir']
        def qualified(parent, method):
            return original(parent, method) or selected['terminal'](parent, method)
        return qualified, value
    return original, value


def state_path(run, tmp_root=Path('/tmp')):
    config = read(run/'rollout/codex_workspace/launch.json')['config']
    source = Path(config['sqlite_home']).parent
    assert source.parent == tmp_root and STATE_NAME.fullmatch(source.name), 'Unexpected SQLite state path'
    assert Path(config['sqlite_home']) == source/'runtime_db'
    assert Path(config['log_dir']) == source/'runtime_logs', 'State and logs must share the owned root'
    return source


def active_states(campaign, tmp_root=Path('/tmp')):
    values = set()
    for parent in campaign.iterdir():
        if not parent.is_dir() or parent.is_symlink():
            continue
        for method in METHODS:
            run = parent/method
            worker = run/'rollout/codex_workspace/worker.json'
            if worker.exists():
                pid = read(worker).get('pid')
                if pid and Path('/proc/'+str(int(pid))).exists():
                    values.add(state_path(run,tmp_root))
    return values


def offload_run(run, cold_root, tmp_root=Path('/tmp'), qualifier=None, active_provider=None):
    assert run.name in METHODS and re.fullmatch('[A-Za-z0-9_]+', run.parent.name)
    assert run.is_dir() and not run.is_symlink() and not run.parent.is_symlink()
    assert cold_root.is_dir() and not cold_root.is_symlink()
    if qualifier is None:qualifier,_=load_qualifier()
    source = state_path(run,tmp_root)
    launch = run/'rollout/codex_workspace/launch.json'
    launch_hash = digest(launch)
    def check():
        assert qualifier(run.parent,run.name), 'Pinned full native audit qualification required'
        assert digest(launch)==launch_hash and state_path(run,tmp_root)==source, 'State metadata changed'
        worker = read(run/'rollout/codex_workspace/worker.json')
        pid = worker.get('pid')
        assert pid and not Path('/proc/'+str(int(pid))).exists(), 'Recorded worker still exists'
        live = active_provider() if active_provider else active_states(run.parent.parent,tmp_root)
        assert source not in live, 'A live worker still uses this state'
    check()
    identity = 'robodojo_'+run.parent.name+'__'+run.name
    return offload_directory(source,cold_root/identity,check,identity)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--limit',type=int,default=2)
    args=parser.parse_args();assert 1<=args.limit<=100
    qualifier,source_hash=load_qualifier()
    cold=ARTIFACTS/'private_runtime_archives';cold.mkdir(mode=0o700,exist_ok=True)
    results=[]
    with Path('/tmp/gpt-policy-robodojo-state-offload.lock').open('a') as owner:
        fcntl.flock(owner,fcntl.LOCK_EX|fcntl.LOCK_NB)
        campaign=ARTIFACTS/'gpt_pair_campaign'
        for parent in sorted(campaign.iterdir()):
            if not parent.is_dir() or parent.is_symlink():continue
            for method in METHODS:
                run=parent/method
                if not run.exists():continue
                try:results.append(offload_run(run,cold,qualifier=qualifier))
                except (AssertionError,FileNotFoundError,KeyError,ValueError) as error:
                    results.append(dict(attempt=parent.name+'__'+method,status='preserved',
                        reason_type=type(error).__name__,reason=str(error) if isinstance(error,AssertionError) else type(error).__name__))
                if sum(v['status']=='offloaded' for v in results)>=args.limit:break
            if sum(v['status']=='offloaded' for v in results)>=args.limit:break
        write(ARTIFACTS/'robodojo_storage_maintenance.json',dict(schema='gpt_policy_robodojo_state_offload.v1',
            updated_utc=datetime.now(timezone.utc).isoformat(),frozen_qualifier_sha256=source_hash,
            scope='Stopped audited RoboDojo state only; all bytes retained privately; active SQLite stays local',results=results))
    print(json.dumps(dict(offloaded=sum(v['status']=='offloaded' for v in results),
        bytes_offloaded=sum(v['bytes'] for v in results if v['status']=='offloaded'))))


if __name__=='__main__':main()
