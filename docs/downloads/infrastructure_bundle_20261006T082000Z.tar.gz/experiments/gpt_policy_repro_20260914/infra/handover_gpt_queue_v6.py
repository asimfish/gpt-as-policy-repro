"""Switch this queue after its current physical episode releases execution ownership."""
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile


def main():
    root = Path(__file__).resolve().parents[1]
    manifest = json.loads((root/'queue_scheduler_v6_manifest.json').read_text())
    old, new = 'gpt-policy-all-pairs-v5.service', 'gpt-policy-all-pairs-v6.service'
    env = dict(os.environ, XDG_RUNTIME_DIR='/run/user/1007',
               DBUS_SESSION_BUS_ADDRESS='unix:path=/run/user/1007/bus')

    def evidence(status):
        path = root/'queue_handover_20261005_v6.json'
        with tempfile.NamedTemporaryFile('w', dir=root, delete=False) as f:
            temporary = Path(f.name)
            json.dump(dict(status=status, old_unit=old, new_unit=new,
                tested_source_sha256=manifest['sha256'],
                stopped_audit_may_be_recomputed=True,
                observed_utc=datetime.now(timezone.utc).isoformat()), f, indent=2)
            f.write('\n')
        temporary.replace(path)

    evidence('waiting_for_current_physical_episode')
    with open('/tmp/gpt-policy-all-pairs.lock', 'a') as owner:
        fcntl.flock(owner, fcntl.LOCK_EX)
        for filename, sha in [(manifest['file'], manifest['sha256']),
                              (manifest['parent_file'], manifest['parent_sha256'])]:
            assert hashlib.sha256((root/'infra'/filename).read_bytes()).hexdigest() == sha, 'Tested queue snapshot changed'
        subprocess.run(['systemctl', '--user', 'stop', old], check=True, env=env)
        subprocess.run(['systemctl', '--user', 'disable', old], check=True, env=env)
        subprocess.run(['systemctl', '--user', 'enable', new], check=True, env=env)
        subprocess.run(['systemctl', '--user', 'start', new], check=True, env=env)
        evidence('switched_at_physical_episode_boundary')
    print('Bounded native-invalid retry queue activated at the episode boundary.', flush=True)


if __name__ == '__main__':
    main()
