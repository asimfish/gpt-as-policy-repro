"""Keep active SQLite local; move sealed, fully audited workspaces to private NAS storage."""
import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat

ARTIFACTS = Path(__file__).resolve().parents[1]
NAME = re.compile(r'(?:direct|hybrid)_20[0-9]{6}T[0-9]{6}Z_[A-Za-z0-9]+_seed[0-9]+')


def read(path):
    return json.loads(path.read_text())


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()


def write(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def inventory(root, require_local_owner=True):
    """Reject links and special files before copying or removing any duplicate."""
    assert root.is_dir() and not root.is_symlink(), 'Regular workspace directory required'
    if require_local_owner:
        assert root.lstat().st_uid == os.getuid(), 'Local workspace ownership changed'
    files = {}
    for folder, dirs, names in os.walk(root, followlinks=False):
        for name in dirs + names:
            path = Path(folder) / name
            info = path.lstat()
            if require_local_owner:
                assert info.st_uid == os.getuid(), 'Local workspace ownership changed'
            assert stat.S_ISDIR(info.st_mode) or stat.S_ISREG(info.st_mode), 'Links/special files forbidden'
            if stat.S_ISREG(info.st_mode):
                files[str(path.relative_to(root))] = dict(size=info.st_size, sha256=digest(path))
    assert files, 'Empty workspace is not an offload candidate'
    return files


def validate(run, active, tmp_root):
    assert NAME.fullmatch(run.name) and run.is_dir() and not run.is_symlink()
    assert active.get('attempt') != run.name, 'Active workspace must stay local'
    record = read(run / 'attempt.json')
    expected = tmp_root / ('gpt-policy-robolab-' + run.name)
    assert record['attempt'] == run.name and Path(record['local_workspace']) == expected
    assert record.get('finished_utc'), 'Controller archival boundary not reached'
    assert read(run / 'remote_archive_receipt.json')['verified'] is True
    result = read(run / 'rollout/result.json')
    proof = read(run / 'complete_action_audit.json')
    assert result.get('complete') is True and (result['terminated'] or result['truncated'])
    assert proof.get('verified') is True and proof.get('complete_episode') is True
    assert proof['scope'] == 'complete_native_episode' and proof['method'] == record['method']
    assert proof['native_actions'] == result['step_id'] and proof['decisions'] == result['decisions']
    assert proof['terminal'] == {k: result[k] for k in ('success', 'terminated', 'truncated')}
    for name in ('rollout/result.json', 'rollout/run.json', 'rollout/codex_workspace/worker.json'):
        assert digest(run / name) == proof['files_sha256'][name], 'Audit identity changed'
    worker = read(run / 'rollout/codex_workspace/worker.json')
    for pid in (record.get('controller_pid'), record.get('tunnel_pid'), worker.get('pid')):
        assert pid is None or not Path('/proc/' + str(int(pid))).exists(), 'Recorded process still exists'
    return expected


def offload(run, active, cold_root, tmp_root=Path('/tmp')):
    source = validate(run, active, tmp_root)
    assert tmp_root.is_dir() and not tmp_root.is_symlink()
    assert cold_root.is_dir() and not cold_root.is_symlink()
    return offload_directory(source, cold_root / run.name,
                             lambda: validate(run, active, tmp_root), run.name)


def offload_directory(source, parent, revalidate, identity):
    """Shared byte-preserving transaction; callers supply an idle/audit boundary."""
    assert source.parent.is_dir() and not source.parent.is_symlink()
    assert parent.parent.is_dir() and not parent.parent.is_symlink()
    if parent.exists():
        assert parent.is_dir() and not parent.is_symlink()
    else:
        parent.mkdir(mode=0o700)
    destination = parent / 'workspace'
    pending = source.with_name(source.name + '.offload-pending')
    receipt_path = parent / 'receipt.json'
    if source.is_symlink():
        assert source.readlink() == destination, 'Unexpected workspace link'
        receipt = read(receipt_path)
        assert receipt['verified'] is True
        if pending.exists():
            assert inventory(destination, False) == receipt['files'] == inventory(pending)
            shutil.rmtree(pending)
        return dict(attempt=identity, status='already_offloaded', bytes=receipt['bytes'])
    if not source.exists() and pending.exists():
        # Recover the rename/link boundary after an interrupted maintenance process.
        receipt = read(receipt_path)
        assert receipt['verified'] is True
        assert inventory(destination, False) == receipt['files'] == inventory(pending)
        source.symlink_to(destination, target_is_directory=True)
        shutil.rmtree(pending)
        return dict(attempt=identity, status='offloaded', bytes=receipt['bytes'])
    assert not pending.exists(), 'Unrecognized maintenance staging directory'
    manifest = inventory(source)
    if destination.exists():
        assert destination.is_dir() and not destination.is_symlink()
        inventory(destination, False)
    else:
        destination.mkdir(mode=0o700)
    # Every source file is retained, including private database/log files. The
    # cold directory is outside all public report/bundle export allowlists.
    shutil.copytree(source, destination, dirs_exist_ok=True)
    # CIFS reports the NAS mount's uid (1000 here), not the local process uid.
    # Local ownership remains mandatory; NAS identity is the pinned path plus
    # regular-file/no-link checks and the exact size/SHA256 manifest.
    assert inventory(source) == manifest == inventory(destination, False), 'Cold copy differs'
    revalidate()
    receipt = dict(schema='gpt_policy_private_workspace_offload.v1', verified=True,
                   attempt=identity, bytes=sum(v['size'] for v in manifest.values()), files=manifest,
                   verified_utc=datetime.now(timezone.utc).isoformat())
    write(receipt_path, receipt)
    source.rename(pending)
    try:
        source.symlink_to(destination, target_is_directory=True)
    except BaseException:
        pending.rename(source)
        raise
    assert inventory(pending) == manifest, 'Source changed at the archival boundary; preserve it'
    shutil.rmtree(pending)
    return dict(attempt=identity, status='offloaded', bytes=receipt['bytes'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--limit', type=int, default=2)
    args = parser.parse_args()
    assert 1 <= args.limit <= 100
    cold = ARTIFACTS / 'private_runtime_archives'
    cold.mkdir(mode=0o700, exist_ok=True)
    results = []
    with Path('/tmp/gpt-policy-robolab-workspace-offload.lock').open('a') as owner:
        fcntl.flock(owner, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for run in sorted((ARTIFACTS / 'robolab_gpt_campaign').iterdir()):
            if not NAME.fullmatch(run.name):
                continue
            try:
                # Refresh active identity for each candidate; an old snapshot is
                # never sufficient to offload the current live episode.
                active = read(ARTIFACTS / 'robolab_gpt_active.json')
                result = offload(run, active, cold)
                results.append(result)
                if sum(r['status'] == 'offloaded' for r in results) >= args.limit:
                    break
            except (AssertionError, FileNotFoundError, KeyError, ValueError) as error:
                results.append(dict(attempt=run.name, status='preserved', reason_type=type(error).__name__,
                                    reason=str(error) if isinstance(error, AssertionError) else type(error).__name__))
        write(ARTIFACTS / 'runtime_storage_maintenance.json', dict(
            schema='gpt_policy_runtime_storage_maintenance.v1', updated_utc=datetime.now(timezone.utc).isoformat(),
            scope='Only stopped fully audited RoboLab workspaces; all bytes retained privately; active SQLite stays local',
            results=results))
    print(json.dumps(dict(offloaded=sum(r['status'] == 'offloaded' for r in results),
                         bytes_offloaded=sum(r['bytes'] for r in results if r['status'] == 'offloaded'))))


if __name__ == '__main__':
    main()
