"""Do not pay for unbounded native-invalid repeats or discard valid failures."""
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch
import run_all_gpt_pairs_v6_20261005 as queue


class NativeInvalidRetryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.cases = self.root/'cases'
        self.cases.mkdir()
        self.identity = dict(case_id='case', layout_sha256='a'*64)
        self.write(self.cases/'gpt__case.json', dict(identity=self.identity))
        self.patcher = patch.object(queue, 'CASES', self.cases)
        self.patcher.start()
        self.addCleanup(self.patcher.stop)

    def write(self, path, value):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(value))

    def attempt(self, index, *, valid=False, **changes):
        parent = self.root/str(index)
        result = dict(complete=True, truncated=True, terminated=False,
                      success=False, step_id=1600, evaluation_case=self.identity)
        outcome = dict(complete=True, valid_for_success_rate=valid,
                       status='native_completed' if valid else 'invalid_native_layout',
                       native_success=False if valid else None,
                       native_score=0 if valid else None,
                       native_control_steps=1600, evaluation_case=self.identity)
        outcome.update(changes)
        self.write(parent/'pi05_plus_gpt/rollout/result.json', result)
        self.write(parent/'pi05_plus_gpt/sim/evaluation_outcome.json', outcome)
        return parent, {}

    def test_three_explicit_native_exclusions_stop_physical_retry(self):
        runs = [self.attempt(i) for i in range(3)]
        self.assertFalse(queue.retry_blocked(runs[:2], 'pi05_plus_gpt'))
        self.assertTrue(queue.retry_blocked(runs, 'pi05_plus_gpt'))

    def test_scheduler_does_not_launch_another_invalid_pair(self):
        runs = [self.attempt(i) for i in range(3)]
        for parent, _ in runs:
            shutil.copytree(parent/'pi05_plus_gpt', parent/'gpt_only')
        observed = {('case', method): runs for method in ('gpt_only', 'pi05_plus_gpt')}
        class ObservedIdle(Exception):
            pass
        with patch.object(queue, 'ART', self.root), patch.object(queue, 'case_ids', return_value=['case']), \
             patch.object(queue, 'inventory', return_value=observed), \
             patch.object(queue, 'try_lock'), patch.object(queue, 'pair_service_active', return_value=False), \
             patch.object(queue, 'run_attempt', side_effect=AssertionError('Unbounded physical retry')) as launch, \
             patch.object(queue.time, 'sleep', side_effect=ObservedIdle):
            with self.assertRaises(ObservedIdle):
                queue.main()
            launch.assert_not_called()
        state = json.loads((self.root/'gpt_queue_state.json').read_text())
        self.assertEqual(state['status'], 'awaiting_native_layout_repair')
        self.assertTrue(all(job['status'] == 'native_invalid_requires_repair'
                            for job in state['cases']['case'].values()))

    def test_valid_native_failure_with_missing_audit_keeps_its_original_precedence(self):
        runs = [self.attempt(i) for i in range(3)] + [self.attempt(3, valid=True)]
        self.assertFalse(queue.retry_blocked(runs, 'pi05_plus_gpt'))
        self.assertTrue(queue.native_terminal(runs[-1][0], 'pi05_plus_gpt'))
        self.assertFalse(queue.terminal(runs[-1][0], 'pi05_plus_gpt'))

    def test_unknown_exclusion_or_contradictory_score_never_consumes_native_bound(self):
        for changes in [dict(status='incomplete'), dict(native_score=0),
                        dict(native_success=False), dict(valid_for_success_rate=True),
                        dict(complete=False), dict(native_control_steps=1599)]:
            with self.subTest(changes=changes):
                runs = [self.attempt(i, **changes) for i in range(3)]
                self.assertFalse(queue.retry_blocked(runs, 'pi05_plus_gpt'))

    def test_foreign_identity_cannot_close_or_exclude_the_frozen_job(self):
        runs = [self.attempt(i, evaluation_case=dict(case_id='other', layout_sha256='b'*64)) for i in range(3)]
        self.assertFalse(queue.retry_blocked(runs, 'pi05_plus_gpt'))

    def test_infrastructure_prefix_cannot_consume_native_bound(self):
        runs = [self.attempt(i) for i in range(3)]
        for parent, _ in runs:
            f = parent/'pi05_plus_gpt/rollout/result.json'
            d = json.loads(f.read_text());d['complete'] = False;d['truncated'] = False
            self.write(f, d)
        self.assertFalse(queue.retry_blocked(runs, 'pi05_plus_gpt'))


if __name__ == '__main__':
    unittest.main()
