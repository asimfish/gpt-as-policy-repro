import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import queue_robolab_parallel_v3_20261006 as queue
import robolab_parallel_state as state
import run_mainskill_robolab_services_v3_20261006 as services


def row(seed=0, method='gpt_only', status='pending', generation_attempts=0):
    return dict(task='BlocksInBinTask',seed=seed,method=method,status=status,generation_attempts=generation_attempts)


def lease(seed=0, slot=0, method='gpt_only', sim_gpu=0, policy_gpu=None):
    prefix='direct_' if method=='gpt_only' else 'hybrid_'
    return dict(row(seed,method),slot=slot,sim_gpu=sim_gpu,policy_gpu=policy_gpu,
        attempt=prefix+'20261006T000000Z_BlocksInBinTask_seed'+str(seed),supervisor_identity=dict(pid=123,boot_id='boot',start_ticks=42))


def record(reservation, **extra):
    return dict(task=reservation['task'],seed=reservation['seed'],method=reservation['method'],
        attempt=reservation['attempt'],worker_slot=reservation['slot'],**extra)


class ReservationTests(unittest.TestCase):
    def test_surviving_supervisor_is_adopted_even_if_native_marker_exists(self):
        item=lease()
        self.assertEqual(state.reconcile(item,record(item,finished_utc='now',remote_archive_verified=True),
            alive=lambda _:True,pid_exists=lambda _:False),'running')

    def test_lost_spawn_ack_adopts_identity_from_original_record(self):
        item=lease();identity=item.pop('supervisor_identity')
        self.assertEqual(state.reconcile(item,record(item,supervisor_identity=identity),
            alive=lambda got:got==identity),'running')
        self.assertEqual(state.reconcile(item,None,alive=lambda _:False),'blocked_uncertain_launch')

    def test_dead_supervisor_does_not_release_live_controller_or_incomplete_archive(self):
        item=lease()
        self.assertEqual(state.reconcile(item,record(item),alive=lambda _:False),'blocked_cleanup_unproven')
        terminal=record(item,finished_utc='now',remote_archive_verified=True,controller_pid=222)
        self.assertEqual(state.reconcile(item,terminal,alive=lambda _:False,pid_exists=lambda _:True),'blocked_cleanup_unproven')
        terminal['remote_archive_verified']=False
        self.assertEqual(state.reconcile(item,terminal,alive=lambda _:False,pid_exists=lambda _:False),'blocked_cleanup_unproven')
        terminal['remote_archive_verified']=True
        self.assertEqual(state.reconcile(item,terminal,alive=lambda _:False,pid_exists=lambda _:False),'released')

    def test_changed_original_identity_is_rejected(self):
        item=lease();original=record(item);original['seed']=1
        with self.assertRaises(ValueError):state.reconcile(item,original)

    def test_real_worker_lifetime_and_pid_reuse(self):
        proc=subprocess.Popen([sys.executable,'-c','import sys;sys.stdin.read()'],stdin=subprocess.PIPE)
        try:
            identity=state.process_identity(proc.pid)
            self.assertTrue(state.identity_alive(identity))
            self.assertFalse(state.identity_alive(dict(identity,start_ticks=identity['start_ticks']+1)))
            self.assertFalse(state.identity_alive(dict(identity,boot_id='different-boot')))
        finally:
            proc.stdin.close();proc.wait(timeout=5)
        self.assertFalse(state.identity_alive(identity))

    def test_atomic_reservation_roundtrip(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'lease.json';state.atomic_json(path,dict(leases=[lease()]))
            self.assertEqual(json.loads(path.read_text())['leases'],[lease()])


class SchedulingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.oracle=queue.load_oracle()

    def test_three_slots_use_distinct_gpus_ports_and_frozen_identities(self):
        rows=[row(i, 'pi05_plus_gpt') for i in range(5)]
        plans=queue.launch_plan(rows,[],{i:80000 for i in range(8)},3,self.oracle.key)
        self.assertEqual(len(plans),3)
        devices=[p[k] for p in plans for k in ('sim_gpu','policy_gpu')]
        self.assertEqual(len(set(devices)),6)
        self.assertEqual(len({self.oracle.key(p) for p in plans}),3)
        self.assertEqual(len({port for p in plans for port in state.slot_ports(p['slot'])}),6)

    def test_reserved_case_and_all_its_gpus_are_skipped_after_restart(self):
        held=lease(method='pi05_plus_gpt',sim_gpu=1,policy_gpu=0)
        rows=[row(0,'pi05_plus_gpt'),row(1),row(2)]
        plans=queue.launch_plan(rows,[held],{i:80000 for i in range(8)},3,self.oracle.key)
        self.assertEqual([p['slot'] for p in plans],[1,2])
        self.assertFalse(any(self.oracle.key(p)==self.oracle.key(held) for p in plans))
        self.assertFalse(any(p['sim_gpu'] in (0,1) for p in plans))

    def test_blocked_lease_occupies_capacity_and_serial_mode_is_bounded(self):
        held=lease();held['status']='blocked_uncertain_launch'
        self.assertEqual(queue.launch_plan([row(1)],[held],{0:80000,1:80000},1,self.oracle.key),[])
        self.assertEqual(len(queue.launch_plan([row(i) for i in range(5)],[],{0:80000,1:80000},1,self.oracle.key)),1)

    def test_no_gpu_capacity_does_not_create_an_attempt(self):
        self.assertEqual(queue.launch_plan([row(method='pi05_plus_gpt')],[],{0:39000,1:14999},3,self.oracle.key),[])
        with self.assertRaises(RuntimeError):services.select_gpus({0:1000,1:80000,2:80000},0,1,'gpt_only')
        with self.assertRaises(RuntimeError):services.select_gpus({0:80000,1:39000,2:80000},0,1,'pi05_plus_gpt')
        self.assertEqual(services.select_gpus({0:20000,1:50000},0,1,'pi05_plus_gpt'),(0,1))

    def test_duplicate_gpu_slot_or_case_reservations_are_denied(self):
        for held in ([lease(),lease(seed=1,slot=0,sim_gpu=1)],
                     [lease(),lease(seed=1,slot=1,sim_gpu=0)],
                     [lease(),lease(seed=0,slot=1,sim_gpu=1)]):
            with self.assertRaises(ValueError):queue.launch_plan([],held,{},3,self.oracle.key)

    def test_lease_paths_and_nonfrozen_identities_are_denied_before_io(self):
        for changed in (dict(attempt='../../other'),dict(task='UnknownTask'),dict(slot=3),dict(sim_gpu=True)):
            item=lease();item.update(changed)
            with self.assertRaises(ValueError):queue.validate_leases([item],[row()],self.oracle.key)

    def test_exact_pinned_oracle_keeps_native_failure_and_failed_audit(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);early=root/'early';later=root/'later'
            for path in (early,later):
                (path/'rollout').mkdir(parents=True)
                (path/'rollout/result.json').write_text(json.dumps(dict(complete=True,truncated=True)))
            attempts=[(later,dict(started_utc='2026-10-06')),(early,dict(started_utc='2026-10-03'))]
            classified=self.oracle.classify(row(),attempts,lambda path,_:dict(success=path==later,step_id=1350))
            self.assertEqual(classified['attempt'],'early');self.assertFalse(classified['success'])
            self.assertEqual(queue.launch_plan([classified],[],{0:80000},3,self.oracle.key),[])
            def reject(*_):raise ValueError('Missing full audit')
            classified=self.oracle.classify(row(),attempts,reject)
            self.assertEqual(classified['status'],'audit_failed')
            self.assertEqual(queue.launch_plan([classified],[],{0:80000},3,self.oracle.key),[])

    def test_existing_infrastructure_budget_and_fairness_are_unchanged(self):
        with tempfile.TemporaryDirectory() as tmp:
            attempts=[(Path(tmp),dict(started_utc='2026-10-05')) for _ in range(3)]
            exhausted=self.oracle.classify(row(),attempts)
            self.assertEqual(exhausted['status'],'infrastructure_retry_exhausted')
            self.assertEqual(queue.launch_plan([exhausted],[],{0:80000},3,self.oracle.key),[])
        plans=queue.launch_plan([row(0,generation_attempts=1),row(1)],[],{0:80000},1,self.oracle.key)
        self.assertEqual(plans[0]['seed'],1)


if __name__=='__main__':unittest.main()
