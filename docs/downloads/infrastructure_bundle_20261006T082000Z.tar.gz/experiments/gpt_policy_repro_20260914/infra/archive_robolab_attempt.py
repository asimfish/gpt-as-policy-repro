"""Resume only stopped RoboLab artifacts; verify every archived byte, without RPC or actions."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shlex
import signal
import stat
import subprocess
import tempfile
import threading
import time

from transfer_checkpoint_chunks import SSH

ARTIFACTS = Path(__file__).resolve().parents[1]
REMOTE_CAMPAIGN = '/home/dataset-assist-0/liyufeng/agentic_robot/experiments/gpt_policy_repro_20260914/robolab_gpt_campaign'
_CLEANUP_GUARD = '''def cleanup_guard(root, services, proc_root=Path('/proc')):
    if services['status'] not in ('starting', 'ready') and services.get('finished_utc'):
        return {'source': 'recorded_cleanup', 'finished_utc': services['finished_utc']}
    assert services.get('attempt') == root.name and (root/'STOP').is_file(), 'Stop request and owned attempt required'
    pids = [services.get('manager_pid'), services.get('simulator_pid')]
    if services.get('policy_pid') is not None:
        pids.append(services['policy_pid'])
    assert all(type(pid) is int and pid > 0 for pid in pids), 'Owned process identities required'
    assert all(not (proc_root/str(pid)).exists() for pid in pids), 'Owned process is still alive'
    for entry in proc_root.iterdir():
        if not entry.name.isdecimal():
            continue
        try:
            fields = (entry/'stat').read_text().rsplit(')', 1)[1].split()
        except FileNotFoundError:
            continue
        assert int(fields[2]) not in pids, 'Owned process group is still alive'
    return {'source': 'dead_owner_after_stop', 'absent_process_ids': pids}
'''
exec(_CLEANUP_GUARD)

REMOTE_MANIFEST = '''from pathlib import Path
import hashlib,json,sys
''' + _CLEANUP_GUARD + '''
root=Path(sys.argv[1]);services=json.loads((root/'services.json').read_text())
cleanup=cleanup_guard(root,services)
files={}
for path in sorted(root.rglob('*')):
 assert not path.is_symlink(), 'Do not archive symbolic links'
 if path.is_file():
  before=path.stat();h=hashlib.sha256()
  with path.open('rb') as stream:
   for block in iter(lambda:stream.read(8*1024*1024),b''):h.update(block)
  after=path.stat()
  assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns), 'Artifact changed during hashing'
  files[path.relative_to(root).as_posix()]={'size':after.st_size,'sha256':h.hexdigest()}
print(json.dumps({'schema':'gpt_policy_robolab_remote_archive.v1','cleanup':cleanup,'files':files}))
'''


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(8*1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def verify_archive(root, manifest):
    assert manifest['schema'] == 'gpt_policy_robolab_remote_archive.v1'
    assert manifest['files'], 'An empty transfer cannot qualify'
    total = 0
    for name, expected in manifest['files'].items():
        relative = PurePosixPath(name)
        assert relative.parts and not relative.is_absolute() and '..' not in relative.parts
        assert relative.as_posix() == name
        path = root.joinpath(*relative.parts)
        assert not any(part.is_symlink() for part in [path, *path.parents]), 'Archive paths must not follow links'
        assert path.is_file(), 'Missing archived file: '+name
        assert path.stat().st_size == expected['size'], 'Archived size differs: '+name
        assert digest(path) == expected['sha256'], 'Archived bytes differ: '+name
        total += expected['size']
    return dict(verified=True, files=len(manifest['files']), bytes=total)


def partitions(manifest, workers=4):
    """Disjoint byte-balanced lists bound each read-only transfer independently."""
    groups=[[] for _ in range(min(workers,len(manifest['files'])))];sizes=[0]*len(groups)
    assert groups, 'An empty transfer cannot qualify'
    for name,row in sorted(manifest['files'].items(),key=lambda pair:(-pair[1]['size'],pair[0])):
        relative=PurePosixPath(name)
        assert relative.parts and not relative.is_absolute() and '..' not in relative.parts
        assert relative.as_posix()==name and '\0' not in name
        assert type(row['size']) is int and row['size']>=0
        index=min(range(len(groups)),key=lambda i:sizes[i])
        groups[index].append(name);sizes[index]+=row['size']
    return groups


def live_process_group(group):
    alive=[]
    for entry in Path('/proc').iterdir():
        if not entry.name.isdecimal():continue
        try:fields=(entry/'stat').read_text().rsplit(')',1)[1].split()
        except (FileNotFoundError,ProcessLookupError,PermissionError):continue
        if int(fields[2])==group and fields[0] not in ('Z','X'):
            alive.append(int(entry.name))
    return alive


def run_rsync(command,timeout=1200):
    # A timed-out rsync parent can leave its receiver writing --partial files.
    # Each invocation owns a fresh process group; cleanup finishes before retry.
    proc=subprocess.Popen(command,start_new_session=True)
    try:
        code=proc.wait(timeout=timeout)
        if code:raise subprocess.CalledProcessError(code,command)
    finally:
        try:os.killpg(proc.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        try:proc.wait(timeout=10)
        except subprocess.TimeoutExpired as error:
            raise RuntimeError('Owned rsync cleanup did not finish; do not retry') from error
        deadline=time.monotonic()+10
        while live_process_group(proc.pid):
            if time.monotonic()>deadline:
                raise RuntimeError('Owned rsync group still alive; do not retry')
            time.sleep(.05)


def transfer_archive(source,target,manifest,ssh,progress=None):
    groups=partitions(manifest)
    with tempfile.TemporaryDirectory(prefix='gpt-policy-robolab-archive-plan.') as tmp:
        lists=[]
        for index,names in enumerate(groups):
            path=Path(tmp)/str(index);path.write_bytes(b''.join(name.encode()+b'\0' for name in sorted(names)));lists.append(path)
        def transfer(index,path):
            names=groups[index]
            event=dict(worker=index,files=len(names),bytes=sum(manifest['files'][name]['size'] for name in names))
            def emit(status,attempt,error=None):
                if progress is not None:
                    update=dict(event,status=status,attempt=attempt)
                    if error is not None:update['error_type']=type(error).__name__
                    progress(update)
            for attempt in range(3):
                emit('transferring',attempt+1)
                try:
                    run_rsync(['rsync','-az','--checksum','--partial','--timeout=90',
                        '--from0','--files-from='+str(path),'-e',shlex.join(ssh),source,str(target)+'/'])
                    emit('transferred',attempt+1)
                    return
                except (subprocess.TimeoutExpired,subprocess.CalledProcessError) as error:
                    emit('failed' if attempt==2 else 'retrying',attempt+1,error)
                    if attempt==2:raise
                    time.sleep(3)
        with ThreadPoolExecutor(max_workers=len(groups)) as pool:
            futures=[pool.submit(transfer,index,path) for index,path in enumerate(lists)]
            errors=[]
            for future in futures:
                try:future.result()
                except Exception as error:errors.append(error)
            if errors:raise errors[0]
    return len(groups)


def atomic_json(path,value):
    with tempfile.NamedTemporaryFile(mode='w',dir=path.parent,prefix='.'+path.name+'.',delete=False) as stream:
        temporary=Path(stream.name)
        try:
            json.dump(value,stream,indent=2);stream.write('\n');stream.flush()
        except BaseException:
            temporary.unlink(missing_ok=True)
            raise
    try:temporary.replace(path)
    finally:temporary.unlink(missing_ok=True)


def _archive_attempt(path, cipher):
    record = json.loads((path/'attempt.json').read_text())
    assert path.name == record['attempt'] and Path(path.name).name == path.name
    assert record['remote_output'] == REMOTE_CAMPAIGN+'/'+path.name
    cipher = cipher or record.get('ssh_cipher', 'default')
    assert cipher in ('default', 'aes128-gcm@openssh.com')
    ssh = [*SSH[:-1], *(['-o', 'Ciphers='+cipher] if cipher != 'default' else [])]
    state=dict(schema='gpt_policy_robolab_archive_transfer.v1',attempt=path.name,
               verification_scope='archived_bytes_only',verified=False,owner_pid=os.getpid(),
               started_utc=datetime.now(timezone.utc).isoformat(),workers={})
    mutex=threading.Lock()
    def persist(phase=None,event=None,**fields):
        with mutex:
            if phase is not None:state['phase']=phase
            state.update(fields)
            if event is not None:state['workers'][str(event['worker'])]=dict(event,updated_utc=datetime.now(timezone.utc).isoformat())
            done=[row for row in state['workers'].values() if row['status']=='transferred']
            state.update(transferred_groups=len(done),transferred_files=sum(row['files'] for row in done),
                         transferred_bytes=sum(row['bytes'] for row in done),updated_utc=datetime.now(timezone.utc).isoformat())
            atomic_json(path/'remote_archive_transfer.json',state)
    persist('fetching_manifest')
    try:
        source = subprocess.run([*ssh, SSH[-1], shlex.join(['python3', '-c', REMOTE_MANIFEST, record['remote_output']])],
                                capture_output=True, text=True, check=True, timeout=180)
        manifest = json.loads(source.stdout)
        assert manifest['schema']=='gpt_policy_robolab_remote_archive.v1'
        groups=partitions(manifest)
        seal=path/'remote_archive_manifest.json'
        assert not seal.is_symlink(), 'Archive seal must not follow links'
        if seal.exists():
            if json.loads(seal.read_text())!=manifest:
                raise ValueError('Stopped archive manifest changed; preserve original seal')
        else:atomic_json(seal,manifest)
        target = path/'remote'
        target.mkdir(exist_ok=True)
        persist('transferring',planned_files=len(manifest['files']),planned_bytes=sum(row['size'] for row in manifest['files'].values()),
                planned_groups=len(groups),manifest_sha256=digest(seal))
        # Each file belongs to one worker; only artifact reads are retried.
        workers=transfer_archive(SSH[-1]+':'+record['remote_output']+'/',target,manifest,ssh,
                                 progress=lambda event:persist(event=event))
        persist('verifying')
        receipt=verify_archive(target,manifest)
        receipt.update(schema='gpt_policy_robolab_archive_receipt.v1', ssh_cipher=cipher,
                       transfer_workers=workers,cleanup=manifest['cleanup'],
                       manifest_sha256=digest(seal),verified_utc=datetime.now(timezone.utc).isoformat())
        atomic_json(path/'remote_archive_receipt.json',receipt)
        persist('verified',verified=True)
        return receipt
    except BaseException as error:
        persist('failed',verified=False,error_type=type(error).__name__)
        raise


def archive_attempt(path, cipher=None):
    # Local flock covers the seal, worker status and receipt as one owned transfer.
    identity=hashlib.sha256(str(path.resolve()).encode()).hexdigest()
    lock_path='/tmp/gpt-policy-robolab-archive-'+identity+'.lock'
    descriptor=os.open(lock_path,os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW,0o600)
    with os.fdopen(descriptor,'a') as lock:
        info=os.fstat(lock.fileno())
        assert info.st_uid==os.getuid() and stat.S_ISREG(info.st_mode), 'Archive lock must be an owned regular file'
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        return _archive_attempt(path,cipher)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('attempt')
    args = parser.parse_args()
    assert Path(args.attempt).name == args.attempt and args.attempt.startswith(('direct_', 'hybrid_'))
    print(json.dumps(archive_attempt(ARTIFACTS/'robolab_gpt_campaign'/args.attempt)))
