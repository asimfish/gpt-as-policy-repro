"""Sequential frozen RoboLab Direct/Hybrid campaign; first native terminals and infra retries stay distinct."""
from datetime import datetime,timezone
import fcntl
import hashlib
import json
from pathlib import Path
import signal
import subprocess
import sys
import time
from audit_robolab_gpt_actions import audit,digest

ARTIFACTS=Path(__file__).resolve().parents[1]
REPAIR_EPOCH="2026-10-04T16:30:00+00:00"


def write(path,value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(path)


def read(path,default=None):
    try:return json.loads(path.read_text())
    except FileNotFoundError:return default


def key(row):
    return row['task']+'__seed'+str(row['seed'])+'__'+row['method']


def native_complete(path):
    result=read(path/'rollout/result.json',{})
    return result.get('complete') is True and (result.get('terminated') is True or result.get('truncated') is True)


def qualified(path,row):
    identity=read(path/'rollout/run.json')
    assert (identity['task'],identity['seed'])==(row['task'],row['seed'])
    assert (identity.get('evaluation_method')=='gpt_only')==(row['method']=='gpt_only')
    proof=read(path/'complete_action_audit.json')
    if proof is None:
        proof=audit(path)
        write(path/'complete_action_audit.json',proof)
    assert proof['verified'] is True and proof['complete_episode'] is True
    assert proof['scope']=='complete_native_episode' and proof['method']==row['method']
    assert (proof['model'],proof['reasoning_effort'])==('gpt-6-astra','xhigh')
    result=read(path/'rollout/result.json')
    assert proof['native_actions']==result['step_id'] and proof['decisions']==result['decisions']
    assert proof['terminal']=={k:result[k] for k in ('terminated','truncated','success')}
    for name in ('rollout/result.json','rollout/run.json','rollout/codex_workspace/worker.json'):
        assert digest(path/name)==proof['files_sha256'][name]
    return result


def classify(row,attempts,qualifier=qualified,max_attempts=3):
    # Never skip a native failure or failed full audit to pick a later success.
    attempts=sorted(attempts,key=lambda pair:pair[1]['started_utc'])
    generation_attempts=sum(record['started_utc']>=REPAIR_EPOCH for _,record in attempts)
    status=dict(status='pending',attempts=len(attempts),generation_attempts=generation_attempts,task=row['task'],seed=row['seed'],method=row['method'])
    for path,record in attempts:
        if native_complete(path):
            try:
                result=qualifier(path,row)
                status.update(status='complete',attempt=path.name,success=result['success'],control_steps=result['step_id'])
            except Exception as error:
                status.update(status='audit_failed',attempt=path.name,error_type=type(error).__name__)
            return status
    if generation_attempts>=max_attempts:status['status']='infrastructure_retry_exhausted'
    return status


def choose(rows):
    eligible=[(i,row) for i,row in enumerate(rows) if row['status']=='pending']
    return min(eligible,key=lambda pair:(pair[1]['generation_attempts'],pair[0]))[1] if eligible else None


def inventory(entries):
    grouped={key(row):[] for row in entries}
    for path in (ARTIFACTS/'robolab_gpt_campaign').iterdir():
        if not path.is_dir():continue
        record=read(path/'attempt.json')
        if record and key(record) in grouped:grouped[key(record)].append((path,record))
    return [classify(row,grouped[key(row)]) for row in entries]


def main():
    frozen_path=ARTIFACTS/'fixtures/robolab_two_methods_frozen.json'
    frozen=read(frozen_path);entries=frozen['entries']
    assert len(entries)==100 and len({key(row) for row in entries})==100
    assert {row['method'] for row in entries}=={'gpt_only','pi05_plus_gpt'}
    campaign=ARTIFACTS/'robolab_gpt_campaign';campaign.mkdir(exist_ok=True)
    proc=None
    def terminate(*_):raise KeyboardInterrupt('Stopping this owned queue without replaying actions')
    signal.signal(signal.SIGTERM,terminate)
    with Path('/tmp/gpt-policy-robolab-two-methods-queue.lock').open('a') as queue_lock:
        fcntl.flock(queue_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        try:
            while True:
                # The already-running first episode owns the controller lock. Wait
                # for its archive/cleanup boundary; never stop it to start a queue.
                with Path('/tmp/gpt-policy-robolab-hybrid-controller.lock').open('a') as active_lock:
                    fcntl.flock(active_lock,fcntl.LOCK_EX)
                    rows=inventory(entries)
                done=sum(row['status']=='complete' for row in rows)
                candidate=choose(rows)
                state=dict(schema='gpt_policy_robolab_queue.v2',frozen_sha256=digest(frozen_path),
                    planned_method_runs=100,complete_method_runs=done,entries=rows,
                    status='complete' if done==100 else 'running' if candidate else 'incomplete_requires_intervention',
                    updated_utc=datetime.now(timezone.utc).isoformat(),
                    direct_implementation='owned_EEF_adapter; historical Direct source/prompt unavailable',
                    repair_epoch=REPAIR_EPOCH,
                    retry_policy='First native complete attempt across all history retained; max3 fresh infra attempts after verified asset/GPU/archive repairs; no ambiguous ACK replay')
                write(ARTIFACTS/'robolab_gpt_queue_state.json',state)
                if done==100:return
                if not candidate:
                    time.sleep(60);continue
                argv=[sys.executable,str(ARTIFACTS/'infra/run_robolab_hybrid_remote.py'),
                    '--method',candidate['method'],'--task',candidate['task'],'--seed',str(candidate['seed']),
                    '--sim-port','20600','--policy-port','20610','--policy-gpu','0','--sim-gpu','6','--ssh-cipher','aes128-gcm@openssh.com']
                with (ARTIFACTS/'robolab_gpt_queue.log').open('a') as log:
                    proc=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT)
                    proc.wait();proc=None
        finally:
            if proc is not None and proc.poll() is None:
                proc.terminate()
                try:proc.wait(timeout=140)
                except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=10)


if __name__=='__main__':main()
