"""Hand over the owned serial queue only after native physics, cleanup and archive."""
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess

from robolab_parallel_state import atomic_json

ARTIFACTS=Path(__file__).resolve().parents[1]


def verify_manifest(source):
    manifest=json.loads((source/'robolab_queue_scheduler_v3_manifest.json').read_text())
    for name,sha in manifest['files_sha256'].items():
        if Path(name).name!=name or hashlib.sha256((source/'infra'/name).read_bytes()).hexdigest()!=sha:
            raise ValueError('Parallel queue differs from reviewed source')
    frozen=source/'fixtures/robolab_two_methods_frozen.json'
    if hashlib.sha256(frozen.read_bytes()).hexdigest()!=manifest['frozen_sha256']:
        raise ValueError('Frozen cohort changed')
    deployment=json.loads((source/'robolab_parallel_deployment_receipt.json').read_text())
    name='run_mainskill_robolab_services_v3_20261006.py'
    if deployment['verified'] is not True or deployment['sha256']!=manifest['files_sha256'][name]:
        raise ValueError('Remote deployment must match the reviewed manager')
    return manifest


def main():
    source=ARTIFACTS
    manifest=verify_manifest(source)
    old='gpt-policy-robolab-two-methods-v2.service'
    new='gpt-policy-robolab-parallel-v3.service'
    env=dict(os.environ,XDG_RUNTIME_DIR='/run/user/1007',DBUS_SESSION_BUS_ADDRESS='unix:path=/run/user/1007/bus')
    def persist(status):
        atomic_json(source/'robolab_parallel_handover_20261006.json',dict(status=status,
            old_unit=old,new_unit=new,files_sha256=manifest['files_sha256'],
            frozen_sha256=manifest['frozen_sha256'],observed_utc=datetime.now(timezone.utc).isoformat()))
    persist('waiting_for_current_controller_and_archive_boundary')
    with open('/tmp/gpt-policy-robolab-hybrid-controller.lock','a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        verify_manifest(source)
        subprocess.run(['systemctl','--user','stop',old],check=True,env=env,timeout=200)
        subprocess.run(['systemctl','--user','disable',old],check=True,env=env,timeout=30)
        subprocess.run(['systemctl','--user','enable',new],check=True,env=env,timeout=30)
        subprocess.run(['systemctl','--user','start',new],check=True,env=env,timeout=30)
        persist('switched_at_controller_and_archive_boundary')


if __name__=='__main__':main()
