from pathlib import Path
import unittest
from unittest.mock import Mock

from run_robodojo_valid_supplement import classify


class NoPolicyOutcomeReplacement(unittest.TestCase):
    def test_earliest_native_failure_is_retained(self):
        queue = Mock()
        failed, later_success = Path('first_failure'), Path('later_success')
        queue.native_terminal.return_value = True
        queue.terminal.return_value = True
        status, selected = classify(queue, [(failed, {}), (later_success, {})], 'gpt_only')
        self.assertEqual((status, selected), ('complete', failed))
        queue.audit_run.assert_not_called()

    def test_native_audit_gap_blocks_fresh_physics(self):
        queue = Mock(); queue.native_terminal.return_value = True
        queue.terminal.return_value = False
        parent = Path('full_episode')
        self.assertEqual(classify(queue, [(parent, {})], 'gpt_only'), ('audit_failed', parent))
        queue.audit_run.assert_called_once_with(parent, 'gpt_only')

    def test_native_invalid_and_infrastructure_bounds(self):
        queue = Mock(); queue.native_terminal.return_value = False
        queue.retry_blocked.return_value = True
        rows = [(Path(str(i)), {}) for i in range(3)]
        self.assertEqual(classify(queue, rows, 'pi05_plus_gpt')[0], 'native_invalid_requires_repair')
        queue.retry_blocked.return_value = False
        self.assertEqual(classify(queue, rows, 'pi05_plus_gpt')[0], 'retry_budget_exhausted')
        self.assertEqual(classify(queue, [], 'pi05_plus_gpt')[0], 'pending')


if __name__ == '__main__': unittest.main()
