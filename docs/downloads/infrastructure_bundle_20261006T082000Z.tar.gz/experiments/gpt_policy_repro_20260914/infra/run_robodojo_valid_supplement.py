"""Run the two newly selected episodes; keep original v6 and its state intact."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import time

from robodojo_valid_cohort import validate, ADDED, CASE_DIR, COHORT

ART = Path(__file__).resolve().parents[1]
QUALIFICATION_SHA = 'c940b0ad975430c776c88c4f77a07386c27a0e49b7ae7333b165c4424d77f40d'
STATE = ART / 'robodojo_valid_queue_state.json'


def load_queue(root=ART):
    source = root / 'infra/run_all_gpt_pairs_v6_20261005.py'
    assert hashlib.sha256(source.read_bytes()).hexdigest() == QUALIFICATION_SHA
    spec = importlib.util.spec_from_file_location('valid_cohort_qualification', source)
    queue = importlib.util.module_from_spec(spec); spec.loader.exec_module(queue)
    queue.ART = root
    queue.CASES = root / CASE_DIR
    queue.CAMPAIGN = root / 'gpt_pair_campaign'
    return queue


def classify(queue, runs, method):
    # The first complete native failure or audit gap blocks another physical run.
    completed = next((parent for parent, _ in runs if queue.native_terminal(parent, method)), None)
    if completed:
        if not queue.terminal(completed, method): queue.audit_run(completed, method)
        return ('complete' if queue.terminal(completed, method) else 'audit_failed'), completed
    if queue.retry_blocked(runs, method): return 'native_invalid_requires_repair', None
    if len(runs) >= 3: return 'retry_budget_exhausted', None
    return 'pending', None


def main():
    doc = validate(ART)
    queue = load_queue()
    state = dict(schema='robodojo.valid_supplement_queue.v2', cohort_id=COHORT,
        qualification_source_sha256=QUALIFICATION_SHA, cases={},
        started_utc=datetime.now(timezone.utc).isoformat())
    while True:
        validate(ART)
        observed = queue.inventory()
        pending = []
        for row in doc['cases']:
            cid = row['case_id']
            jobs = state['cases'].setdefault(cid, {})
            for method in ('gpt_only', 'pi05_plus_gpt'):
                runs = observed.get((cid, method), [])
                status, complete = classify(queue, runs, method)
                jobs[method] = dict(status=status, attempts=len(runs))
                if complete: jobs[method]['last_output'] = str(complete)
                if status == 'pending':
                    # This additive queue cannot retry or overwrite original jobs.
                    assert cid == ADDED, 'Unfinished original case requires its original queue'
                    pending.append((cid, method, len(runs)))
        state['updated_utc'] = datetime.now(timezone.utc).isoformat()
        all_complete = all(j['status'] == 'complete' for jobs in state['cases'].values() for j in jobs.values())
        state['status'] = 'complete' if all_complete else 'pending' if pending else 'awaiting_audit_or_retry_budget'
        queue.atomic_json(STATE, state)
        if all_complete:
            state['finished_utc'] = state['updated_utc']; queue.atomic_json(STATE, state); return
        if not pending:
            time.sleep(60); continue
        handle = queue.try_lock()
        if handle is None or queue.pair_service_active():
            if handle is not None: handle.close()
            time.sleep(30); continue
        handle.close()  # The supervisor acquires the same physical-episode lock.
        cid, method = queue.choose_next(pending)
        parent = queue.CAMPAIGN / f'valid2_{queue.utc_stamp()}_{method}_{cid}'
        state['cases'][cid][method].update(status='running', last_output=str(parent))
        state['status'] = 'running'; queue.atomic_json(STATE, state)
        cmd = ['bash', str(ART / 'infra/run_gpt_pair.sh'), '--case', cid,
            '--case-dir', str(ART / CASE_DIR), '--method', method, '--output', str(parent),
            '--gpu', os.environ.get('GPT_QUEUE_GPU', '1'), '--continue-after-failure',
            '--lock-path', str(queue.LOCK_PATH)]
        code = subprocess.run(cmd).returncode
        queue.audit_run(parent, method)
        state['cases'][cid][method].update(last_returncode=code, last_output=str(parent))
        queue.atomic_json(STATE, state)
        if not queue.terminal(parent, method): time.sleep(90)


if __name__ == '__main__': main()
