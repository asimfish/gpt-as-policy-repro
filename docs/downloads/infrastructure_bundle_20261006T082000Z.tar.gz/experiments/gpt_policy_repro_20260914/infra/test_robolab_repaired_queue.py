import json
from pathlib import Path
import tempfile
import unittest
import queue_robolab_two_methods_v2_20261005 as queue


class RepairedQueueTests(unittest.TestCase):
    def test_repaired_infrastructure_has_a_new_bounded_budget(self):
        row=dict(task='blocks',seed=0,method='gpt_only')
        with tempfile.TemporaryDirectory() as tmp:
            old=[(Path(tmp),dict(started_utc='2026-10-03T00:00:00+00:00')) for _ in range(3)]
            status=queue.classify(row,old)
            self.assertEqual(status['status'],'pending');self.assertEqual(status['attempts'],3)
            new=[(Path(tmp),dict(started_utc='2026-10-05T00:00:00+00:00')) for _ in range(3)]
            self.assertEqual(queue.classify(row,old+new)['status'],'infrastructure_retry_exhausted')

    def test_old_native_failure_and_audit_gap_still_block_later_retries(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'rollout').mkdir()
            (root/'rollout/result.json').write_text(json.dumps(dict(complete=True,terminated=False,truncated=True)))
            row=dict(task='blocks',seed=0,method='gpt_only');attempts=[(root,dict(started_utc='2026-10-03'))]
            result=queue.classify(row,attempts,lambda *_:dict(success=False,step_id=10))
            self.assertEqual(result['status'],'complete');self.assertFalse(result['success'])
            def reject(*_):raise AssertionError('Missing audit')
            result=queue.classify(row,attempts,reject)
            self.assertEqual(result['status'],'audit_failed');self.assertIsNone(queue.choose([result]))

    def test_new_generation_is_fair_to_previously_exhausted_jobs(self):
        self.assertEqual(queue.choose([dict(status='pending',attempts=2,generation_attempts=1,id='retried'),
                                     dict(status='pending',attempts=3,generation_attempts=0,id='repaired')])['id'],'repaired')


if __name__=='__main__':unittest.main()
