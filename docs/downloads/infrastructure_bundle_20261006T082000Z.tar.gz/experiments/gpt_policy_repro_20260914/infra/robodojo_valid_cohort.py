"""Additive, immutable cohort selection; original fixtures and outcomes stay intact."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import shutil

REMOVED = 'imitate_sorting_sequence__standard__g0__l4'
ADDED = 'imitate_sorting_sequence__standard__g0__l5'
COHORT = 'robodojo_valid50_v2'
MANIFEST = 'fixtures/robodojo_valid_cohort_v2.json'
POINTER = 'fixtures/robodojo_active_cohort.json'
CASE_DIR = 'fixtures/cases_valid_v2'
DIAG = 'publication_checks/native_layout_20261005'
IDENTITY_KEYS = ('case_id', 'task', 'runtime_task', 'variant', 'eval_seed',
                 'layout_id', 'reset_seed', 'simulator_initial_seed', 'policy_rng_seed')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
        ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def local(root, name):
    p = PurePosixPath(name)
    assert not p.is_absolute() and p.parts and p.as_posix() == name
    assert all(part not in ('.', '..') for part in p.parts)
    target = root
    for part in p.parts:
        target = target / part
        assert not target.is_symlink(), 'Cohort input must not be a symlink'
    return target


def read(root, name):
    return json.loads(local(root, name).read_text())


def identity(panel, case):
    return dict(panel_id=panel['panel_id'], panel_sha256=panel['panel_sha256'],
                **{k: case[k] for k in IDENTITY_KEYS}, layout_sha256=case['layout']['sha256'])


def validate(root, pointer=None):
    root = Path(root).resolve()
    pointer = pointer or read(root, POINTER)
    assert pointer['cohort_id'] == COHORT and pointer['manifest'] == MANIFEST
    assert sha(local(root, MANIFEST)) == pointer['manifest_sha256']
    doc = read(root, MANIFEST)
    assert doc['schema'] == 'robodojo.valid_cohort.v2' and doc['cohort_id'] == COHORT
    assert doc['fixture_dir'] == CASE_DIR and doc['retain_original_outcomes'] is True
    assert doc['decision']['user_instruction'] == '继续推进'
    assert doc['decision']['basis'] == 'user_continue_20261006_after_reviewable_replacement_proposal'
    assert sha(local(root, 'fixtures/evaluation_manifest.json')) == doc['parent_manifest_file_sha256']
    panel = read(root, 'fixtures/evaluation_manifest.json')
    assert panel['panel_sha256'] == doc['parent_panel_sha256'] == canonical(
        {k: v for k, v in panel.items() if k != 'panel_sha256'})
    originals = sorted(p.name for p in local(root, 'fixtures/cases').glob('*.json'))
    assert originals == sorted(doc['original_fixture_sha256']) and len(originals) == 100
    for name, digest in doc['original_fixture_sha256'].items():
        assert re.fullmatch(r'(gpt|mix)__[A-Za-z0-9_]+\.json', name)
        assert sha(local(root, 'fixtures/cases/' + name)) == digest, 'Original fixture changed'
    for name, digest in doc['diagnostic_sha256'].items():
        assert sha(local(root, name)) == digest, 'Diagnostic proof changed'
    proposal = read(root, DIAG + '/replacement_proposal.json')
    assert proposal['replace_paired_case'] == REMOVED and proposal['with_case'] == ADDED
    assert proposal['retain_all_original_artifacts'] is True
    original_ids = {name.removeprefix('gpt__').removesuffix('.json')
                    for name in originals if name.startswith('gpt__')}
    selected = doc['cases']
    selected_ids = {row['case_id'] for row in selected}
    assert len(original_ids) == len(selected) == len(selected_ids) == 50
    assert selected_ids == original_ids - {REMOVED} | {ADDED}
    assert {row['case_id']: row for row in selected} == {
        row['case_id']: row for row in proposal['proposed_cases']}
    assert doc['replacement'] == dict(removed=REMOVED, added=ADDED,
        methods=['gpt_only', 'pi05_plus_gpt'], reason='invalid_original_native_demonstration')
    native = {c['case_id']: c for c in panel['cases']}
    assert set(original_ids) | {ADDED} <= native.keys()
    for row in selected:
        assert row == identity(panel, native[row['case_id']])
    names = sorted(p.name for p in local(root, CASE_DIR).glob('*.json'))
    assert names == sorted(doc['selected_fixture_sha256']) and len(names) == 100
    for row in selected:
        cid = row['case_id']
        for prefix in ('gpt', 'mix'):
            name = prefix + '__' + cid + '.json'
            target = local(root, CASE_DIR + '/' + name)
            assert sha(target) == doc['selected_fixture_sha256'][name]
            fixture = json.loads(target.read_text())
            assert fixture == dict(case=native[cid], identity=row, method=prefix,
                                   public_case_id=prefix + '__' + cid)
            if cid != ADDED:
                assert sha(target) == doc['original_fixture_sha256'][name]
    configs = []
    for seed, cid, valid in ((4, REMOVED, False), (5, ADDED, True)):
        base = DIAG + '/hold_seed' + str(seed)
        proof = read(root, base + '/diagnostic_integrity.json')
        support = read(root, base + '/sim/support_validation.json')
        outcome = read(root, base + '/sim/evaluation_outcome.json')
        assert proof['benchmark_eligible'] is False
        assert proof['model_calls'] == proof['policy_calls'] == 0
        assert proof['native_actions_verified'] == 1600 and proof['original_video_frames'] == 1601
        assert proof['all_actions_match_initial_robot_state'] is True
        assert support['model_calls'] == 0 and support['benchmark_eligible'] is False
        assert support['support_actions_remaining'] == 0 and support['support_queries'] == 1
        assert support['unstable'] is (not valid)
        assert (all(v == 1 for v in support['aim_in_basket1'].values())) is valid
        assert outcome['evaluation_case'] == identity(panel, native[cid])
        assert outcome['complete'] is True and outcome['valid_for_success_rate'] is valid
        assert outcome['native_control_steps'] == outcome['native_step_limit'] == 1600
        assert proof['sha256']['support_validation.json'] == sha(local(root, base + '/sim/support_validation.json'))
        assert proof['sha256']['evaluation_outcome.json'] == sha(local(root, base + '/sim/evaluation_outcome.json'))
        configs.append(sha(local(root, base + '/sim/resolved_config.json')))
        assert configs[-1] == proof['sha256']['resolved_config.json']
    assert configs[0] == configs[1], 'Native configurations differ'
    return doc


def freeze(root):
    """Execute the reviewed single paired replacement, never overwrite its inputs."""
    root = Path(root).resolve()
    if local(root, POINTER).exists():
        return validate(root)
    assert not local(root, MANIFEST).exists() and not local(root, CASE_DIR).exists()
    proposal = read(root, DIAG + '/replacement_proposal.json')
    panel = read(root, 'fixtures/evaluation_manifest.json')
    original = {p.name: sha(p) for p in local(root, 'fixtures/cases').glob('*.json')}
    stage = local(root, CASE_DIR + '.preparing')
    stage.mkdir(exist_ok=False)
    native = {c['case_id']: c for c in panel['cases']}
    for row in proposal['proposed_cases']:
        for prefix in ('gpt', 'mix'):
            name = prefix + '__' + row['case_id'] + '.json'
            if row['case_id'] != ADDED:
                shutil.copyfile(local(root, 'fixtures/cases/' + name), stage / name)
            else:
                value = dict(case=native[ADDED], identity=identity(panel, native[ADDED]),
                             method=prefix, public_case_id=prefix + '__' + ADDED)
                (stage / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    stage.rename(local(root, CASE_DIR))
    refs = [DIAG + '/replacement_proposal.json']
    for seed in (4, 5):
        refs.extend(DIAG + '/hold_seed' + str(seed) + '/' + name for name in (
            'diagnostic_integrity.json', 'sim/support_validation.json',
            'sim/evaluation_outcome.json', 'sim/resolved_config.json'))
    doc = dict(schema='robodojo.valid_cohort.v2', cohort_id=COHORT,
        frozen_utc=datetime.now(timezone.utc).isoformat(), fixture_dir=CASE_DIR,
        parent_manifest_file_sha256=sha(local(root, 'fixtures/evaluation_manifest.json')),
        parent_panel_sha256=panel['panel_sha256'], retain_original_outcomes=True,
        decision=dict(user_instruction='继续推进',
            basis='user_continue_20261006_after_reviewable_replacement_proposal',
            scope='Separate valid50 report; preserve original50 statistics and all attempts'),
        replacement=dict(removed=REMOVED, added=ADDED, methods=['gpt_only', 'pi05_plus_gpt'],
            reason='invalid_original_native_demonstration'), cases=proposal['proposed_cases'],
        original_fixture_sha256=original, diagnostic_sha256={name: sha(local(root, name)) for name in refs},
        selected_fixture_sha256={p.name: sha(p) for p in local(root, CASE_DIR).glob('*.json')})
    local(root, MANIFEST).write_text(json.dumps(doc, ensure_ascii=False, indent=2) + '\n')
    pointer = dict(cohort_id=COHORT, manifest=MANIFEST, manifest_sha256=sha(local(root, MANIFEST)))
    validate(root, pointer)
    # Selection becomes visible only after the full manifest has passed validation.
    local(root, POINTER).write_text(json.dumps(pointer, indent=2) + '\n')
    return doc


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('root', type=Path)
    parser.add_argument('--freeze', action='store_true')
    args = parser.parse_args()
    doc = freeze(args.root) if args.freeze else validate(args.root)
    print(json.dumps(dict(cohort_id=doc['cohort_id'], cases=len(doc['cases']),
        replacement=doc['replacement'], retain_original_outcomes=doc['retain_original_outcomes'])))
