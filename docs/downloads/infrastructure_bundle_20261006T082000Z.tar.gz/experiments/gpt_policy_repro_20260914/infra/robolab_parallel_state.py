"""Pure reservation boundaries; ambiguity never authorizes another physical launch."""
import json
import os
from pathlib import Path
import tempfile


def atomic_json(path, value):
    path = Path(path)
    with tempfile.NamedTemporaryFile('w', dir=path.parent, delete=False) as stream:
        temp = Path(stream.name)
        json.dump(value, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    temp.replace(path)
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def slot_ports(slot):
    if type(slot) is not int or slot not in range(3):
        raise ValueError('Expected one of three isolated slots')
    return 20700 + 20 * slot, 20710 + 20 * slot


def process_identity(pid, proc_root=Path('/proc')):
    if type(pid) is not int or pid <= 0:
        raise ValueError('Positive process ID required')
    try:
        fields = (proc_root / str(pid) / 'stat').read_text().rsplit(')', 1)[1].split()
        if fields[0] in ('Z', 'X'):
            return None
        return dict(pid=pid, boot_id=(proc_root / 'sys/kernel/random/boot_id').read_text().strip(),
                    start_ticks=int(fields[19]))
    except (FileNotFoundError, ProcessLookupError):
        return None


def identity_alive(identity):
    return bool(identity and process_identity(identity['pid']) == identity)


def reconcile(lease, record, alive=identity_alive, pid_exists=lambda pid: Path('/proc', str(pid)).exists()):
    """Only verified cleanup releases a slot; a lost spawn ACK is fail closed."""
    identity = lease.get('supervisor_identity')
    if record:
        expected = (lease['task'], lease['seed'], lease['method'], lease['attempt'], lease['slot'])
        actual = tuple(record.get(k) for k in ('task', 'seed', 'method', 'attempt', 'worker_slot'))
        if actual != expected:
            raise ValueError('Reservation identity differs from the original attempt')
        identity = identity or record.get('supervisor_identity')
    if identity and alive(identity):
        return 'running'
    if not identity:
        return 'blocked_uncertain_launch'
    if not record or not record.get('finished_utc'):
        return 'blocked_cleanup_unproven'
    if any(pid_exists(record[k]) for k in ('controller_pid', 'tunnel_pid') if record.get(k)):
        return 'blocked_cleanup_unproven'
    return 'released' if record.get('remote_archive_verified') is True else 'blocked_cleanup_unproven'


def resources(free, reserved, method):
    """Exact reservations; memory thresholds match the pinned serial manager."""
    available = sorted((i for i in free if i not in reserved), key=lambda i: (-free[i], i))
    if method == 'gpt_only':
        for sim in available:
            if free[sim] >= 15000:
                return dict(sim_gpu=sim, policy_gpu=None)
    elif method == 'pi05_plus_gpt':
        for policy in available:
            if free[policy] >= 40000:
                for sim in available:
                    if sim != policy and free[sim] >= 15000:
                        return dict(sim_gpu=sim, policy_gpu=policy)
    else:
        raise ValueError('Only the two frozen methods are supported')
    return None
