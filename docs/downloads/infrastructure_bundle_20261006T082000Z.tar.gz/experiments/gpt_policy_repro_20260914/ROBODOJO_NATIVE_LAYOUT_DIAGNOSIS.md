# RoboDojo 最后一对案例的原生演示失效

2026-10-05。当前主实验为99个有效完整审计回合、49对；没有完成100回合。

冻结案例 `imitate_sorting_sequence__standard__g0__l4` 的四个 Hybrid 原回合均走满1600控制步，
原生结果明确为 `invalid_native_layout`、`valid_for_success_rate=false`、native success/score均null。
录像显示辅助演示臂的手表仍在桌上，其他四件演示物品在后方篮子中。
原Direct回合在300步原生终止失败，当时辅助演示尚未在432步接受最终稳定性检查。
原Direct结果仍按当时原生评估器的有效完整失败保留，不能倒改原结果。

竞争解释包括策略与辅助臂干涉、资产缺失或漂移、原生演示轨迹在固定物理环境中重放失败。
为区分它们，独立启动相同冻结布局、相同原生配置和服务器，双臂始终保持初始关节命令，
不调用GPT或π，不更改物理步长、判定条件或演示轨迹。仅在原生检查返回后读取五个原生篮内谓词。
该程序与所有物理数据均位于 `publication_checks/native_layout_20261005`，不被正式队列或报告扫描。

`hold_seed4/sim/support_validation.json` 记录：原生控制步432，辅助队列已清空，查询一次；
aim0/1/3/4均为1，aim2为0，原生unstable为true。
`hold_seed4/diagnostic_progress.json` 与 `sim/evaluation_outcome.json` 随后记录1600步原生截断及相同排除。
诊断model_calls与policy_calls均为0，benchmark_eligible=false。
手表00002的37440121字节文件SHA256为
`d6c002ded6059ce40a64fc8203dc8bfcad29b0243eee3fbaf1c07f175758279a`，匹配上游已提交LFS指针；
4313个物理样本的原生layout4辅助轨迹SHA256仍为
`27eca96475f60a02d5540dd7d6293d0bdb9caa9313e0c8665a07d330a904d94a`。
原生源码、冻结布局与轨迹由既有 `verify_assets` 检查通过。

因此可定位到无需策略干涉即可出现的原生演示失效；尚不能断言具体抓取或PhysX缺陷已经找到或修复。
不修改原生谓词，不给原排除回合补造成绩，不用视觉判断覆盖原生结果。

旧v5调度器把这些完整原生排除归入基础设施重试，预算1000次。
新v6只对冻结身份一致、完整、原生明确排除且native success/score为null的尝试计数，三次后不再创建新的物理尝试。
有效完整失败与未完成原审计仍优先；基础设施前缀、身份不匹配或矛盾结果不消耗此边界。
真正调度循环测试在v5因再次启动而失败，在v6通过；另有排除与回合边界回归，共7项通过。
`queue_scheduler_v6_manifest.json` 绑定新旧源码SHA与未改变的资格/审计/执行函数AST。
handover持有原执行锁才停止旧单元，不能打断当前第五次回合；具体状态见 `queue_handover_20261005_v6.json`。

修复范围建议已另存 `replacement_proposal.json`，尚未启用。
候选layout5来自同一个实验前已冻结的60案例原面板，不根据任一策略成败挑选；先进行零模型原生辅助演示诊断。
若允许补齐，应同时补跑Direct与Hybrid，并另列修订50对有效案例；原layout4回合、原50案例统计和原冻结输入都保留。
这需要案例范围决定，不是篡改既有成绩。RoboLab的原100回合矩阵继续执行。

2026-10-05 13:34 UTC：layout5在553步通过演示检查，五件均在后篮；走满1600步后原生仍有效。
两条保持诊断各1600条执行动作逐项等于初始关节命令，各原传感视频1601帧。
resolved_config.json均为SHA256 `3b49982c5b7c45266b246d370e0ce110deef068973defd729421df21669ed59d`。
完整证据分别见hold_seed4/diagnostic_integrity.json与hold_seed5/diagnostic_integrity.json。
候选仍prepared_not_activated；已有异步案例范围问题，未答复不能视为已授权替换。

诊断第一次启动由于systemd的PATH没有rg而未发出reset或动作，原数据保存在
`hold_seed4_startup_path_failure`。准备检查改用绝对路径的系统grep后启动新的独立诊断。
两个诊断服务都有独立端口、GPU空闲容量检查、1800秒运行边界和仅本服务进程组清理。


## 2026-10-06 独立有效面板补齐

按上次具体补齐提案之后用户“继续推进”执行layout5两方法的新原生回合；原面板及所有原结果保留。`infra/robodojo_valid_cohort.py`固定原100个方法fixture哈希、原60面板、零模型诊断与唯一整对替换；先校验再发布不可变选择指针。补齐队列`infra/run_robodojo_valid_supplement.py`复用冻结v6资格函数和同一物理执行锁，独立写`robodojo_valid_queue_state.json`。首次有效完整失败及审计缺口不能用新物理回合替代；单方法最多3条基础设施尝试。

原v5→v6已于2026-10-05T14:28:01.696574UTC在物理回合边界切换。原面板99/100、49对；RoboLab21/100、6对，原归档积压为零。最终验收针对所选有效50对及RoboLab50对；另验保留的原面板回合，两个RoboDojo面板互有重叠，不能相加当作独立样本。补齐运行、独立在线报告和最终全量验收尚未完成。
