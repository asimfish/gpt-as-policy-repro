# GPT-as-Policy 两种方法复现目标

## Outcome

按用户 2026-09-16 的范围修正，主要复现报告自己的两种方法：GPT Direct 与 π0.5 + GPT（Hybrid）。交付我们自己运行生成的在线报告、完整轨迹和可复用基础设施。

## In scope

- GPT Direct：使用原仓库的持久 GPT 控制器与 GPTOnlyTools，观察图像和状态，直接生成并执行短段末端控制，不调用 π0.5。
- Hybrid：使用原仓库 RoboDojoTools；π0.5 提议动作，GPT 根据观测与反馈接受前缀、修改或接管，保留完整闭环历史。
- 优先 RoboDojo 主实验：同一冻结面板50个案例，每个案例分别运行两方法，共100条轨迹。
- 两方法的 RoboLab 补充实验后续推进；不扩展其他模型基线。
- 保留原生终止条件、输入输出、prompt、工具调用、模型身份、token、初态、视频与失败证据。

## Out of scope for active work

Cosmos、DreamZero、独立 π0.5 全量基线、prefix/chunk 对照扩展。已获得的结果和资产保留为历史辅助材料，不能当作 Direct/Hybrid 复现成绩。π0.5 推理服务继续保留，作为 Hybrid 必需组件。

## Acceptance

- [x] 原生仿真与 π0.5 推理链路验证。
- [x] 原仓库持久控制器启动入口已准备；2026-09-16两方法真实app-server握手/工具注册及原生工具预检通过（零模型调用）。
- [x] 用户授权当前Codex CLI后，gpt-6-astra/xhigh真实模型响应验证通过；证据astra_live_probe_20260916。
- [x] 同一个冻结案例完成 Direct 与 Hybrid 两条完整轨迹并审计；截至 2026-10-02 已有 7 个完整配对。
- [ ] RoboDojo 两方法100条配对轨迹完成，失败和基础设施中断区分。
- [x] 在线报告以两方法自己的结果为主；公开数字与已有基线分开（v2 自动生成主板已发布、字节与浏览器验收通过）。
- [ ] 完成两方法 RoboLab 补充评测并明确历史环境等价性限制。

## Current frontier

2026-10-02 10:22 UTC：18/100 个完整原生方法回合通过完整动作审计，7/50 个案例已完成两方法配对。
Direct 成功 1/10，Hybrid 成功 1/8；已配齐子集分别为 1/7 和 0/7。首个 Hybrid 成功为
build_tower / standard / layout 3：719 个原生控制步、48 次决策。样本仍不能代表全量表现。
v5 队列已在物理回合边界安全接管；layout 4 Direct 已跑满 1050 步原生失败，Hybrid 正在运行。
RoboLab 已冻结 50 案例 × 两方法。原版 Hybrid 的 7 次完成决策 / 105 个动作已通过前缀审计，
随后 EEF 动作 RPC 的 SSH 通道中断；该轨迹没有原生终止，不计分。
独立 Direct EEF 适配器已实现，10 个接口测试通过；两次真实模型验证均在首条动作 ACK 前中断。
当前前沿是用不计分的 RPC 诊断区分原生运行时与 SSH 通道：普通 echo 包往返已通过，
远端原生 loopback 的 1 步与 15 步 hold 执行也通过；尚未证明实际 EEF 链路可运行。
RoboLab 完整审计器的 6 个测试与两方法持续队列的 3 个测试通过；队列暂未启用，等待链路验证。
100 个主回合与 100 个 RoboLab 补充回合均尚未完成；历史初态和未公开 Direct 源码的等价性仍有限。
主板现改为从冻结案例与完整审计自动导出：50 案例矩阵、全部已完成回放、逐任务结果、
中断原因分类和独立分母；保留此前完整失败。站点已发布，定时更新已启动；
以 online_publication.json 的精确字节校验为准。审计不独立重算 IK，关节状态哈希不等于完整物理初态。

## Decisions

- 2026-09-16：用户明确“主要复现这个文档自己的两种方法就行”；优先级覆盖此前全模型扩展范围。
- 停止继续运行独立π0.5基线队列和额外模型传输；不删除已下载资产和历史结果。
- 2026-09-16追加授权：用户明确要求直接使用当前Codex CLI的GPT-6 Astra。通过CLI自身认证复用当前登录态，不复制、不输出凭据；SQLite运行状态保持每次实验独立。该决定覆盖此前要求单独实验账号的限制。
- 既有历史目标保存在 GOAL_before_scope_correction_20260916.md，仅供追溯。

## Evidence

report_interpretation_zh.md、infra/run_original_controller.sh、现有仿真与π0.5审计记录。在线报告：https://asimfish.github.io/gpt-as-policy-repro/scenes.html 。当前在线报告已以两种主方法的自有结果为主；50 个配对与 RoboLab 补充仍未全量完成。
