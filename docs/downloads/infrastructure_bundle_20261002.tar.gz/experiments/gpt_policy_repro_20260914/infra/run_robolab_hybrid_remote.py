"""Run the original RoboLab Hybrid controller locally against owned mainskill services."""
import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import signal
import socket
import subprocess
import sys
import time

from transfer_checkpoint_chunks import SSH, remote

ROOT = Path(__file__).resolve().parents[3]
ARTIFACTS = Path(__file__).resolve().parents[1]
REMOTE_ROOT = '/home/dataset-assist-0/liyufeng/agentic_robot'
REMOTE_ARTIFACTS = REMOTE_ROOT+'/experiments/gpt_policy_repro_20260914'
PYTHON = '/home/liyufeng/miniforge3/envs/safeduo/bin/python'


def write(path, data):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(data, indent=2)+'\n')
    temp.replace(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--task', default='BlocksInBinTask')
    parser.add_argument('--method', choices=('pi05_plus_gpt','gpt_only'),default='pi05_plus_gpt')
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--sim-port', type=int, default=20600)
    parser.add_argument('--policy-port', type=int, default=20610)
    parser.add_argument('--policy-gpu', type=int, default=0)
    parser.add_argument('--sim-gpu', type=int, default=6)
    args = parser.parse_args()
    tasks = json.loads((ARTIFACTS/'fixtures/robolab_task_files.json').read_text())['tasks']
    if args.task not in tasks or args.seed not in range(5):
        raise ValueError('Expected a frozen RoboLab task and seed 0..4')
    with Path('/tmp/gpt-policy-robolab-hybrid-controller.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for port in (args.sim_port, args.policy_port):
            with socket.socket() as sock:
                sock.bind(('127.0.0.1', port))
        prefix='hybrid_' if args.method=='pi05_plus_gpt' else 'direct_'
        attempt = prefix+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'_'+args.task+'_seed'+str(args.seed)
        output = ARTIFACTS/'robolab_gpt_campaign'/attempt
        output.mkdir(parents=True, exist_ok=False)
        workspace = Path('/tmp/gpt-policy-robolab-'+attempt)
        workspace.mkdir(mode=0o700, exist_ok=False)
        remote_output = REMOTE_ARTIFACTS+'/robolab_gpt_campaign/'+attempt
        source_hashes = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in (ROOT/'gpt-as-policy/hybrid_rollout/robolab').rglob('*.py')}
        owned_sources=[Path(__file__)]
        if args.method=='gpt_only':
            owned_sources += [ARTIFACTS/'infra'/name for name in ('robolab_direct_tools.py','run_robolab_direct_controller.py')]
            owned_sources += list((ARTIFACTS/'infra/robolab_direct_skill').rglob('*.md'))
        source_hashes.update({str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in owned_sources})
        record = dict(schema='gpt_policy_robolab_attempt.v1', method=args.method,
            task=args.task, seed=args.seed, status='starting', completed=False,
            started_utc=datetime.now(timezone.utc).isoformat(), attempt=attempt,
            local_workspace=str(workspace), remote_output=remote_output,
            controller_source_sha256=source_hashes, native_horizon=True,
            max_decisions=100000, decision_budget_note='Above native control horizon; no 180-decision cap',
            historical_initial_state_recovered=False,
            equivalence_limit='New fixed-seed cohort; Isaac 5.1 and pinned current RoboLab; historical raw initial states unavailable')
        write(output/'attempt.json', record)
        write(ARTIFACTS/'robolab_gpt_active.json', record)
        remote_argv = ['python3', REMOTE_ARTIFACTS+'/infra/run_mainskill_robolab_hybrid_services.py',
            '--attempt', attempt, '--task', args.task, '--method',args.method,'--seed', str(args.seed),
            '--sim-port', str(args.sim_port), '--policy-port', str(args.policy_port),
            '--policy-gpu', str(args.policy_gpu), '--sim-gpu', str(args.sim_gpu)]
        launch = '''import pathlib,subprocess,sys
root=pathlib.Path(sys.argv[1]);root.mkdir(parents=True,exist_ok=True)
with (root/(sys.argv[2]+'.manager.log')).open('x') as log:
 p=subprocess.Popen(sys.argv[3:],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
print(p.pid)
'''
        manager_pid = None
        tunnel = controller = None
        tunnel_log = controller_log = None
        def terminate(*_):
            raise KeyboardInterrupt('Stopping this owned attempt; no automatic action retry')
        signal.signal(signal.SIGTERM, terminate)
        try:
            # Mutating SSH startup is invoked once; a lost ACK is never re-launched.
            started = subprocess.run([*SSH, shlex.join(['python3', '-c', launch,
                REMOTE_ARTIFACTS+'/robolab_gpt_campaign', attempt, *remote_argv])],
                capture_output=True, text=True, check=True, timeout=45)
            manager_pid = int(started.stdout.strip())
            record['remote_manager_pid'] = manager_pid
            deadline = time.monotonic()+960
            while True:
                probe="""import pathlib,json,sys
p=pathlib.Path(sys.argv[1])/'services.json'
try: alive=sys.argv[3] in pathlib.Path('/proc/'+sys.argv[2]+'/cmdline').read_text()
except FileNotFoundError: alive=False
print(p.read_text() if p.exists() else json.dumps({'status':'starting' if alive else 'manager_failed'}))"""
                state = json.loads(remote(probe,(remote_output,manager_pid,attempt),timeout=30))
                write(output/'remote_services.json', state)
                if state['status'] == 'ready':
                    break
                if state['status'] not in ('starting',):
                    raise RuntimeError('Remote startup failed: '+state['status'])
                if time.monotonic() >= deadline:
                    raise TimeoutError('Remote services startup exceeded 960 seconds')
                time.sleep(10)
            tunnel_log = (output/'tunnel.log').open('w')
            tunnel_args = [*SSH[:-1], '-o', 'ExitOnForwardFailure=yes', '-o', 'ServerAliveInterval=30',
                '-o', 'ServerAliveCountMax=10', '-N', '-L', f'127.0.0.1:{args.sim_port}:127.0.0.1:{args.sim_port}',
                '-L', f'127.0.0.1:{args.policy_port}:127.0.0.1:{args.policy_port}', SSH[-1]]
            tunnel = subprocess.Popen(tunnel_args, stdout=tunnel_log, stderr=subprocess.STDOUT)
            time.sleep(2)
            if tunnel.poll() is not None:
                raise RuntimeError('Owned SSH tunnel failed')
            env = os.environ.copy()
            env['PYTHONPATH'] = str(ROOT/'gpt-as-policy')+':'+str(ROOT/'upstream/openpi-robolab/packages/openpi-client/src')
            env['PATH'] = str(Path(PYTHON).parent)+':'+env['PATH']
            codex = env.get('CODEX_BIN') or shutil.which('codex')
            if not codex or not (Path(env.get('CODEX_HOME',''))/'config.toml').is_file():
                raise RuntimeError('Authorized existing Codex CLI configuration required')
            argv = [PYTHON, '-m', 'hybrid_rollout.robolab.skill.run', '--output', str(workspace/'rollout'),
                '--task', args.task, '--checkpoint', REMOTE_ROOT+'/upstream/checkpoints/pi05_droid_jointpos',
                '--codex', codex, '--sim-port', str(args.sim_port), '--student-port', str(args.policy_port),
                '--seed', str(args.seed), '--max-decisions', '100000']
            if args.method=='gpt_only':
                argv=[PYTHON,str(ARTIFACTS/'infra/run_robolab_direct_controller.py'),'--output',str(workspace/'rollout'),
                    '--task',args.task,'--codex',codex,'--sim-port',str(args.sim_port),'--seed',str(args.seed),'--max-decisions','100000']
            record.update(status='controller_running', controller_argv=argv,
                controller_started_utc=datetime.now(timezone.utc).isoformat())
            write(output/'attempt.json', record)
            write(ARTIFACTS/'robolab_gpt_active.json', record)
            controller_log = (output/'controller.log').open('w')
            controller = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=controller_log,
                stderr=subprocess.STDOUT, start_new_session=True)
            # Native simulator termination is the only physical episode budget.
            while controller.poll() is None:
                if tunnel.poll() is not None:
                    raise RuntimeError('SSH tunnel disconnected; do not reconnect an ambiguous physical action')
                time.sleep(5)
            record.update(status='controller_finished' if controller.returncode==0 else 'infrastructure_interrupted',
                          controller_exit=controller.returncode)
        except BaseException as error:
            record.update(status='infrastructure_interrupted', error=str(error))
        finally:
            if controller is not None and controller.poll() is None:
                os.killpg(controller.pid, signal.SIGTERM)
                try:
                    controller.wait(timeout=60)
                except subprocess.TimeoutExpired:
                    os.killpg(controller.pid, signal.SIGKILL)
                    controller.wait(timeout=10)
            if controller_log:
                controller_log.close()
            if tunnel is not None and tunnel.poll() is None:
                tunnel.terminate()
                tunnel.wait(timeout=15)
            if tunnel_log:
                tunnel_log.close()
            try:
                # Unique attempt path is the ownership boundary, never an arbitrary PID.
                remote("from pathlib import Path;import sys;p=Path(sys.argv[1]);p.mkdir(parents=True,exist_ok=True);(p/'STOP').touch();print('stop requested')", (remote_output,), timeout=30)
                time.sleep(5)
                ssh_command = shlex.join(SSH[:-1])
                archived = subprocess.run(['rsync', '-az', '--partial', '--timeout=90', '-e', ssh_command,
                    'mainskill:'+remote_output+'/', str(output/'remote')+'/'], timeout=300)
                record['remote_archive_exit'] = archived.returncode
            except Exception as error:
                record['archive_error'] = str(error)
            if (workspace/'rollout').exists():
                shutil.copytree(workspace/'rollout', output/'rollout', ignore=shutil.ignore_patterns('runtime_db','runtime_logs'))
            record['finished_utc'] = datetime.now(timezone.utc).isoformat()
            # Auditing is separate; successful process exit cannot imply completed evaluation.
            record['action_audit_pending'] = True
            write(output/'attempt.json', record)
            write(ARTIFACTS/'robolab_gpt_active.json', record)
        print(json.dumps(dict(attempt=attempt, status=record['status'], completed=False)), flush=True)
        return 0 if record['status'] == 'controller_finished' else 1


if __name__ == '__main__':
    raise SystemExit(main())
