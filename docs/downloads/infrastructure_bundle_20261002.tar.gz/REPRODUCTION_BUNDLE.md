# 复现实验基建快照

包含运行脚本、调度器、逐步动作审计、回归测试、冻结案例与依赖锁、报告解读、运行手册和 GPT-as-Policy 源码补丁。按归档中的相对路径解压到工作区；先按 RUNBOOK.md 准备固定版本上游仓库与环境，再应用源码补丁。

运行入口：experiments/gpt_policy_repro_20260914/RUNBOOK.md。

环境配置保留本项目工作区与 mainskill 部署路径；迁移到其他机器时需调整 infra/env.sh 和部署脚本中的根路径、Python 路径及 SSH alias。模型权重、大型资产、SSH 密钥、API 凭据不在包内，下载清单和校验逻辑保留。用户已授权复用现有 Codex CLI 登录态：配置 CODEX_HOME/CODEX_BIN 与 ROLLOUT_USE_CURRENT_CODEX_HOME=1，由 CLI 自身读取认证，禁止复制或公开 auth.json。unit_templates 提供去掉私有环境的 systemd 模板，runtime.env 由部署者自行在本机以0600权限创建。此包是可审阅的基建快照，不表示全量实验已经完成。

当前有效范围只包含 GPT Direct 与 π0.5 + GPT Hybrid。遗留基线辅助脚本仅用于追溯，不应据此启动额外方法。RoboLab Direct 是本项目 EEF 适配器，历史实现未公开；三个真实尝试因 RPC 连接中断而不计分，持续队列尚未启用。

manifest.json 给出每个文件的 SHA256 与固定源码提交。大型实验轨迹和在线站点源码留在工作区及报告 GitHub 仓库。
