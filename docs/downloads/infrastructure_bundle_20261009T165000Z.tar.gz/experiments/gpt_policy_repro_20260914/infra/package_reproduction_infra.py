"""Create a local, hash-verified handoff of experiment infrastructure and frozen inputs."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile
from datetime import datetime,timezone

ROOT=Path(__file__).resolve().parents[3]
ART=ROOT/'experiments/gpt_policy_repro_20260914'


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--date',default=datetime.now(timezone.utc).strftime('%Y%m%d'))
    args=parser.parse_args();assert re.fullmatch(r'20[0-9]{6}(?:T[0-9]{6}Z)?',args.date)
    files=[p for p in (ART/'infra').iterdir() if p.is_file() and p.suffix in {'.py','.sh','.txt','.json'}]
    files += list((ART/'infra/robolab_direct_skill').rglob('*.md'))
    files += [p for p in (ART/'fixtures').rglob('*') if p.is_file() and p.suffix in {'.json','.lock'}]
    files += [ART/name for name in ['GOAL.md','RUNBOOK.md','scope_matrix.md','baseline_protocol_audit.md','report_interpretation_zh.md','additional_baseline_sources.json','ROBOLAB_DIRECT_ADR.md','ROBOLAB_RPC_DIAGNOSIS.md','ROBOLAB_ARCHIVE_DIAGNOSIS.md','ROBOLAB_PARALLEL_ADR.md','ROBOLAB_LOCAL_STORAGE_ADR.md','ROBOLAB_LAUNCH_GUARD_ADR.md','ROBODOJO_NATIVE_LAYOUT_DIAGNOSIS.md','PROGRESS_20261002.md']]
    files += [p for p in (ART/'queue_scheduler_v5_manifest.json',ART/'queue_scheduler_v6_manifest.json',ART/'robolab_queue_scheduler_v1_manifest.json',ART/'robolab_queue_scheduler_v2_manifest.json',ART/'robolab_queue_scheduler_v3_manifest.json',ART/'robolab_queue_scheduler_v4_manifest.json',ART/'robolab_queue_scheduler_v5_manifest.json',ART/'robolab_parallel_deployment_receipt.json') if p.exists()]
    diagnosis=ART/'publication_checks/native_layout_20261005'
    files += [diagnosis/name for name in ('probe_server.py','probe_client.py','run_probe.sh',
        'support_trajectory_identities.json','watch_asset_identity.json','replacement_proposal.json',
        'replacement_activation_20261006.json',
        'mix__imitate_sorting_sequence__standard__g0__l5.json',
        'hold_seed4/diagnostic_progress.json','hold_seed4/sim/support_validation.json',
        'hold_seed4/sim/evaluation_outcome.json',
        'hold_seed4/sim/resolved_config.json','hold_seed4/diagnostic_integrity.json',
        'hold_seed5/diagnostic_progress.json','hold_seed5/sim/support_validation.json',
        'hold_seed5/sim/evaluation_outcome.json',
        'hold_seed5/sim/resolved_config.json','hold_seed5/diagnostic_integrity.json') if (diagnosis/name).is_file()]
    milestone=ART/'publication_checks/robodojo_completed_20261006'
    # Completed-cohort evidence contains hashes and public paths only; neither
    # runtime logs nor an unfinished progress state belongs in this snapshot.
    certificate=milestone/'certificate.json'
    if certificate.is_file():
        proof=json.loads(certificate.read_text())
        assert proof['cohort_verified'] is True and proof['full_reproduction_complete'] is False
        assert proof['status']=='cohort_verified_full_reproduction_pending'
        assert proof['verified_selected_episodes']==100 and proof['verified_retained_original_episodes']==1
        files += [milestone/name for name in ('verify_completed_robodojo.py','certificate.json',
            'execution_sources.json','execution_sources_after_restart.json','paired_initial_states.json',
            'new_parallel_native_originals.json','serial_boundary_native_original.json') if (milestone/name).is_file()]
    recovery=ART/'publication_checks/cleanup_recovery_20261006'
    delta=recovery/'new_native_certificate.json'
    if delta.is_file():
        proof=json.loads(delta.read_text())
        assert proof['verified'] is True and proof['full_reproduction_complete'] is False
        assert proof['status']=='delta_verified_full_reproduction_pending'
        assert proof['verified_delta_episodes']==proof['delta_episodes']
        assert proof['public_files_verified']==4*proof['delta_episodes']
        files += [recovery/name for name in ('verify_new_robolab.py','new_native_certificate.json',
            'diagnosis.json','live_reconciliation.json','cleanup_reconciliation.json',
            'activation.json','implementation_checks.json') if (recovery/name).is_file()]
    local_ssd=ART/'publication_checks/local_ssd_20261006'
    activation=local_ssd/'activation.json'
    if activation.is_file():
        proof=json.loads(activation.read_text())
        assert proof['verified'] is True and proof['live_workspaces_relocated'] is False
        files += [local_ssd/name for name in ('preflight.json','activation.json') if (local_ssd/name).is_file()]
    launch=ART/'publication_checks/launch_recovery_20261007'
    activation=launch/'activation.json'
    if activation.is_file():
        proof=json.loads(activation.read_text())
        assert proof['verified'] is True and proof['full_reproduction_complete'] is False
        assert proof['existing_authorized_login_preserved'] is True
        assert len(proof['verified_nonphysical_releases'])==3
        files += [launch/name for name in ('diagnosis.json','initial_sources.json',
            'robolab_gpt_parallel_leases.json','preoutput_recovery.json','activation.json',
            'implementation_checks.json','runtime_verified.json') if (launch/name).is_file()]
        for lease in proof['verified_nonphysical_releases']:
            run=ART/'robolab_gpt_campaign'/lease['attempt']
            record=json.loads((run/'attempt.json').read_text())
            assert record['metadata_reconstructed'] is True and record['completed'] is False
            assert record['remote_launch_attempted'] is False
            files += [run/'attempt.json',run/'startup_recovery.json']
        delta=launch/'new_native_certificate.json'
        if delta.is_file():
            proof=json.loads(delta.read_text())
            assert proof['verified'] is True and proof['full_reproduction_complete'] is False
            assert proof['verified_delta_episodes']==proof['delta_episodes']
            assert proof['public_files_verified']==4*proof['delta_episodes']
            files += [delta,launch/'verify_new_robolab.py']
    ssd_native=ART/'publication_checks/ssd_native_complete_20261007'
    delta=ssd_native/'new_native_certificate.json'
    if delta.is_file():
        proof=json.loads(delta.read_text())
        assert proof['verified'] is True and proof['full_reproduction_complete'] is False
        assert proof['verified_delta_episodes']==proof['delta_episodes']>=3
        assert proof['public_files_verified']==4*proof['delta_episodes']
        assert {'hybrid_20261007T045112Z_RubiksCubeTask_seed3',
            'hybrid_20261007T045112Z_RubiksCubeTask_seed4',
            'direct_20261007T045112Z_RubiksCubeTask_seed0'} <= {p['run_id'] for p in proof['proofs']}
        files += [delta,ssd_native/'verify_new_robolab.py']
    alignment=ART/'publication_checks/blog_alignment_20261008'
    comparison=ROOT/'gpt-policy-report-site/docs/data/blog-comparison.json'
    alignment_proof=None
    if (alignment/'statistics_audit.json').is_file() and comparison.is_file():
        alignment_proof=json.loads((alignment/'statistics_audit.json').read_text())
        value=json.loads(comparison.read_text())
        assert alignment_proof['verified'] is True and alignment_proof['complete_native_episodes']==200
        assert len(alignment_proof['files_sha256'])==900
        assert alignment_proof['comparison_sha256']==hashlib.sha256(comparison.read_bytes()).hexdigest()
        assert value['independent_evaluation_complete'] is True and value['historical_equivalence_verified'] is False
        files += [ART/'BLOG_ALIGNMENT_20261008.md',comparison,ROOT/'gpt-policy-report-site/docs/blog-comparison.html']
        files += [alignment/name for name in ('original_sources.json','upstream_public_tree.json',
            'original_robodojo_cases.json','original_robolab.json','original_robolab_leaderboard.csv',
            'statistics_audit.json','missing_evidence.json','verification_contract.json',
            'implementation_checks.json','browser_local.json','verify_browser.cjs','verify_public_delivery.py',
            'preserved_native_evidence.json','verify_preserved_evidence.py')]
        files += [ROOT/'gpt-policy-report-site/tools'/name for name in ('blog_comparison.py',
            'test_blog_comparison.py','render_gpt_progress.py','publish_gpt_progress.py','verify_site.py')]
    completion=None
    historical=ART/'publication_checks/historical_protocol_20261008'
    historical_proof=None
    if (historical/'recovered_comparison.json').is_file():
        historical_proof=json.loads((historical/'original_record_recount.json').read_text())
        metadata=json.loads((historical/'recovered_comparison.json').read_text())
        assert historical_proof['verified'] is True and historical_proof['core_archives_verified']==100
        assert historical_proof['original_control_steps_verified']==80971
        assert metadata['verified'] is True and metadata['historical_full_physics_state_verified'] is False
        assert metadata['original_record_recount_sha256']==hashlib.sha256((historical/'original_record_recount.json').read_bytes()).hexdigest()
        assert value['original_record_recovery']['original_record_recount_sha256']==metadata['original_record_recount_sha256']
        files += [ART/'ORIGINAL_ARTIFACT_RECOVERY_ADR.md']
        files += [historical/name for name in ('protocol_sources.json','catalog_alignment.json',
            'hf_manifest.json','hf_pairing.json','hf_validation.json','hf_LICENSE-DATA.md',
            'original_robolab_gallery.json','original_robolab_gallery_manifest.json','original_website_provenance.json',
            'core_download_receipt.json','original_record_recount.json','recovered_comparison.json','initial_difference_inspection.json',
            'statistics_audit.json','verification_contract.json','implementation_checks.json',
            'browser_local.json','verify_browser.cjs','verify_public_delivery.py',
            'preserved_native_evidence.json','verify_preserved_evidence.py')]
    worker=ART/'publication_checks/worker_fidelity_20261008'
    worker_manifest=None
    if (worker/'historical_worker_offline_gate.json').is_file():
        worker_manifest=json.loads((worker/'historical_worker_manifest.json').read_text())
        offline=json.loads((worker/'historical_worker_offline_gate.json').read_text())
        cli=json.loads((worker/'original_cli_zero_turn_probe.json').read_text())
        assert worker_manifest['verified'] is True and len(worker_manifest['source_profiles'])==5
        assert offline['verified'] is cli['verified'] is True
        digest=hashlib.sha256((worker/'historical_worker_manifest.json').read_bytes()).hexdigest()
        assert offline['manifest_sha256']==cli['manifest_sha256']==digest
        assert value['historical_worker_fidelity']['evidence_sha256']['historical_worker_manifest.json']==digest
        files += [ART/'ADR_HISTORICAL_WORKER_RECONSTRUCTION.md']
        files += [worker/name for name in ('failure_contract.json','worker_protocol_inspection.json',
            'original_cli_linux_registry.json','original_cli_toolchain.json','historical_worker_manifest.json',
            'historical_worker_offline_gate.json','original_cli_zero_turn_probe.json',
            'original_cli_zero_turn_probe_initial_failure.json','initial_model_rgb_differences.json',
            'historical_pair_preflight.json','historical_canary_admission.json','implementation_checks.json',
            'historical_canary_evidence_gate.json','historical_canary_watcher.json',
            'verification_contract.json','additional_public_repo_search.json',
            'browser_local.json','verify_browser.cjs','verify_preserved_evidence.py','preserved_native_evidence.json',
            'verify_public_delivery.py') if (worker/name).is_file()]
        files += [historical/'original_cli_registry.json']
        from stage_historical_workers import verify_tree
        for profile in worker_manifest['source_profiles']:
            root=ART/profile['package_root']
            expected={**profile['frozen_files_sha256'],**profile['added_runtime_bridge_sha256']}
            verify_tree(root,expected)
            files += [root/name for name in expected]
    execution=value.get('historical_worker_fidelity',{}).get('original_version_execution') if alignment_proof else None
    if execution:
        sys.path.insert(0,str(ROOT/'gpt-policy-report-site/tools'))
        from blog_comparison import validate_historical_execution
        validate_historical_execution(execution)
        cohort=ART/'publication_checks/historical_cohort_20261010'
        files += [ART/'HISTORICAL_REMAINING_COHORT_20261010.md']
        files += [cohort/name for name in ('cohort_plan.json','preflight.json','admission.json','activation.json',
            'runtime_snapshot.json','implementation_checks.json','verification_contract.json',
            'current_direct_prefix5_audit.json','public_source_refresh.json','original_git_head.json','publisher_datasets.json',
            'layout4_validity_exposure.json','mobile_overflow_red.json','delivery_checks.json',
            'verify_public_delivery.py','verify_browser.cjs','browser_local.json',
            'verify_preserved_evidence.py','preserved_native_evidence.json') if (cohort/name).is_file()]
        canary=json.loads((worker/'historical_canary_evidence_gate.json').read_text())
        canary_root=ART/canary['cohort'];files += [canary_root/'pair_plan.json']
        for result in canary['results']:
            run=canary_root/result['method'];proof=run/'complete_action_audit.json'
            assert hashlib.sha256(proof.read_bytes()).hexdigest()==result['complete_action_audit_sha256']
            files += [proof]
    current=ART/'full_reproduction_verification.json'
    if current.is_file() and json.loads(current.read_text()).get('full_reproduction_complete') is True:
        state=json.loads(current.read_text())
        commit=state['published_commit'];assert re.fullmatch('[a-f0-9]{40}',commit)
        certificate=ART/'final_verification'/commit/'certificate.json'
        assert certificate.read_bytes()==current.read_bytes(), 'Preserve the immutable gate receipt'
        completion=dict(path=str(certificate.relative_to(ROOT)),sha256=hashlib.sha256(certificate.read_bytes()).hexdigest(),published_commit=commit)
        sys.path.insert(0,str(ROOT/'gpt-policy-report-site/tools'))
        from export_infra_bundle import validate_completion_certificate
        validate_completion_certificate(certificate.read_bytes(),completion)
        delivery=ART/'publication_checks/completion_delivery_20261007'
        binding=json.loads((delivery/'evidence_binding.json').read_text())
        assert binding['verified'] is True and binding['certificate_sha256']==completion['sha256']
        assert binding['original_audit_proofs_unchanged']==201 and binding['public_files_unchanged']==815
        files += [certificate,ART/'COMPLETION_20261007.md',delivery/'evidence_binding.json',delivery/'deactivation.json',delivery/'implementation_checks.json',delivery/'browser_local.json',ROOT/'gpt-policy-report-site/tools/export_infra_bundle.py']
    payload={str(p.relative_to(ROOT)):p.read_bytes() for p in sorted(set(files))}
    # Installed unit environments are private machine configuration. Publish templates
    # with a user-owned, private EnvironmentFile rather than account paths or values.
    units=ART/'infra/report-progress-units'
    for path in sorted(units.glob('*')):
        lines=path.read_text().splitlines();had_environment=any(x.startswith(('Environment=','EnvironmentFile=')) for x in lines)
        data='\n'.join(x for x in lines if not x.startswith('Environment=') and not x.startswith('EnvironmentFile='))+'\n'
        if had_environment:data=data.replace('[Service]\n','[Service]\nEnvironmentFile=%h/.config/gpt-policy/runtime.env\n')
        data=data.replace(str(ROOT),'/absolute/path/to/agentic_robot')
        payload['unit_templates/'+path.name]=data.encode()
    payload['unit_templates/runtime.env.example']=b'CODEX_HOME=/absolute/path/to/existing/authorized/codex/home\nCODEX_BIN=/absolute/path/to/codex\nPATH=/absolute/path/to/node/bin:/usr/local/bin:/usr/bin:/bin\n# Optional: HTTP_PROXY, HTTPS_PROXY, ALL_PROXY. Never put auth.json in this bundle.\n'

    for name,data in payload.items():
        assert not re.search(rb'-----BEGIN (?:OPENSSH |RSA |EC )?PRIVATE KEY-----|github_pat_[A-Za-z0-9_]{30,}|ghp_[A-Za-z0-9]{30,}',data),name
    patch=subprocess.check_output(['git','-C',str(ROOT/'gpt-as-policy'),'diff','--','hybrid_rollout/robolab/robolab_server/scene_recording.py','hybrid_rollout/robolab/robolab_server/server.py','hybrid_rollout/robolab/robolab_server/session.py'])
    payload['source_patches/gpt-as-policy.patch']=patch
    payload['REPRODUCTION_BUNDLE.md']='''# 复现实验基建快照

包含运行脚本、调度器、逐步动作审计、回归测试、冻结案例与依赖锁、报告解读、运行手册和 GPT-as-Policy 源码补丁。按归档中的相对路径解压到工作区；先按 RUNBOOK.md 准备固定版本上游仓库与环境，再应用源码补丁。

运行入口：experiments/gpt_policy_repro_20260914/RUNBOOK.md。

环境配置保留本项目工作区与 mainskill 部署路径；迁移到其他机器时需调整 infra/env.sh 和部署脚本中的根路径、Python 路径及 SSH alias。模型权重、大型资产、SSH 密钥、API 凭据不在包内，下载清单和校验逻辑保留。用户已授权复用现有 Codex CLI 登录态：配置 CODEX_HOME/CODEX_BIN 与 ROLLOUT_USE_CURRENT_CODEX_HOME=1，由 CLI 自身读取认证，禁止复制或公开 auth.json。unit_templates 提供去掉私有环境的 systemd 模板，runtime.env 由部署者自行在本机以0600权限创建。此包是可审阅的基建快照，不表示全量实验已经完成。

当前有效范围只包含 GPT Direct 与 π0.5 + GPT Hybrid。遗留基线辅助脚本仅用于追溯，不应据此启动额外方法。RoboLab Direct 是本项目 EEF 适配器，历史实现未公开；当前完整结果、验证门和队列状态见GOAL.md。SSH传输缓解、只读归档补传及完整审计说明均在包内，前缀或连接中断不得计入完整成绩。\n\n包含两种环境的SSD容量维护脚本与定时服务：完整审计后，对RoboLab整工作区、RoboDojo封存Codex状态逐文件SHA256核验，归档到私有NAS，活动SQLite只使用本机ext4（早期/tmp，新RoboLab回合使用第二SSD）；不得放入NAS；运行数据库和日志冷归档不在公开包内。主实验维护使用哈希固定的v5原资格函数，安装和恢复边界见RUNBOOK.md。\n\nmanifest.json 给出每个文件的 SHA256 与固定源码提交（包括在线报告源码版本）。大型实验轨迹和在线站点源码留在工作区及报告 GitHub 仓库。
'''.encode()
    if completion:
        payload['REPRODUCTION_BUNDLE.md']=payload['REPRODUCTION_BUNDLE.md'].replace('此包是可审阅的基建快照，不表示全量实验已经完成。'.encode(),('所选两套评测的200回合和100对已通过原始证据、完整视频、815个线上文件及同提交CI终验。包内封存原始完成证明 '+completion['path']+'；验收绑定原报告提交 '+completion['published_commit']+'，保留原验收时间。后续交付提交只发布该证明与基础设施，不能改写历史完成证明或声称历史逐位环境等价。详细结果和限制见 COMPLETION_20261007.md。').encode())
    if alignment_proof is not None:
        payload['REPRODUCTION_BUNDLE.md']+='\n原blog逐任务与共同案例对照见BLOG_ALIGNMENT_20261008.md和包内gpt-policy-report-site/docs/blog-comparison.html。所选200回合执行完成不代表严格历史等价；manifest.blog_comparison.historical_equivalence_verified保持false。RoboLab决策预算和Direct实现差异、缺失历史证据及900项统计输入SHA均分列。预算前缀只记录已终止/尚未终止，不补失败，也不是新的限预算评测。\n'.encode()
    if historical_proof is not None:
        payload['REPRODUCTION_BUNDLE.md']+='\n原始公开记录恢复：YuMoool/astra-robodojo-rollouts 固定版本的100个核心档案、80971步动作/执行后关节状态已独立核验，原结果重算一致；原作者署名及CC BY 4.0数据许可见包内hf_LICENSE-DATA.md与公开对照JSON。档案下载/校验入口为infra/recover_original_robodojo.py、verify_original_robodojo_records.py；大型ZIP、RGB和模型文字未放入本包。98条共同回合的布局/配置/时域一致；关节/姿态哈希差异仅约3.3e-18/1.5e-8，归档prompt仅工作目录行不同，其余字节一致。这个限定比较不证明原始模型输入、完整物理初态或服务状态等价，也不能定位结果差异原因。\n'.encode()
    pins={name:subprocess.check_output(['git','-C',str(ROOT/path),'rev-parse','HEAD'],text=True).strip() for name,path in {'gpt-as-policy':'gpt-as-policy','RoboDojo':'upstream/RoboDojo','RoboLab':'upstream/RoboLab','openpi-robolab':'upstream/openpi-robolab','cosmos-framework':'upstream/cosmos-framework','dreamzero':'upstream/dreamzero','report_site':'gpt-policy-report-site'}.items()}
    manifest=dict(active_methods=['gpt_only','pi05_plus_gpt'],full_reproduction_complete=completion is not None,created_utc=datetime.now(timezone.utc).isoformat(),source_commits=pins,files=[dict(path=k,size=len(v),sha256=hashlib.sha256(v).hexdigest()) for k,v in payload.items()])
    if completion:manifest['completion_certificate']=completion
    if alignment_proof is not None:
        assert completion and alignment_proof['native_completion_sha256']==completion['sha256']
        manifest['blog_comparison']=dict(path=str(comparison.relative_to(ROOT)),sha256=hashlib.sha256(comparison.read_bytes()).hexdigest(),historical_equivalence_verified=False)
    if historical_proof is not None:
        manifest['original_record_recovery']=dict(path=str((historical/'original_record_recount.json').relative_to(ROOT)),
            sha256=hashlib.sha256((historical/'original_record_recount.json').read_bytes()).hexdigest(),
            original_core_archives_verified=100,original_control_steps_verified=80971,
            original_results_recounted=True,historical_full_physics_state_verified=False)
    if worker_manifest is not None:
        manifest['historical_worker_reconstruction']=dict(source_profiles=5,worker_versions=4,case_assignments=100,
            manifest_sha256=hashlib.sha256((worker/'historical_worker_manifest.json').read_bytes()).hexdigest(),
            cli_version='codex-cli 0.153.4',offline_gate_verified=True,zero_turn_cli_probe_verified=True,
            original_gateway_source_recovered=False,historical_protocol_equivalence=False,full_blog_reproduction_complete=False)
        payload['REPRODUCTION_BUNDLE.md']+='\n历史控制器恢复：包内包含5套41/42文件的原始冻结源码及两份明确标记的当前授权运行环境桥接文件。原CLI安装器仅从官方npm固定0.153.4并验证SHA512 SRI；大型二进制、auth和私有运行日志不在包内。5套原源码通过30项离线协议场景与5次零推理临时线程初始化；原网关代码、服务快照和持久历史未恢复。独立历史版本试跑仅保留首次尝试，输入错误阈值退出保持未完成，不替换封存200回合。入口为infra/run_historical_pair.sh，具体边界见ADR_HISTORICAL_WORKER_RECONSTRUCTION.md。\n'.encode()
    if execution:
        manifest['historical_original_version_execution']=dict(canary_complete_native_audited=2,
            pilot_included_in_benchmark=False,remaining_pairs_planned=49,remaining_episodes_planned=98,
            evidence_sha256=execution['evidence_sha256'],automatic_physical_retries=0,
            historical_protocol_equivalence=False,full_blog_reproduction_complete=False)
        payload['REPRODUCTION_BUNDLE.md']+='\n原版本试跑两方法均1050步原生完整失败，分数0.3，动作及1051帧原视频审计通过。试跑Hybrid与原记录0.05不同，不声称结果一致；试跑不混入基准。其余49对/98次首次尝试已另行冻结并启动，入口infra/run_historical_cohort.sh，逐回合启动凭据禁止自动物理重试，未完成前缀和无效布局不计成绩。本包含完成动作审计的SHA清单及队列准入快照；大型原视频、原动作文件和私有模型运行内容仍在独立实验输出，未装入此基建包。具体限定见HISTORICAL_REMAINING_COHORT_20261010.md，全部历史复现仍未完成。\n'.encode()
    # Include final README bytes; every payload mutation must precede this seal.
    manifest['files']=[dict(path=k,size=len(v),sha256=hashlib.sha256(v).hexdigest()) for k,v in payload.items()]
    payload['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
    out=ART/'deliverables';out.mkdir(exist_ok=True);archive=out/('infrastructure_bundle_'+args.date+'.tar.gz')
    assert not archive.exists(),'A dated bundle is immutable; choose a fresh date/snapshot name'
    with tarfile.open(archive,'w:gz') as tar:
        for name,data in payload.items():
            info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o755 if name.endswith('.sh') else 0o644;tar.addfile(info,io.BytesIO(data))
    with tarfile.open(archive) as tar:
        for row in manifest['files']:
            data=tar.extractfile(row['path']).read();assert len(data)==row['size'] and hashlib.sha256(data).hexdigest()==row['sha256'],row['path']
    result=dict(path=str(archive.relative_to(ART)),files=len(manifest['files']),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),contents_verified=True)
    receipt=out/'infrastructure_bundle_verification.json';temporary=receipt.with_suffix('.tmp')
    temporary.write_text(json.dumps(result,indent=2)+'\n');temporary.replace(receipt);print(json.dumps(result))


if __name__=='__main__':main()
