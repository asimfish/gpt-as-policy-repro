# 原版本剩余49对执行约定

本阶段执行原RoboDojo面板中尚未使用恢复版本运行的49对、98次首次尝试。已审计的arrange_largest_number随机layout0试跑单独保留，不重新运行，不改变其benchmark_eligible=false，不混入本阶段分母。既有200条自有完整回合及其封存证明保持原字节。

准入依据为5套只读原源码、每条原记录的源码组合映射、官方CLI0.153.4、原布局/辅助轨迹SHA、种子、control_dt和原生时域。max_decisions保持原记录的0。缺失的原网关通过已明确标记的当前授权环境桥接；不复制认证，不修改全局CLI。原服务快照、隐藏物理和历史尝试选择仍未恢复，历史严格等价和整篇blog全部复现保持false。

运行次序只读取冻结案例和源码身份，先覆盖尚未真实试跑的源码组合，再按case_id字典序排序，不读取原或当前成绩决定顺序。首对为arrange_largest_number standard layout1；第二对classify_objects_by_language standard layout1。原layout4仍原样尝试，原生布局无效时留存且不计成绩，不换成layout5。

每个回合先以独占、完整写入并fsync的launch_claim.json留存启动凭据，再启动独立仿真与所需π0.5服务。使用单个历史队列锁、GPU空闲显存不少于20000MiB、两个空闲端口；等待资源时不启动回合，不停止其他进程。执行器仅清理自己新建的进程组。

自动物理重试为0。已有启动凭据而缺少已通过审计门的回合，会阻止恢复执行；不能借重启重跑该回合。已审计的完整原生失败直接保留并推进。旧源码输入错误上限造成的退出仍是未完成前缀，不能补成原生失败。基础设施失败和审计失败停止队列以供排查，不替换第一次尝试。

完整有效回合使用原完整Direct/Hybrid动作审计器，并验证每步ACK、原视频T+1帧和完整解码；前缀只使用前缀审计，不声称覆盖未提交动作。每个终止尝试另存全部保留输入的SHA，证据门不可覆盖。98个首次尝试均审计完成只是本阶段执行交付完成，未完成前缀、原生无效布局和缺失外部协议仍会阻止“全部历史复现完成”。

本地入口：

```bash
ART=/absolute/path/to/agentic_robot/experiments/gpt_policy_repro_20260914
bash "$ART/infra/run_historical_cohort.sh" --prepare-only \
  --output "$ART/historical_worker_campaign/remaining49_20261010" --gpu 1 --base-port 19930
ROLLOUT_USE_CURRENT_CODEX_HOME=1 bash "$ART/infra/run_historical_cohort.sh" \
  --output "$ART/historical_worker_campaign/remaining49_20261010"
```

准备命令要求新输出目录，只做准入和SHA核验，模型调用与仿真步数均为0。运行命令验证准备的全部字节；迁移机器须在独立新目录重新准备并调整env.sh。此处实际输出已准备，恢复时不能重复准备或覆盖。停止后若有未审计启动凭据，须先排查保留证据；没有自动重试或自动丢弃机制。

验收边界回归覆盖首次启动、孤立凭据、空已存在目录、失败审计、已审计失败的续进、证据独占写入和分数资格。完整原生链路证据来自已完成的两方法试跑，不能用离线回归替代98次实际运行。
