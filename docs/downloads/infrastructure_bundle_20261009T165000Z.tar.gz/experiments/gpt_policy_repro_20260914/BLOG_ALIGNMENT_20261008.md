# 原 blog 对照与尚缺证据（2026-10-08）

所选 Direct/Hybrid 的200个原生回合已完成并通过封存终验；严格历史等价性仍未证明。本轮只读取既有原始结果与作者公开快照，补齐逐任务、49个共同案例、统计口径和预算协议对照，不重跑完整失败，不修改已封存证明。

公开对照入口：https://asimfish.github.io/gpt-as-policy-repro/blog-comparison.html 。机器数据：`data/blog-comparison.json`。新的统计证据见 `publication_checks/blog_alignment_20261008/statistics_audit.json`，缺失历史证据清单见同目录 `missing_evidence.json`。

## 来源与范围

作者源码快照 `8f3d362b077d8efb77e2a7274d5b2c20e2243846`；作者网站数据快照 `6ead090465d3b0fb19e90eb70569689c19f73d00`。三个原始数据文件与本地原公开快照逐字节相同，URL、大小和SHA保存在 `original_sources.json`。当前限定两方法；π0.5、Cosmos、DreamZero全量基线不计入该范围。用户本轮尚未回答可选范围问题，继续沿此前两方法授权工作。

## 已确认差异

| RoboDojo指标 | 原Direct | 本次Direct | 原Hybrid | 本次Hybrid |
|---|---:|---:|---:|---:|
| 成功数 / 50 | 13 | 13 | 24 | 21 |
| 平均score | 0.378125，n=48 | 0.395，n=50 | 0.626，n=50 | 0.548，n=50 |
| 原生控制步 | 38221 | 45259 | 42750 | 42993 |
| 已执行段 | 7729 | 9581 | 3776 | 4004 |
| 纠错控制步 | 0 | 0 | 6174 | 7799 |
| 最后记录的累计Token | 1132343772 | 1469027502 | 624762828 | 755959377 |

Hybrid实际执行的edit/EEF纠错步比例从原14.4421%变为本次18.1402%。Token包含缓存输入，不能直接换算账单或时延；已执行段只计 `executed_steps > 0`，沿用作者提取口径。原Direct缺失的两条score保持缺失，不补零；成功率分母仍为50。

49个共同案例、98条方法回合的案例ID和五个种子字段完全相同；Direct有13条、Hybrid有11条成功判定不同。原layout4与新增layout5分列，不能当作相同案例，也不能将两个重叠面板相加。种子相同不证明完整历史物理初态等价。

RoboLab总成功数双方同为Direct49/50、Hybrid46/50，失败任务分布不同。本次Direct失败在ReorientRedMug，原Direct失败在LargerObjectRaisinBox。本次Hybrid失败分布为ClutterPumpkin两条、BlockStacking一条、Yogurt一条；原Hybrid分别在ClutterPumpkin、BlockStacking、ReorientRedMug、LargerObjectRaisinBox各一条。历史与本次初态未逐seed配对，只有逐任务对照，不计算逐回合一致率。RoboLab未记录独立Token用量汇总，公开值保持未知。

## 预算与实现缺口

本次全部100条RoboLab运行配置为 `max_decisions=100000`，主要受原生控制时域约束。作者公开注释说明其表格包含保留历史结果与授权重试，最后两条BlocksInBin Direct重试从180决策扩为500，因此原表本身也不是统一预算的新鲜单次配对评测。这是明确的协议差异，不能仅凭总成功数相同称为原实验复现。

新页面对180/500决策只截看既有轨迹：已成功终止、已原生失败、仍未终止。仍未终止保持删失状态，不补成失败；此表不是重新运行的限预算策略成绩，不能用它估计改变预算的因果效果。

当前Direct适配器要求决策预算超过原生物理时域。若要实际运行历史限预算协议，须建立独立版本的适配器和独立队列/资格规则，明确预算终止与原生失败的区别，不能更改冻结执行代码或重标当前结果。原历史Direct代码/prompt、逐槽重试与预算映射、完整物理初态/构建版本和模型服务修订尚未恢复；所需材料与验收条件逐项列于 `missing_evidence.json`。未向作者发送消息，也未启动新模型或仿真回合。

## 证据边界

新的统计提取绑定200份原审计证明、200份结果、200份运行配置、200份history和100份主实验Token汇总，共900个输入SHA。其中150个统计输入未列于较早原审计manifest，单独捕获当前SHA，并用原审计的原生控制步与纠错计数核对，不追溯声称它们属于原终验输入。

原终验证明仍绑定提交 `5d7a430557ba91da93a16b5b174305ded275bf39`，SHA256 `cc38b42cfcf0c098c2ad58a3af9a2e265fc1bd3b6e92ddeeae7208f18e4b3ee9`。本轮公开交付的源码、测试、浏览器、CI、HTTP字节与新不可变基建包验收另存，不覆盖原证书或修改其时间。


## 2026-10-08 原始档案恢复与初始字段差异核验

2026-10-08 原始公开档案恢复：已从固定版本的公共数据集取回100个核心ZIP（7,864,111,231字节），逐包SHA与原报告100条目录匹配。独立核验80,971步动作及执行后关节状态，原Direct13/50、平均Score×100=37.8125（n=48），Hybrid24/50、62.6（n=50），纠错6174步及累计Token均重算一致。原Direct含48条原生完整轨迹和2条RPC超时前缀裁定失败；本次Direct50条均原生完整，两者口径明确分列。

共同98条回合的布局、解析配置、原生时域、控制步长、决策上限和context版本全部一致。初始关节和四元数哈希均不相同，但实测最大绝对数值差仅3.2526065174565133e-18和1.4901164746561335e-08；末端位置完全相同。全部98条归档prompt仅替换一行工作目录后，其余字节完全一致。归档导出规范化了私有路径，不能把原运行prompt哈希与归档文本的差异当作语义更改。此证据只覆盖记录的机器人字段和限定文本，不能证明完整物理状态、原模型输入或闭源服务状态等价，也不能解释成功率差异。

RoboLab20个任务/方法组合的原生控制时域全部与作者视频目录相同；最终槽位不代表同seed，逐槽决策上限/重试及历史Direct实现仍缺证据。原Dojo档案提供42种源码路径，其中10个路径有多个已归档哈希，不能将最新公开源码当作所有历史回合的唯一实现。下一前沿是对这些冻结控制源码做函数级比较，并继续追溯原RoboLab Direct及逐槽预算证据；不改变现有200条回合凑原表数值。

完整RGB档案约126.7GB未取回，隐藏物理/模型状态也未恢复。本轮未调用模型或仿真，未执行任何下载源码。详见 `publication_checks/historical_protocol_20261008/original_record_recount.json`、`recovered_comparison.json`、`initial_difference_inspection.json` 和 `ORIGINAL_ARTIFACT_RECOVERY_ADR.md`；新元数据592项与初始NPZ/prompt196项另行绑定，不改写原终验证明。历史严格等价与整篇blog全部复现仍未证明。


2026-10-08 03:29 UTC原档案恢复交付验收：网页提交`14661b3a3170158f16b03ab2dff61aacfadab5fd`、源码提交`705d379362f7ec5d6776fd9d09228c54e24c77d7`；同提交CI`37722698545`成功，17个在线文件与提交字节一致。新包`downloads/infrastructure_bundle_20261008T032400Z.tar.gz`的957份文件公开下载逐成员SHA通过，归档SHA256`a5c0e359436e4481cbc482ec1f56937b1fc489ebde6cc2abdd32bbd8a423bcdf`，原终验证明仍逐字节等于封存cc38b42c...原件。57项报告与13项新增工具回归、全站检查、桌面/390px浏览器通过，线上截图与本地SHA相同。Git工作树干净，单次发布已自然退出；周期发布和终验timer仍disabled。原始100条/80971步记录恢复及其交付阶段PASS；严格历史等价与整篇blog全部复现保持false。证据`publication_checks/historical_protocol_20261008/checkpoint.json`。

只读源码试查已保存`source_comparison_pilot.json`：8个路径中，session、kinematics、client、validation、prompt_context、settings的全部100份原冻结AST均与当前本地checkout相同；原Direct实际采用的gpt_only_client在50条Direct中均相同。Hybrid档案中旧gpt_only_client的区别涉及另一方法，不能直接归因到Hybrid。skill/run存在四个版本，22条Direct AST相同，28条Direct和50条Hybrid尚有CodexPolicy/main/tool_specs等候选差异。这里只比较当前checkout，不证明每个历史部署进程都用了这些字节。下一具体动作是核对这些工作进程的实际执行分支、工具注册及记录身份，继续查找RoboLab历史Direct/逐槽预算。公开数据发布者的当前数据集目录只找到RoboDojo集合，未找到同发布者的RoboLab集合；该有界查询不等于全网不存在此材料。


## 历史控制器恢复与独立试跑（09:43 UTC）

2026-10-08 历史控制器恢复推进：100条原记录均使用Codex CLI0.153.4，本次封存100条Dojo中96条为0.159.2、4条为0.153.4。恢复5套完整源码组合（41/42文件，合计42条路径），包含4个工作进程版本。78条原回合对应累计5次输入拒绝即终止的旧规则；98个共同方法案例中有11条本次记录超过该阈值，这是记录与停止规则差异，不是反事实成功率。

已独立安装官方CLI0.153.4，核验SHA512 SRI和重用文件字节；5套源码保持原字节并只读隔离。原网关模块不在公开冻结文件中，两份单独哈希的适配文件桥接现有授权运行环境，不能声称历史服务等价。5套源码的30项离线协议场景与5次真实临时线程初始化均通过，兼容性检查模型推理0次；新增12项边界/资格回归通过。临时线程检查不验证原持久历史行为。初始RGB的三个相机均0/98逐像素相同，跨案例平均每通道绝对差0.969–1.130（0..255），不据此归因成绩变化。

独立试跑已于09:43 UTC启动原面板首对arrange_largest_number随机layout0，固定原Direct/Hybrid各自源码、CLI0.153.4、种子、1050步原生时域和max_decisions=0。首批原生控制ACK已观察，成绩尚待完整动作审计。unit为gpt-policy-historical-worker-canary-20261008.scope；输出historical_worker_campaign/canary_20261008T094400Z_arrange_largest_number_random_g0_l0，自动物理重试0。首次尝试无论结果均保留，错误阈值或基础设施退出保持未完成；现有200回合、失败与封存证明不改变。

下一前沿：完成这对原版本真实动作链路与完整审计，再判断新的历史版本面板如何继续；继续恢复RoboLab Direct源码/prompt、逐槽180/500预算与重试选择。已向用户请求这些材料链接，仍待答复。布局4的原辅助臂物理差异、历史网关/模型服务与隐藏物理快照仍缺证据；历史严格等价与整篇blog全部复现保持false。执行边界见ADR_HISTORICAL_WORKER_RECONSTRUCTION.md，身份/兼容性凭据见publication_checks/worker_fidelity_20261008。


历史工作进程恢复交付已于2026-10-08 10:11 UTC验收：源码提交`bb07bec81d59076d15bb5167cc32489c7f117d8e`，发布提交`9f4bd3fefb863d00165ced436d175355d4c07674`，CI`37761496246`成功，17份在线文件和1207份公开下载包成员逐字节/SHA一致，包SHA`7e27acfffb8904d207e4c65d0cf0197906e4763b703bc7b9f7160b7ede1c7375`。59项报告+12项工具回归全部通过；桌面与390px线上截图与本地SHA一致、页面错误0；旧原生证明cc38b42c...不改写。新原版本Direct真实试跑已观察445/1050步，前5次决策25步通过独立原动作审计，仍不是完整成绩。两方法完成后，独立只读gpt-policy-historical-canary-audit-20261008.scope将执行完整动作/原视频检查；没有模型或物理重试。正在运行的试跑和检查不因本次网页交付结束而停止。具体状态publication_checks/worker_fidelity_20261008/checkpoint.json；历史严格等价和整篇blog全部复现仍为false。



2026-10-10继续推进：原版本试跑两方法已于10-08自然完成并于12:31 UTC通过完整动作和原视频审计，Direct1050步/210决策、Hybrid1050步/127决策，二者原生失败、分数0.3。原Hybrid同案例为0.05，不能据控制链审计通过声称结果一致。完整原始首次尝试与失败保留，自动物理重试0；试跑benchmark_eligible=false保持，不混入封存200回合。

其余49对/98次首次尝试已独立冻结为historical_worker_campaign/remaining49_20261010，准入SHA d564c1e7cde3d1bfb7aabe80b247100bf31f8b849fdb7789f264692ece30345d，19项相关边界回归和零调用真实预检通过。执行scope gpt-policy-historical-remaining49-20261010.scope于10-09 16:31 UTC启动；首对arrange_largest_number standard layout1 Direct已进入真实运行。排程只依据冻结身份覆盖源码版本；保留第一尝试，已有启动凭据缺审计时停止恢复，禁止自动物理重试。输入错误上限前缀和原生无效布局不计成绩，基础设施/审计失败停止排查。逐回合将完整审计原动作和视频。执行约定HISTORICAL_REMAINING_COHORT_20261010.md；进展以队列progress.json及独立证据门为准。

剩余前沿为实际完成并审计这98次尝试，继续恢复RoboLab Direct源码/prompt、逐槽180/500预算及重试选择，并核查layout4辅助臂有效性差异。原网关/模型快照和隐藏物理仍缺证据；历史严格等价与整篇blog全部复现保持false。封存200回合和cc38b42c...原验收证明不改写。
