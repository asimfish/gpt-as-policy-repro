import json
import os
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch

import run_historical_cohort as original
import continue_historical_cohort as serial
from continue_historical_parallel_admission import retained_prefix


class ParallelAdmissionTests(unittest.TestCase):
    def fixture(self, root):
        rows = [dict(episode_id='case_'+str(i), profile_id='profile') for i in range(4)]
        plan = dict(pairs=[dict(cases=rows[:2]), dict(cases=rows[2:])])
        (root/'cohort_plan.json').write_text(json.dumps(plan))
        for row in rows[:2]:
            run = root/'episodes'/row['episode_id']; run.mkdir(parents=True)
            (run/'launch_claim.json').write_text('{}')
            (run/'input.json').write_text(json.dumps(row))
            gate = dict(verified=True, episode_id=row['episode_id'], profile_id='profile',
                plan_sha256=original.sha((root/'cohort_plan.json').read_bytes()),
                evidence_inputs_sha256={'input.json':original.sha((run/'input.json').read_bytes())})
            (run/'evidence_gate.json').write_text(json.dumps(gate))
        return plan

    def test_same_gates_and_pending_order_as_frozen_serial_verifier(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);plan=self.fixture(root)
            self.assertEqual(retained_prefix(root,plan), serial.retained_prefix(root,plan))

    def test_tampered_retained_input_fails_before_admission(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);plan=self.fixture(root)
            (root/'episodes/case_1/input.json').write_text('changed')
            for verifier in (retained_prefix,serial.retained_prefix):
                with self.assertRaises(ValueError):verifier(root,plan)

    def test_symlinked_input_is_rejected_by_original_verifier(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);plan=self.fixture(root);p=root/'episodes/case_1/input.json'
            target=root/'replacement.json';target.write_bytes(p.read_bytes());p.unlink();p.symlink_to(target)
            with self.assertRaises(ValueError):retained_prefix(root,plan)

    def test_orphan_first_claim_is_never_replayed(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);plan=self.fixture(root)
            (root/'episodes/case_1/evidence_gate.json').unlink()
            with self.assertRaises(ValueError):retained_prefix(root,plan)

    def test_hole_before_retained_attempt_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);plan=self.fixture(root)
            plan['pairs'][0]['cases'].reverse()
            plan['pairs'][0]['cases'].insert(0,plan['pairs'][1]['cases'].pop())
            with self.assertRaises(ValueError):retained_prefix(root,plan)

    def test_file_reviews_overlap_without_changing_return_order(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);plan=self.fixture(root);barrier=threading.Barrier(2)
            real=original.verify_retained
            def coordinated(*args):
                barrier.wait(timeout=2)
                return real(*args)
            review=serial.retained_prefix if os.environ.get('ADMISSION_REVIEW_REFERENCE')=='serial' else retained_prefix
            with patch.object(original,'verify_retained',side_effect=coordinated):
                gates,pending=review(root,plan)
            self.assertEqual([x['episode_id'] for x in gates],['case_0','case_1'])
            self.assertEqual([x['episode_id'] for x in pending],['case_2','case_3'])


class JitParallelAdmissionTests(ParallelAdmissionTests):
    """Apply the same corruption/order oracle to the versioned JIT entrypoint."""
    def setUp(self):
        from continue_historical_parallel_admission_v2 import retained_prefix as jit_review
        replacement = patch(__name__ + '.retained_prefix', jit_review)
        replacement.start()
        self.addCleanup(replacement.stop)


if __name__=='__main__':unittest.main()
