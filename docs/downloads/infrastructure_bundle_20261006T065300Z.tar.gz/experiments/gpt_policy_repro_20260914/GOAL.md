# GPT-as-Policy 两种方法复现目标

## Outcome

按用户 2026-09-16 的范围修正，主要复现报告自己的两种方法：GPT Direct 与 π0.5 + GPT（Hybrid）。交付我们自己运行生成的在线报告、完整轨迹和可复用基础设施。

## In scope

- GPT Direct：使用原仓库的持久 GPT 控制器与 GPTOnlyTools，观察图像和状态，直接生成并执行短段末端控制，不调用 π0.5。
- Hybrid：使用原仓库 RoboDojoTools；π0.5 提议动作，GPT 根据观测与反馈接受前缀、修改或接管，保留完整闭环历史。
- 优先 RoboDojo 主实验：同一冻结面板50个案例，每个案例分别运行两方法，共100条轨迹。
- RoboLab 补充实验：10任务×5种子×两方法，共100条新固定种子轨迹；不扩展其他模型基线。
- 保留原生终止条件、输入输出、prompt、工具调用、模型身份、token、初态、视频与失败证据。

## Out of scope for active work

Cosmos、DreamZero、独立 π0.5 全量基线、prefix/chunk 对照扩展。已获得的结果和资产保留为历史辅助材料，不能当作 Direct/Hybrid 复现成绩。π0.5 推理服务继续保留，作为 Hybrid 必需组件。

## Acceptance

- [x] 原生仿真与 π0.5 推理链路验证。
- [x] 原仓库持久控制器启动入口已准备；2026-09-16两方法真实app-server握手/工具注册及原生工具预检通过（零模型调用）。
- [x] 用户授权当前Codex CLI后，gpt-6-astra/xhigh真实模型响应验证通过；证据astra_live_probe_20260916。
- [x] 同一个冻结案例完成 Direct 与 Hybrid 两条完整轨迹并审计；截至 2026-10-05 已有 49 个主实验完整配对，另有 6 个 RoboLab 补充配对。
- [ ] RoboDojo 两方法100条配对轨迹完成，失败和基础设施中断区分。
- [x] 在线报告以两方法自己的结果为主；公开数字与已有基线分开（v2 自动生成主板已发布、字节与浏览器验收通过）。
- [ ] 完成两方法 RoboLab 补充评测并明确历史环境等价性限制。

## Current frontier

2026-10-06：原面板线上已完整审计RoboDojo99/100、49/50配对；RoboLab21/100、6/50配对。
原面板提交0b44186afee1307acca5d46629edff8ab6cd12d9已于2026-10-05T22:22:17.815820+00:00精确HTTP/hash核验。
完整目标仍进行中，RoboLab当前Direct ClutterPumpkinTask seed1正常执行；21份原归档已验证，积压为零。

用户在上次可审阅的layout5补齐方案之后再次要求“继续推进”。本轮按此续推进指令执行该方案，
记录为user_continue_20261006_after_reviewable_replacement_proposal：另建有效50对清单，
只将imitate_sorting_sequence layout4整对替换成同一原60案例面板中预冻结的下一编号layout5，
补跑Direct和Hybrid两条新原生回合。原50案例清单、全部旧结果、完整失败与无效布局尝试均保留；
原面板与有效面板分别报告，不能相加为独立样本，也不选择两方法中更好的结果。

layout4已有五次Hybrid完整1600步原生排除。保持初态、零模型/零π推理的独立诊断，
同样于432步得到原辅助臂验证失败（aim2手表不在basket1），走满1600步仍无效。
layout5通过相同冻结原生配置的553步演示检查，并走满1600步诊断。
两条诊断3200条动作全部核对为保持初态，各1601帧原视频；诊断不计作模型实验。
底层抓取/物理重放原因尚未完全证明，未修改原生判定、轨迹、prompt、模型或时域。

v6有界原生无效重试队列已于2026-10-05T14:28:01.696574+00:00在物理回合边界切换成功；
原资格函数与最早有效原生失败/审计缺口优先级保留。原v6及RoboLab v2冻结源码不改写。
新补齐队列独立状态、使用相同执行锁，只负责layout5两方法，完整失败和审计缺口仍阻止物理替代。
不可变有效清单及原文件/诊断SHA核验见fixtures/robodojo_valid_cohort_v2.json，
显式选择指针为fixtures/robodojo_active_cohort.json；补齐过程与上线验收尚在执行，不能称为完成。

旧RoboLab归档积压已经清零：截至2026-10-05T12:59:08.758233+00:00，最早原生完整回合18条全部完成原归档与完整动作审计，
summary为verified18/requires_repair0/pending0。ClutterPumpkinTask seed0/1 Hybrid原生成功801/632步，seed2原生失败1350步，三条完整结果均保留。
新验收器再次核对三条原回合的3015个审计输入、整份原归档manifest与原传感视频帧数，均通过。

RoboDojo build_tower standard layout3 Direct已原生完整失败1050步/210决策，完整审计通过并按原失败计分。
旧启动超时缺项已全部完成原生回合及完整审计；唯一未完成项为上述原生演示无效布局。后续启动等待保持1200秒。
修复了报告把invalid_native_layout当作audit_pending候选而永久挡住有效重试的问题：
仅原生eligibility=false、success/score=null且冻结身份匹配的无效布局排除。
有效完整失败和最早有效完整审计缺口继续保留。实站漏掉的新原因标签也已补齐，34项站点回归与真实构建通过。

新增verify_reproduction_completion.py及14项验收边界回归，gpt-policy-final-verification.timer已enabled。
覆盖未满时只记录pending_native_episodes，不启动模型或仿真；两套均100/100与50/50后才扫描全部原审计输入、
最早有效原生回合、每一步传感视频、全视频解码及807个公开文件的字节/hash，并核对同一提交CI。
完成证明按提交存入final_verification/<commit>/certificate.json，保留原验收时间；full_reproduction_complete当前false。
两条真实已停止原回合共3400个审计输入已用新验收器复核，完整原视频帧数1051/557通过，不代替200条最终验收。

RoboLab后续监督器在慢归档前保存原生结果和完整控制器输出、同步controller_finished阶段；
复制中断先保留原结果，冻结v2会标成audit_failed并禁止新的物理替代，原完整失败不能被后续成功覆盖。
旧监督器的seed4原归档已完成，新ClutterPumpkin进程已实际加载新保存逻辑并核对源码SHA一致；不重连或重放不确定动作。
RoboLab v2切换、2228文件完整资产和独立空闲GPU选择已实际验证，两个冻结调度器SHA保持不变。
活动SQLite继续位于本机/tmp；已封存工作区与状态自动转存私有NAS，报告与归档恢复timer继续运行。

下一前沿是完成layout5两方法原生回合与独立报告，继续RoboLab矩阵至100/100和50/50，再执行所选200回合及保留原回合的最终全量在线验收。
RoboLab Direct为本项目EEF适配器；历史源码/完整初态未公开，不声称逐位环境等价或独立重算IK。
详细证据见RUNBOOK.md、ROBOLAB_ARCHIVE_DIAGNOSIS.md及publication_checks/remediation_20261005。

## Decisions

- 2026-10-06：在可审阅的layout5整对补齐提案之后，按用户“继续推进”执行独立有效50对面板；原50对结果与失败统计保留并分别发布，原冻结文件不改写。

- 2026-09-16：用户明确“主要复现这个文档自己的两种方法就行”；优先级覆盖此前全模型扩展范围。
- 停止继续运行独立π0.5基线队列和额外模型传输；不删除已下载资产和历史结果。
- 2026-09-16追加授权：用户明确要求直接使用当前Codex CLI的GPT-6 Astra。通过CLI自身认证复用当前登录态，不复制、不输出凭据；SQLite运行状态保持每次实验独立。该决定覆盖此前要求单独实验账号的限制。
- 既有历史目标保存在 GOAL_before_scope_correction_20260916.md，仅供追溯。

## Evidence

report_interpretation_zh.md、infra/run_original_controller.sh、现有仿真与π0.5审计记录。在线报告：https://asimfish.github.io/gpt-as-policy-repro/scenes.html 。当前在线报告已以两种主方法的自有结果为主；50 个配对与 RoboLab 补充仍未全量完成。


2026-10-06补齐执行进展：独立清单SHA256为d0b76047a1f570f964b6987550538982f49182ba321a07c568f7ba1d2c7473cd。`gpt-policy-robodojo-supplement-v2.service`已enabled并于22:43:13UTC启动；Direct layout5新物理回合运行中，Hybrid随后执行。真实构建与页面验证：原面板99/100、49对，独立有效面板98/100、49对，RoboLab21/100、6对；桌面与390px手机验证通过，两面板筛选、深链接与完整视频实际播放均通过。已停止回合的自动私有状态转存已支持新增案例，仍执行同一哈希固定的v5完整资格检查并拒绝活动worker；六项回归通过。验收器16项回归通过，当前记录pending_native_episodes，不生成完成证书。页面及新基建包的线上精确字节验证另行记录，尚未完成时不得声称发布完成。
