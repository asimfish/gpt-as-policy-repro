"""Take a private immutable audit snapshot of completed live Direct/Hybrid decisions, without RPC."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import shlex
import shutil
import subprocess

from transfer_checkpoint_chunks import SSH
from audit_robolab_gpt_actions import audit

ARTIFACTS=Path(__file__).resolve().parents[1]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--decisions',type=int,required=True)
    parser.add_argument('--no-publish-latest',action='store_true')
    args=parser.parse_args()
    active=json.loads((ARTIFACTS/'robolab_gpt_active.json').read_text())
    assert active['method'] in ('pi05_plus_gpt','gpt_only') and active['status']=='controller_running'
    prefix='hybrid_' if active['method']=='pi05_plus_gpt' else 'direct_'
    assert active['attempt'].startswith(prefix) and Path(active['attempt']).name==active['attempt']
    workspace=Path(active['local_workspace'])
    assert workspace.parent==Path('/tmp') and workspace.name=='gpt-policy-robolab-'+active['attempt']
    destination=ARTIFACTS/'robolab_gpt_prefix_audits'/(active['attempt']+'_d'+str(args.decisions)+'_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
    destination.mkdir(parents=True,exist_ok=False)
    shutil.copytree(workspace/'rollout',destination/'rollout',ignore=shutil.ignore_patterns('runtime_db','runtime_logs'))
    remote_output=active['remote_output']
    assert remote_output=='/home/dataset-assist-0/liyufeng/agentic_robot/experiments/gpt_policy_repro_20260914/robolab_gpt_campaign/'+active['attempt']
    includes=(['/policy_identity.json'] if active['method']=='pi05_plus_gpt' else [])+['/sim/','/sim/*/','/sim/*/chunk_*.npz','/sim/*/initial_scene.json',
              '/sim/*/codex_decisions/','/sim/*/codex_decisions/*.json']
    argv=['rsync','-az','--partial','--timeout=90','-e',shlex.join(SSH[:-1])]
    argv += ['--include='+p for p in includes]+['--exclude=*','mainskill:'+remote_output+'/',str(destination/'remote')+'/']
    subprocess.run(argv,check=True,timeout=300)
    proof=audit(destination,args.decisions)
    (destination/'action_audit_prefix.json').write_text(json.dumps(proof,indent=2)+'\n')
    latest=dict(proof)
    latest.update(attempt=active['attempt'],snapshot=str(destination),audited_utc=datetime.now(timezone.utc).isoformat())
    if not args.no_publish_latest:(ARTIFACTS/'robolab_gpt_latest_prefix_audit.json').write_text(json.dumps(latest,indent=2)+'\n')
    print(json.dumps({k:v for k,v in latest.items() if k not in ('snapshot','files_sha256','model_tool_event_sha256')}))


if __name__=='__main__':main()
