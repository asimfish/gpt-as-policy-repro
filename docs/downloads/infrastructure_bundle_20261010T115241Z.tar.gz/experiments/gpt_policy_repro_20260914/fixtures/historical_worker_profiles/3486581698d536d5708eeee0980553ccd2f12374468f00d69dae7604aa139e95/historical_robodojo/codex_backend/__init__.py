"""Explicit current-runtime bridge, absent from original frozen source."""
