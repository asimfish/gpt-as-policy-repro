# 两方法复现完成交付 · 2026-10-07

所选两套固定范围评测已全部完成：RoboDojo 100/100 回合、50/50 对；RoboLab 100/100 回合、50/50 对。RoboLab 队列于 2026-10-07 08:24 UTC 自然结束，全部100份原归档verified，requires_repair=0、pending=0、活动保留槽为0。

联合终验于 2026-10-07 09:34:13 UTC 完成，status=complete、full_reproduction_complete=true。原始证明绑定报告提交 `5d7a430557ba91da93a16b5b174305ded275bf39`，同提交 CI `37594282741` 成功；覆盖所选200条及另存原布局1条，共232427项原审计输入、整份RoboLab归档、原始及导出完整视频，并核验815个公开文件。证明封存于 `final_verification/5d7a430557ba91da93a16b5b174305ded275bf39/certificate.json`，SHA256 `cc38b42cfcf0c098c2ad58a3af9a2e265fc1bd3b6e92ddeeae7208f18e4b3ee9`。后续交付不覆盖原证明或刷新原验收时间。

最终成功数：RoboDojo Direct 13/50（平均score 0.395）、Hybrid 21/50（平均score 0.548）；RoboLab Direct 49/50、Hybrid 46/50。所有原生完整失败保留并计入分母。原RoboDojo面板99/100和49对另行报告，与有效面板共享49对，不能相加作为独立样本；无效layout4按已批准方案整对改为预冻结layout5。

本轮只读重核200条所选及1条保留原审计证明的SHA、815个当前发布文件的SHA、19份冻结v5源码和精确提交CI，均与封存证明一致。证据：`publication_checks/completion_delivery_20261007/evidence_binding.json`。完成队列已禁用自启动；模型文字探测、周期发布和周期联合验收已停用，原归档恢复及私有冷归档维护仍启用。只停用已无活动进程的单元，未中断任何物理回合。

RoboLab Direct 使用本项目EEF适配器；历史Direct源码、prompt及完整物理初态不可得，未独立重算IK。本次完成指上述冻结范围的执行、审计和交付，不声称与历史实验逐位环境等价。最终交付说明见 `COMPLETION_20261007.md`。

## 验收与复用

在线主报告：https://asimfish.github.io/gpt-as-policy-repro/scenes.html

有效主实验：https://asimfish.github.io/gpt-as-policy-repro/gpt-methods-valid.html

补充实验：https://asimfish.github.io/gpt-as-policy-repro/robolab-methods.html

公开完成证明：https://asimfish.github.io/gpt-as-policy-repro/data/reproduction-completion.json

最终基础设施包由 `deliverables/infrastructure_bundle_verification.json` 指向最新不可变归档；`manifest.json` 绑定每份文件SHA256、上游源码提交及终验凭据。归档不含认证、原始模型日志、SQLite、权重或大型资产。大型原始实验数据保留于原工作区/私有NAS，公开报告保留所有完整回放及脱敏审计。

迁移时按 RUNBOOK.md 和包内 REPRODUCTION_BUNDLE.md 准备固定源码、资产、环境与既有授权登录。封存证明只认证本次已完成的固定实验；重新运行属于新实验，应新建输出和证明，不能覆写本次结果。源码补丁、无效布局诊断、冻结替换清单与恢复证据均在包中。

## 最终公开交付核验

最终公开交付已于 2026-10-07 11:08 UTC 核验：提交 `69b9902ec6a84adec64a667607abfe28cb790ebc` 的 CI `37611841778` 成功，15个在线文件与提交字节一致；公开下载包 `downloads/infrastructure_bundle_20261007T110456Z.tar.gz` 的905份文件SHA逐项通过，归档SHA256 `0c70bdc83a89440cd4ac8e0540196dde813e2170a29417c2ffb8b6fd3a3a083d`。公开 `data/reproduction-completion.json` 与封存原件逐字节一致；原终验提交和时间保持不变。具体证明：`publication_checks/completion_delivery_20261007/public_bundle_verified.json`、`exact_commit_ci.json`、`publication_http.json`。本次约定范围无剩余原生回合、审计或发布阻塞。
