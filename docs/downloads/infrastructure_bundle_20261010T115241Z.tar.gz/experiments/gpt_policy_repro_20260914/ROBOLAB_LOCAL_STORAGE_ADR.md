# ADR: use the second local SSD for future RoboLab runtime state

Status: accepted within the user's continuing authorization to complete the frozen evaluation. This is a reversible local runtime deployment; active episodes and SQLite files are not moved.

At 2026-10-06 14:45 UTC the system ext4 volume had about 5.9 GiB available, down from 9.3 GiB twenty minutes earlier. All 73 stopped and fully audited workspaces had already been moved to private NAS storage with byte verification. Only about 1 GiB of live and retained interrupted RoboLab state remained; deleting it would neither preserve evidence nor address the continuing pressure. The separate ext4 volume mounted at /data had about 867 GiB available.

| Candidate | Benefit | Constraint |
| --- | --- | --- |
| Continue using /tmp and offload stopped audited state | Keep current deployment | Limited and shrinking headroom; maintenance already processed all eligible state |
| Put future native episodes' workspace on the second local SSD | Preserve local SQLite semantics with substantial headroom | Version the two launch entrypoints and let storage maintenance recognize both approved roots |

Choose the second approach. Canonical configuration remains JSON: the v4 source manifest records one exact owned runtime root, source hashes, the existing v2 qualification hash, original v3 provenance and the frozen 100-run SHA. A small storage boundary validates ownership, private permissions, canonical paths, local ext4 and available capacity. New launches must use the approved second SSD; there is no automatic fallback to NAS or the full system volume.

Existing live workers retain their original workspace, ports, GPUs, app-server connection, prompts, model identity and native horizon. A local coordinator replacement adopts their durable leases using the existing boot/start identity logic. Only the coordinator process is stopped; KillMode=process and explicit PID identity verification fence the operation. Original v3 code and unit remain available for rollback. The v4 coordinator keeps the exact v2 oracle, retry epoch, first-native-failure/audit-gap behavior, three-slot reservations and cleanup/archive release rules. The remote manager is unchanged.

New v4 supervisors differ only in the validated local workspace root and source provenance of the added storage helper. Original controller code, tool interface, model arguments, simulator parameters, asset pins and scoring are unchanged. Activity export already reads the recorded workspace and publishes only sanitized progress. Storage maintenance accepts only the two explicit roots and still requires stopped owners, complete native audits, every-file SHA verification and private NAS retention before removing a duplicate.

Acceptance: validate SQLite WAL on the second SSD with zero model/simulator calls; reject symlinks, foreign roots, ownership changes and insufficient capacity; re-run reservation/adoption tests against v4; prove source differences are restricted to workspace/configuration; record pre/post live process identities and increasing original controls; observe a later native worker use the second SSD. Whole reproduction stays incomplete until the existing joint 200-episode gate passes.
