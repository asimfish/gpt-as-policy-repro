import hashlib
import io
import json
from pathlib import Path
import tarfile
import tempfile
import unittest
from prepare_original_codex_cli import safe_members,verify_extracted_package,check_tarball_url
from stage_historical_workers import checked_relative,verify_tree
from inspect_historical_worker_protocol import rejection_stop,rejection_summary,RECOVERABLE_WORKER,FIVE_STOP_WORKERS

class HistoricalBoundaries(unittest.TestCase):
    def test_rejection_stop_requires_reviewed_hash(self):
        self.assertIsNone(rejection_stop(RECOVERABLE_WORKER))
        for digest in FIVE_STOP_WORKERS:self.assertEqual(rejection_stop(digest),5)
        with self.assertRaises(ValueError):rejection_stop('0'*64)
    def test_rejection_requires_explicit_no_execution(self):
        calls=[dict(call_index=i,result=packet) for i,packet in enumerate([
            None,dict(error='uncertain'),dict(error='rejected',no_execution=True),dict(error='not proven',no_execution=1),dict(step_id=1)])]
        r=rejection_summary(calls);self.assertEqual(r['recorded_no_execution_rejections'],1)
        self.assertEqual(r['missing_result_packets'],1);self.assertEqual(r['other_error_packets'],2)
    def test_source_path_rejects_noncanonical_and_executable_non_source(self):
        for name in ('../run.py','/run.py','skill//run.py','skill/./run.py','skill\\run.py','run.py:stream','blob.pkl'):
            with self.subTest(name=name),self.assertRaises(ValueError):checked_relative(name)
        self.assertEqual(str(checked_relative('skill/run.py')),'skill/run.py')
    def test_tree_rejects_tampering_and_symlink(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);p=root/'run.py';p.write_bytes(b'pass\n');expected={'run.py':hashlib.sha256(p.read_bytes()).hexdigest()}
            verify_tree(root,expected);p.write_bytes(b'raise Exception\n')
            with self.assertRaises(ValueError):verify_tree(root,expected)
            p.unlink();p.symlink_to('/etc/passwd')
            with self.assertRaises(ValueError):verify_tree(root,expected)
    def test_package_denies_escape_links_and_duplicate(self):
        for name,kind in (('package/../../escape',tarfile.REGTYPE),('outside/run',tarfile.REGTYPE),('package/link',tarfile.SYMTYPE),('package/device',tarfile.CHRTYPE)):
            with self.subTest(name=name),tempfile.TemporaryDirectory() as d:
                path=Path(d)/'test.tar'
                with tarfile.open(path,'w') as tar:
                    item=tarfile.TarInfo(name);item.type=kind;tar.addfile(item)
                with tarfile.open(path) as tar,self.assertRaises(ValueError):safe_members(tar)
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'duplicate.tar'
            with tarfile.open(path,'w') as tar:
                tar.addfile(tarfile.TarInfo('package/run'));tar.addfile(tarfile.TarInfo('package/run'))
            with tarfile.open(path) as tar,self.assertRaises(ValueError):safe_members(tar)
    def test_reused_package_bytes_checked_before_execution(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);target=root/'package';target.mkdir();archive=root/'package.tar'
            contents={'package.json':json.dumps(dict(name='@openai/codex',version='0.153.4')).encode(),'bin/run':b'original'}
            with tarfile.open(archive,'w') as tar:
                for name,data in contents.items():
                    item=tarfile.TarInfo('package/'+name);item.size=len(data);tar.addfile(item,io.BytesIO(data))
                    path=target/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
            self.assertEqual(len(verify_extracted_package(archive,target,'0.153.4')),2)
            (target/'bin/run').write_bytes(b'modified executable')
            with self.assertRaises(ValueError):verify_extracted_package(archive,target,'0.153.4')
    def test_registry_url_is_exact_release(self):
        check_tarball_url('https://registry.npmjs.org/@openai/codex/-/codex-0.153.4.tgz','0.153.4')
        for url in ('http://registry.npmjs.org/@openai/codex/-/codex-0.153.4.tgz','https://registry.npmjs.org.attacker.invalid/@openai/codex/-/codex-0.153.4.tgz','https://registry.npmjs.org/@openai/codex/-/codex-0.153.4.tgz?redirect=x'):
            with self.assertRaises(ValueError):check_tarball_url(url,'0.153.4')

if __name__=='__main__':unittest.main()
