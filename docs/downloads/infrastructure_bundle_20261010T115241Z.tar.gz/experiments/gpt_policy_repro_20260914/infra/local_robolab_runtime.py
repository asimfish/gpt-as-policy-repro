"""Explicit owned local ext4 roots; runtime SQLite never falls back to NAS."""
import os
from pathlib import Path
import shutil
import stat
import subprocess

LOCAL_ROOT=Path('/data/liyufeng/agentic_robot_runtime/gpt_policy_repro_20260914')
MIN_FREE_BYTES=16*1024**3


def validate_root(root, *, free_bytes=None, filesystem=None, distinct_device=None):
    root=Path(root)
    if root!=LOCAL_ROOT or root.resolve()!=root:
        raise ValueError('Only the exact approved second-SSD runtime root is supported')
    if not root.is_dir() or any(p.is_symlink() for p in [root,*root.parents]):
        raise ValueError('Runtime root must be a canonical regular directory')
    info=root.stat()
    if info.st_uid!=os.getuid() or stat.S_IMODE(info.st_mode)!=0o700:
        raise ValueError('Runtime root must be owned and private')
    if distinct_device is None:distinct_device=root.stat().st_dev!=Path('/tmp').stat().st_dev
    if not distinct_device:raise ValueError('Runtime root must use the separate local volume')
    if filesystem is None:filesystem=subprocess.check_output(['stat','-f','-c','%T',str(root)],text=True,timeout=10).strip()
    if filesystem!='ext2/ext3':raise ValueError('A local ext4 runtime filesystem is required')
    if free_bytes is None:free_bytes=shutil.disk_usage(root).free
    if free_bytes<MIN_FREE_BYTES:raise ValueError('Insufficient free space for new native workers')
    return root


def recorded_root(record):
    if not isinstance(record,dict) or not isinstance(record.get('local_workspace'),str) or not isinstance(record.get('attempt'),str):
        raise ValueError('Workspace identity metadata is incomplete')
    workspace=Path(record['local_workspace']);name='gpt-policy-robolab-'+record['attempt']
    if workspace.name!=name or workspace.parent not in (Path('/tmp'),LOCAL_ROOT):
        raise ValueError('Workspace is outside the two approved local roots')
    return workspace.parent
