"""An execution-only update cannot change already delivered benchmark statistics."""
import copy
import hashlib
import json
import unittest
from build_historical_execution_delta import validate_parent,unchanged_baseline,BASE_COMMIT


class HistoricalExecutionDeltaTests(unittest.TestCase):
    def fixture(self):
        value=dict(independent_evaluation_complete=True,historical_equivalence_verified=False,native_completion_sha256='certificate',
                   robodojo={'successes':13},historical_worker_fidelity={'core':{'value':1},'original_version_execution':{'old':True}})
        data=json.dumps(value).encode();sha=hashlib.sha256(data).hexdigest()
        delivery=dict(verified=True,commit=BASE_COMMIT,comparison_sha256=sha,certificate_sha256='certificate')
        stats=dict(verified=True,complete_native_episodes=200,comparison_sha256=sha,files_sha256={str(i):'hash' for i in range(900)})
        return value,data,delivery,stats

    def test_verified_parent_and_execution_only_change_are_accepted(self):
        value,data,delivery,stats=self.fixture();self.assertEqual(validate_parent(data,delivery,stats),value)
        changed=copy.deepcopy(value);changed['historical_worker_fidelity']['original_version_execution']={'new':True}
        unchanged_baseline(value,changed)

    def test_wrong_parent_or_tampered_blob_is_rejected(self):
        _,data,delivery,stats=self.fixture()
        with self.assertRaises(ValueError):validate_parent(data+b' ',delivery,stats)
        delivery['commit']='another'
        with self.assertRaises(ValueError):validate_parent(data,delivery,stats)

    def test_native_or_worker_statistics_cannot_change(self):
        value,_,_,_=self.fixture()
        for changed in (copy.deepcopy(value),copy.deepcopy(value)):
            if changed==value:changed['robodojo']['successes']=14
            with self.assertRaises(ValueError):unchanged_baseline(value,changed)
        changed=copy.deepcopy(value);changed['historical_worker_fidelity']['core']['value']=2
        with self.assertRaises(ValueError):unchanged_baseline(value,changed)


if __name__=='__main__':unittest.main()
