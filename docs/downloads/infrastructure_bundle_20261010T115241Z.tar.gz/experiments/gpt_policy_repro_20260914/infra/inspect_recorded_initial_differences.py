"""Measure observed float differences; distinguish archived prompt paths from instructions."""
import datetime,hashlib,io,json,re,zipfile
from pathlib import Path
import numpy as np
from compare_recovered_originals import ART,Q,METHODS,FIELDS,sha,read
from verify_original_robodojo_records import checked_zip,arrays

def numeric_delta(a,b):
    assert a.shape==b.shape and a.dtype==b.dtype==np.dtype('float32')
    assert np.isfinite(a).all() and np.isfinite(b).all()
    return float(np.max(np.abs(a.astype('float64')-b.astype('float64'))))

def working_directory_free_prompt(data):
    """Ignore exactly one documented deployment line; preserve every other byte."""
    lines=data.splitlines(keepends=True)
    matches=[i for i,line in enumerate(lines) if line.startswith(b'Agent working directory: ')]
    assert len(matches)==1,'Expected one deployment directory line'
    lines[matches[0]]=b'Agent working directory: <deployment directory>\n'
    return b''.join(lines)

def own_initial(data):
    result={}
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        checked_zip(z,max_entries=10,max_member=4*1024**2,max_total=16*1024**2)
        for name,shape in [('states',(14,)),('eef_positions',(2,3)),('eef_quaternions_wxyz',(2,4))]:
            raw=z.read(name+'.npy');assert len(raw)<4096
            f=io.BytesIO(raw);version=np.lib.format.read_magic(f)
            assert version in ((1,0),(2,0))
            reader=np.lib.format.read_array_header_1_0 if version==(1,0) else np.lib.format.read_array_header_2_0
            actual,order,dtype=reader(f);assert actual==shape and dtype==np.dtype('float32')
            assert len(raw)-f.tell()==int(np.prod(shape))*4
            result[name]=np.load(io.BytesIO(raw),allow_pickle=False)
    return result

def main():
    proof=read(Q/'original_record_recount.json');comparison=read(Q/'recovered_comparison.json')
    assert proof['verified'] is True and proof['core_archives_verified']==100
    old={(r['case_id'],METHODS[r['method']]):r for r in proof['records']}
    rows=[];inputs={}
    for r in comparison['robodojo']['cases']:
        a=old[r['case_id'],r['method']]
        archive=ART/'original_public_rollouts/astra_robodojo_bf8d15ea/core'/(a['episode_id']+'.core.zip')
        with zipfile.ZipFile(archive) as z:
            checked_zip(z);trajectory=arrays(z.read('trajectory.npz'));archived_prompt=z.read('prompts/PROMPT.md')
        root=ART/'gpt_pair_campaign'/r['run_id']/r['method']
        # Episode directory must be unique and local; never resolve downloaded paths.
        episodes=[p for p in (root/'sim').iterdir() if p.is_dir() and re.fullmatch('[a-f0-9]{32}',p.name)]
        assert len(episodes)==1
        path=episodes[0]/'observations/000000.npz';data=path.read_bytes()
        inputs[str(path.relative_to(ART))]=sha(data);initial=own_initial(data)
        prompt_path=root/'rollout/codex_workspace/PROMPT.md';prompt=prompt_path.read_bytes()
        inputs[str(prompt_path.relative_to(ART))]=sha(prompt)
        assert sha(prompt)==r['reproduction_teacher_prompt_sha256']
        for k in FIELDS:
            assert sha(initial[k].tobytes())==r['reproduction_recorded_fields'][k]['sha256']
            assert sha(trajectory[k][0].tobytes())==r['original_recorded_fields'][k]['sha256']
        rows.append(dict(case_id=r['case_id'],method=r['method'],run_id=r['run_id'],
            original_core_sha256=a['core_sha256'],max_absolute_difference={k:numeric_delta(trajectory[k][0],initial[k]) for k in FIELDS},
            archived_prompt_sha256=sha(archived_prompt),
            archived_prompt_matches_prearchive_run_hash=sha(archived_prompt)==r['original_teacher_prompt_sha256'],
            prompt_equal_after_replacing_working_directory_line=working_directory_free_prompt(archived_prompt)==working_directory_free_prompt(prompt)))
    assert len(rows)==98
    result=dict(schema='gpt_policy_recorded_initial_difference_inspection.v1',verified=True,
        verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        original_record_recount_sha256=sha((Q/'original_record_recount.json').read_bytes()),
        recovered_comparison_sha256=sha((Q/'recovered_comparison.json').read_bytes()),files_sha256=inputs,cases=rows,
        summary=dict(episodes=98,max_absolute_difference={k:max(r['max_absolute_difference'][k] for r in rows) for k in FIELDS},
            prompt_equal_after_replacing_working_directory_line=sum(r['prompt_equal_after_replacing_working_directory_line'] for r in rows),
            archived_prompt_matches_prearchive_run_hash=sum(r['archived_prompt_matches_prearchive_run_hash'] for r in rows)),
        historical_full_physics_state_verified=False,
        scope='Numeric differences cover three recorded float32 robot fields only. Prompt comparison removes exactly the deployment directory line and preserves every other byte. Archived paths were normalized by the data exporter, so its prompt bytes need not have the prearchive run hash. Neither test proves identical original model input or explains changed outcomes.',
        input_binding_scope='Original numeric values come from previously SHA-verified core trajectories. Current initial NPZ and deployed prompt files are separately SHA captured and checked against recorded fingerprints/run prompt hash; no original native gate is rewritten.')
    (Q/'initial_difference_inspection.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result['summary']),flush=True)

if __name__=='__main__':main()
