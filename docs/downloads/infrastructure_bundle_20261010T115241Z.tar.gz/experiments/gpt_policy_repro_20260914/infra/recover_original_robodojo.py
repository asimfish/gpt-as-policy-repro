"""Download immutable public core records; never execute released code or models."""
import argparse
from concurrent.futures import ThreadPoolExecutor,as_completed
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import time
import urllib.error
import urllib.parse
import urllib.request

ART=Path(__file__).resolve().parents[1]
Q=ART/'publication_checks/historical_protocol_20261008'
REVISION='bf8d15ea74c08e095037187ef10201c0f445a2d2'
BASE='https://huggingface.co/datasets/YuMoool/astra-robodojo-rollouts/resolve/'+REVISION+'/'
DEST=ART/'original_public_rollouts/astra_robodojo_bf8d15ea/core'

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def descriptor(row):
    episode=row['episode_id'];file=row['files']['core']
    if not re.fullmatch(r'(direct|hybrid)__[a-z0-9_]+',episode) or episode!=row['method']+'__'+row['case_id']:
        raise ValueError('Invalid episode identity')
    expected=f"episodes/{row['method']}/{row['task']}/{episode}.core.zip"
    if file['path']!=expected or not re.fullmatch(r'episodes/(direct|hybrid)/[a-z0-9_]+/[a-z0-9_]+\.core\.zip',file['path']):
        raise ValueError('Invalid core path')
    if type(file['bytes']) is not int or not 0<file['bytes']<=1024**3:raise ValueError('Invalid core size')
    if not re.fullmatch('[a-f0-9]{64}',file['sha256']):raise ValueError('Invalid core hash')
    return episode,file

def destination_allowed(url):
    p=urllib.parse.urlsplit(url);host=p.hostname or ''
    return p.scheme=='https' and p.username is None and p.password is None and p.port in (None,443) and (
        host=='huggingface.co' or host.endswith('.huggingface.co') or host.endswith('.hf.co') or host.endswith('.amazonaws.com'))

class PublicRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        if not destination_allowed(newurl):raise ValueError('Unapproved public-data redirect')
        return super().redirect_request(req,fp,code,msg,headers,newurl)

def offset_and_mode(status,content_range,offset,total):
    if status==200:return 0,'wb'
    match=re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)',content_range or '')
    if status!=206 or not match:raise ValueError('Invalid range response')
    begin,end,length=map(int,match.groups())
    if begin!=offset or length!=total or not begin<=end<length:raise ValueError('Range identity mismatch')
    return offset,'ab' if offset else 'wb'

def download(row,destination=DEST,opener=None):
    episode,file=descriptor(row);target=destination/(episode+'.core.zip');part=target.with_suffix('.zip.part')
    if target.is_symlink() or part.is_symlink():raise ValueError('Archive links are denied')
    if target.exists():
        if target.stat().st_size!=file['bytes'] or digest(target)!=file['sha256']:
            raise ValueError('Existing final archive differs; preserve it for review')
        return dict(episode_id=episode,status='verified',bytes=file['bytes'],sha256=file['sha256'],reused=True,
                    path=str(target.relative_to(ART)) if target.is_relative_to(ART) else target.name)
    client=opener or urllib.request.build_opener(PublicRedirect())
    failures=[]
    for attempt in range(1,4):
        try:
            offset=part.stat().st_size if part.exists() else 0
            if offset>file['bytes']:raise ValueError('Oversized partial archive')
            if offset!=file['bytes']:
                headers={'User-Agent':'gpt-policy-original-record-recovery','Accept':'application/octet-stream'}
                if offset:headers['Range']='bytes='+str(offset)+'-'
                # The fixed revision and SHA remain authoritative; nonce avoids stale signed redirects.
                req=urllib.request.Request(BASE+file['path']+'?download=true&verify='+str(time.time_ns()),headers=headers)
                with client.open(req,timeout=40) as response:
                    if not destination_allowed(response.geturl()):raise ValueError('Unapproved archive host')
                    start,mode=offset_and_mode(response.status,response.headers.get('Content-Range'),offset,file['bytes'])
                    with part.open(mode) as output:
                        count=start
                        while True:
                            block=response.read(1024*1024)
                            if not block:break
                            count+=len(block)
                            if count>file['bytes']:raise ValueError('Archive exceeds declared size')
                            output.write(block)
            if part.stat().st_size!=file['bytes']:raise ValueError('Incomplete public archive')
            if digest(part)!=file['sha256']:
                quarantine=part.with_name(part.name+'.hash_mismatch_'+str(time.time_ns()))
                part.replace(quarantine)
                raise ValueError('Archive checksum mismatch; original bytes retained')
            part.replace(target)
            return dict(episode_id=episode,status='verified',bytes=file['bytes'],sha256=file['sha256'],reused=False,
                        path=str(target.relative_to(ART)) if target.is_relative_to(ART) else target.name,attempts=attempt)
        except (OSError,ValueError,urllib.error.URLError) as error:
            # Redirect URLs can contain signed tokens; never serialize exception text.
            failures.append(dict(attempt=attempt,type=type(error).__name__,http_status=getattr(error,'code',None)))
            if attempt<3:time.sleep(2)
    return dict(episode_id=episode,status='pending',failures=failures)

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--limit',type=int,default=100)
    args=parser.parse_args();assert 1<=args.limit<=100
    manifest_data=(Q/'hf_manifest.json').read_bytes();manifest=json.loads(manifest_data)
    validation=json.loads((Q/'hf_validation.json').read_text())
    assert hashlib.sha256(manifest_data).hexdigest()==validation['manifest_sha256']
    rows=manifest['episodes'];assert len(rows)==100 and len({r['episode_id'] for r in rows})==100
    for row in rows:descriptor(row)
    rows=sorted(rows,key=lambda r:r['files']['core']['bytes'])[:args.limit]
    DEST.mkdir(parents=True,exist_ok=True,mode=0o700)
    for parent in [DEST,DEST.parent,DEST.parent.parent]:assert not parent.is_symlink()
    assert shutil.disk_usage(DEST).free>sum(r['files']['core']['bytes'] for r in rows)+1024**3
    lock=(Q/'original_core_download.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    results=[];started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    def save():
        complete=sum(r['status']=='verified' for r in results)
        value=dict(schema='gpt_policy_original_core_download.v1',revision=REVISION,started_utc=started,
            updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),planned=len(rows),
            verified=complete,finished=len(results)==len(rows),all100_verified=complete==100,
            public_source_manifest_sha256=hashlib.sha256(manifest_data).hexdigest(),
            source_dataset='YuMoool/astra-robodojo-rollouts',records=sorted(results,key=lambda r:r['episode_id']))
        p=Q/'core_download_receipt.json';temp=p.with_suffix('.tmp');temp.write_text(json.dumps(value,indent=2)+'\n');temp.replace(p)
    save()
    with ThreadPoolExecutor(max_workers=4) as pool:
        jobs={pool.submit(download,row):row for row in rows}
        for job in as_completed(jobs):
            try:row=job.result()
            except Exception as error:
                row=dict(episode_id=jobs[job]['episode_id'],status='pending',failures=[dict(type=type(error).__name__)])
            results.append(row);save()
            print(json.dumps(dict(finished=len(results),planned=len(rows),episode_id=row['episode_id'],status=row['status'],bytes=row.get('bytes'),failures=row.get('failures'))),flush=True)
    if any(r['status']!='verified' for r in results):raise SystemExit('Some core archives remain pending; preserve receipt and partial files')

if __name__=='__main__':main()
