import copy
import unittest
from compare_recovered_originals import compare_fields,unique

class ComparisonTest(unittest.TestCase):
    def test_all_three_dimensions_define_recorded_field_match(self):
        a={k:dict(shape=[14],dtype='float32',sha256='a'*64) for k in ('states','eef_positions','eef_quaternions_wxyz')}
        for key,value in [('shape',[1,14]),('dtype','float64'),('sha256','b'*64)]:
            b=copy.deepcopy(a);b['states'][key]=value
            self.assertFalse(compare_fields(a,b)['states'])
            self.assertTrue(compare_fields(a,b)['eef_positions'])
    def test_duplicate_case_method_cannot_enter_denominator(self):
        with self.assertRaises(AssertionError):unique([{'id':1},{'id':1}],lambda r:r['id'])

if __name__=='__main__':unittest.main()
