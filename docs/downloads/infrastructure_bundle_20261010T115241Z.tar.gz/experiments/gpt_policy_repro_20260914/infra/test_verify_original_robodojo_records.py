import copy,io,json,unittest,zipfile
import numpy as np
from verify_original_robodojo_records import arrays,checked_zip,verify_controls

def fixture(native=True):
    trajectory=dict(states=np.zeros((3,14),np.float32),eef_positions=np.zeros((3,2,3),np.float32),
        eef_quaternions_wxyz=np.zeros((3,2,4),np.float32),instruction=np.array(['x']*3),
        remaining_steps=np.array([10,9,8]),actions=np.zeros((2,14),np.float32))
    metadata=dict(control_steps=2,decision_count=2,method='hybrid',native_complete=native,
        native_success=False if native else None,evaluation_success=False,native_score=0 if native else None,
        adjudication=None if native else dict(schema='robodojo.rpc_idle_timeout_failure.v1',evaluation_failure=True,retry=False))
    decisions=[dict(decision=i,start_tick=i,end_tick=i+1,executed_steps=1,response={'mode':mode}) for i,mode in enumerate(['student','eef'])]
    controls=[dict(action_index=i,step_id=i+1,valid=True,executed_action=[0]*14,
        obs={'states':[0]*14},terminated=False,truncated=native and i==1,success=False) for i in range(2)]
    return metadata,decisions,controls,trajectory

class OriginalRecordTests(unittest.TestCase):
    def test_native_trace_uses_recorded_post_action_joint_state(self):
        self.assertEqual(verify_controls(*fixture()),{'student':1,'eef':1})

    def test_action_or_post_action_state_drift_is_rejected(self):
        for field in ['executed_action','states']:
            values=fixture()
            if field=='states':values[2][0]['obs'][field][0]=1
            else:values[2][0][field][0]=1
            with self.assertRaises(AssertionError):verify_controls(*values)

    def test_gap_and_premature_native_stop_are_rejected(self):
        values=fixture();values[1][1]['start_tick']=0
        with self.assertRaises(AssertionError):verify_controls(*values)
        values=fixture();values[2][0]['terminated']=True
        with self.assertRaises(AssertionError):verify_controls(*values)

    def test_adjudicated_prefix_remains_non_native_and_requires_no_retry(self):
        values=fixture(False);self.assertEqual(verify_controls(*values),{'student':1,'eef':1})
        values[0]['adjudication']['retry']=True
        with self.assertRaises(AssertionError):verify_controls(*values)

    def test_zip_traversal_and_duplicates_are_rejected(self):
        for names in [['../state.json'],['state.json','state.json']]:
            stream=io.BytesIO()
            with zipfile.ZipFile(stream,'w') as z:
                for name in names:z.writestr(name,b'{}')
            with zipfile.ZipFile(io.BytesIO(stream.getvalue())) as z:
                with self.assertRaises(ValueError):checked_zip(z)

    def test_safe_npz_roundtrip_and_object_array_denial(self):
        stream=io.BytesIO();np.savez(stream,**fixture()[3])
        parsed=arrays(stream.getvalue());self.assertEqual(parsed['states'].shape,(3,14))
        values=fixture()[3];values['instruction']=np.array([object()],dtype=object)
        stream=io.BytesIO();np.savez(stream,**values)
        with self.assertRaises(ValueError):arrays(stream.getvalue())

if __name__=='__main__':unittest.main()
