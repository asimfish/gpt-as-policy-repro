"""Probe original controller/CLI initialization without permitting a model turn."""
import contextlib
import datetime
import io
import json
import os
from pathlib import Path
import subprocess
import tempfile
from verify_historical_worker_protocol import load_profile
from stage_historical_workers import ART,Q,sha

def main():
    raw=(Q/'historical_worker_manifest.json').read_bytes();manifest=json.loads(raw)
    assert manifest['verified'] is True
    cli=ART/manifest['cli']['launcher'];assert sha(cli.read_bytes())==manifest['cli']['launcher_sha256']
    cli_receipt=(Q/'original_cli_toolchain.json').read_bytes()
    assert sha(cli_receipt)==manifest['cli']['toolchain_receipt_sha256']
    for pkg in json.loads(cli_receipt)['packages']:
        for name,digest in pkg['files_sha256'].items():
            path=ART/'toolchains/codex_cli_0_153_4'/name
            assert not path.is_symlink() and sha(path.read_bytes())==digest
    private=Path(tempfile.mkdtemp(prefix='gpt-original-cli-probe-'));private.chmod(0o700)
    fs=subprocess.run(['stat','-f','-c','%T',str(private)],capture_output=True,text=True,check=True).stdout.strip()
    if fs in ('nfs','nfs4','cifs','smb2'):raise ValueError('CLI probe state must be on a local filesystem')
    previous={key:os.environ.get(key) for key in ('ROLLOUT_CODEX_STATE_DIR','ROLLOUT_AUTH_PROFILE')};rows=[]
    # The already-authorized experiment wrapper uses this upstream routing label.
    # Without it the current bridge's unrelated default provider is selected.
    os.environ['ROLLOUT_AUTH_PROFILE']='codex_a'
    try:
        for index,profile in enumerate(manifest['source_profiles']):
            module=load_profile(profile)
            method=next(r['method'] for r in manifest['cases'] if r['profile_id']==profile['profile_id'])
            root=private/str(index);root.mkdir(mode=0o700)
            state=root/'state';state.mkdir(mode=0o700);os.environ['ROLLOUT_CODEX_STATE_DIR']=str(state)
            calls=[];responses=[];transports=[]
            class NoTurnTransport(module.StdioAppServer):
                def __init__(self,*args,**kwargs):super().__init__(*args,**kwargs);transports.append(self)
                def request(self,name,params,timeout):
                    if name not in ('initialize','thread/start'):raise AssertionError('Probe forbids model turns and execution RPC')
                    calls.append(name)
                    if name=='thread/start':
                        # Probe-only persistence override; source bytes are unchanged.
                        params=dict(params,ephemeral=True)
                    response=super().request(name,params,min(timeout,30))
                    if name=='thread/start':responses.append(response)
                    return response
                def notify(self,name,params):
                    if name!='initialized':raise AssertionError('Probe notification denied')
                    return super().notify(name,params)
            policy=None;passed=False;exception=None
            try:
                with contextlib.redirect_stdout(io.StringIO()):
                    policy=module.CodexPolicy(root/'controller/codex_workspace',str(cli),timeout=30,
                        transport_factory=NoTurnTransport,method=method)
                assert len(responses)==1
                response=responses[0]
                assert response['model']=='gpt-6-astra' and response['reasoningEffort']=='xhigh'
                assert response['thread']['ephemeral'] is True
                worker=json.loads((policy.workspace/'worker.json').read_text())
                assert worker['codex_version']=='codex-cli 0.153.4'
                assert worker['tools']==[s['name'] for s in module.tool_specs(method)]
                config=json.loads((policy.workspace/'launch.json').read_text())['config']
                assert Path(config['sqlite_home']).is_relative_to(state)
                assert Path(config['log_dir']).is_relative_to(state)
                passed=True
            except Exception as error:
                exception=type(error).__name__
                # Details may contain current-runtime account information. Retain privately.
                (root/'private_failure.txt').write_text(str(error));(root/'private_failure.txt').chmod(0o600)
            finally:
                if policy is not None:policy.close()
                for transport in transports:transport.close()
            rows.append(dict(profile_id=profile['profile_id'],method=method,verified=passed,
                exception_type=exception,rpc_methods=calls,model_turn_start_calls=0,
                model='gpt-6-astra',reasoning_effort='xhigh',cli_version='codex-cli 0.153.4',
                probe_ephemeral_override=True,sqlite_state_isolated=True,raw_logs_public=False))
            print(json.dumps(dict(profile=profile['profile_id'],initialization_passed=passed,exception_type=exception)),flush=True)
    finally:
        for key,value in previous.items():
            if value is None:os.environ.pop(key,None)
            else:os.environ[key]=value
    result=dict(schema='gpt_policy_original_cli_zero_turn_probe.v1',verified=all(r['verified'] for r in rows),
        verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),manifest_sha256=sha(raw),profiles=rows,
        local_state_filesystem=fs,model_turn_start_calls=0,model_calls=0,simulator_steps=0,
        authentication_copied=False,global_cli_replaced=False,persistent_threads_created=False,
        current_runtime_routing_label='codex_a',
        scope='Original controller initialization and exact pinned CLI; only initialize/thread-start RPC allowed. '
            'Probe forces ephemeral threads, so persistent-history behavior is not verified. No inference/physics call; '
            'current authorized runtime gateway is reused, not a recovered historical service snapshot.')
    (Q/'original_cli_zero_turn_probe.json').write_text(json.dumps(result,indent=2)+'\n')
    # A local-only locator is intentionally excluded from public bundles.
    (Q/'private_probe_location.txt').write_text(str(private)+'\n');(Q/'private_probe_location.txt').chmod(0o600)
    if not result['verified']:raise SystemExit(1)

if __name__=='__main__':main()
