import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import local_robolab_runtime as storage


class LocalRuntimeTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name);os.chmod(self.root,0o700)
        self.owner=patch.object(storage,'LOCAL_ROOT',self.root);self.owner.start();self.addCleanup(self.owner.stop)

    def validate(self,**kwargs):
        inputs=dict(free_bytes=100*1024**3,filesystem='ext2/ext3',distinct_device=True);inputs.update(kwargs)
        return storage.validate_root(self.root,**inputs)

    def test_private_separate_ext4_root_is_accepted(self):self.assertEqual(self.validate(),self.root)

    def test_system_disk_nas_and_low_capacity_are_rejected(self):
        for kwargs in [dict(distinct_device=False),dict(filesystem='cifs'),dict(free_bytes=storage.MIN_FREE_BYTES-1)]:
            with self.assertRaises(ValueError):self.validate(**kwargs)

    def test_foreign_or_missing_root_is_rejected(self):
        with self.assertRaises(ValueError):storage.validate_root(self.root/'foreign')

    def test_world_readable_root_is_rejected(self):
        os.chmod(self.root,0o755)
        with self.assertRaises(ValueError):self.validate()

    def test_symlink_root_is_rejected(self):
        p=self.root/'link';p.symlink_to(self.root,target_is_directory=True)
        with patch.object(storage,'LOCAL_ROOT',p):
            with self.assertRaises(ValueError):storage.validate_root(p)

    def test_existing_tmp_and_future_ssd_records_remain_supported(self):
        for root in [Path('/tmp'),self.root]:
            self.assertEqual(storage.recorded_root({'attempt':'direct_owned','local_workspace':str(root/'gpt-policy-robolab-direct_owned')}),root)

    def test_foreign_record_paths_and_incomplete_metadata_are_rejected(self):
        for record in [None,{},dict(attempt='direct_owned',local_workspace='/etc/gpt-policy-robolab-direct_owned'),dict(attempt='direct_owned',local_workspace=str(self.root/'other'))]:
            with self.assertRaises(ValueError):storage.recorded_root(record)


if __name__=='__main__':unittest.main()
