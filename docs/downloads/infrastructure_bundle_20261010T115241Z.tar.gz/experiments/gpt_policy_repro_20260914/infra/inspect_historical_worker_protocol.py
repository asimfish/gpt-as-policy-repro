"""Read recorded worker identity, actual rejection branches and first model images."""
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
import datetime,hashlib,io,json,re,zipfile
from pathlib import Path
from PIL import Image
from compare_recovered_originals import ART,Q,METHODS,sha,read
from verify_original_robodojo_records import checked_zip

OUT=ART/'publication_checks/worker_fidelity_20261008'
CAMERAS=('cam_high','cam_left_wrist','cam_right_wrist')
WORKER_FIELDS=('model','model_provider','evaluation_method','controller_version','reasoning_effort',
    'context_version','codex_version','tools','network_recovery','codex_image_max_edge','policy_images_resized')
RECOVERABLE_WORKER='807ee734702943f242680c0627ffc91232657dac0e81293c69102202de8d72c0'
FIVE_STOP_WORKERS=frozenset(('df1b5d598dbef8b319e7c1a0646b454a35ce5b8beb4e6ac098d9d6eafbb56d44',
    '34971b09d4a7463b01fd327ea059398480d13a5ebfb7a44dba2c5f400401dc94',
    'cb5133f455721bc075eaed9da6eb1f39e9f2a164e6e56325532190c3e8bbf483'))

def rejection_stop(source_sha256):
    if source_sha256==RECOVERABLE_WORKER:return None
    if source_sha256 in FIVE_STOP_WORKERS:return 5
    raise ValueError('Unreviewed historical worker source')

def rejection_summary(calls):
    rejected=[];missing=0;unclassified=0
    for call in calls:
        result=call['result']
        if not isinstance(result,dict):missing+=1;continue
        if not result.get('error'):continue
        if result.get('no_execution') is True:rejected.append(call)
        else:unclassified+=1
    return dict(recorded_calls=len(calls),recorded_no_execution_rejections=len(rejected),
        missing_result_packets=missing,other_error_packets=unclassified,
        rejection_indices=[r['call_index'] for r in rejected],
        rejection_steps=[r['result'].get('step_id') for r in rejected],
        fifth_rejection_step=rejected[4]['result'].get('step_id') if len(rejected)>=5 else None,
        enhanced_feedback_packets=sum(r['result'].get('error_type')=='recoverable_tool_input' for r in rejected),
        euclidean_distance_feedback_packets=sum('eef_translation' in r['result'] for r in rejected))

def image_identity(data):
    with Image.open(io.BytesIO(data)) as img:
        assert img.format=='PNG' and 0<img.width<=640 and 0<img.height<=480
        assert img.mode in ('RGB','RGBA')
        return dict(encoded_sha256=sha(data),pixels_sha256=sha(img.tobytes()),mode=img.mode,size=list(img.size))

def original(record):
    archive=ART/'original_public_rollouts/astra_robodojo_bf8d15ea/core'/(record['episode_id']+'.core.zip')
    with zipfile.ZipFile(archive) as z:
        checked_zip(z);episode=json.loads(z.read('episode.json'))
        calls=[json.loads(line) for line in z.read('service_calls.jsonl').decode().splitlines()]
        indices=[r['call_index'] for r in calls];assert len(indices)==len(set(indices)) and indices==sorted(indices)
        worker=episode['worker'];first=json.loads(z.read('observation_index.json'))[0]
        assert first['step_id']==0
        previews={name:image_identity(z.read(first['preview_members'][name])) for name in CAMERAS}
        frozen=record['normalized_frozen_source_sha256']['skill/run.py']
        # Source variants were already independently AST compared and their actual
        # old-vs-new error branch is preserved in the source-diff evidence.
        cap=rejection_stop(frozen)
        return dict(case_id=record['case_id'],method=METHODS[record['method']],original_core_sha256=record['core_sha256'],
            worker={k:worker.get(k) for k in WORKER_FIELDS},frozen_worker_source_sha256=frozen,
            declared_cumulative_input_rejection_stop=cap,rejections=rejection_summary(calls),
            initial_model_previews=previews,upstream_robodojo_commit=z.read('metadata/robodojo_head.txt').decode().strip())

def current(record,sealed):
    root=ART/'gpt_pair_campaign'/record['run_id']/record['method'];inputs={};extra=[]
    def capture(path,expected=None):
        data=path.read_bytes();digest=sha(data)
        if expected is not None:assert digest==expected,str(path.relative_to(ART))
        name=str(path.relative_to(ART));inputs[name]=digest
        if expected is None:extra.append(name)
        return data
    audit=json.loads(capture(root/'complete_action_audit.json',sealed['audit_sha256']))
    hashes=audit['files_sha256'];workspace=root/'rollout/codex_workspace'
    worker=json.loads(capture(workspace/'worker.json',hashes['rollout/codex_workspace/worker.json']))
    calls=[]
    for path in sorted(workspace.glob('call_*_result.json')):
        assert re.fullmatch(r'call_[0-9]{4,}_result.json',path.name)
        key=str(path.relative_to(root));result=json.loads(capture(path,hashes.get(key)))
        calls.append(dict(call_index=int(path.name.split('_')[1]),result=result))
    calls.sort(key=lambda r:r['call_index'])
    previews={}
    for name in CAMERAS:
        path=root/'rollout/observations/000/codex_previews'/(name+'.max480.png')
        assert worker['codex_image_max_edge']==480
        previews[name]=image_identity(capture(path,hashes.get(str(path.relative_to(root)))))
    return dict(case_id=record['case_id'],method=record['method'],run_id=record['run_id'],
        worker={k:worker.get(k) for k in WORKER_FIELDS},rejections=rejection_summary(calls),
        initial_model_previews=previews,inputs_sha256=inputs,separately_captured_inputs=extra)

def main():
    OUT.mkdir(exist_ok=True)
    proof=read(Q/'original_record_recount.json');assert proof['verified'] is True and len(proof['records'])==100
    gate=read(ART/'full_reproduction_verification.json')
    assert (ART/'full_reproduction_verification.json').read_bytes()==(ART/'final_verification'/gate['published_commit']/'certificate.json').read_bytes()
    sealed={(r['case_id'],r['method']):r for r in gate['original_episodes'] if r['cohort']=='robodojo'}
    own=[r for r in read(ART.parents[1]/'gpt-policy-report-site/docs/data/blog-comparison.json')['reproduction_episodes'] if r['cohort']=='robodojo']
    with ThreadPoolExecutor(max_workers=4) as pool:
        old=list(pool.map(original,proof['records']))
        new=list(pool.map(lambda r:current(r,sealed[r['case_id'],r['method']]),own))
    lookup={(r['case_id'],r['method']):r for r in new};common=[]
    for a in old:
        key=a['case_id'],a['method']
        if key not in lookup:continue
        b=lookup[key]
        common.append(dict(case_id=key[0],method=key[1],run_id=b['run_id'],
            original_rejection_stop=a['declared_cumulative_input_rejection_stop'],
            reproduction_recorded_rejections=b['rejections']['recorded_no_execution_rejections'],
            original_recorded_rejections=a['rejections']['recorded_no_execution_rejections'],
            original_cli=a['worker']['codex_version'],reproduction_cli=b['worker']['codex_version'],
            images={name:dict(pixel_equal=all(a['initial_model_previews'][name][k]==b['initial_model_previews'][name][k] for k in ('size','mode','pixels_sha256')),
                encoded_equal=a['initial_model_previews'][name]['encoded_sha256']==b['initial_model_previews'][name]['encoded_sha256']) for name in CAMERAS},
            crosses_original_five_rejection_stop=a['declared_cumulative_input_rejection_stop']==5 and b['rejections']['recorded_no_execution_rejections']>=5,
            fifth_rejection_step=b['rejections']['fifth_rejection_step']))
    assert len(common)==98
    result=dict(schema='gpt_policy_historical_worker_protocol_inspection.v1',verified=True,
        verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        native_certificate_sha256=sha((ART/'full_reproduction_verification.json').read_bytes()),
        original_record_recount_sha256=sha((Q/'original_record_recount.json').read_bytes()),
        original=old,reproduction=new,common_cases=common,
        summary=dict(original_cli_counts=dict(Counter(r['worker']['codex_version'] for r in old)),
            reproduction_cli_counts=dict(Counter(r['worker']['codex_version'] for r in new)),
            original_five_rejection_stop_episodes=sum(r['declared_cumulative_input_rejection_stop']==5 for r in old),
            original_recorded_rejections=sum(r['rejections']['recorded_no_execution_rejections'] for r in old),
            reproduction_recorded_rejections=sum(r['rejections']['recorded_no_execution_rejections'] for r in new),
            crosses_original_five_rejection_stop=sum(r['crosses_original_five_rejection_stop'] for r in common),
            initial_model_preview_pixel_matches={k:sum(r['images'][k]['pixel_equal'] for r in common) for k in CAMERAS}),
        scope='Recorded service rejection counts and initial model attachment bytes, plus worker metadata. Fifth-rejection crossings describe the current trace under an old stopping rule; they are not rerun outcomes or causal success estimates. Full model context, hidden physics and service snapshots remain unverified.')
    (OUT/'worker_protocol_inspection.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result['summary']),flush=True)

if __name__=='__main__':main()
