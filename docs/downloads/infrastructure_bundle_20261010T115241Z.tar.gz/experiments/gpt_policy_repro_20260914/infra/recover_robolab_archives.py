"""Repair only the earliest native-complete artifacts; never launch or replay a rollout."""
from datetime import datetime, timezone
import fcntl
import json
from pathlib import Path
import traceback
from archive_robolab_attempt import archive_attempt
from reconcile_robolab_cleanup import REMOTE_CAMPAIGN, promote_recovered_archive, remote_cleanup
from queue_robolab_two_methods import key, native_complete, qualified, read, write

ARTIFACTS=Path(__file__).resolve().parents[1]


def main():
    with Path('/tmp/gpt-policy-robolab-archive-recovery.lock').open('a') as lock:
        try:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:
            return
        frozen=read(ARTIFACTS/'fixtures/robolab_two_methods_frozen.json')['entries']
        identities={key(row):row for row in frozen}
        groups={identity:[] for identity in identities}
        for path in (ARTIFACTS/'robolab_gpt_campaign').iterdir():
            record=read(path/'attempt.json') if path.is_dir() else None
            if record and key(record) in groups and native_complete(path):
                groups[key(record)].append((record['started_utc'],path))
        results=[]
        plan=[]
        for identity,attempts in groups.items():
            if attempts:
                path=min(attempts,key=lambda pair:pair[0])[1]
                plan.append(dict(attempt=path.name,**identities[identity]))
        active=None
        def persist():
            verified=sum(row['status']=='verified' for row in results)
            failed=sum(row['status']=='preserved_requires_repair' for row in results)
            write(ARTIFACTS/'robolab_archive_recovery.json',dict(
                schema='gpt_policy_robolab_archive_recovery.v1',
                updated_utc=datetime.now(timezone.utc).isoformat(),
                scope='Earliest native-complete episodes only; artifact transfers and original audits; no model or simulator calls',
                planned_native_episodes=len(plan),plan=plan,active=active,
                phase='running' if active is not None or len(results)<len(plan) else 'finished',
                summary=dict(verified=verified,requires_repair=failed,pending=len(plan)-len(results)),
                results=results))
        persist()
        for candidate in plan:
            path=ARTIFACTS/'robolab_gpt_campaign'/candidate['attempt']
            result=dict(candidate)
            try:
                if not (path/'complete_action_audit.json').exists() and not (path/'remote_archive_receipt.json').exists():
                    active=dict(attempt=path.name,phase='archive',started_utc=datetime.now(timezone.utc).isoformat())
                    persist()
                    archive_attempt(path)
                active=dict(attempt=path.name,phase='audit',started_utc=datetime.now(timezone.utc).isoformat())
                persist()
                outcome=qualified(path,identities[key(candidate)])
                result.update(status='verified',success=outcome['success'],control_steps=outcome['step_id'])
                try:
                    result['cleanup_recovery']=promote_recovered_archive(path,remote_probe=remote_cleanup)
                except Exception as cleanup_error:
                    # A valid original remains verified; an unproven release stays blocked.
                    result['cleanup_recovery']=dict(status='preserved_cleanup_requires_repair',error_type=type(cleanup_error).__name__)
            except Exception as error:
                result.update(status='preserved_requires_repair',error_type=type(error).__name__,
                              diagnostic=traceback.format_exc(limit=5)[-2500:])
            results.append(result);active=None;persist()
            print(json.dumps({k:v for k,v in result.items() if k!='diagnostic'}),flush=True)
        persist()


if __name__=='__main__':main()
