"""A recovered archive must release only a proven dead, matching reservation."""
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import recover_robolab_archives as recovery


class CleanupRecovery(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.run = self.root/'robolab_gpt_campaign/direct_20261006T072440Z_Task_seed0'
        self.run.mkdir(parents=True)
        self.record = dict(task='Task', seed=0, method='gpt_only', attempt=self.run.name,
            worker_slot=1, status='controller_finished', completed=False,
            finished_utc='2026-10-06T09:19:39+00:00', controller_output_sealed=True,
            controller_pid=921010, tunnel_pid=921011, remote_manager_pid=921012,
            supervisor_identity=dict(pid=921009, boot_id='old', start_ticks=1),
            remote_output='/home/dataset-assist-0/liyufeng/agentic_robot/experiments/gpt_policy_repro_20260914/robolab_gpt_campaign/'+self.run.name,
            archive_error='[Errno 11] Resource temporarily unavailable')
        self.write('attempt.json', self.record)
        lease=dict(self.record, slot=1, status='blocked_cleanup_unproven')
        self.leases={'schema':'gpt_policy_robolab_leases.v1','leases':[lease],'history':[]}
        (self.root/'robolab_gpt_parallel_leases.json').write_text(json.dumps(self.leases))
        (self.root/'fixtures').mkdir()
        (self.root/'fixtures/robolab_two_methods_frozen.json').write_text(json.dumps({'entries':[{'task':'Task','seed':0,'method':'gpt_only'}]}))
        (self.run/'remote').mkdir()
        (self.run/'remote/original.txt').write_bytes(b'original native failure evidence')
        self.manifest={'schema':'gpt_policy_robolab_remote_archive.v1',
            'cleanup':{'source':'recorded_cleanup','finished_utc':'2026-10-06T09:19:00+00:00'},
            'files':{'original.txt':{'size':32,'sha256':hashlib.sha256(b'original native failure evidence').hexdigest()}}}
        self.manifest['files']['original.txt']['size']=(self.run/'remote/original.txt').stat().st_size
        self.write('remote_archive_manifest.json',self.manifest)
        receipt=dict(schema='gpt_policy_robolab_archive_receipt.v1',verified=True,files=1,
            bytes=self.manifest['files']['original.txt']['size'],cleanup=self.manifest['cleanup'],
            manifest_sha256=hashlib.sha256((self.run/'remote_archive_manifest.json').read_bytes()).hexdigest())
        self.write('remote_archive_receipt.json',receipt)
        self.write('complete_action_audit.json',dict(verified=True,complete_episode=True,scope='complete_native_episode',method='gpt_only',files_sha256={},terminal={'success':False,'terminated':False,'truncated':True}))
        self.write('rollout/result.json',dict(complete=True,success=False,terminated=False,truncated=True,step_id=5,decisions=1))
        self.remote={'verified':True,'attempt':self.run.name,'task':'Task','seed':0,'method':'gpt_only','worker_slot':1,'manager_pid':921012,'owned_processes_absent':True,'owned_process_groups_absent':True}

    def write(self,name,value):
        p=self.run/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value))

    def promote(self, **kwargs):
        return recovery.promote_recovered_archive(self.run, lock_root=self.root,
            remote_probe=lambda record:self.remote, alive=lambda identity:False,
            pid_exists=lambda pid:False, groups_alive=lambda pid:[], **kwargs)

    def test_recovered_archive_propagates_and_preserves_native_failure_and_archive_error(self):
        original=(self.run/'rollout/result.json').read_bytes()
        original_record=(self.run/'attempt.json').read_bytes()
        value=self.promote()
        record=json.loads((self.run/'attempt.json').read_text())
        self.assertEqual(value['status'],'reconciled')
        self.assertTrue(record['remote_archive_verified'])
        self.assertEqual(record['archive_error'],self.record['archive_error'])
        self.assertFalse(record['completed'])
        self.assertEqual((self.run/'rollout/result.json').read_bytes(),original)
        self.assertEqual((self.run/'cleanup_recovery_original_attempt.json').read_bytes(),original_record)

    def test_repeat_after_commit_is_idempotent(self):
        self.promote();first=(self.run/'attempt.json').read_bytes()
        self.assertEqual(self.promote()['status'],'already_recorded')
        self.assertEqual((self.run/'attempt.json').read_bytes(),first)

    def test_resume_after_proof_before_marker_commit(self):
        import reconcile_robolab_cleanup as helper
        writer=helper.atomic_json
        def fail_marker(path,data):
            if path.name=='attempt.json':raise OSError('interrupted metadata write')
            return writer(path,data)
        with patch.object(helper,'atomic_json',side_effect=fail_marker):
            with self.assertRaises(OSError):self.promote()
        self.assertFalse(json.loads((self.run/'attempt.json').read_text()).get('remote_archive_verified',False))
        self.assertEqual(self.promote()['status'],'reconciled')

    def test_mismatched_lease_cannot_release(self):
        self.leases['leases'][0]['seed']=1
        (self.root/'robolab_gpt_parallel_leases.json').write_text(json.dumps(self.leases))
        with self.assertRaises(ValueError):self.promote()
        self.assertNotIn('remote_archive_verified',json.loads((self.run/'attempt.json').read_text()))

    def test_corrupt_archive_does_not_promote(self):
        (self.run/'remote/original.txt').write_bytes(b'corrupt')
        with self.assertRaises(AssertionError):self.promote()
        self.assertFalse((self.run/'cleanup_reconciliation.json').exists())

    def test_changed_seal_does_not_promote(self):
        self.manifest['cleanup']['finished_utc']='changed'
        self.write('remote_archive_manifest.json',self.manifest)
        with self.assertRaises(ValueError):self.promote()

    def test_live_supervisor_is_deferred_without_remote_probe(self):
        with patch.object(recovery,'promote_recovered_archive',wraps=recovery.promote_recovered_archive):
            value=recovery.promote_recovered_archive(self.run, lock_root=self.root,alive=lambda identity:True,remote_probe=lambda _:self.fail('must not probe a live supervisor'))
        self.assertEqual(value['status'],'deferred_live_supervisor')

    def test_live_controller_or_group_cannot_release(self):
        for kwargs in [dict(pid_exists=lambda pid:pid==921010),dict(groups_alive=lambda pid:[33])]:
            defaults=dict(lock_root=self.root,remote_probe=lambda _:self.remote,alive=lambda _:False,pid_exists=lambda _:False,groups_alive=lambda _:[]);defaults.update(kwargs)
            with self.assertRaises(ValueError):recovery.promote_recovered_archive(self.run,**defaults)

    def test_remote_owned_processes_or_foreign_identity_cannot_release(self):
        for key,value in [('owned_processes_absent',False),('attempt','foreign'),('manager_pid',991111)]:
            old=self.remote[key];self.remote[key]=value
            with self.assertRaises(ValueError):self.promote()
            self.remote[key]=old

    def test_receipt_marker_alone_without_full_audit_cannot_release(self):
        self.write('complete_action_audit.json',{'verified':False})
        with self.assertRaises(ValueError):self.promote()

    def test_slot_lock_contention_is_deferred(self):
        import fcntl
        with (self.root/'gpt-policy-robolab-controller-slot1.lock').open('a') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            self.assertEqual(self.promote()['status'],'deferred_owned_lock')

    def test_recovery_pulse_propagates_already_audited_receipt(self):
        real_path=Path
        def isolated_path(value):
            return self.root/'recovery.lock' if str(value)=='/tmp/gpt-policy-robolab-archive-recovery.lock' else real_path(value)
        promote=getattr(recovery,'promote_recovered_archive',None)
        def isolated_promote(path,**_):
            return promote(path,lock_root=self.root,remote_probe=lambda _:self.remote,alive=lambda _:False,pid_exists=lambda _:False,groups_alive=lambda _:[])
        self.record['started_utc']='2026-10-06T07:24:40+00:00';self.write('attempt.json',self.record)
        with patch.object(recovery,'ARTIFACTS',self.root),patch.object(recovery,'Path',side_effect=isolated_path), \
             patch.object(recovery,'qualified',side_effect=lambda path,_:json.loads((path/'rollout/result.json').read_text())), \
             patch.object(recovery,'promote_recovered_archive',side_effect=isolated_promote,create=True):
            recovery.main()
        record=json.loads((self.run/'attempt.json').read_text())
        self.assertTrue(record.get('remote_archive_verified'), 'Verified receipt must propagate after the original supervisor exits')
        self.assertFalse(json.loads((self.run/'rollout/result.json').read_text())['success'])

    def test_legacy_attempts_are_unchanged(self):
        self.record.pop('worker_slot');self.write('attempt.json',self.record)
        self.assertEqual(self.promote()['status'],'not_parallel_attempt')
        self.assertFalse((self.run/'cleanup_reconciliation.json').exists())


if __name__=='__main__':unittest.main()
