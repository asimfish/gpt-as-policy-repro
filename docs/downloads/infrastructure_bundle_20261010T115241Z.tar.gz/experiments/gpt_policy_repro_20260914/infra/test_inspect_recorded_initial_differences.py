import unittest
import numpy as np
from inspect_recorded_initial_differences import numeric_delta,working_directory_free_prompt

class InspectionTest(unittest.TestCase):
    def test_directory_normalization_preserves_instruction_change(self):
        a=b'Use EEF controls.\nAgent working directory: episode:/controller\n'
        b=b'Use EEF controls.\nAgent working directory: /private/workspace\n'
        self.assertEqual(working_directory_free_prompt(a),working_directory_free_prompt(b))
        self.assertNotEqual(working_directory_free_prompt(a),working_directory_free_prompt(b.replace(b'EEF',b'joint')))
        with self.assertRaises(AssertionError):working_directory_free_prompt(a+a)
    def test_float_measurement_rejects_nan_and_does_not_zero_small_differences(self):
        a=np.zeros(2,dtype='float32');b=a.copy();b[0]=1e-18
        self.assertGreater(numeric_delta(a,b),0)
        b[0]=np.nan
        with self.assertRaises(AssertionError):numeric_delta(a,b)

if __name__=='__main__':unittest.main()
