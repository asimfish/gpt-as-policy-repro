"""Replay startup failure without fabricating a run or repeating physical work."""
import json
from pathlib import Path
import tempfile
import unittest

from run_historical_cohort import finalize, sha
from reconcile_historical_startup_failure import audit_startup_failure


class HistoricalStartupRecoveryTests(unittest.TestCase):
    def fixture(self, temporary):
        root=Path(temporary); run=root/'episodes/direct__case'; run.mkdir(parents=True)
        plan=dict(cli_version='codex-cli 0.153.4',model='gpt-6-astra',reasoning_effort='xhigh',
                  receipt_sha256={'historical_worker_manifest.json':'m'})
        (root/'cohort_plan.json').write_text(json.dumps(plan))
        row=dict(episode_id='direct__case',method='gpt_only',profile_id='p')
        def put(name,value):
            path=run/name; path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value))
        put('launch_claim.json',dict(episode_id=row['episode_id'],plan_sha256=sha((root/'cohort_plan.json').read_bytes()),automatic_physical_retries=0))
        put('attempt.json',dict(episode_id=row['episode_id'],method='gpt_only',profile_id='p',status='controller_incomplete',
                               first_attempt=True,controller_returncode=1,native_complete=False,owned_processes=[]))
        put('historical_launch.json',dict(episode=row['episode_id'],manifest_sha256='m',profile_id='p',case={'max_episode_steps':1050}))
        put('rollout/codex_workspace/worker.json',dict(codex_version=plan['cli_version'],model=plan['model'],
                    reasoning_effort='xhigh',evaluation_method='gpt_only',thread_id='thread1'))
        put('rollout/failure.json',dict(episode_id=None,step_id=0,completed=False))
        events=[dict(method='error',params=dict(threadId='thread1',turnId='turn1',willRetry=False,
                                              error=dict(codexErrorInfo='usageLimitExceeded'))),
                dict(method='turn/completed',params=dict(threadId='thread1',turn=dict(id='turn1',status='failed',
                           error=dict(codexErrorInfo='usageLimitExceeded'))))]
        (run/'rollout/codex_workspace/rpc_out.jsonl').write_text(''.join(json.dumps(e)+'\n' for e in events))
        return root,run,row,plan,put

    def test_original_finalizer_reproduces_missing_run_metadata(self):
        with tempfile.TemporaryDirectory() as temporary:
            root,run,row,plan,_=self.fixture(temporary)
            with self.assertRaises(FileNotFoundError) as error:finalize(root,run,row,plan)
            self.assertEqual(Path(error.exception.filename).name,'run.json')

    def test_startup_failure_retained_with_no_scores_and_partial_identity(self):
        with tempfile.TemporaryDirectory() as temporary:
            root,run,row,plan,_=self.fixture(temporary)
            result=audit_startup_failure(root,run,row,plan)
            self.assertTrue(result['verified']);self.assertEqual(result['status'],'startup_failed_no_execution')
            self.assertEqual(result['failure_reason'],'usageLimitExceeded')
            self.assertEqual(result['stopped_prefix_actions'],0)
            self.assertIsNone(result['native_success']);self.assertIsNone(result['native_score'])
            self.assertFalse(result['runtime_identity_verified'])
            self.assertTrue(result['worker_identity_verified'])
            self.assertFalse((run/'rollout/run.json').exists())
            self.assertFalse((run/'rollout/result.json').exists())

    def test_service_tool_call_cannot_be_claimed_as_no_execution(self):
        with tempfile.TemporaryDirectory() as temporary:
            root,run,row,plan,_=self.fixture(temporary)
            with (run/'rollout/codex_workspace/rpc_out.jsonl').open('a') as stream:
                stream.write(json.dumps(dict(method='item/tool/call',params=dict(tool='robodojo_start')))+'\n')
            with self.assertRaises(ValueError):audit_startup_failure(root,run,row,plan)

    def test_any_native_action_or_episode_identity_requires_normal_audit(self):
        with tempfile.TemporaryDirectory() as temporary:
            root,run,row,plan,put=self.fixture(temporary)
            put('sim/native/action_000000.json',dict(valid=True))
            with self.assertRaises(ValueError):audit_startup_failure(root,run,row,plan)
        with tempfile.TemporaryDirectory() as temporary:
            root,run,row,plan,put=self.fixture(temporary)
            put('rollout/failure.json',dict(episode_id='native',step_id=0,completed=False))
            with self.assertRaises(ValueError):audit_startup_failure(root,run,row,plan)

    def test_foreign_quota_error_and_complete_flags_are_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            root,run,row,plan,_=self.fixture(temporary)
            p=run/'rollout/codex_workspace/rpc_out.jsonl'
            p.write_text(p.read_text().replace('thread1','foreign'))
            with self.assertRaises(ValueError):audit_startup_failure(root,run,row,plan)
        with tempfile.TemporaryDirectory() as temporary:
            root,run,row,plan,put=self.fixture(temporary)
            put('rollout/failure.json',dict(episode_id=None,step_id=0,completed=True))
            with self.assertRaises(ValueError):audit_startup_failure(root,run,row,plan)

    def test_existing_gate_is_not_reclassified(self):
        with tempfile.TemporaryDirectory() as temporary:
            root,run,row,plan,put=self.fixture(temporary)
            put('evidence_gate.json',dict(verified=True,native_success=False))
            with self.assertRaises(ValueError):audit_startup_failure(root,run,row,plan)


if __name__=='__main__':unittest.main()
