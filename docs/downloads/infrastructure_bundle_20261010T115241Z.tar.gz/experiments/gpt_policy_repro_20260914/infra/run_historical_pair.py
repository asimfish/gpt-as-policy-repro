"""One fresh original-version case pair, without physical retries or score substitution."""
import argparse
import datetime
import fcntl
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import time
from stage_historical_workers import ART,Q,SOURCE_ROOT,sha
from run_historical_controller import admitted_case
from run_batch_student import terminate,wait_log,check,write
from run_gpt_pair import check_pair_simulator

def classify_outcome(controller_code,result,outcome):
    if outcome.get('status')=='invalid_native_layout':return 'invalid_native_layout'
    native=result.get('complete') is True and (result.get('terminated') is True or result.get('truncated') is True)
    if native and outcome.get('complete') is True and outcome.get('valid_for_success_rate') is True:
        return 'native_complete_pending_audit'
    return 'controller_incomplete' if controller_code else 'incomplete_pending_review'

def selected_cases(case_id):
    rows=[]
    for label,method,prefix in (('direct','gpt_only','gpt'),('hybrid','pi05_plus_gpt','mix')):
        manifest,case,profile=admitted_case(label+'__'+case_id)
        fixture=ART/'fixtures/cases'/(prefix+'__'+case_id+'.json');raw=fixture.read_bytes();data=json.loads(raw)
        assert data['case']['case_id']==case['case_id']
        for key in ('runtime_task','variant','eval_seed','layout_id','reset_seed','simulator_initial_seed','policy_rng_seed','layout','native_support_trajectories'):
            assert data['case'].get(key,[])==case[key]
        assert case['max_decisions']==0 and case['policy_rng_seed']==case['simulator_initial_seed']==0
        root=Path(os.environ['ROBO_ROOT']);assert sha((root/case['layout']['path']).read_bytes())==case['layout']['sha256']
        for support in case['native_support_trajectories']:
            assert sha((root/support['path']).read_bytes())==support['sha256']
        rows.append(dict(episode_id=label+'__'+case_id,method=method,case=case,fixture=str(fixture),fixture_sha256=sha(raw),
            profile_id=profile['profile_id'],identity=data['identity']))
    assert rows[0]['identity']==rows[1]['identity']
    return manifest,rows

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--case',required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--gpu',default='0');p.add_argument('--base-port',type=int,default=19920)
    p.add_argument('--prepare-only',action='store_true')
    args=p.parse_args();manifest,rows=selected_cases(args.case)
    output=args.output.absolute();allowed=(ART/'historical_worker_campaign').absolute()
    assert output.resolve()==output and output.is_relative_to(allowed) and not output.exists()
    plan=dict(schema='gpt_policy_historical_fresh_pair_plan.v1',case_id=args.case,cases=rows,
        manifest_sha256=sha((Q/'historical_worker_manifest.json').read_bytes()),cli_version='codex-cli 0.153.4',
        original_cli_toolchain_sha256=manifest['cli']['toolchain_receipt_sha256'],gpu=args.gpu,base_port=args.base_port,
        source_sha256={str(path.relative_to(ART)):sha(path.read_bytes()) for path in
            [Path(__file__),Path(__file__).with_name('run_historical_controller.py'),Path(__file__).with_name('env.sh'),
             Path(__file__).with_name('run_sim_server.sh'),Path(__file__).with_name('run_pi05_server.sh')]},
        native_adapter_sha256={name:sha((SOURCE_ROOT/'hybrid_rollout/robodojo'/name).read_bytes()) for name in
            ('robodojo_server/server.py','robodojo_server/session.py','robodojo_server/rpc.py','robodojo_server/kinematics.py','robodojo_server/validation.py','evaluation.py')},
        physical_retry_limit=0,attempt_selection='retain the first attempt of each method regardless of outcome',
        original_selected_attempt_protocol_recovered=False,original_gateway_source_recovered=False,
        historical_protocol_equivalence=False,full_blog_reproduction_complete=False)
    if args.prepare_only:
        with (Q/'historical_pair_preflight.json').open('w') as stream:json.dump(plan,stream,indent=2);stream.write('\n')
        print(json.dumps(dict(prepared=True,case=args.case,methods=2,model_calls=0,simulator_steps=0)),flush=True);return
    prior=json.loads((Q/'historical_pair_preflight.json').read_text());assert prior==plan,'Prepared plan changed'
    assert os.environ.get('ROLLOUT_USE_CURRENT_CODEX_HOME')=='1'
    lock=Path('/tmp/gpt-historical-worker-campaign.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    for port in (args.base_port,args.base_port+1):
        with socket.socket() as listener:listener.bind(('127.0.0.1',port)) # no simulator RPC connection
    free=int(subprocess.check_output(['nvidia-smi','-i',args.gpu,'--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
    if free<20000:raise RuntimeError('Historical pair needs 20000 MiB free; no foreign process is stopped')
    output.mkdir(parents=True,exist_ok=False);write(output/'pair_plan.json',plan)
    def interrupted(signum,frame):
        signal.signal(signum,signal.SIG_IGN);raise KeyboardInterrupt('Owned historical pair interrupted')
    signal.signal(signal.SIGTERM,interrupted)
    completed=[]
    for row in rows:
        run=output/row['method'];run.mkdir();processes=[];handles=[]
        state=dict(episode_id=row['episode_id'],method=row['method'],profile_id=row['profile_id'],status='starting',
            started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),benchmark_eligible=False)
        write(run/'attempt.json',state)
        env=dict(os.environ,CUDA_VISIBLE_DEVICES=args.gpu,SIM_GPU=args.gpu,
            EVAL_MANIFEST=str(ART/'fixtures/evaluation_manifest.json'),CASE_FILE=row['fixture'])
        def start(command,path):
            handle=path.open('x');handles.append(handle)
            proc=subprocess.Popen(command,env=env,stdout=handle,stderr=subprocess.STDOUT,start_new_session=True)
            processes.append(proc);return proc
        try:
            policy=None
            if row['method']=='pi05_plus_gpt':
                policy=start(['bash',str(ART/'infra/run_pi05_server.sh'),str(args.base_port+1),str(run/'policy_identity.json')],run/'policy.log')
                wait_log(policy,run/'policy.log','server listening',timeout=1200)
                assert json.loads((run/'policy_identity.json').read_text())['checkpoint_sha256']==row['case']['student_identity_sha256']
            simulator=start(['bash',str(ART/'infra/run_sim_server.sh'),row['case']['runtime_task'],str(run/'sim'),
                str(args.base_port),str(row['case']['eval_seed'])],run/'sim.log')
            wait_log(simulator,run/'sim.log','"event": "ready"',timeout=1200)
            ready=[json.loads(line) for line in (run/'sim.log').read_text(errors='replace').splitlines() if line.startswith('{"event": "ready"')]
            assert len(ready)==1
            metadata=ready[0]['metadata'];assert metadata['max_episode_steps']==row['case']['max_episode_steps']
            assert metadata['control_dt']==row['case']['control_dt']
            command=[os.environ['ROBO_PYTHON'],str(ART/'infra/run_historical_controller.py'),'--episode',row['episode_id'],
                '--output',str(run/'rollout'),'--sim-port',str(args.base_port),'--student-port',str(args.base_port+1)]
            if policy is not None:command+=['--checkpoint',os.environ['PI05_CHECKPOINT']]
            controller=start(command,run/'controller.log');state.update(status='running',owned_pids=[p.pid for p in processes]);write(run/'attempt.json',state)
            deadline=time.monotonic()+12*3600;finalizing=None
            while controller.poll() is None:
                finalizing=check_pair_simulator(simulator,run,time.monotonic(),finalizing)
                if policy is not None:check(policy,run/'policy.log')
                if time.monotonic()>deadline:raise TimeoutError('Infrastructure watchdog; no native failure label')
                time.sleep(2)
            result=json.loads((run/'rollout/result.json').read_text()) if (run/'rollout/result.json').exists() else {}
            outcome=json.loads((run/'sim/evaluation_outcome.json').read_text()) if (run/'sim/evaluation_outcome.json').exists() else {}
            state.update(status=classify_outcome(controller.returncode,result,outcome),controller_returncode=controller.returncode,
                native_complete=outcome.get('complete') is True,native_outcome=outcome)
        except BaseException as error:
            state.update(status='interrupted' if isinstance(error,KeyboardInterrupt) else 'infrastructure_failed',exception_type=type(error).__name__)
            (run/'private_error.txt').write_text(str(error));(run/'private_error.txt').chmod(0o600)
        finally:
            for proc in reversed(processes):terminate(proc)
            for handle in handles:handle.close()
            state['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();write(run/'attempt.json',state)
            completed.append(state);write(output/'progress.json',completed)
            print(json.dumps(dict(episode=row['episode_id'],status=state['status'],native_complete=state.get('native_complete',False))),flush=True)
        if state['status']=='interrupted':raise SystemExit(1)

if __name__=='__main__':main()
