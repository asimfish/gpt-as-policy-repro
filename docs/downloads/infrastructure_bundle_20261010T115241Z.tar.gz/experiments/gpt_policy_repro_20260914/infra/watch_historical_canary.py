"""Finalize the admitted pair's evidence after it stops; no physical/model retries."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import time
from stage_historical_workers import ART,Q,SOURCE_ROOT,sha
from audit_gpt_direct_complete import audit as audit_direct
from audit_hybrid_actions import audit as audit_hybrid
from audit_gpt_direct_prefix import audit as audit_direct_prefix

def read(path):return json.loads(path.read_text())

def video_coverage(path,expected):
    metadata=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-count_frames',
        '-show_entries','stream=nb_read_frames','-of','json',str(path)],text=True,timeout=600))
    frames=int(metadata['streams'][0]['nb_read_frames']);assert frames==expected
    decoded=subprocess.run(['ffmpeg','-v','error','-i',str(path),'-map','0:v:0','-f','null','-'],capture_output=True,timeout=600)
    assert decoded.returncode==0 and not decoded.stderr
    return dict(frames=frames,complete_decode_passed=True,sha256=sha(path.read_bytes()))

def finalize(root):
    plan=read(root/'pair_plan.json');admission=read(Q/'historical_canary_admission.json')
    assert sha((root/'pair_plan.json').read_bytes())==admission['plan_sha256']
    assert (root/'pair_plan.json').read_bytes()==(Q/'historical_pair_preflight.json').read_bytes()
    for name,digest in plan['source_sha256'].items():assert sha((ART/name).read_bytes())==digest
    for name,digest in plan['native_adapter_sha256'].items():assert sha((SOURCE_ROOT/'hybrid_rollout/robodojo'/name).read_bytes())==digest
    manifest=read(Q/'historical_worker_manifest.json');assert sha((Q/'historical_worker_manifest.json').read_bytes())==plan['manifest_sha256']
    for profile in manifest['source_profiles']:
        for name,digest in {**profile['frozen_files_sha256'],**profile['added_runtime_bridge_sha256']}.items():
            assert sha((ART/profile['package_root']/name).read_bytes())==digest
    results=[]
    for case in plan['cases']:
        run=root/case['method'];attempt=read(run/'attempt.json');row=dict(episode_id=case['episode_id'],method=case['method'],
            status=attempt['status'],profile_id=case['profile_id'],benchmark_eligible=False,full_blog_reproduction_complete=False)
        assert attempt['profile_id']==case['profile_id']
        launch=read(run/'historical_launch.json');assert launch['manifest_sha256']==plan['manifest_sha256'] and launch['profile_id']==case['profile_id']
        worker=read(run/'rollout/codex_workspace/worker.json');config=read(run/'rollout/run.json')
        assert worker['codex_version']=='codex-cli 0.153.4' and worker['model']=='gpt-6-astra' and worker['reasoning_effort']=='xhigh'
        assert config['max_decisions']==case['case']['max_decisions']==0
        assert config['max_episode_steps']==case['case']['max_episode_steps'] and config['control_dt']==case['case']['control_dt']
        assert config['evaluation_case']==case['identity']
        if case['method']=='pi05_plus_gpt':assert config['student_identity_sha256']==case['case']['student_identity_sha256']
        if attempt['status']=='native_complete_pending_audit':
            proof=audit_direct(run) if case['method']=='gpt_only' else audit_hybrid(run)
            assert proof['verified'] is True and proof['complete_episode'] is True
            with (run/'complete_action_audit.json').open('x') as stream:json.dump(proof,stream,indent=2);stream.write('\n')
            n=proof['native_actions'];outcome=read(run/'sim/evaluation_outcome.json')
            source=video_coverage(run/'sim/sensors.mp4',n+1)
            row.update(status='native_complete_audited',source_video=source,native_actions=n,decisions=proof['decisions'],
                native_success=outcome['native_success'],native_score=outcome['native_score'],
                complete_action_audit_sha256=sha((run/'complete_action_audit.json').read_bytes()),
                source_and_control_chain_verified=True,historical_protocol_equivalence=False)
        else:
            history_path=run/'rollout/history.json'
            if history_path.exists() and read(history_path):
                decisions=len(read(history_path))
                proof=audit_direct_prefix(run,decisions) if case['method']=='gpt_only' else audit_hybrid(run,decisions)
                assert proof['complete_episode'] is False
                with (run/'stopped_prefix_audit.json').open('x') as stream:json.dump(proof,stream,indent=2);stream.write('\n')
                row.update(stopped_prefix_decisions=decisions,stopped_prefix_actions=proof['native_actions'],native_success=None,native_score=None)
        results.append(row)
    result=dict(schema='gpt_policy_historical_canary_evidence_gate.v1',verified=True,
        verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),cohort=str(root.relative_to(ART)),
        admission_sha256=sha((Q/'historical_canary_admission.json').read_bytes()),plan_sha256=admission['plan_sha256'],
        first_attempts_retained=True,automatic_physical_retries=0,results=results,
        complete_native_audited=sum(r['status']=='native_complete_audited' for r in results),
        historical_protocol_equivalence=False,full_blog_reproduction_complete=False,
        scope='Fresh original-version canary only; complete native controls and source sensor videos audited where present. '
            'Incomplete first attempts remain unscored. Hidden physics, historical service and selected-attempt parity are unverified.')
    return result

def main():
    admission=read(Q/'historical_canary_admission.json');root=ART/admission['cohort']
    target=Q/'historical_canary_evidence_gate.json'
    if target.exists():raise ValueError('Existing gate is immutable')
    deadline=time.monotonic()+25*3600
    while True:
        progress=root/'progress.json'
        rows=read(progress) if progress.exists() else []
        if len(rows)==2:break
        if time.monotonic()>deadline:raise TimeoutError('Watcher deadline; no model or physical retry')
        time.sleep(30)
    try:result=finalize(root)
    except Exception as error:
        result=dict(schema='gpt_policy_historical_canary_evidence_gate.v1',verified=False,
            verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exception_type=type(error).__name__,
            full_blog_reproduction_complete=False,automatic_physical_retries=0)
        private=Q/'private_canary_evidence_failure.txt';private.write_text(str(error));private.chmod(0o600)
    with target.open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
    print(json.dumps(dict(verified=result['verified'],complete_native_audited=result.get('complete_native_audited',0),
        full_blog_reproduction_complete=False)),flush=True)
    if not result['verified']:raise SystemExit(1)

if __name__=='__main__':main()
