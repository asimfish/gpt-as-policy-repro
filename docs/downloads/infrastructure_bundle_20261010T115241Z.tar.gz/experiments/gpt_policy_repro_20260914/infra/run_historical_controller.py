"""Launch one admitted historical source profile; keep the completed cohort intact."""
import argparse
import json
import os
from pathlib import Path
import sys
import tempfile
from stage_historical_workers import ART,Q,SOURCE_ROOT,REVIEWED_PROFILES,profile_id,sha
from verify_historical_worker_protocol import load_profile

def admitted_case(episode):
    raw=(Q/'historical_worker_manifest.json').read_bytes();manifest=json.loads(raw)
    assert manifest['verified'] is True and len(manifest['cases'])==100
    profiles={p['profile_id']:p for p in manifest['source_profiles']}
    assert set(profiles)==REVIEWED_PROFILES
    for pid,p in profiles.items():assert profile_id(p['frozen_files_sha256'])==pid
    for name in ('historical_worker_offline_gate.json','original_cli_zero_turn_probe.json'):
        gate=json.loads((Q/name).read_text())
        assert gate['verified'] is True and gate['manifest_sha256']==sha(raw)
        assert {p['profile_id'] for p in gate['profiles']}==REVIEWED_PROFILES
    case=next(c for c in manifest['cases'] if c['episode_id']==episode)
    backend=SOURCE_ROOT/'hybrid_rollout/robodojo/codex_backend/profiles.py'
    assert sha(backend.read_bytes())==manifest['current_gateway_bridge']['backend_sha256']
    receipt=(Q/'original_cli_toolchain.json').read_bytes()
    assert sha(receipt)==manifest['cli']['toolchain_receipt_sha256']
    launcher=ART/manifest['cli']['launcher'];assert sha(launcher.read_bytes())==manifest['cli']['launcher_sha256']
    for package in json.loads(receipt)['packages']:
        for name,digest in package['files_sha256'].items():
            path=ART/'toolchains/codex_cli_0_153_4'/name
            assert path.resolve()==path.absolute() and sha(path.read_bytes())==digest
    return manifest,case,profiles[case['profile_id']]

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--episode',required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--sim-port',type=int,required=True);p.add_argument('--student-port',type=int,required=True)
    p.add_argument('--checkpoint',type=Path)
    args=p.parse_args()
    if os.environ.get('ROLLOUT_USE_CURRENT_CODEX_HOME')!='1':raise ValueError('Existing authorized Codex runtime must be explicitly selected')
    if not (Path(os.environ['CODEX_HOME'])/'config.toml').is_file():raise ValueError('Existing authorized config is unavailable')
    output=args.output.absolute();allowed=(ART/'historical_worker_campaign').absolute()
    if output.resolve()!=output or not output.is_relative_to(allowed) or output.exists():
        raise ValueError('Historical controller requires a fresh isolated campaign output')
    manifest,case,profile=admitted_case(args.episode)
    os.environ['ROLLOUT_AUTH_PROFILE']='codex_a'
    os.environ['CODEX_IMAGE_MAX_EDGE']='480';os.environ['CODEX_MAX_TOTAL_TOKENS']='0'
    os.environ['PYTHONDONTWRITEBYTECODE']='1'
    state=Path(tempfile.mkdtemp(prefix='gpt-historical-codex-state-'));state.chmod(0o700)
    os.environ['ROLLOUT_CODEX_STATE_DIR']=str(state)
    module=load_profile(profile)
    output.parent.mkdir(parents=True,exist_ok=True)
    binding=dict(schema='gpt_policy_historical_controller_launch.v1',episode=args.episode,case=case,
        manifest_sha256=sha((Q/'historical_worker_manifest.json').read_bytes()),profile_id=profile['profile_id'],
        cli_version='codex-cli 0.153.4',cli_launcher_sha256=manifest['cli']['launcher_sha256'],
        current_runtime_routing_label='codex_a',model='gpt-6-astra',reasoning_effort='xhigh',
        image_max_edge=480,token_limit=0,local_sqlite_state=str(state),
        original_gateway_source_recovered=False,historical_protocol_equivalence=False,
        full_blog_reproduction_complete=False,authorization='user_existing_codex_login_20260916_and_full_reproduction_20261008')
    path=output.parent/'historical_launch.json'
    with path.open('x') as stream:json.dump(binding,stream,indent=2);stream.write('\n')
    argv=['--output',str(output),'--task',case['runtime_task'],'--evaluation-method',case['method'],
        '--codex',str(ART/manifest['cli']['launcher']),'--sim-port',str(args.sim_port),
        '--student-port',str(args.student_port),'--seed',str(case['reset_seed']),'--max-decisions',str(case['max_decisions'])]
    if case['method']=='pi05_plus_gpt':
        if args.checkpoint is None:raise ValueError('Historical hybrid requires an identified checkpoint')
        argv+=['--checkpoint',str(args.checkpoint)]
    sys.argv=[str(module.__file__),*argv]
    module.main()

if __name__=='__main__':main()
