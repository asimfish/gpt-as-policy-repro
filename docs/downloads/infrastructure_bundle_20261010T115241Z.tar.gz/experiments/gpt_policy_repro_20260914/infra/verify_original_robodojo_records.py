"""Recount immutable recorded controls, without executing historical controller code."""
import argparse
from collections import Counter
import datetime
import hashlib
import io
import json
import math
from pathlib import Path,PurePosixPath
import stat
import zipfile
import numpy as np
from recover_original_robodojo import ART,Q,REVISION,DEST,digest,descriptor

FIELDS=('states','eef_positions','eef_quaternions_wxyz','instruction','remaining_steps','actions')

def sha(data):return hashlib.sha256(data).hexdigest()

def checked_zip(archive,max_entries=20000,max_member=128*1024*1024,max_total=2*1024**3):
    infos=archive.infolist();names=[i.filename for i in infos]
    if len(infos)>max_entries or len(set(names))!=len(names):raise ValueError('Duplicate or excessive archive members')
    if sum(i.file_size for i in infos)>max_total:raise ValueError('Archive decompression exceeds budget')
    for info in infos:
        p=PurePosixPath(info.filename);mode=info.external_attr>>16
        if p.is_absolute() or '..' in p.parts or '\\' in info.filename or ':' in info.filename:
            raise ValueError('Archive path escapes its record')
        if info.flag_bits&1 or stat.S_ISLNK(mode) or info.is_dir():raise ValueError('Unsupported archive member')
        if not 0<=info.file_size<=max_member:raise ValueError('Archive member exceeds budget')
    return names

def arrays(data):
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        names=checked_zip(z,max_entries=10,max_member=32*1024**2,max_total=64*1024**2)
        assert set(names)=={k+'.npy' for k in FIELDS}
        result={}
        for name in names:
            value=z.read(name);f=io.BytesIO(value);version=np.lib.format.read_magic(f)
            if version==(1,0):shape,order,dtype=np.lib.format.read_array_header_1_0(f)
            elif version==(2,0):shape,order,dtype=np.lib.format.read_array_header_2_0(f)
            else:raise ValueError('Unsupported NPY version')
            if dtype.hasobject or len(shape)>4 or any(type(s) is not int or not 0<=s<=10001 for s in shape):
                raise ValueError('Unsupported NPY shape/dtype')
            expected=math.prod(shape)*dtype.itemsize
            if expected>32*1024**2 or len(value)-f.tell()!=expected:raise ValueError('NPY allocation or byte count invalid')
            result[name[:-4]]=np.load(io.BytesIO(value),allow_pickle=False)
        return result

def verify_controls(metadata,decisions,controls,trajectory):
    T=metadata['control_steps'];assert type(T) is int and 0<T<=10000
    assert len(controls)==T and len(decisions)==metadata['decision_count']
    expected={'states':(T+1,14),'eef_positions':(T+1,2,3),'eef_quaternions_wxyz':(T+1,2,4),
              'remaining_steps':(T+1,),'instruction':(T+1,),'actions':(T,14)}
    for key,shape in expected.items():
        value=trajectory[key];assert value.shape==shape,key
        if key in ('states','eef_positions','eef_quaternions_wxyz','actions'):
            assert value.dtype==np.dtype('float32') and np.isfinite(value).all(),key
    cursor=0;counts=Counter()
    for number,decision in enumerate(decisions):
        assert decision['decision']==number and decision['start_tick']==cursor
        steps=decision['executed_steps'];assert type(steps) is int and steps>0
        cursor+=steps;assert decision['end_tick']==cursor
        mode=decision['response']['mode'];assert mode in ('student','edit','eef')
        if metadata['method']=='direct':assert mode=='eef'
        counts[mode]+=steps
    assert cursor==T
    for t,control in enumerate(controls):
        assert control['action_index']==t and control['step_id']==t+1 and control['valid'] is True
        assert np.array_equal(np.asarray(control['executed_action'],dtype=np.float32),trajectory['actions'][t])
        # Native action ACKs retain post-action joints; the richer EEF/text fields
        # are in exported observations and their initial fingerprint, not this ACK.
        assert np.array_equal(np.asarray(control['obs']['states'],dtype=np.float32),trajectory['states'][t+1]),(t,'states')
        if t<T-1:assert control['terminated'] is False and control['truncated'] is False
    last=controls[-1]
    if metadata['native_complete']:
        assert last['terminated'] or last['truncated']
        assert metadata['native_success']==last['success']==metadata['evaluation_success']
        assert metadata['adjudication'] is None
    else:
        assert not last['terminated'] and not last['truncated']
        adjudication=metadata['adjudication']
        assert adjudication['schema']=='robodojo.rpc_idle_timeout_failure.v1'
        assert adjudication['evaluation_failure'] is True and adjudication['retry'] is False
        assert metadata['evaluation_success'] is False and metadata['native_score'] is None
    return dict(counts)

def verify_record(record):
    episode,file=descriptor(record);path=DEST/(episode+'.core.zip')
    assert path.stat().st_size==file['bytes'] and digest(path)==file['sha256']
    with zipfile.ZipFile(path) as z:
        names=checked_zip(z)
        def document(name):return json.loads(z.read(name))
        metadata=document('episode.json');case=metadata['case'];run=metadata['run']
        assert metadata['episode_id']==episode and metadata['method']==record['method']
        for key in ('control_steps','decision_count','native_complete','evaluation_success','native_score','status'):
            assert metadata[key]==record[key],key
        assert case['case_id']==record['case_id'] and case['layout']['sha256']==record['layout_sha256']
        for key in ('eval_seed','layout_id','reset_seed','simulator_initial_seed','policy_rng_seed'):assert case[key]==record[key]
        assert run['teacher_model']=='gpt-6-astra' and run['teacher_reasoning_effort']=='xhigh'
        decisions=[json.loads(line) for line in z.read('decisions.jsonl').decode().splitlines()]
        controls=[json.loads(line) for line in z.read('actions.jsonl').decode().splitlines()]
        trajectory=arrays(z.read('trajectory.npz'))
        counts=verify_controls(metadata,decisions,controls,trajectory)
        assert counts==record['source_steps']
        fingerprint=document('metadata/sim/initial_observation_fingerprint.json')
        for key in ('states','eef_positions','eef_quaternions_wxyz'):
            assert sha(trajectory[key][0].tobytes())==fingerprint['fields'][key]['sha256']
        config=document('metadata/sim/resolved_config.json')
        token=document('metadata/controller/token_usage.json')
        total=token['usage']['total'];assert total==record['token_usage']['total']
        assert total['totalTokens']==total['inputTokens']+total['outputTokens']
        frozen={name.removeprefix('frozen_control_source/'):sha(z.read(name)) for name in names if name.startswith('frozen_control_source/')}
        return dict(episode_id=episode,case_id=record['case_id'],method=record['method'],core_sha256=file['sha256'],
            native_complete=metadata['native_complete'],evaluation_success=metadata['evaluation_success'],
            native_score=metadata['native_score'],status=metadata['status'],control_steps=len(controls),
            decision_count=len(decisions),source_steps=counts,tokens=total,
            robot_initial_sha256=fingerprint['fields']['states']['sha256'],
            initial_recorded_fields={k:fingerprint['fields'][k] for k in ('states','eef_positions','eef_quaternions_wxyz')},
            layout_sha256=record['layout_sha256'],initial_state_scope=fingerprint['scope'],
            max_episode_steps=run['max_episode_steps'],control_dt=run['control_dt'],max_decisions=run['max_decisions'],
            teacher_prompt_sha256=run['teacher_prompt_sha256'],context_version=run.get('context_version'),
            student_identity_sha256=run.get('student_identity_sha256'),
            normalized_frozen_source_sha256=frozen,recorded_native_configuration_sha256=sha(json.dumps(config,sort_keys=True).encode()),
            support_trajectories=case.get('native_support_trajectories',[]))

def summarize(records):
    result={}
    for method in ('direct','hybrid'):
        rows=[r for r in records if r['method']==method];scores=[r['native_score'] for r in rows if r['native_score'] is not None]
        steps=Counter()
        for r in rows:steps.update(r['source_steps'])
        result[method]=dict(episodes=len(rows),native_complete=sum(r['native_complete'] for r in rows),
            adjudicated_failures=sum(not r['native_complete'] for r in rows),successes=sum(r['evaluation_success'] for r in rows),
            score_samples=len(scores),mean_score_0_100=100*sum(scores)/len(scores) if scores else None,
            control_steps=sum(r['control_steps'] for r in rows),decision_count=sum(r['decision_count'] for r in rows),
            corrected_steps=steps['edit']+steps['eef'] if method=='hybrid' else 0,
            tokens={k:sum(r['tokens'][k] for r in rows) for k in ('totalTokens','inputTokens','cachedInputTokens','cacheWriteInputTokens','outputTokens','reasoningOutputTokens')})
    return result

def main():
    p=argparse.ArgumentParser();p.add_argument('--partial',action='store_true');args=p.parse_args()
    manifest=json.loads((Q/'hf_manifest.json').read_text());records=[]
    for r in manifest['episodes']:
        if not (DEST/(r['episode_id']+'.core.zip')).is_file():
            if args.partial:continue
            raise RuntimeError('A selected original core archive is not downloaded yet')
        records.append(verify_record(r))
        print(json.dumps(dict(verified=len(records),episode_id=r['episode_id'])),flush=True)
    totals=summarize(records)
    if len(records)==100:
        assert totals['direct']['native_complete']==48 and totals['direct']['successes']==13
        assert totals['hybrid']['native_complete']==50 and totals['hybrid']['successes']==24
        assert totals['direct']['score_samples']==48 and math.isclose(totals['direct']['mean_score_0_100'],37.8125)
        assert totals['hybrid']['score_samples']==50 and math.isclose(totals['hybrid']['mean_score_0_100'],62.6)
    value=dict(schema='gpt_policy_original_record_recount.v1',verified=len(records)==100,
        verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),revision=REVISION,
        dataset='YuMoool/astra-robodojo-rollouts',core_archives_verified=len(records),
        original_control_steps_verified=sum(r['control_steps'] for r in records),full_observation_archives_verified=False,
        historical_full_physics_state_verified=False,selected_original_records_recounted=totals,records=records,
        scope='Full core archive SHA; committed decisions and every executed action/post-action joint-state join; native vs adjudicated outcomes; recorded initial robot/EEF fingerprints. Original RGB ZIPs and hidden physics/model state are not verified.')
    name='original_record_recount.json' if len(records)==100 else 'original_record_recount_partial.json'
    (Q/name).write_text(json.dumps(value,indent=2)+'\n')
    print(json.dumps({k:v for k,v in value.items() if k!='records'}),flush=True)

if __name__=='__main__':main()
