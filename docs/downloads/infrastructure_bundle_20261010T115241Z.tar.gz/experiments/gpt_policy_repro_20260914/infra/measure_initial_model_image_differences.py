"""Measure saved initial RGB differences; no image edits or causal attribution."""
from concurrent.futures import ThreadPoolExecutor
import datetime
import io
import json
import zipfile
import numpy as np
from PIL import Image
from inspect_historical_worker_protocol import ART,OUT,CAMERAS,image_identity
from stage_historical_workers import sha
from verify_original_robodojo_records import checked_zip

def rgb(data,expected):
    assert image_identity(data)==expected
    with Image.open(io.BytesIO(data)) as image:
        assert image.mode=='RGB'
        return np.asarray(image,dtype=np.int16)

def compare_pair(pair,old,new):
    key=pair['case_id'],pair['method'];a=old[key];b=new[key]
    label={'gpt_only':'direct','pi05_plus_gpt':'hybrid'}[key[1]]
    archive=ART/'original_public_rollouts/astra_robodojo_bf8d15ea/core'/(label+'__'+key[0]+'.core.zip')
    root=ART/'gpt_pair_campaign'/b['run_id']/b['method']/'rollout/observations/000/codex_previews'
    metrics={}
    with zipfile.ZipFile(archive) as z:
        checked_zip(z);first=json.loads(z.read('observation_index.json'))[0]
        for name in CAMERAS:
            original=rgb(z.read(first['preview_members'][name]),a['initial_model_previews'][name])
            current=rgb((root/(name+'.max480.png')).read_bytes(),b['initial_model_previews'][name])
            assert original.shape==current.shape
            delta=np.abs(original-current)
            metrics[name]=dict(mean_absolute_channel_difference_0_255=float(delta.mean()),
                maximum_absolute_channel_difference_0_255=int(delta.max()),
                changed_pixel_fraction=float(np.any(delta!=0,axis=2).mean()),
                changed_channel_fraction=float((delta!=0).mean()),
                root_mean_squared_channel_difference_0_255=float(np.sqrt(np.mean(delta.astype(np.float64)**2))))
    return dict(case_id=key[0],method=key[1],metrics=metrics)

def main():
    raw=(OUT/'worker_protocol_inspection.json').read_bytes();proof=json.loads(raw)
    assert proof['verified'] is True
    old={(r['case_id'],r['method']):r for r in proof['original']}
    new={(r['case_id'],r['method']):r for r in proof['reproduction']}
    with ThreadPoolExecutor(max_workers=4) as pool:
        cases=list(pool.map(lambda pair:compare_pair(pair,old,new),proof['common_cases']))
    assert len(cases)==98
    summary={name:dict(episodes=98,pixel_identical_episodes=sum(r['metrics'][name]['changed_pixel_fraction']==0 for r in cases),
        mean_absolute_channel_difference_mean=float(np.mean([r['metrics'][name]['mean_absolute_channel_difference_0_255'] for r in cases])),
        mean_absolute_channel_difference_max=max(r['metrics'][name]['mean_absolute_channel_difference_0_255'] for r in cases),
        changed_pixel_fraction_mean=float(np.mean([r['metrics'][name]['changed_pixel_fraction'] for r in cases]))) for name in CAMERAS}
    result=dict(schema='gpt_policy_initial_model_rgb_difference_measurement.v1',verified=True,
        verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),worker_protocol_inspection_sha256=sha(raw),
        cases=cases,summary=summary,model_calls=0,simulator_steps=0,
        scope='SHA-bound saved first model-preview RGB arrays only; MAE on 0..255 channels and changed-pixel fractions. '
            'Pixel equality or magnitude does not prove full physical-state equality or explain model outcome differences.')
    (OUT/'initial_model_rgb_differences.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(summary),flush=True)

if __name__=='__main__':main()
