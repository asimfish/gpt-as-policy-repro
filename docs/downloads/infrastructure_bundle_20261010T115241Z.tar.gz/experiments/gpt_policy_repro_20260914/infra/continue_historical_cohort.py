"""Continue a frozen cohort through independently audited startup failures.

The original execution plan and runner stay unchanged. Every retained gate is
rehashed before admission, and every new episode keeps its original first claim.
A capacity error stops subsequent launches; resumption requires a new successful
same-model text probe. No stopped physical attempt can be replayed.
"""
import argparse
from collections import Counter
import datetime
import fcntl
import json
import os
from pathlib import Path
import signal
import time

import run_historical_cohort as original
from reconcile_historical_startup_failure import audit_startup_failure

SOURCE_NAMES = ('continue_historical_cohort.py', 'continue_historical_cohort.sh', 'reconcile_historical_startup_failure.py',
                'probe_historical_service.py')
CAPACITY_CODES = {'usageLimitExceeded', 'rateLimitExceeded'}


def validate_probe(proof, plan, now=None):
    now = now or datetime.datetime.now(datetime.timezone.utc)
    checked = datetime.datetime.fromisoformat(proof['checked_utc'])
    if checked.tzinfo is None or not 0 <= (now-checked).total_seconds() <= 1800:
        raise ValueError('A successful availability probe must be at most 30 minutes old')
    expected = (plan['model'], plan['reasoning_effort'], plan['cli_version'])
    actual = (proof.get('model'), proof.get('reasoning_effort'), proof.get('cli_version'))
    if (proof.get('verified') is not True or proof.get('model_available') is not True
            or proof.get('turn_status') != 'completed' or proof.get('reply_exact_ok') is not True
            or proof.get('model_turn_start_calls') != 1 or proof.get('service_tools_registered') != 0
            or proof.get('simulator_steps') != 0 or proof.get('authentication_copied') is not False
            or proof.get('error_code') is not None or actual != expected
            or proof.get('manifest_sha256') != plan['receipt_sha256']['historical_worker_manifest.json']):
        raise ValueError('Probe does not establish same authorized original-CLI/model availability')


def capacity_errors(run):
    """Only identify failures on this worker thread; never expose error text."""
    worker = run/'rollout/codex_workspace/worker.json'
    transcript = run/'rollout/codex_workspace/rpc_out.jsonl'
    if not worker.exists() or not transcript.exists():
        return []
    thread = original.read(worker)['thread_id']; codes = set()
    with transcript.open() as stream:
        for line in stream:
            event = json.loads(line); params = event.get('params', {})
            if params.get('threadId') != thread:
                continue
            if event.get('method') == 'error' and params.get('willRetry') is not True:
                code = (params.get('error') or {}).get('codexErrorInfo')
            elif event.get('method') == 'turn/completed' and params.get('turn', {}).get('status') == 'failed':
                code = (params['turn'].get('error') or {}).get('codexErrorInfo')
            else:
                continue
            if isinstance(code, str) and code in CAPACITY_CODES:
                codes.add(code)
    return sorted(codes)


def retained_prefix(root, plan):
    """Reject holes or unreviewed claims before launching any later episode."""
    retained = []; pending = []; gap = False
    for pair in plan['pairs']:
        for row in pair['cases']:
            run = root/'episodes'/row['episode_id']; action = original.next_action(run)
            if action == 'retain' and not gap:
                retained.append(original.verify_retained(run, root, row))
            elif action == 'launch':
                gap = True; pending.append(row)
            else:
                raise ValueError('Existing first attempt or out-of-order gate requires review; no replay')
    return retained, pending


def finalize_first_attempt(root, run, row, plan):
    if (run/'evidence_gate.json').exists():
        raise ValueError('An existing gate cannot be replaced')
    if ((run/'rollout/codex_workspace/worker.json').exists()
            and not (run/'rollout/run.json').exists()):
        proof = audit_startup_failure(root, run, row, plan)
        original.new_json(run/'evidence_gate.json', proof)
        return proof
    return original.finalize(root, run, row, plan)


def save_progress(root, retained, phase, admission, current=None, errors=None):
    original.write(root/'progress.json', dict(schema='gpt_policy_historical_cohort_progress.v1',
        updated_utc=original.utc(), phase=phase, episodes_planned=98, first_attempts_audited=len(retained),
        current_episode=current, native_complete_audited=sum(g['status']=='native_complete_audited' for g in retained),
        statuses=dict(Counter(g['status'] for g in retained)), automatic_physical_retries=0,
        continuation_admission=str(admission.relative_to(root)), service_capacity_errors=errors or [],
        results=[{k:g.get(k) for k in ('episode_id','method','profile_id','status','native_actions','decisions',
                    'native_success','native_score','stopped_prefix_actions')} for g in retained],
        separate_pilot_native_audited=2, historical_protocol_equivalence=False,
        full_blog_reproduction_complete=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cohort', type=Path, required=True)
    parser.add_argument('--availability', type=Path, required=True)
    args = parser.parse_args(); root = args.cohort.absolute(); probe_path = args.availability.absolute()
    if (os.environ.get('ROLLOUT_USE_CURRENT_CODEX_HOME') != '1'
            or os.environ.get('ROLLOUT_AUTH_PROFILE') != 'codex_a'):
        raise ValueError('The existing authorized route must be explicitly selected')
    lock = Path('/tmp/gpt-historical-worker-campaign.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    plan = original.verify_plan(root); retained, pending = retained_prefix(root, plan)
    probe = original.read(probe_path); validate_probe(probe, plan)
    directory = root/'continuations'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    directory.mkdir(parents=True, mode=0o700, exist_ok=False)
    admission = directory/'admission.json'
    sources = {'infra/'+name:original.sha((original.ART/'infra'/name).read_bytes()) for name in SOURCE_NAMES}
    original.new_json(admission, dict(schema='gpt_policy_historical_continuation_admission.v1', verified=True,
        admitted_utc=original.utc(), plan_sha256=original.sha((root/'cohort_plan.json').read_bytes()),
        availability_sha256=original.sha(probe_path.read_bytes()), source_sha256=sources,
        prior_episode_gate_sha256={g['episode_id']:original.sha((root/'episodes'/g['episode_id']/'evidence_gate.json').read_bytes())
                                  for g in retained},
        retained_first_attempts=len(retained), unclaimed_episodes=len(pending),
        physical_retry_limit=0, original_execution_source_unchanged=True, authentication_copied=False,
        stop_after_service_capacity_failure=True, historical_protocol_equivalence=False,
        full_blog_reproduction_complete=False))

    def interrupted(signum, frame):
        signal.signal(signum, signal.SIG_IGN)
        raise KeyboardInterrupt('Owned continuation interrupted')
    signal.signal(signal.SIGTERM, interrupted)
    save_progress(root, retained, 'running', admission)
    print(json.dumps(dict(event='continuation_admitted', retained=len(retained), unclaimed=len(pending),
                          physical_retries=0)), flush=True)
    for row in pending:
        run = root/'episodes'/row['episode_id']
        if original.next_action(run) != 'launch':
            save_progress(root, retained, 'blocked_existing_attempt_requires_review', admission, row['episode_id'])
            raise SystemExit(1)
        save_progress(root, retained, 'waiting_for_available_gpu_and_ports', admission, row['episode_id'])
        while not original.available(plan):
            time.sleep(30)
        original.verify_plan(root)
        for name, digest in sources.items():
            if original.sha((original.ART/name).read_bytes()) != digest:
                raise ValueError('Admitted continuation source changed')
        if not retained or len(retained) == original.read(admission)['retained_first_attempts']:
            validate_probe(probe, plan)  # Reject a probe that became stale while waiting for resources.
        save_progress(root, retained, 'running', admission, row['episode_id'])
        original.execute(root, row, plan)
        try:
            errors = capacity_errors(run)
            gate = finalize_first_attempt(root, run, row, plan); retained.append(gate)
        except Exception as error:
            private = run/'private_continuation_audit_error.txt'
            private.write_text(str(error)); private.chmod(0o600)
            save_progress(root, retained, 'blocked_audit_requires_review', admission, row['episode_id'])
            print(json.dumps(dict(event='audit_failed', episode=row['episode_id'], exception_type=type(error).__name__)), flush=True)
            raise SystemExit(1)
        print(json.dumps(dict(event='first_attempt_audited', episode=row['episode_id'], status=gate['status'])), flush=True)
        if errors:
            save_progress(root, retained, 'blocked_service_capacity', admission, row['episode_id'], errors)
            raise SystemExit(1)
        if original.read(run/'attempt.json').get('interrupted') is True:
            save_progress(root, retained, 'interrupted', admission); raise SystemExit(1)
        if gate['status'] in ('infrastructure_failed', 'incomplete_pending_review'):
            save_progress(root, retained, 'blocked_infrastructure_requires_review', admission, row['episode_id'])
            raise SystemExit(1)
        save_progress(root, retained, 'running', admission)
    save_progress(root, retained, 'all_first_attempts_audited', admission)
    if (root/'completion.json').exists():
        completion = original.read(root/'completion.json')
        expected = {g['episode_id']:original.sha((root/'episodes'/g['episode_id']/'evidence_gate.json').read_bytes())
                    for g in retained}
        if completion.get('verified') is not True or completion.get('episode_gate_sha256') != expected:
            raise ValueError('Existing completion receipt differs')
        return
    original.new_json(root/'completion.json', dict(verified=True, completed_utc=original.utc(), episodes=98,
        episode_gate_sha256={g['episode_id']:original.sha((root/'episodes'/g['episode_id']/'evidence_gate.json').read_bytes())
                            for g in retained},
        complete_native_audited=sum(g['status']=='native_complete_audited' for g in retained),
        all_first_attempts_retained=True, automatic_physical_retries=0,
        historical_protocol_equivalence=False, full_blog_reproduction_complete=False))


if __name__ == '__main__':
    main()
