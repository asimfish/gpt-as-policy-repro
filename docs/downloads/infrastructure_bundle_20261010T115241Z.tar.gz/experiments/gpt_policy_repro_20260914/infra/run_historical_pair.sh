#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/env.sh"
: "${ROLLOUT_USE_CURRENT_CODEX_HOME:?Existing experiment authorization must be selected}"
export ROLLOUT_AUTH_PROFILE=codex_a
export PYTHONDONTWRITEBYTECODE=1
export PATH="$(dirname "$ROBO_PYTHON"):$PATH"
exec "$ROBO_PYTHON" "$(dirname "$0")/run_historical_pair.py" "$@"
