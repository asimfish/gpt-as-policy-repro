"""A report observer must not treat prefixes or another continuation as completion."""
import unittest
import json
from pathlib import Path
import tempfile
from watch_historical_publication import ready, initial_delivery_ready


class HistoricalPublicationWatchTests(unittest.TestCase):
    def progress(self,phase='blocked_service_capacity'):
        return dict(continuation_admission='continuations/a/admission.json',phase=phase,
                    first_attempts_audited=1,native_complete_audited=0,automatic_physical_retries=0,
                    results=[dict(episode_id='direct__a',status='startup_failed_no_execution')],
                    historical_protocol_equivalence=False,full_blog_reproduction_complete=False)

    def test_only_admitted_terminal_phase_triggers_publication(self):
        p=self.progress();self.assertTrue(ready(p,p['continuation_admission']))
        self.assertFalse(ready(p,'other'))
        p['phase']='running';self.assertFalse(ready(p,p['continuation_admission']))

    def test_prefix_cannot_count_as_native_complete_or_full_blog(self):
        p=self.progress();p['native_complete_audited']=1
        with self.assertRaises(ValueError):ready(p,p['continuation_admission'])
        p=self.progress();p['full_blog_reproduction_complete']=True
        with self.assertRaises(ValueError):ready(p,p['continuation_admission'])

    def test_incomplete_or_duplicate_attempts_cannot_claim_all_done(self):
        p=self.progress('all_first_attempts_audited')
        with self.assertRaises(ValueError):ready(p,p['continuation_admission'])
        p=self.progress();p['results']*=2;p['first_attempts_audited']=2
        with self.assertRaises(ValueError):ready(p,p['continuation_admission'])

    def test_initial_publication_must_finish_and_bind_the_reviewed_source(self):
        with tempfile.TemporaryDirectory() as temporary:
            path=Path(temporary)/'initial.json'
            self.assertFalse(initial_delivery_ready(path,'source'))
            path.write_text(json.dumps(dict(verified=True,source_commit='foreign',continuation_no_physical_retries_verified=True)))
            self.assertFalse(initial_delivery_ready(path,'source'))
            path.write_text(json.dumps(dict(verified=True,source_commit='source',continuation_no_physical_retries_verified=True)))
            self.assertTrue(initial_delivery_ready(path,'source'))


if __name__=='__main__':unittest.main()
