"""Publish a fully built historical snapshot without rebuilding its raw statistics.

The caller holds the normal publication lock. A successful comparison build is
bound to its statistics receipt; bundle export and site checks still run before
the ordinary, authorized push. Existing publisher transaction/auth/HTTP helpers
remain authoritative, and stale or changed comparison bytes are rejected.
"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def validate_binding(comparison, statistics):
    if (statistics.get('verified') is not True
            or statistics.get('comparison_sha256')!=hashlib.sha256(comparison).hexdigest()
            or statistics.get('complete_native_episodes')!=200
            or len(statistics.get('files_sha256',{}))!=900):
        raise ValueError('Prepared comparison does not bind the verified 200-run statistics')
    value=json.loads(comparison)
    if value.get('independent_evaluation_complete') is not True or value.get('historical_equivalence_verified') is not False:
        raise ValueError('Prepared comparison changed the historical completion boundary')
    return value


def publish(repo,source,credentials_repo,proxy='http://127.0.0.1:7897'):
    sys.path.insert(0,str(repo/'tools'))
    import publish_gpt_progress as existing
    from blog_comparison import validate_historical_execution,verify_public
    existing.resume_transaction(repo,source);existing.check_worktree(repo)
    path=repo/'docs/data/blog-comparison.json';before=path.read_bytes()
    proof=json.loads((source/'publication_checks/blog_alignment_20261008/statistics_audit.json').read_text())
    value=validate_binding(before,proof)
    validate_historical_execution(value['historical_worker_fidelity']['original_version_execution'])
    old=json.loads((repo/'docs/data/gpt-methods-progress.json').read_text())
    subprocess.run([sys.executable,str(repo/'tools/build_gpt_site.py'),'--source',str(source),'--out',str(repo/'docs')],check=True)
    if path.read_bytes()!=before:raise ValueError('Bundle export changed the prepared comparison')
    current=json.loads((repo/'docs/data/gpt-methods-progress.json').read_text())
    if not {e['id'] for e in old['episodes']}<={e['id'] for e in current['episodes']}:
        raise ValueError('Published native episodes would be lost')
    verify_public(repo/'docs')
    subprocess.run([sys.executable,str(repo/'tools/verify_site.py'),str(repo/'docs')],check=True)
    existing.check_worktree(repo)
    changed=[p for p in existing.git(repo,'ls-files','--modified').splitlines() if existing.owned(p)]
    changed += [p for p in existing.git(repo,'ls-files','--others','--exclude-standard').splitlines() if existing.owned(p)]
    if changed:
        existing.git(repo,'add','--',*changed)
        existing.record_transaction(repo,source,changed,'[report/build]: publish verified historical continuation evidence')
        existing.resume_transaction(repo,source)
    env=existing.credential_env(credentials_repo)
    existing.git(repo,'-c','http.proxy='+proxy,'push','origin','docs/site',env=env)
    if not existing.await_online(repo,source):raise ValueError('Push completed; hosted exact bytes remain pending verification')
