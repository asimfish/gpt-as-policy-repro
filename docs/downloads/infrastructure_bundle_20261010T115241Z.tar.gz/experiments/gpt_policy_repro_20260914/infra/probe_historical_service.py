"""Read current original-CLI availability without any robot services.

Default mode permits initialize and account/rateLimits/read only. An explicitly
selected single-text-turn probe uses the same authorized model/CLI, with no robot
tools, images, or simulator. Raw replies/configuration remain in private local
storage; only bounded status fields and hashes are written to the public receipt.
"""
import argparse
import datetime
import json
import os
from pathlib import Path
import re
import tempfile
import time

from run_historical_controller import admitted_case
from stage_historical_workers import ART, sha
from verify_historical_worker_protocol import load_profile
from run_historical_cohort import new_json, utc


def limits_summary(response):
    buckets=response.get('rateLimitsByLimitId')
    if not isinstance(buckets,dict) or not buckets:
        buckets={'default':response.get('rateLimits')}
    summary=[]
    for key,value in buckets.items():
        if not isinstance(value,dict):continue
        windows={}
        for name in ('primary','secondary'):
            item=value.get(name)
            if not isinstance(item,dict):continue
            windows[name]={field:item.get(field) for field in ('usedPercent','windowDurationMins','resetsAt')}
        reached=value.get('rateLimitReachedType')
        summary.append(dict(limit_id=value.get('limitId',key),windows=windows,
                            reached_type=reached if isinstance(reached,str) and re.fullmatch(r'[A-Za-z_]{1,80}',reached) else None))
    return summary


def probe(destination,model_turn=False):
    if destination.exists():raise ValueError('An availability receipt is immutable')
    if os.environ.get('ROLLOUT_USE_CURRENT_CODEX_HOME')!='1':raise ValueError('Existing authorized runtime must be explicitly selected')
    manifest,_,profile=admitted_case('direct__arrange_largest_number__standard__g0__l0')
    private=Path(tempfile.mkdtemp(prefix='gpt-historical-service-probe-'));private.chmod(0o700)
    previous={key:os.environ.get(key) for key in ('ROLLOUT_AUTH_PROFILE','ROLLOUT_CODEX_STATE_DIR')}
    transport=None;result=None;calls=[]
    try:
        os.environ['ROLLOUT_AUTH_PROFILE']='codex_a';os.environ['ROLLOUT_CODEX_STATE_DIR']=str(private/'state')
        module=load_profile(profile);workspace=private/'workspace';workspace.mkdir(mode=0o700)
        agent=workspace/'agent';agent.mkdir(mode=0o700)
        config=module.agent_config(workspace,agent)
        config['features.shell_tool']=False;config['features.view_image']=False;config['web_search']='disabled'
        argv=[str(ART/manifest['cli']['launcher']),'app-server','--stdio','--strict-config']
        for key,value in config.items():argv+=['-c',key+'='+module.toml_value(value)]
        transport=module.StdioAppServer(argv,workspace)
        allowed={'initialize','account/rateLimits/read'}|({'thread/start','turn/start'} if model_turn else set())
        def request(name,params):
            if name not in allowed:raise ValueError('Probe RPC denied')
            calls.append(name);return transport.request(name,params,30)
        request('initialize',dict(clientInfo=dict(name='gpt-historical-availability',version='1'),capabilities=dict(experimentalApi=True)))
        transport.notify('initialized',{})
        raw=request('account/rateLimits/read',{})
        (private/'private_rate_limits.json').write_text(json.dumps(raw));(private/'private_rate_limits.json').chmod(0o600)
        result=dict(schema='gpt_policy_historical_service_availability.v1',verified=True,checked_utc=utc(),
                    model='gpt-6-astra',reasoning_effort='xhigh',cli_version='codex-cli 0.153.4',
                    manifest_sha256=sha((ART/'publication_checks/worker_fidelity_20261008/historical_worker_manifest.json').read_bytes()),
                    rate_limits=limits_summary(raw),model_turn_start_calls=0,model_available=None,
                    service_tools_registered=0,simulator_steps=0,authentication_copied=False,
                    persistent_thread_created=False,raw_response_public=False)
        if model_turn:
            started=request('thread/start',dict(cwd=str(agent),model='gpt-6-astra',modelProvider=module.PROVIDER,
                    config=dict(model_reasoning_effort='xhigh'),developerInstructions='Return exactly OK. Do not use any tool.',
                    dynamicTools=[],ephemeral=True,allowProviderModelFallback=False,approvalPolicy='never',
                    approvalsReviewer='auto_review',permissions='rollout_agent',runtimeWorkspaceRoots=[str(agent)]))
            if started.get('model')!='gpt-6-astra' or started.get('reasoningEffort')!='xhigh' or started['thread']['ephemeral'] is not True:
                raise ValueError('Probe model/effort/temporary thread differs')
            thread=started['thread']['id']
            turn=request('turn/start',dict(threadId=thread,model='gpt-6-astra',effort='xhigh',approvalPolicy='never',
                    approvalsReviewer='auto_review',permissions='rollout_agent',cwd=str(agent),runtimeWorkspaceRoots=[str(agent)],
                    input=[dict(type='text',text='Reply exactly OK, without tool calls.')]))['turn']['id']
            result['model_turn_start_calls']=1;deadline=time.monotonic()+120;answer=[];failure=None
            while time.monotonic()<deadline:
                event=transport.next_message(min(20,max(.1,deadline-time.monotonic())))
                params=event.get('params',{});method=event.get('method')
                if params.get('threadId') not in (None,thread) or params.get('turnId') not in (None,turn):continue
                if method=='item/tool/call':raise ValueError('Text-only probe received a tool request')
                if method in ('item/started','item/completed'):
                    item=params.get('item',{})
                    if item.get('type') not in ('userMessage','agentMessage','reasoning'):
                        raise ValueError('Text-only probe received a native tool item')
                    if method=='item/completed' and item.get('type')=='agentMessage':
                        for content in item.get('content',[]):
                            if content.get('type')=='text':answer.append(content.get('text',''))
                        if isinstance(item.get('text'),str):answer.append(item['text'])
                if method=='error' and params.get('willRetry') is not True:
                    failure=params.get('error') or {}
                if method=='turn/completed' and params.get('turn',{}).get('id')==turn:
                    terminal=params['turn'];failure=terminal.get('error') or failure
                    result['turn_status']=terminal['status']
                    result['model_available']=terminal['status']=='completed' and failure is None
                    result['reply_exact_ok']=bool(answer) and ''.join(answer).strip()=='OK'
                    if result['model_available'] and not result['reply_exact_ok']:
                        raise ValueError('Model returned an unexpected text-only probe response')
                    if failure:
                        code=failure.get('codexErrorInfo')
                        result['error_code']=code if isinstance(code,str) and re.fullmatch(r'[A-Za-z_]{1,80}',code) else 'unclassified'
                        message=failure.get('message','')
                        retry=re.search(r'try again at ([A-Za-z]{3,9} \d{1,2}(?:st|nd|rd|th)?, 20\d\d \d{1,2}:\d{2} [AP]M)',message)
                        result['service_retry_after_text']=retry.group(1) if retry else None
                        result['service_retry_after_timezone_verified']=False
                    break
            else:raise TimeoutError('Bounded text-only availability probe deadline')
        result['rpc_methods']=calls
    except Exception as error:
        private_failure=private/'private_failure.txt';private_failure.write_text(str(error));private_failure.chmod(0o600)
        result=dict(schema='gpt_policy_historical_service_availability.v1',verified=False,checked_utc=utc(),
                    exception_type=type(error).__name__,model_available=None,rpc_methods=calls,
                    model_turn_start_calls=calls.count('turn/start'),simulator_steps=0,authentication_copied=False)
    finally:
        if transport is not None:transport.close()
        for key,value in previous.items():
            if value is None:os.environ.pop(key,None)
            else:os.environ[key]=value
    result['private_log_files_sha256']={str(p.relative_to(private)):sha(p.read_bytes()) for p in private.rglob('*') if p.is_file()}
    destination.parent.mkdir(parents=True,exist_ok=True);new_json(destination,result)
    locator=destination.with_suffix('.private_locator');locator.write_text(str(private)+'\n');locator.chmod(0o600)
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True);parser.add_argument('--probe-model',action='store_true')
    args=parser.parse_args();result=probe(args.output,args.probe_model)
    print(json.dumps({k:result.get(k) for k in ('verified','checked_utc','model_available','error_code','service_retry_after_text',
                    'model_turn_start_calls','simulator_steps','exception_type')}),flush=True)
    if result['verified'] is not True:raise SystemExit(1)


if __name__=='__main__':main()
