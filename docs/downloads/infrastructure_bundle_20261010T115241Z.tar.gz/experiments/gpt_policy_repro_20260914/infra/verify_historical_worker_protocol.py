"""Execute reviewed controller branches offline; never invoke a model or simulator."""
import contextlib
import datetime
import hashlib
import importlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch
from stage_historical_workers import ART,Q,SOURCE_ROOT,verify_tree,sha

class Events:
    def __init__(self,events):self.events=iter(events);self.replies=[]
    def next_message(self,timeout):return next(self.events)
    def reply(self,identifier,result):self.replies.append((identifier,result))
    def request(self,*args,**kwargs):raise AssertionError('Offline test requested external RPC')

class Rollout:
    """Each accepted call advances once; rejected calls have no physical effects."""
    def __init__(self,module,method):
        self.module=module;self.task='offline_contract';self.tick=0
        self.phase='act' if method=='gpt_only' else 'execute'
        self.counters={};self.accepted=0;self.invocations=0
        self.observation_path=None;self.request=None
    def next_call(self):return dict(tool='robodojo_act',step_id=self.tick)
    def handler(self,kind='reject',**kwargs):
        self.invocations+=1
        if kind=='reject':raise self.module.InputError('Synthetic pre-execution rejection')
        if kind=='uncertain':raise RuntimeError('Synthetic uncertain RPC outcome')
        self.accepted+=1;self.tick+=1
        if kind=='done':self.phase='done'
        return dict(step_id=self.tick,images=[])
    start=act=infer=execute=handler

def tool_event(index,method,kind='reject',*,arguments=None,thread='offline-thread',turn='offline-turn'):
    return dict(id=index+1,method='item/tool/call',params=dict(threadId=thread,turnId=turn,callId='offline-'+str(index),
        tool='robodojo_act' if method=='gpt_only' else 'robodojo_execute',arguments=dict(kind=kind) if arguments is None else arguments))

def terminal(turn='offline-turn',status='completed',error=None):
    return dict(method='turn/completed',params=dict(threadId='offline-thread',turn=dict(id=turn,status=status,error=error)))

def load_profile(profile):
    root=ART/profile['package_root'];expected={**profile['frozen_files_sha256'],**profile['added_runtime_bridge_sha256']}
    verify_tree(root,expected)
    sys.path.insert(0,str(SOURCE_ROOT))
    name='historical_worker_'+profile['profile_id']
    if name not in sys.modules:
        spec=importlib.util.spec_from_file_location(name,root/'__init__.py',submodule_search_locations=[str(root)])
        package=importlib.util.module_from_spec(spec);sys.modules[name]=package;spec.loader.exec_module(package)
    return importlib.import_module(name+'.skill.run')

def scenario(module,method,kinds,*,bad_thread=False,malformed=False,network=False):
    with tempfile.TemporaryDirectory(prefix='gpt-historical-offline-') as temporary:
        workspace=Path(temporary);rollout=Rollout(module,method)
        events=[tool_event(i,method,kind,thread='foreign-thread' if bad_thread else 'offline-thread',
            arguments='{' if malformed and i==0 else None) for i,kind in enumerate(kinds)]
        if network:
            error=dict(message='stream disconnected before completion: connection error')
            events=[dict(method='error',params=dict(threadId='offline-thread',turnId='offline-turn',willRetry=False,error=error)),
                terminal(status='failed',error=error),tool_event(0,method,'done',turn='offline-continued-turn'),terminal('offline-continued-turn')]
        else:events.append(terminal())
        transport=Events(events);policy=module.CodexPolicy.__new__(module.CodexPolicy)
        policy.method=method;policy.workspace=workspace;policy.thread_id='offline-thread'
        policy.timeout=1;policy.image_max_edge=480;policy.transport=transport
        policy._turn=lambda text:'offline-turn'
        continuations=[]
        def continue_network(*args):
            assert args[0] is rollout
            continuations.append(dict(tick=rollout.tick,accepted=rollout.accepted,thread_id=policy.thread_id))
            return 'offline-continued-turn'
        policy._network_continue=continue_network
        exception=None
        with contextlib.redirect_stdout(io.StringIO()):
            try:policy.run(rollout)
            except Exception as error:exception=type(error).__name__
        result_files=sorted(workspace.glob('call_*_result.json'))
        packets=[json.loads(path.read_text()) for path in result_files]
        return dict(exception=exception,handler_invocations=rollout.invocations,accepted_calls=rollout.accepted,
            native_stub_tick=rollout.tick,reply_count=len(transport.replies),persisted_result_count=len(packets),
            rejected_replies=sum(r['success'] is False for _,r in transport.replies),
            enhanced_rejection_packets=sum(r.get('error_type')=='recoverable_tool_input' for r in packets),
            network_continuations=continuations)

def verify_profile(profile,module):
    methods=profile['methods'];legacy=profile['cumulative_input_rejection_stop']==5
    results={}
    for method in methods:
        runs={
            'six_rejections_then_done':scenario(module,method,['reject']*6+['done']),
            'cumulative_errors_across_success':scenario(module,method,['reject']*4+['advance','reject','done']),
            'malformed_json':scenario(module,method,['reject','done'],malformed=True),
            'foreign_thread':scenario(module,method,['done'],bad_thread=True),
            'uncertain_handler_error':scenario(module,method,['uncertain','done']),
            'network_failure':scenario(module,method,[],network=True)}
        a=runs['six_rejections_then_done']
        assert (a['exception'],a['handler_invocations'],a['accepted_calls'],a['reply_count'],a['persisted_result_count'])==(
            ('RuntimeError',5,0,5,4) if legacy else (None,7,1,7,7))
        a=runs['cumulative_errors_across_success']
        assert (a['exception'],a['handler_invocations'],a['accepted_calls'],a['reply_count'],a['persisted_result_count'])==(
            ('RuntimeError',6,1,6,5) if legacy else (None,7,2,7,7))
        a=runs['malformed_json']
        assert (a['exception'],a['handler_invocations'],a['reply_count'])==(
            ('JSONDecodeError',0,0) if legacy else (None,1,2))
        for name in ('foreign_thread','uncertain_handler_error'):
            a=runs[name];assert a['exception']=='RuntimeError' and a['accepted_calls']==a['reply_count']==0
        assert runs['foreign_thread']['handler_invocations']==0
        assert runs['uncertain_handler_error']['handler_invocations']==1
        a=runs['network_failure'];supported=profile['same_thread_network_continue_supported']
        assert a['accepted_calls']==(1 if supported else 0)
        assert len(a['network_continuations'])==(1 if supported else 0)
        assert a['exception']==(None if supported else 'RuntimeError')
        if supported:assert a['network_continuations']==[dict(tick=0,accepted=0,thread_id='offline-thread')]
        results[method]=runs
    # Exercise the actual continuation body while replacing only time and RPC.
    network_body=None
    if profile['same_thread_network_continue_supported']:
        with tempfile.TemporaryDirectory(prefix='gpt-historical-network-') as temporary:
            policy=module.CodexPolicy.__new__(module.CodexPolicy);policy.workspace=Path(temporary)
            policy.thread_id='offline-thread';rollout=Rollout(module,methods[0]);rollout.tick=3;rollout.accepted=3
            turns=[];sleeps=[]
            def turn(text):turns.append(text);return 'continued-turn'
            policy._turn=turn
            with patch.object(module.time,'sleep',side_effect=lambda n:sleeps.append(n)),contextlib.redirect_stdout(io.StringIO()):
                result=policy._network_continue(rollout,'old-turn',dict(message='stream disconnected before completion: connection error'),0,0)
            assert result=='continued-turn' and len(turns)==1 and rollout.tick==rollout.accepted==3
            record=json.loads((policy.workspace/'network_continue_0000.json').read_text())
            assert record['physical_actions_replayed']==0 and record['thread_id']=='offline-thread' and record['status']=='continue_sent'
            network_body=dict(passed=True,backoff_seconds=sum(sleeps),turn_start_stub_calls=len(turns),unchanged_tick=rollout.tick,
                replayed_actions=record['physical_actions_replayed'])
    return dict(profile_id=profile['profile_id'],methods=results,network_continue_body=network_body,
        active_tool_schema_sha256={method:sha(json.dumps(module.tool_specs(method),sort_keys=True).encode()) for method in methods})

def main():
    raw=(Q/'historical_worker_manifest.json').read_bytes();manifest=json.loads(raw)
    assert manifest['verified'] is True and len(manifest['source_profiles'])==5 and len(manifest['cases'])==100
    backend=SOURCE_ROOT/'hybrid_rollout/robodojo/codex_backend/profiles.py'
    assert sha(backend.read_bytes())==manifest['current_gateway_bridge']['backend_sha256']
    rows=[]
    for profile in manifest['source_profiles']:
        profile=dict(profile,methods=sorted({r['method'] for r in manifest['cases'] if r['profile_id']==profile['profile_id']}))
        module=load_profile(profile);rows.append(verify_profile(profile,module))
        print(json.dumps(dict(profile=profile['profile_id'],offline_contracts_passed=True)),flush=True)
    for method in ('gpt_only','pi05_plus_gpt'):
        hashes={r['active_tool_schema_sha256'][method] for r in rows if method in r['active_tool_schema_sha256']}
        assert len(hashes)==1,'Active same-method tool schema changed across historical profiles'
    result=dict(schema='gpt_policy_historical_worker_offline_gate.v1',verified=True,
        verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),manifest_sha256=sha(raw),profiles=rows,
        verified_source_profiles=len(rows),recorded_case_assignments=len(manifest['cases']),model_calls=0,simulator_steps=0,
        original_source_bytes_unchanged=True,historical_protocol_equivalence=False,full_blog_reproduction_complete=False,
        scope='Executed reviewed original event-loop and network-continuation branches with synthetic events and stub handlers. '
            'No model/simulator calls; not a physical rerun or service snapshot equivalence proof.')
    (Q/'historical_worker_offline_gate.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(verified=True,source_profiles=len(rows),model_calls=0,simulator_steps=0)),flush=True)

if __name__=='__main__':main()
