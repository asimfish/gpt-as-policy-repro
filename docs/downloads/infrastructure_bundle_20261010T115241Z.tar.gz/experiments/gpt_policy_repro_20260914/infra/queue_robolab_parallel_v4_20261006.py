"""Bounded independent RoboLab episodes using the exact pinned v2 selection oracle."""
import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import types

from robolab_parallel_state import atomic_json, process_identity, reconcile, resources, slot_ports
from transfer_checkpoint_chunks import remote
from local_robolab_runtime import LOCAL_ROOT, validate_root

ARTIFACTS = Path(__file__).resolve().parents[1]
V2_SHA = 'e91048862320a6a7f7a10942c07b4343a43bbd6d6412148b05189bafa3b708ea'
FROZEN_SHA = '760894e9bc19bd2affe8d83a735936037c1317fe869dce1e10377d637e7beb72'


def read(path, default=None):
    try:
        return json.loads(path.read_text())
    except FileNotFoundError:
        return default


def load_oracle():
    path = ARTIFACTS / 'infra/queue_robolab_two_methods_v2_20261005.py'
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != V2_SHA:
        raise ValueError('Original selection oracle changed')
    module = types.ModuleType('pinned_robolab_v2')
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def launch_plan(rows, leases, free, max_workers, key):
    """Pure scheduling: reserve identities and all GPUs before another choice."""
    if type(max_workers) is not int or max_workers not in range(1, 4):
        raise ValueError('Concurrency must be 1..3')
    if len({lease['slot'] for lease in leases}) != len(leases):
        raise ValueError('Duplicate slot reservations')
    if len({key(lease) for lease in leases}) != len(leases):
        raise ValueError('Duplicate frozen identity reservations')
    used = [lease[name] for lease in leases for name in ('sim_gpu', 'policy_gpu') if lease[name] is not None]
    if len(set(used)) != len(used):
        raise ValueError('Overlapping GPU reservations')
    identities = {key(lease) for lease in leases}
    reserved = set(used)
    pending = sorted(enumerate(rows), key=lambda pair: (pair[1]['generation_attempts'], pair[0]))
    plans = []
    for slot in range(max_workers):
        if any(lease['slot'] == slot for lease in leases):
            continue
        for _, row in pending:
            if row['status'] != 'pending' or key(row) in identities:
                continue
            devices = resources(free, reserved, row['method'])
            if devices is None:
                continue
            plans.append(dict(task=row['task'], seed=row['seed'], method=row['method'], slot=slot, **devices))
            identities.add(key(row))
            reserved.update(v for v in devices.values() if v is not None)
            break
    return plans


def gpu_inventory():
    code = "import subprocess,json;v=subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.free','--format=csv,noheader,nounits'],text=True);print(json.dumps({int(r.split(',')[0]):int(r.split(',')[1]) for r in v.splitlines()}))"
    return {int(k): v for k, v in json.loads(remote(code, (), timeout=30)).items()}


def validate_leases(leases, entries, key):
    allowed = {key(row) for row in entries}
    import re
    for lease in leases:
        slot_ports(lease['slot'])
        if key(lease) not in allowed or type(lease['seed']) is not int:
            raise ValueError('Reservation outside the frozen cohort')
        prefix = 'direct_' if lease['method']=='gpt_only' else 'hybrid_'
        pattern = prefix+r'20[0-9]{6}T[0-9]{6}Z_'+re.escape(lease['task'])+'_seed'+str(lease['seed'])
        if not re.fullmatch(pattern, lease['attempt']):
            raise ValueError('Invalid reserved attempt path')
        for name in ('sim_gpu', 'policy_gpu'):
            value = lease[name]
            if not (value is None and name=='policy_gpu') and (type(value) is not int or value not in range(8)):
                raise ValueError('Invalid reserved GPU')
        if lease['method']=='pi05_plus_gpt' and lease['policy_gpu'] is None:
            raise ValueError('Hybrid needs a separate policy GPU')
    launch_plan([], leases, {}, 3, key)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--max-workers', type=int, choices=range(1, 4), default=3)
    parser.add_argument('--poll-seconds', type=int, choices=range(5, 61), default=20)
    args = parser.parse_args()
    oracle = load_oracle()
    frozen_path = ARTIFACTS / 'fixtures/robolab_two_methods_frozen.json'
    if hashlib.sha256(frozen_path.read_bytes()).hexdigest() != FROZEN_SHA:
        raise ValueError('Frozen 100-case identities changed')
    entries = read(frozen_path)['entries']
    if len(entries) != 100 or len({oracle.key(row) for row in entries}) != 100:
        raise ValueError('Exactly 100 unique frozen method runs required')
    manifest = read(ARTIFACTS / 'robolab_queue_scheduler_v4_manifest.json')
    workspace_root=validate_root(Path(manifest['local_workspace_root']))
    for name, sha in manifest['files_sha256'].items():
        if Path(name).name != name or hashlib.sha256((ARTIFACTS/'infra'/name).read_bytes()).hexdigest() != sha:
            raise ValueError('Versioned queue source differs from the reviewed manifest')
    leases_path = ARTIFACTS / 'robolab_gpt_parallel_leases.json'
    draining = False
    def terminate(*_):
        nonlocal draining
        draining = True
    signal.signal(signal.SIGTERM, terminate)
    signal.signal(signal.SIGINT, terminate)
    children = {}
    with Path('/tmp/gpt-policy-robolab-two-methods-queue.lock').open('a') as singleton:
        fcntl.flock(singleton, fcntl.LOCK_EX | fcntl.LOCK_NB)
        state = read(leases_path, dict(schema='gpt_policy_robolab_leases.v1', leases=[], history=[]))
        if state['schema'] != 'gpt_policy_robolab_leases.v1':
            raise ValueError('Unknown reservation schema')
        while True:
            validate_leases(state['leases'], entries, oracle.key)
            for attempt, proc in list(children.items()):
                if proc.poll() is not None:
                    children.pop(attempt)
            leases = []
            for lease in state['leases']:
                record = read(ARTIFACTS/'robolab_gpt_campaign'/lease['attempt']/'attempt.json')
                lease['status'] = reconcile(lease, record)
                if lease['status'] == 'released':
                    state['history'].append(dict(lease, released_utc=datetime.now(timezone.utc).isoformat()))
                else:
                    leases.append(lease)
            state['leases'] = leases
            atomic_json(leases_path, state)
            rows = oracle.inventory(entries)
            for row in rows:
                lease = next((v for v in leases if oracle.key(v) == oracle.key(row)), None)
                if lease and row['status'] == 'pending':
                    row['status'] = 'running' if lease['status'] == 'running' else lease['status']
            done = sum(row['status'] == 'complete' for row in rows)
            queue = dict(schema='gpt_policy_robolab_queue.v4', frozen_sha256=FROZEN_SHA,
                planned_method_runs=100, complete_method_runs=done, entries=rows,
                status='draining' if draining else 'complete' if done==100 and not leases else 'running',
                max_workers=args.max_workers, active_reservations=len(leases),
                updated_utc=datetime.now(timezone.utc).isoformat(), repair_epoch=oracle.REPAIR_EPOCH,
                retry_policy='Pinned v2 first native terminal and max3 repaired infrastructure attempts; uncertain launches stay reserved')
            atomic_json(ARTIFACTS/'robolab_gpt_queue_state.json', queue)
            if not leases and (done == 100 or draining):
                return 0
            if not draining:
                try:
                    validate_root(workspace_root)
                    plans = launch_plan(rows, leases, gpu_inventory(), args.max_workers, oracle.key)
                except (subprocess.SubprocessError, OSError, ValueError, json.JSONDecodeError) as error:
                    plans = []
                    queue['resource_probe_error_type'] = type(error).__name__
                    atomic_json(ARTIFACTS/'robolab_gpt_queue_state.json', queue)
                for plan in plans:
                    if draining:
                        break
                    prefix = 'direct_' if plan['method']=='gpt_only' else 'hybrid_'
                    attempt = prefix+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'_'+plan['task']+'_seed'+str(plan['seed'])
                    lease = dict(plan, attempt=attempt, status='prepared', supervisor_identity=None,
                                 reserved_utc=datetime.now(timezone.utc).isoformat())
                    state['leases'].append(lease)
                    atomic_json(leases_path, state)  # Durable intent before the one mutating spawn.
                    sim_port, policy_port = slot_ports(plan['slot'])
                    argv = [sys.executable, str(ARTIFACTS/'infra/run_robolab_remote_v4_20261006.py'),
                        '--workspace-root',str(workspace_root),
                        '--worker-slot', str(plan['slot']), '--attempt', attempt,
                        '--method', plan['method'], '--task', plan['task'], '--seed', str(plan['seed']),
                        '--sim-port', str(sim_port), '--policy-port', str(policy_port),
                        '--sim-gpu', str(plan['sim_gpu']), '--policy-gpu', str(plan['policy_gpu'] or 0),
                        '--ssh-cipher', 'aes128-gcm@openssh.com']
                    with (ARTIFACTS/'robolab_gpt_queue.log').open('a') as log:
                        proc = subprocess.Popen(argv, stdout=log, stderr=subprocess.STDOUT)
                    children[attempt] = proc
                    lease.update(supervisor_identity=process_identity(proc.pid), status='running')
                    atomic_json(leases_path, state)
            time.sleep(args.poll_seconds)


if __name__ == '__main__':
    raise SystemExit(main())
