"""Audit a stopped, zero-execution quota failure without changing frozen runners.

This read-only inspection creates one new immutable gate for an existing first
attempt. It never creates run/result metadata, invokes a model, resets a simulator,
or releases an attempt for replay. Missing or ambiguous execution evidence fails.
"""
import argparse
import fcntl
import json
from pathlib import Path

from run_historical_cohort import ART, read, utc, sha, new_json, verify_plan


def stopped_processes(attempt):
    for process in attempt['owned_processes']:
        stat=Path('/proc',str(process['pid']),'stat')
        if stat.exists() and stat.read_text().rsplit(')',1)[1].split()[19]==process['start_ticks']:
            raise ValueError('Owned process is still alive')


def audit_startup_failure(root,run,row,plan):
    if (run/'evidence_gate.json').exists():raise ValueError('Existing evidence gate is immutable')
    attempt=read(run/'attempt.json');claim=read(run/'launch_claim.json')
    stopped_processes(attempt)
    plan_digest=sha((root/'cohort_plan.json').read_bytes())
    if (attempt['episode_id']!=row['episode_id'] or attempt['method']!=row['method']
            or attempt['profile_id']!=row['profile_id'] or attempt['first_attempt'] is not True
            or attempt['status']!='controller_incomplete' or attempt['controller_returncode']!=1
            or attempt['native_complete'] is not False or claim['episode_id']!=row['episode_id']
            or claim['plan_sha256']!=plan_digest or claim['automatic_physical_retries']!=0):
        raise ValueError('Stopped attempt does not satisfy the original first-attempt contract')
    launch=read(run/'historical_launch.json');worker=read(run/'rollout/codex_workspace/worker.json')
    if (launch['episode']!=row['episode_id'] or launch['profile_id']!=row['profile_id']
            or launch['manifest_sha256']!=plan['receipt_sha256']['historical_worker_manifest.json']
            or worker['codex_version']!=plan['cli_version'] or worker['model']!=plan['model']
            or worker['reasoning_effort']!=plan['reasoning_effort'] or worker['evaluation_method']!=row['method']):
        raise ValueError('Original worker/source/CLI launch identity differs')
    forbidden=('rollout/run.json','rollout/result.json','rollout/history.json','sim/evaluation_outcome.json',
               'complete_action_audit.json','stopped_prefix_audit.json')
    if any((run/name).exists() for name in forbidden):
        raise ValueError('A started or scored episode requires its regular audit')
    paths=sorted(run.rglob('*'))
    if any(path.is_symlink() for path in paths):raise ValueError('Evidence contains a symlink')
    if any(path.name.startswith(('action_','execution_','response_')) or path.name=='initial_observation.npz'
           for path in paths if path.is_file()):
        raise ValueError('Native or controller execution evidence exists')
    failure=read(run/'rollout/failure.json')
    if failure['episode_id'] is not None or failure['step_id']!=0 or failure['completed'] is not False:
        raise ValueError('Controller failure has a native episode or completion')
    thread=worker['thread_id'];quota_errors=[];terminal=[]
    events=[json.loads(line) for line in (run/'rollout/codex_workspace/rpc_out.jsonl').read_text().splitlines()]
    for event in events:
        method=event.get('method');params=event.get('params',{})
        if method=='item/tool/call':raise ValueError('An execution service was requested')
        if method in ('item/started','item/completed'):
            item=params.get('item',{})
            if item.get('type') not in ('agentMessage','reasoning','userMessage','systemMessage'):
                raise ValueError('A native tool or unknown execution item was observed')
        if method=='error' and params.get('threadId')==thread:
            error=params.get('error',{})
            if error.get('codexErrorInfo')=='usageLimitExceeded' and params.get('willRetry') is False:
                quota_errors.append(params)
        if method=='turn/completed' and params.get('threadId')==thread:
            turn=params.get('turn',{})
            if turn.get('status')=='failed' and (turn.get('error') or {}).get('codexErrorInfo')=='usageLimitExceeded':
                terminal.append(turn)
    if len(quota_errors)!=1 or len(terminal)!=1 or quota_errors[0].get('turnId')!=terminal[0].get('id'):
        raise ValueError('No uniquely joined quota failure and failed terminal turn')
    return dict(schema='gpt_policy_historical_cohort_episode_gate.v1',verified=True,verified_utc=utc(),
        episode_id=row['episode_id'],method=row['method'],profile_id=row['profile_id'],
        status='startup_failed_no_execution',original_attempt_status=attempt['status'],
        failure_reason='usageLimitExceeded',first_attempt_retained=True,automatic_physical_retries=0,
        plan_sha256=plan_digest,native_success=None,native_score=None,
        worker_identity_verified=True,controller_source_launch_verified=True,runtime_identity_verified=False,
        stopped_prefix_decisions=0,stopped_prefix_actions=0,service_tool_calls=0,
        native_reset_observed=False,run_metadata_fabricated=False,
        evidence_inputs_sha256={str(path.relative_to(run)):sha(path.read_bytes()) for path in paths if path.is_file()},
        recovery_scope='Original CLI/source/model thread and non-execution failure chain verified. '
                       'Missing native run identity is not fabricated. This attempt stays unscored and cannot be replayed.',
        historical_protocol_equivalence=False,full_blog_reproduction_complete=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cohort',type=Path,required=True);parser.add_argument('--episode',required=True)
    args=parser.parse_args();root=args.cohort.absolute()
    lock=Path('/tmp/gpt-historical-worker-campaign.lock').open('a')
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    plan=verify_plan(root)
    row=next(row for pair in plan['pairs'] for row in pair['cases'] if row['episode_id']==args.episode)
    run=root/'episodes'/row['episode_id']
    proof=audit_startup_failure(root,run,row,plan);new_json(run/'evidence_gate.json',proof)
    print(json.dumps({k:proof[k] for k in ('verified','episode_id','status','failure_reason','stopped_prefix_actions',
                                        'native_success','native_score','automatic_physical_retries')}),flush=True)


if __name__=='__main__':main()
