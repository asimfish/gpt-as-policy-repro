"""Publishing a prepared report requires its complete, exact statistics binding."""
import hashlib
import json
import unittest
from publish_verified_historical_snapshot import validate_binding


class PreparedHistoricalPublicationTests(unittest.TestCase):
    def fixture(self):
        data=json.dumps(dict(independent_evaluation_complete=True,historical_equivalence_verified=False)).encode()
        proof=dict(verified=True,comparison_sha256=hashlib.sha256(data).hexdigest(),complete_native_episodes=200,
                   files_sha256={str(i):'digest' for i in range(900)})
        return data,proof

    def test_exact_prepared_report_is_bound(self):
        data,proof=self.fixture();self.assertFalse(validate_binding(data,proof)['historical_equivalence_verified'])

    def test_changed_bytes_or_missing_native_statistics_are_rejected(self):
        data,proof=self.fixture()
        with self.assertRaises(ValueError):validate_binding(data+b' ',proof)
        proof['files_sha256'].pop('0')
        with self.assertRaises(ValueError):validate_binding(data,proof)

    def test_self_consistent_hash_cannot_promote_historical_completion(self):
        data,proof=self.fixture();value=json.loads(data);value['historical_equivalence_verified']=True
        data=json.dumps(value).encode();proof['comparison_sha256']=hashlib.sha256(data).hexdigest()
        with self.assertRaises(ValueError):validate_binding(data,proof)


if __name__=='__main__':unittest.main()
