"""Admission and restart boundaries of the remaining historical-source cohort."""
import json
from pathlib import Path
import tempfile
import unittest

from run_historical_cohort import order_pairs, next_action, new_json, gate_score


class HistoricalCohortTests(unittest.TestCase):
    def test_profile_order_uses_only_frozen_identity(self):
        pairs = [dict(case_id='c', profiles=['old', 'third']),
                 dict(case_id='a', profiles=['old', 'new']),
                 dict(case_id='b', profiles=['old', 'old'])]
        self.assertEqual([p['case_id'] for p in order_pairs(pairs, {'old'})], ['a', 'c', 'b'])
        self.assertEqual(order_pairs(list(reversed(pairs)), {'old'}), order_pairs(pairs, {'old'}))

    def test_first_attempt_claim_prevents_physical_retry(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)/'fresh_episode'
            self.assertEqual(next_action(root), 'launch')
            root.mkdir()
            new_json(root/'launch_claim.json', dict(episode_id='direct__a'))
            self.assertEqual(next_action(root), 'review_stopped_attempt')
            (root/'attempt.json').write_text(json.dumps(dict(status='controller_incomplete')))
            self.assertEqual(next_action(root), 'review_stopped_attempt')

    def test_empty_existing_run_requires_review(self):
        with tempfile.TemporaryDirectory() as temporary:
            self.assertEqual(next_action(Path(temporary)), 'review_stopped_attempt')

    def test_audited_failure_advances_without_replacement(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            new_json(root/'launch_claim.json', {})
            new_json(root/'evidence_gate.json', dict(verified=True))
            self.assertEqual(next_action(root), 'retain')

    def test_failed_or_orphan_audit_stops_queue(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            new_json(root/'evidence_gate.json', dict(verified=True))
            self.assertEqual(next_action(root), 'review_stopped_attempt')
            (root/'evidence_gate.json').unlink()
            new_json(root/'launch_claim.json', {})
            new_json(root/'evidence_gate.json', dict(verified=False))
            self.assertEqual(next_action(root), 'review_stopped_attempt')

    def test_immutable_record_cannot_be_overwritten(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary)/'proof.json'
            new_json(path, {'native_success': False})
            before = path.read_bytes()
            with self.assertRaises(FileExistsError):
                new_json(path, {'native_success': True})
            self.assertEqual(path.read_bytes(), before)

    def test_only_complete_valid_audited_episodes_have_scores(self):
        failure = dict(status='native_complete_audited', verified=True,
                       native_success=False, native_score=0.3)
        self.assertEqual(gate_score(failure), (False, 0.3))
        for status in ('controller_incomplete', 'invalid_native_layout', 'infrastructure_failed'):
            self.assertEqual(gate_score(dict(failure, status=status)), (None, None))
        self.assertEqual(gate_score(dict(failure, verified=False)), (None, None))


if __name__ == '__main__':
    unittest.main()
