"""Propagate a recovered sealed archive to a dead v3 supervisor's release record."""
from contextlib import ExitStack
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import tempfile

from archive_robolab_attempt import REMOTE_CAMPAIGN, digest, live_process_group, verify_archive
from robolab_parallel_state import atomic_json, identity_alive
from transfer_checkpoint_chunks import remote

REMOTE_CLEANUP = '''import json,sys
from pathlib import Path
root=Path(sys.argv[1]);value=json.loads((root/'services.json').read_text())
assert root.name==value['attempt'] and (root/'STOP').is_file()
assert value['status'] not in ('starting','ready') and value.get('finished_utc')
pids=[value['manager_pid'],value['simulator_pid']]
if value.get('policy_pid') is not None:pids.append(value['policy_pid'])
assert all(type(pid) is int and pid>0 for pid in pids)
assert all(not Path('/proc',str(pid)).exists() for pid in pids)
for entry in Path('/proc').iterdir():
 if not entry.name.isdecimal():continue
 try:fields=(entry/'stat').read_text().rsplit(')',1)[1].split()
 except (FileNotFoundError,ProcessLookupError):continue
 assert int(fields[2]) not in pids
result={k:value[k] for k in ('attempt','task','seed','method','worker_slot','manager_pid','finished_utc')}
result.update(verified=True,owned_processes_absent=True,owned_process_groups_absent=True)
print(json.dumps(result))
'''


def remote_cleanup(record):
    return json.loads(remote(REMOTE_CLEANUP, (record['remote_output'],), timeout=30))


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    require(not path.is_symlink(), 'Reconciliation input must not follow a link')
    return json.loads(path.read_text())


def promote_recovered_archive(path, *, lock_root=Path('/tmp'), remote_probe=remote_cleanup,
                              alive=identity_alive, pid_exists=lambda pid:Path('/proc',str(pid)).exists(),
                              groups_alive=live_process_group):
    path=Path(path);source=path.parent.parent;record=read(path/'attempt.json')
    if 'worker_slot' not in record:
        return dict(status='not_parallel_attempt')
    if record.get('remote_archive_verified') is True:
        return dict(status='already_recorded')
    if alive(record.get('supervisor_identity')):
        return dict(status='deferred_live_supervisor')
    slot=record['worker_slot']
    require(type(slot) is int and slot in range(3), 'Unknown worker slot')
    require(path.parent.name=='robolab_gpt_campaign' and path.name==record['attempt'], 'Foreign attempt path')
    prefix='direct_' if record['method']=='gpt_only' else 'hybrid_'
    require(record['method'] in ('gpt_only','pi05_plus_gpt') and type(record['seed']) is int and record['seed'] in range(5), 'Foreign frozen method or seed')
    require(re.fullmatch(prefix+r'20[0-9]{6}T[0-9]{6}Z_'+re.escape(record['task'])+'_seed'+str(record['seed']),path.name), 'Attempt identity differs')
    require(record['remote_output']==REMOTE_CAMPAIGN+'/'+path.name, 'Foreign remote archive root')
    identity=(record['task'],record['seed'],record['method'])
    frozen=read(source/'fixtures/robolab_two_methods_frozen.json')['entries']
    require(identity in {(x['task'],x['seed'],x['method']) for x in frozen}, 'Case is outside the frozen matrix')
    archive_id=hashlib.sha256(str(path.resolve()).encode()).hexdigest()
    with ExitStack() as stack:
        for name in [f'gpt-policy-robolab-controller-slot{slot}.lock',f'gpt-policy-robolab-archive-{archive_id}.lock']:
            fd=os.open(Path(lock_root)/name,os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW,0o600)
            lock=stack.enter_context(os.fdopen(fd,'a'));info=os.fstat(lock.fileno())
            require(info.st_uid==os.getuid() and stat.S_ISREG(info.st_mode), 'Owned regular lock required')
            try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError:return dict(status='deferred_owned_lock')
        raw=(path/'attempt.json').read_bytes();record=read(path/'attempt.json')
        require(json.loads(raw)==record, 'Attempt changed while acquiring locks')
        require(record.get('finished_utc') and record.get('controller_output_sealed') is True, 'Stopped sealed controller output required')
        if alive(record.get('supervisor_identity')):return dict(status='deferred_live_supervisor')
        expected=(record['task'],record['seed'],record['method'],record['attempt'],slot)
        leases=read(source/'robolab_gpt_parallel_leases.json')['leases']
        lease=next((x for x in leases if x and x['attempt']==path.name),None)
        require(lease is not None and tuple(lease.get(k) for k in ('task','seed','method','attempt','slot'))==expected, 'Original reservation differs')
        require(lease.get('supervisor_identity')==record.get('supervisor_identity') and lease.get('supervisor_identity'), 'Supervisor identity not bound to reservation')
        for field in ('controller_pid','tunnel_pid'):
            pid=record.get(field)
            require(type(pid) is int and pid>0 and not pid_exists(pid) and not groups_alive(pid), 'Owned local process or group remains')
        audit=read(path/'complete_action_audit.json');outcome=read(path/'rollout/result.json')
        require(audit.get('verified') is True and audit.get('complete_episode') is True and audit.get('scope')=='complete_native_episode' and audit.get('method')==record['method'], 'Full original audit required')
        require(outcome.get('complete') is True and (outcome.get('terminated') is True or outcome.get('truncated') is True) and audit['terminal']=={k:outcome[k] for k in ('success','terminated','truncated')}, 'Original native terminal differs')
        require('attempt.json' not in audit['files_sha256'], 'Changing release metadata would invalidate the original audit')
        manifest=read(path/'remote_archive_manifest.json');receipt=read(path/'remote_archive_receipt.json')
        require(receipt.get('verified') is True and receipt.get('schema')=='gpt_policy_robolab_archive_receipt.v1' and receipt['manifest_sha256']==digest(path/'remote_archive_manifest.json') and receipt['cleanup']==manifest['cleanup'], 'Original archive receipt and seal differ')
        verified=verify_archive(path/'remote',manifest)
        require(all(receipt[k]==verified[k] for k in ('files','bytes')), 'Archive totals differ')
        fresh=remote_probe(record)
        require(fresh.get('verified') is True and fresh.get('owned_processes_absent') is True and fresh.get('owned_process_groups_absent') is True, 'Fresh remote cleanup is unproven')
        require(tuple(fresh.get(k) for k in ('task','seed','method','attempt','worker_slot'))==expected and fresh.get('manager_pid')==record.get('remote_manager_pid'), 'Fresh remote service identity differs')
        require((path/'attempt.json').read_bytes()==raw, 'Attempt changed during verification')
        require(not alive(record.get('supervisor_identity')), 'Supervisor became active')
        original=path/'cleanup_recovery_original_attempt.json'
        if original.exists():require(original.read_bytes()==raw, 'Preserve original pre-recovery metadata')
        else:
            with tempfile.NamedTemporaryFile('wb',dir=path,delete=False) as stream:
                temporary=Path(stream.name);stream.write(raw);stream.flush();os.fsync(stream.fileno())
            temporary.replace(original)
        stamp=datetime.now(timezone.utc).isoformat()
        proof=dict(schema='gpt_policy_robolab_cleanup_reconciliation.v1',verified=True,
            attempt=path.name,worker_slot=slot,verified_utc=stamp,
            original_attempt_sha256=hashlib.sha256(raw).hexdigest(),
            archive_manifest_sha256=receipt['manifest_sha256'],archive_receipt_sha256=digest(path/'remote_archive_receipt.json'),
            archive_files=verified['files'],archive_bytes=verified['bytes'],
            native_result_sha256=digest(path/'rollout/result.json'),action_audit_sha256=digest(path/'complete_action_audit.json'),
            fresh_remote_cleanup=fresh,supervisor_identity=record['supervisor_identity'],
            no_model_or_simulator_calls=True,no_lease_mutation=True)
        atomic_json(path/'cleanup_reconciliation.json',proof)
        record.update(remote_archive_verified=True,remote_archive_exit=0,
            remote_archive_files=verified['files'],remote_archive_bytes=verified['bytes'],
            archive_recovered_utc=stamp,cleanup_reconciliation_sha256=digest(path/'cleanup_reconciliation.json'))
        atomic_json(path/'attempt.json',record)
        return dict(status='reconciled',attempt=path.name,files=verified['files'],bytes=verified['bytes'])
