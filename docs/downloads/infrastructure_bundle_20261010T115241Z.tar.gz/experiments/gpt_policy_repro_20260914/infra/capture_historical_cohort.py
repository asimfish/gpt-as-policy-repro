"""Capture public, dated historical-cohort evidence without invoking policies."""
import argparse
import json
from pathlib import Path

import run_historical_cohort as original
from continue_historical_cohort import capacity_errors


def copy_immutable(source, destination):
    data = source.read_bytes()
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        if destination.read_bytes() != data:
            raise ValueError('Existing public evidence copy differs')
    else:
        with destination.open('xb') as stream:
            stream.write(data)
        destination.chmod(0o444)
    return original.sha(data)


def capture(root, out, availability=None):
    plan = original.verify_plan(root); progress = original.read(root/'progress.json')
    digest = original.sha((root/'cohort_plan.json').read_bytes())
    rows = {r['episode_id']:r for pair in plan['pairs'] for r in pair['cases']}
    evidence = {}; codes = {}
    for result in progress['results']:
        episode = result['episode_id']; run = root/'episodes'/episode
        gate = original.read(run/'evidence_gate.json')
        if (gate['verified'] is not True or gate['plan_sha256'] != digest
                or gate['method'] != rows[episode]['method'] or gate['profile_id'] != rows[episode]['profile_id']):
            raise ValueError('Episode gate identity differs from the frozen cohort')
        for key in result:
            if key not in gate or result[key] != gate.get(key):
                # Progress has optional null fields that absent gate fields denote.
                if result[key] is not None or gate.get(key) is not None:
                    raise ValueError('Public progress differs from the audited episode')
        destination = out/'episode_evidence'/episode
        names = ['evidence_gate.json']
        for name, field in (('complete_action_audit.json','complete_action_audit_sha256'),
                            ('stopped_prefix_audit.json','stopped_prefix_audit_sha256')):
            if field in gate:
                if original.sha((run/name).read_bytes()) != gate[field]:
                    raise ValueError('Action audit bytes differ from the gate')
                names.append(name)
        for name in names:
            target = destination/name
            evidence[str(target.relative_to(out))] = copy_immutable(run/name, target)
        codes[episode] = capacity_errors(run)
    assert len(progress['results']) == progress['first_attempts_audited']
    assert progress['native_complete_audited'] == sum(r['status']=='native_complete_audited' for r in progress['results'])
    current = progress['current_episode']; observed = 0; worker = None
    if current:
        run = root/'episodes'/current; identity = run/'rollout/codex_workspace/worker.json'
        observed = len(list((run/'sim').glob('*/action_*.json')))
        if identity.exists():
            value = original.read(identity)
            worker = {key:value[key] for key in ('model','reasoning_effort','codex_version','evaluation_method')}
    resume = {}
    if progress.get('continuation_admission'):
        source = root/progress['continuation_admission']
        admission = original.read(source)
        assert admission['verified'] is True and admission['plan_sha256'] == digest
        destination = out/'continuation_evidence'/source.parent.name
        resume['admission_path'] = str((destination/'admission.json').relative_to(out))
        resume['admission_sha256'] = copy_immutable(source, destination/'admission.json')
        availability = availability or original.ART/'publication_checks/historical_resume_20261010/current_service_probe.json'
        if original.sha(availability.read_bytes()) != admission['availability_sha256']:
            raise ValueError('The selected availability receipt differs from this continuation admission')
        resume['availability_path'] = str((destination/'availability.json').relative_to(out))
        resume['availability_sha256'] = copy_immutable(availability, destination/'availability.json')
    claimed = sum((root/'episodes'/episode/'launch_claim.json').exists() for episode in rows)
    value = dict(schema='gpt_policy_historical_cohort_runtime_snapshot.v2',captured_utc=original.utc(),
        plan_sha256=digest,cohort=str(root.relative_to(original.ART)),progress=progress,
        observed_native_steps=observed,current_worker_identity=worker,current_run_complete_audit=False,
        episode_evidence_sha256=evidence,capacity_error_codes_by_episode=codes,
        claimed_first_attempts=claimed,unclaimed_episodes=98-claimed,continuation=resume,
        automatic_physical_retries=0,historical_protocol_equivalence=False,full_blog_reproduction_complete=False)
    if progress['phase']=='all_first_attempts_audited':
        completion=original.read(root/'completion.json')
        expected={r['episode_id']:evidence['episode_evidence/'+r['episode_id']+'/evidence_gate.json'] for r in progress['results']}
        if (completion.get('verified') is not True or completion.get('episodes')!=98 or len(expected)!=98
                or completion['episode_gate_sha256']!=expected or completion['automatic_physical_retries']!=0
                or completion['full_blog_reproduction_complete'] is not False
                or completion['complete_native_audited']!=progress['native_complete_audited']):
            raise ValueError('All-first-attempt completion receipt differs from captured episode gates')
        value['first_attempt_completion_sha256']=copy_immutable(root/'completion.json',out/'first_attempt_completion.json')
    destination = out/'runtime_snapshot.json'
    if destination.exists():
        prior = original.read(destination); stamp = prior['captured_utc'].replace(':','').replace('-','')
        copy_immutable(destination, out/'prior_snapshots'/('runtime_snapshot_'+stamp+'.json'))
    original.write(destination, value)
    return value


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cohort',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--availability',type=Path)
    args=parser.parse_args();value=capture(args.cohort.absolute(),args.output.absolute(),args.availability)
    print(json.dumps({k:value[k] for k in ('captured_utc','claimed_first_attempts','unclaimed_episodes','observed_native_steps')}))


if __name__=='__main__':main()
