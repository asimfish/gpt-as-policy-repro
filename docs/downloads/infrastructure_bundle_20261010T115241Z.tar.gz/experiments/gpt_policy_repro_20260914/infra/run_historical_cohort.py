"""Run the 49 remaining original-source pairs once, without replacing any result.

The already audited canary stays a separate, ineligible pilot. This cohort pins
each remaining original case's source profile, CLI and assets before any launch.
An existing launch claim without a verified gate stops recovery: it never causes
a second physical attempt. No private runtime configuration is copied or printed.
"""
import argparse
from collections import Counter
import datetime
import fcntl
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import time
import uuid

from stage_historical_workers import ART, Q, SOURCE_ROOT, sha, verify_tree
from run_historical_controller import admitted_case
from run_historical_pair import classify_outcome
from run_batch_student import terminate, wait_log, check, write
from run_gpt_pair import check_pair_simulator
from watch_historical_canary import video_coverage
from audit_gpt_direct_complete import audit as audit_direct
from audit_gpt_direct_prefix import audit as audit_direct_prefix
from audit_hybrid_actions import audit as audit_hybrid

PILOT_CASE = 'arrange_largest_number__random__g0__l0'
SEALED_CERTIFICATE = 'cc38b42cfcf0c098c2ad58a3af9a2e265fc1bd3b6e92ddeeae7208f18e4b3ee9'
NATIVE_NAMES = ('robodojo_server/server.py', 'robodojo_server/session.py',
                'robodojo_server/rpc.py', 'robodojo_server/kinematics.py',
                'robodojo_server/validation.py', 'evaluation.py')
PIN_FILES = ('run_historical_cohort.py', 'run_historical_cohort.sh',
             'run_historical_controller.py', 'run_historical_pair.py',
             'watch_historical_canary.py', 'stage_historical_workers.py',
             'verify_historical_worker_protocol.py', 'inspect_historical_worker_protocol.py',
             'verify_original_robodojo_records.py', 'run_batch_student.py',
             'run_gpt_pair.py', 'audit_gpt_direct_complete.py',
             'audit_gpt_direct_prefix.py', 'audit_hybrid_actions.py',
             'env.sh', 'run_sim_server.sh', 'run_pi05_server.sh')


def read(path):
    return json.loads(path.read_text())


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def new_json(path, value):
    """Publish complete bytes exclusively, including a durable launch claim."""
    temporary = path.with_name('.' + path.name + '.' + uuid.uuid4().hex)
    try:
        with temporary.open('x') as stream:
            json.dump(value, stream, indent=2); stream.write('\n')
            stream.flush(); os.fsync(stream.fileno())
        temporary.chmod(0o444)
        os.link(temporary, path)  # Atomic create; an existing receipt is never overwritten.
        descriptor = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
    finally:
        temporary.unlink(missing_ok=True)


def order_pairs(pairs, covered):
    """Cover source profiles early using metadata only; never inspect outcomes."""
    remaining = list(pairs); result = []; covered = set(covered)
    while remaining:
        chosen = min(remaining, key=lambda p: (-len(set(p['profiles']) - covered), p['case_id']))
        result.append(chosen); covered.update(chosen['profiles']); remaining.remove(chosen)
    return result


def next_action(run):
    claim, gate = run/'launch_claim.json', run/'evidence_gate.json'
    if claim.exists() and gate.exists() and read(gate).get('verified') is True:
        return 'retain'
    if claim.exists() or gate.exists() or run.exists():
        return 'review_stopped_attempt'
    return 'launch'


def gate_score(gate):
    if gate.get('verified') is True and gate.get('status') == 'native_complete_audited':
        return gate['native_success'], gate['native_score']
    return None, None


def check_root(root):
    allowed = (ART/'historical_worker_campaign').absolute()
    if root.resolve() != root.absolute() or not root.is_relative_to(allowed) or root == allowed:
        raise ValueError('A canonical, separate historical campaign directory is required')


def case_rows(manifest):
    grouped = {}; assets = {}
    for case in manifest['cases']:
        prefix = 'gpt' if case['method'] == 'gpt_only' else 'mix'
        fixture = ART/'fixtures/cases'/(prefix+'__'+case['case_id']+'.json')
        data = read(fixture)
        for key in ('case_id', 'runtime_task', 'variant', 'eval_seed', 'layout_id',
                    'reset_seed', 'simulator_initial_seed', 'policy_rng_seed',
                    'layout', 'native_support_trajectories'):
            if data['case'].get(key, []) != case[key]:
                raise ValueError('Original case and frozen fixture differ')
        if case['max_decisions'] != 0 or case['simulator_initial_seed'] != 0 or case['policy_rng_seed'] != 0:
            raise ValueError('Original case budget or RNG contract differs')
        for asset in [case['layout'], *case['native_support_trajectories']]:
            path = Path(os.environ['ROBO_ROOT'])/asset['path']
            if path not in assets:
                assets[path] = sha(path.read_bytes())
            if assets[path] != asset['sha256']:
                raise ValueError('Frozen layout/support bytes changed')
        row = dict(episode_id=case['episode_id'], method=case['method'], case=case,
                   fixture=str(fixture.relative_to(ART)), fixture_sha256=sha(fixture.read_bytes()),
                   identity=data['identity'], profile_id=case['profile_id'])
        grouped.setdefault(case['case_id'], []).append(row)
    if len(grouped) != 50 or len(manifest['cases']) != 100:
        raise ValueError('Expected 50 original pairs')
    pairs = []
    for case_id, rows in grouped.items():
        rows.sort(key=lambda row: row['method'])
        if [r['method'] for r in rows] != ['gpt_only', 'pi05_plus_gpt'] or rows[0]['identity'] != rows[1]['identity']:
            raise ValueError('Methods are not paired by their frozen case identity')
        pairs.append(dict(case_id=case_id, profiles=[r['profile_id'] for r in rows], cases=rows))
    return pairs


def prepare(root, gpu, port):
    check_root(root)
    if root.exists() or not gpu.isdecimal() or not 1024 <= port < 65535:
        raise ValueError('Fresh output and bounded device/ports required')
    manifest, _, _ = admitted_case('direct__'+PILOT_CASE)
    pilot = read(Q/'historical_canary_evidence_gate.json')
    if pilot['verified'] is not True or pilot['complete_native_audited'] != 2:
        raise ValueError('Both canary methods must be completely audited first')
    for result in pilot['results']:
        run = ART/pilot['cohort']/result['method']
        if (sha((run/'complete_action_audit.json').read_bytes()) != result['complete_action_audit_sha256']
                or sha((run/'sim/sensors.mp4').read_bytes()) != result['source_video']['sha256']):
            raise ValueError('Audited pilot evidence changed')
    if sha((ART/'full_reproduction_verification.json').read_bytes()) != SEALED_CERTIFICATE:
        raise ValueError('Sealed native certificate changed')
    pairs = case_rows(manifest)
    prior = next(pair for pair in pairs if pair['case_id'] == PILOT_CASE)
    pairs = order_pairs([pair for pair in pairs if pair['case_id'] != PILOT_CASE], prior['profiles'])
    receipts = ('historical_worker_manifest.json', 'historical_worker_offline_gate.json',
                'original_cli_zero_turn_probe.json', 'original_cli_toolchain.json',
                'historical_canary_evidence_gate.json', 'historical_canary_admission.json')
    plan = dict(schema='gpt_policy_remaining_historical_cohort_plan.v1', prepared_utc=utc(),
                pairs=pairs, pairs_planned=49, episodes_planned=98,
                ordering='Greedy unseen source-profile coverage, then lexical frozen case_id; no outcome access',
                gpu=gpu, base_port=port, physical_retry_limit=0,
                attempt_selection='First claimed attempt per original episode; every outcome retained',
                pilot=dict(case_id=PILOT_CASE, cohort=pilot['cohort'], reused_for_grading=False,
                           evidence_gate_sha256=sha((Q/'historical_canary_evidence_gate.json').read_bytes())),
                receipt_sha256={name:sha((Q/name).read_bytes()) for name in receipts},
                source_sha256={'infra/'+name:sha((ART/'infra'/name).read_bytes()) for name in PIN_FILES},
                native_adapter_sha256={name:sha((SOURCE_ROOT/'hybrid_rollout/robodojo'/name).read_bytes())
                                       for name in NATIVE_NAMES},
                sealed_native_certificate_sha256=SEALED_CERTIFICATE,
                cli_version='codex-cli 0.153.4', model='gpt-6-astra', reasoning_effort='xhigh',
                original_selected_attempt_protocol_recovered=False,
                historical_protocol_equivalence=False, full_blog_reproduction_complete=False,
                scope='Fresh original-source remaining-case evaluation. Pilot separate; invalid layouts and '
                      'controller prefixes remain unscored. No historical service or hidden-physics equivalence claim.')
    root.mkdir(parents=True, mode=0o700, exist_ok=False)
    new_json(root/'cohort_plan.json', plan)
    new_json(root/'preflight.json', dict(verified=True, plan_sha256=sha((root/'cohort_plan.json').read_bytes()),
                                      model_calls=0, simulator_steps=0, prepared_utc=utc()))
    return plan


def verify_plan(root):
    check_root(root); plan = read(root/'cohort_plan.json')
    if sha((root/'cohort_plan.json').read_bytes()) != read(root/'preflight.json')['plan_sha256']:
        raise ValueError('Plan bytes differ from preflight')
    for name, digest in plan['source_sha256'].items():
        if sha((ART/name).read_bytes()) != digest:
            raise ValueError('Admitted infrastructure source changed')
    for name, digest in plan['native_adapter_sha256'].items():
        if sha((SOURCE_ROOT/'hybrid_rollout/robodojo'/name).read_bytes()) != digest:
            raise ValueError('Native adapter changed')
    for name, digest in plan['receipt_sha256'].items():
        if sha((Q/name).read_bytes()) != digest:
            raise ValueError('Admitted source/CLI/probe receipt changed')
    manifest = read(Q/'historical_worker_manifest.json')
    pairs = case_rows(manifest); prior = next(p for p in pairs if p['case_id'] == PILOT_CASE)
    expected = order_pairs([p for p in pairs if p['case_id'] != PILOT_CASE], prior['profiles'])
    if plan['pairs'] != expected or plan['episodes_planned'] != 98 or plan['physical_retry_limit'] != 0:
        raise ValueError('Cohort selection or no-retry policy changed')
    if (sha((ART/'full_reproduction_verification.json').read_bytes()) != SEALED_CERTIFICATE
            or plan['sealed_native_certificate_sha256'] != SEALED_CERTIFICATE):
        raise ValueError('Sealed 200-episode certificate changed')
    for profile in manifest['source_profiles']:
        verify_tree(ART/profile['package_root'], {**profile['frozen_files_sha256'],
                                                **profile['added_runtime_bridge_sha256']})
    return plan


def available(plan):
    free = int(subprocess.check_output(['nvidia-smi', '-i', plan['gpu'], '--query-gpu=memory.free',
                                      '--format=csv,noheader,nounits'], text=True).strip())
    if free < 20000:
        return False
    try:
        for port in (plan['base_port'], plan['base_port']+1):
            with socket.socket() as listener:
                listener.bind(('127.0.0.1', port))
    except OSError:
        return False
    return True


def execute(root, row, plan):
    run = root/'episodes'/row['episode_id']
    run.mkdir(mode=0o700, exist_ok=False)
    new_json(run/'launch_claim.json', dict(episode_id=row['episode_id'], claimed_utc=utc(),
        plan_sha256=sha((root/'cohort_plan.json').read_bytes()), automatic_physical_retries=0))
    state = dict(episode_id=row['episode_id'], method=row['method'], profile_id=row['profile_id'],
                 status='starting', started_utc=utc(), first_attempt=True, owned_processes=[])
    write(run/'attempt.json', state); processes = []; handles = []
    env = dict(os.environ, CUDA_VISIBLE_DEVICES=plan['gpu'], SIM_GPU=plan['gpu'],
               EVAL_MANIFEST=str(ART/'fixtures/evaluation_manifest.json'), CASE_FILE=str(ART/row['fixture']))

    def start(command, log):
        handle = log.open('x'); log.chmod(0o600); handles.append(handle)
        proc = subprocess.Popen(command, env=env, stdout=handle, stderr=subprocess.STDOUT, start_new_session=True)
        processes.append(proc)
        state['owned_processes'].append(dict(pid=proc.pid,
            start_ticks=Path('/proc', str(proc.pid), 'stat').read_text().rsplit(')', 1)[1].split()[19]))
        write(run/'attempt.json', state)
        return proc

    try:
        policy = None
        if row['method'] == 'pi05_plus_gpt':
            policy = start(['bash', str(ART/'infra/run_pi05_server.sh'), str(plan['base_port']+1),
                            str(run/'policy_identity.json')], run/'policy.log')
            wait_log(policy, run/'policy.log', 'server listening', timeout=1200)
            if read(run/'policy_identity.json')['checkpoint_sha256'] != row['case']['student_identity_sha256']:
                raise ValueError('Student checkpoint changed')
        simulator = start(['bash', str(ART/'infra/run_sim_server.sh'), row['case']['runtime_task'],
                           str(run/'sim'), str(plan['base_port']), str(row['case']['eval_seed'])], run/'sim.log')
        wait_log(simulator, run/'sim.log', '"event": "ready"', timeout=1200)
        ready = [json.loads(line) for line in (run/'sim.log').read_text(errors='replace').splitlines()
                 if line.startswith('{"event": "ready"')]
        if len(ready) != 1 or any(ready[0]['metadata'][key] != row['case'][key]
                                  for key in ('max_episode_steps', 'control_dt')):
            raise ValueError('Simulator native horizon/dt differs from original')
        command = [os.environ['ROBO_PYTHON'], str(ART/'infra/run_historical_controller.py'),
                   '--episode', row['episode_id'], '--output', str(run/'rollout'),
                   '--sim-port', str(plan['base_port']), '--student-port', str(plan['base_port']+1)]
        if policy is not None:
            command += ['--checkpoint', os.environ['PI05_CHECKPOINT']]
        controller = start(command, run/'controller.log'); state['status'] = 'running'; write(run/'attempt.json', state)
        deadline = time.monotonic()+12*3600; finalizing = None
        while controller.poll() is None:
            finalizing = check_pair_simulator(simulator, run, time.monotonic(), finalizing)
            if policy is not None:
                check(policy, run/'policy.log')
            if time.monotonic() > deadline:
                raise TimeoutError('Infrastructure watchdog; prefix remains unscored')
            time.sleep(2)
        state['controller_returncode'] = controller.returncode
    except BaseException as error:
        state.update(status='interrupted' if isinstance(error, KeyboardInterrupt) else 'infrastructure_failed',
                     exception_type=type(error).__name__, interrupted=isinstance(error, KeyboardInterrupt))
        private = run/'private_error.txt'; private.write_text(str(error)); private.chmod(0o600)
    finally:
        for proc in reversed(processes):
            terminate(proc)
        for handle in handles:
            handle.close()
        result = read(run/'rollout/result.json') if (run/'rollout/result.json').exists() else {}
        outcome = read(run/'sim/evaluation_outcome.json') if (run/'sim/evaluation_outcome.json').exists() else {}
        classification = classify_outcome(state.get('controller_returncode'), result, outcome)
        if classification in ('native_complete_pending_audit', 'invalid_native_layout') or 'exception_type' not in state:
            state['status'] = classification
        state.update(finished_utc=utc(), native_complete=outcome.get('complete') is True)
        write(run/'attempt.json', state)
    return run


def finalize(root, run, row, plan):
    attempt = read(run/'attempt.json'); claim = read(run/'launch_claim.json')
    if claim['plan_sha256'] != sha((root/'cohort_plan.json').read_bytes()) or claim['episode_id'] != row['episode_id']:
        raise ValueError('Attempt is not bound to admitted plan')
    if attempt['profile_id'] != row['profile_id'] or attempt['episode_id'] != row['episode_id']:
        raise ValueError('Attempt identity differs')
    for process in attempt['owned_processes']:
        stat = Path('/proc', str(process['pid']), 'stat')
        if stat.exists() and stat.read_text().rsplit(')', 1)[1].split()[19] == process['start_ticks']:
            raise ValueError('Audit cannot finalize a live owned process')
    gate = dict(schema='gpt_policy_historical_cohort_episode_gate.v1', verified=True, verified_utc=utc(),
                episode_id=row['episode_id'], method=row['method'], profile_id=row['profile_id'],
                status=attempt['status'], first_attempt_retained=True, automatic_physical_retries=0,
                plan_sha256=claim['plan_sha256'], native_success=None, native_score=None,
                historical_protocol_equivalence=False, full_blog_reproduction_complete=False)
    worker_path = run/'rollout/codex_workspace/worker.json'
    if worker_path.exists():
        worker = read(worker_path); config = read(run/'rollout/run.json'); launch = read(run/'historical_launch.json')
        if (worker['codex_version'], worker['model'], worker['reasoning_effort']) != (
                plan['cli_version'], plan['model'], plan['reasoning_effort']):
            raise ValueError('Runtime CLI/model identity differs')
        if launch['manifest_sha256'] != plan['receipt_sha256']['historical_worker_manifest.json'] or launch['profile_id'] != row['profile_id']:
            raise ValueError('Controller source launch differs')
        if config['evaluation_case'] != row['identity'] or any(config[key] != row['case'][key]
                for key in ('max_decisions', 'max_episode_steps', 'control_dt')):
            raise ValueError('Run native identity/budget differs')
        if row['method'] == 'pi05_plus_gpt' and config['student_identity_sha256'] != row['case']['student_identity_sha256']:
            raise ValueError('Run checkpoint identity differs')
        gate['runtime_identity_verified'] = True
    else:
        gate['runtime_identity_verified'] = False
    if attempt['status'] == 'native_complete_pending_audit':
        proof = audit_direct(run) if row['method'] == 'gpt_only' else audit_hybrid(run)
        if proof['verified'] is not True or proof['complete_episode'] is not True or not gate['runtime_identity_verified']:
            raise ValueError('Complete native action chain was not verified')
        new_json(run/'complete_action_audit.json', proof)
        outcome = read(run/'sim/evaluation_outcome.json')
        gate.update(status='native_complete_audited', native_actions=proof['native_actions'], decisions=proof['decisions'],
                    native_success=outcome['native_success'], native_score=outcome['native_score'],
                    complete_action_audit_sha256=sha((run/'complete_action_audit.json').read_bytes()),
                    source_video=video_coverage(run/'sim/sensors.mp4', proof['native_actions']+1))
    elif (run/'rollout/history.json').exists() and read(run/'rollout/history.json'):
        count = len(read(run/'rollout/history.json'))
        proof = audit_direct_prefix(run, count) if row['method'] == 'gpt_only' else audit_hybrid(run, count)
        if proof['verified'] is not True or proof['complete_episode'] is not False:
            raise ValueError('Stopped prefix could not be verified')
        new_json(run/'stopped_prefix_audit.json', proof)
        gate.update(stopped_prefix_decisions=count, stopped_prefix_actions=proof['native_actions'],
                    stopped_prefix_audit_sha256=sha((run/'stopped_prefix_audit.json').read_bytes()))
    # Hash every retained input; do not publish its private contents.
    paths = sorted(run.rglob('*'))
    if any(path.is_symlink() for path in paths):
        raise ValueError('Retained evidence contains a symlink')
    gate['evidence_inputs_sha256'] = {str(path.relative_to(run)):sha(path.read_bytes())
        for path in paths if path.is_file()}
    new_json(run/'evidence_gate.json', gate)
    return gate


def verify_retained(run, root, row):
    gate = read(run/'evidence_gate.json')
    if (gate.get('verified') is not True or gate['episode_id'] != row['episode_id']
            or gate['profile_id'] != row['profile_id']
            or gate['plan_sha256'] != sha((root/'cohort_plan.json').read_bytes())):
        raise ValueError('Retained gate does not bind the selected first attempt')
    for name, digest in gate['evidence_inputs_sha256'].items():
        path = run/name
        if path.resolve() != path.absolute() or not path.is_relative_to(run) or sha(path.read_bytes()) != digest:
            raise ValueError('Retained first-attempt evidence changed')
    return gate


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--prepare-only', action='store_true')
    parser.add_argument('--gpu', default='1'); parser.add_argument('--base-port', type=int, default=19930)
    args = parser.parse_args(); root = args.output.absolute()
    if args.prepare_only:
        plan = prepare(root, args.gpu, args.base_port)
        print(json.dumps(dict(prepared=True, pairs=49, episodes=98, model_calls=0, simulator_steps=0)), flush=True)
        return
    if os.environ.get('ROLLOUT_USE_CURRENT_CODEX_HOME') != '1':
        raise ValueError('Existing authorized runtime must be explicitly selected')
    lock = Path('/tmp/gpt-historical-worker-campaign.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    plan = verify_plan(root); (root/'episodes').mkdir(mode=0o700, exist_ok=True)
    if not (root/'admission.json').exists():
        new_json(root/'admission.json', dict(admitted_utc=utc(), plan_sha256=sha((root/'cohort_plan.json').read_bytes()),
                  authentication_copied=False, physical_retry_limit=0, original_200_episode_certificate_preserved=True))

    def interrupted(signum, frame):
        signal.signal(signum, signal.SIG_IGN)
        raise KeyboardInterrupt('Owned historical cohort interrupted')
    signal.signal(signal.SIGTERM, interrupted)
    retained = []

    def progress(phase, current=None):
        write(root/'progress.json', dict(schema='gpt_policy_historical_cohort_progress.v1', updated_utc=utc(),
            phase=phase, episodes_planned=98, first_attempts_audited=len(retained), current_episode=current,
            native_complete_audited=sum(g['status']=='native_complete_audited' for g in retained),
            statuses=dict(Counter(g['status'] for g in retained)), automatic_physical_retries=0,
            results=[{k:g.get(k) for k in ('episode_id','method','profile_id','status','native_actions','decisions',
                                        'native_success','native_score','stopped_prefix_actions')} for g in retained],
            separate_pilot_native_audited=2, historical_protocol_equivalence=False,
            full_blog_reproduction_complete=False))
    for pair in plan['pairs']:
        for row in pair['cases']:
            run = root/'episodes'/row['episode_id']; action = next_action(run)
            if action == 'retain':
                retained.append(verify_retained(run, root, row)); progress('running'); continue
            if action != 'launch':
                progress('blocked_existing_attempt_requires_review', row['episode_id'])
                raise ValueError('Existing first attempt requires evidence review; no automatic physical retry')
            progress('waiting_for_available_gpu_and_ports', row['episode_id'])
            while not available(plan):
                time.sleep(30)
            verify_plan(root)
            progress('running', row['episode_id']); execute(root, row, plan)
            try:
                retained.append(finalize(root, run, row, plan))
            except Exception as error:
                private = run/'private_audit_error.txt'; private.write_text(str(error)); private.chmod(0o600)
                progress('blocked_audit_requires_review', row['episode_id'])
                print(json.dumps(dict(event='audit_failed', episode=row['episode_id'], exception_type=type(error).__name__)), flush=True)
                raise SystemExit(1)
            progress('running')
            print(json.dumps(dict(event='first_attempt_audited', episode=row['episode_id'], status=retained[-1]['status'])), flush=True)
            if read(run/'attempt.json').get('interrupted') is True:
                progress('interrupted'); raise SystemExit(1)
            if retained[-1]['status'] in ('infrastructure_failed', 'incomplete_pending_review'):
                progress('blocked_infrastructure_requires_review', row['episode_id'])
                raise SystemExit(1)
    progress('all_first_attempts_audited')
    if (root/'completion.json').exists():
        completion = read(root/'completion.json')
        if completion.get('verified') is not True or completion['episode_gate_sha256'] != {
                g['episode_id']:sha((root/'episodes'/g['episode_id']/'evidence_gate.json').read_bytes()) for g in retained}:
            raise ValueError('Existing completion receipt differs')
        return
    new_json(root/'completion.json', dict(verified=True, completed_utc=utc(), episodes=98,
        episode_gate_sha256={g['episode_id']:sha((root/'episodes'/g['episode_id']/'evidence_gate.json').read_bytes())
                            for g in retained}, complete_native_audited=sum(g['status']=='native_complete_audited' for g in retained),
        all_first_attempts_retained=True, automatic_physical_retries=0,
        historical_protocol_equivalence=False, full_blog_reproduction_complete=False))


if __name__ == '__main__':
    main()
