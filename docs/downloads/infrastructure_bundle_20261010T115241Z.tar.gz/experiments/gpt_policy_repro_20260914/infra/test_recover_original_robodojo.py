import unittest
from recover_original_robodojo import descriptor,destination_allowed,offset_and_mode

class RecoveryBoundaryTests(unittest.TestCase):
    def test_manifest_path_binds_method_task_and_episode(self):
        row=dict(episode_id='direct__task__standard__g0__l0',case_id='task__standard__g0__l0',method='direct',task='task',files={'core':dict(path='episodes/direct/task/direct__task__standard__g0__l0.core.zip',bytes=10,sha256='a'*64)})
        self.assertEqual(descriptor(row)[1]['bytes'],10)
        row['files']['core']['path']='episodes/direct/task/../../../auth.json'
        with self.assertRaises(ValueError):descriptor(row)
        row['files']['core']['path']='episodes/hybrid/task/direct__task__standard__g0__l0.core.zip'
        with self.assertRaises(ValueError):descriptor(row)

    def test_range_requires_exact_offset_and_total(self):
        self.assertEqual(offset_and_mode(206,'bytes 50-99/100',50,100),(50,'ab'))
        self.assertEqual(offset_and_mode(200,None,50,100),(0,'wb'))
        for header in ['bytes 0-49/100','bytes 50-99/101','bytes 50-100/100',None]:
            with self.assertRaises(ValueError):offset_and_mode(206,header,50,100)

    def test_redirect_rejects_credentials_internal_hosts_and_suffix_confusion(self):
        self.assertTrue(destination_allowed('https://cas-bridge.xethub.hf.co/object?signature=opaque'))
        for url in ['http://huggingface.co/file','https://huggingface.co.evil.test/file','https://127.0.0.1/file','https://user:secret@huggingface.co/file','https://huggingface.co:8443/file']:
            self.assertFalse(destination_allowed(url))

if __name__=='__main__':unittest.main()
