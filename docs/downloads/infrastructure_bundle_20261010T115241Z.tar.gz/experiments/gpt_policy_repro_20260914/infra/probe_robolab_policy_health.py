"""Independent text-only policy connectivity; never starts an episode or RPC tool."""
from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import sys
import time

from local_robolab_runtime import LOCAL_ROOT, validate_root
from robolab_launch_guard import runtime_identity
from robolab_parallel_state import atomic_json

ARTIFACTS=Path(__file__).resolve().parents[1]
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'gpt-as-policy'))
from hybrid_rollout.robolab.skill.run import agent_config, toml_value
from hybrid_rollout.robolab.skill.transport import StdioAppServer

FORBIDDEN_ITEMS=frozenset(('commandExecution','fileChange','imageView','webSearch',
    'mcpToolCall','collabAgentToolCall','dynamicToolCall'))


def probe(workspace, binary, *, transport_factory=StdioAppServer):
    workspace.mkdir(mode=0o700);agent=workspace/'agent';agent.mkdir(mode=0o700)
    config=agent_config(workspace,agent)
    config.update({'features.shell_tool':False,'features.view_image':False,'web_search':'disabled'})
    argv=[binary,'app-server','--stdio','--strict-config']
    for key,value in config.items():argv+=['-c',key+'='+toml_value(value)]
    transport=None;start=time.monotonic()
    proof=dict(schema='gpt_policy_robolab_policy_health.v1',verified=False,
        model='gpt-6-astra',reasoning_effort='xhigh',no_simulator_calls=True,
        no_episode_actions=True,phase='initialize')
    try:
        transport=transport_factory(argv,workspace)
        transport.request('initialize',dict(clientInfo=dict(name='robolab-infrastructure-health',version='1'),
            capabilities=dict(experimentalApi=True)),180)
        transport.notify('initialized',{})
        proof['phase']='thread_start'
        response=transport.request('thread/start',dict(cwd=str(agent),model='gpt-6-astra',
            modelProvider='openai',config=dict(model_reasoning_effort='xhigh'),
            developerInstructions='Infrastructure connectivity probe. Reply READY. Do not use tools or modify files.',
            dynamicTools=[],ephemeral=True,allowProviderModelFallback=False,approvalPolicy='never',
            approvalsReviewer='auto_review',permissions='rollout_agent',runtimeWorkspaceRoots=[str(agent)]),60)
        if (response.get('model'),response.get('reasoningEffort'))!=('gpt-6-astra','xhigh'):
            raise ValueError('Pinned policy model differs')
        proof['phase']='turn'
        response=transport.request('turn/start',dict(threadId=response['thread']['id'],model='gpt-6-astra',
            effort='xhigh',approvalPolicy='never',approvalsReviewer='auto_review',permissions='rollout_agent',
            cwd=str(agent),runtimeWorkspaceRoots=[str(agent)],input=[dict(type='text',text='Reply READY.')]),30)
        turn_id=response['turn']['id'];deadline=time.monotonic()+90;answer=''
        while time.monotonic()<deadline:
            message=transport.next_message(max(.1,deadline-time.monotonic()))
            method=message.get('method');params=message.get('params',{})
            if method=='error' or ('id' in message and method):raise RuntimeError('Policy error or unexpected tool request')
            item=params.get('item',{})
            if method in ('item/started','item/completed') and item.get('type') in FORBIDDEN_ITEMS:
                raise RuntimeError('Connectivity probe must not use tools')
            if method=='item/completed' and item.get('type')=='agentMessage':answer+=item.get('text','')
            if method=='turn/completed':
                turn=params['turn']
                if turn['id']!=turn_id or turn['status']!='completed' or answer.strip()!='READY':
                    raise ValueError('Policy acknowledgement differs')
                proof.update(verified=True,phase='completed');break
        if not proof['verified']:raise TimeoutError('Policy acknowledgement timed out')
    except Exception as error:
        proof.update(error_type=type(error).__name__,error_category='policy_connection_or_protocol_failure')
    finally:
        if transport:transport.close()
    proof.update(elapsed_seconds=round(time.monotonic()-start,2),verified_utc=datetime.now(timezone.utc).isoformat())
    return proof


def main():
    with Path('/tmp/gpt-policy-robolab-policy-health.lock').open('a') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:return 0
        root=validate_root(LOCAL_ROOT);identity=runtime_identity()
        name='policy_health_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
        proof=probe(root/name,os.environ['CODEX_BIN'])
        proof.update(profile_sha256=identity[0],binary_sha256=identity[1])
        atomic_json(root/name/'proof.json',proof)
        atomic_json(ARTIFACTS/'robolab_policy_health.json',proof)
        print(json.dumps(proof),flush=True)
        return 0 if proof['verified'] else 1


if __name__=='__main__':raise SystemExit(main())
