from pathlib import Path
import tempfile
import unittest
from probe_robolab_policy_health import probe


class Transport:
    items=[]
    closed=False
    def __init__(self,*_):self.messages=iter(self.items)
    def request(self,method,params,timeout):
        if method=='thread/start':return dict(model='gpt-6-astra',reasoningEffort='xhigh',thread=dict(id='thread'))
        if method=='turn/start':return dict(turn=dict(id='turn'))
        return {}
    def notify(self,*_):pass
    def next_message(self,*_):return next(self.messages)
    def close(self):self.closed=True


def event(method,**params):return dict(method=method,params=params)


class PolicyHealthTests(unittest.TestCase):
    def run_probe(self,items):
        class Fake(Transport):pass
        Fake.items=items
        with tempfile.TemporaryDirectory() as tmp:return probe(Path(tmp)/'health','fixture',transport_factory=Fake)

    def test_real_user_message_event_is_allowed_without_any_tools(self):
        result=self.run_probe([event('item/started',item=dict(type='userMessage')),
            event('item/completed',item=dict(type='agentMessage',text='READY')),
            event('turn/completed',turn=dict(id='turn',status='completed'))])
        self.assertTrue(result['verified'])

    def test_error_or_any_tool_or_wrong_terminal_denies_readiness(self):
        for items in ([event('error')],
                      [event('item/started',item=dict(type='dynamicToolCall'))],
                      [event('item/started',item=dict(type='commandExecution'))],
                      [event('item/completed',item=dict(type='agentMessage',text='READY')),
                       event('turn/completed',turn=dict(id='foreign',status='completed'))]):
            self.assertFalse(self.run_probe(items)['verified'])


if __name__=='__main__':unittest.main()
