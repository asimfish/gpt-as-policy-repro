"""Compare recovered historical metadata with sealed, independently run episodes."""
from collections import Counter
import datetime
import hashlib
import json
from pathlib import Path

ART=Path(__file__).resolve().parents[1]
Q=ART/'publication_checks/historical_protocol_20261008'
DOCS=ART.parents[1]/'gpt-policy-report-site/docs'
METHODS={'direct':'gpt_only','hybrid':'pi05_plus_gpt'}
FIELDS=('states','eef_positions','eef_quaternions_wxyz')

def sha(data):return hashlib.sha256(data).hexdigest()
def read(path):return json.loads(path.read_bytes())

def compare_fields(original,current):
    """Equal means equal shape, dtype and bytes, not equivalent physics."""
    result={}
    for name in FIELDS:
        a,b=original[name],current[name]
        assert set(a)>=set(('shape','dtype','sha256')) and set(b)>=set(('shape','dtype','sha256'))
        result[name]=all(a[k]==b[k] for k in ('shape','dtype','sha256'))
    return result

def unique(rows,key):
    pairs=[key(r) for r in rows];assert len(pairs)==len(set(pairs)), 'Duplicate episode identity'
    return dict(zip(pairs,rows))

def summarize(rows):
    assert rows
    return dict(common_method_runs=len(rows),common_case_pairs=len({r['case_id'] for r in rows}),
        recorded_field_matches={k:sum(r['recorded_field_matches'][k] for r in rows) for k in FIELDS},
        **{k:sum(r[k] for r in rows) for k in ('layout_matches','resolved_configuration_matches',
           'native_horizon_matches','control_dt_matches','decision_cap_matches','context_version_matches',
           'teacher_prompt_hash_matches','student_identity_matches')},
        all_recorded_robot_fields_match=sum(all(r['recorded_field_matches'].values()) for r in rows))

def main():
    proof_path=Q/'original_record_recount.json';proof=read(proof_path)
    assert proof['verified'] and proof['core_archives_verified']==100 and proof['original_control_steps_verified']==80971
    current_doc=DOCS/'data/blog-comparison.json';current=read(current_doc)['reproduction_episodes']
    gate_path=ART/'full_reproduction_verification.json';gate=read(gate_path)
    assert gate_path.read_bytes()==(ART/'final_verification'/gate['published_commit']/'certificate.json').read_bytes()
    sealed=unique(gate['original_episodes'],lambda r:(r['cohort'],r['case_id'],r['method']))
    old=unique(proof['records'],lambda r:(r['case_id'],METHODS[r['method']]))
    own=unique([r for r in current if r['cohort']=='robodojo'],lambda r:(r['case_id'],r['method']))
    inputs={};rows=[];lab=[]
    def capture(path,expected=None):
        data=path.read_bytes();digest=sha(data)
        if expected is not None:assert digest==expected,str(path.relative_to(ART))
        inputs[str(path.relative_to(ART))]=digest
        return json.loads(data)
    def bound_run(r,cohort):
        root=ART/('gpt_pair_campaign' if cohort=='robodojo' else 'robolab_gpt_campaign')/r['run_id']
        if cohort=='robodojo':root=root/r['method']
        audit=capture(root/'complete_action_audit.json',sealed[cohort,r['case_id'],r['method']]['audit_sha256'])
        config=capture(root/'rollout/run.json',audit['files_sha256']['rollout/run.json'])
        return root,config
    for key in sorted(set(old)&set(own)):
        a,r=old[key],own[key];root,config=bound_run(r,'robodojo')
        finger=capture(root/'sim/initial_observation_fingerprint.json')
        resolved=capture(root/'sim/resolved_config.json')
        assert finger['fields']['states']['sha256']==config['initial_state_hash']
        assert finger['evaluation_case']['case_id']==r['case_id']
        rows.append(dict(case_id=r['case_id'],method=r['method'],run_id=r['run_id'],
            original_core_sha256=a['core_sha256'],
            recorded_field_matches=compare_fields(a['initial_recorded_fields'],finger['fields']),
            original_recorded_fields=a['initial_recorded_fields'],
            reproduction_recorded_fields={k:finger['fields'][k] for k in FIELDS},
            layout_matches=a['layout_sha256']==finger['evaluation_case']['layout_sha256'],
            resolved_configuration_matches=a['recorded_native_configuration_sha256']==sha(json.dumps(resolved,sort_keys=True).encode()),
            native_horizon_matches=a['max_episode_steps']==config['max_episode_steps'],
            control_dt_matches=a['control_dt']==config['control_dt'],
            decision_cap_matches=a['max_decisions']==config['max_decisions'],
            context_version_matches=a['context_version']==config['context_version'],
            teacher_prompt_hash_matches=a['teacher_prompt_sha256']==config['teacher_prompt_sha256'],
            original_teacher_prompt_sha256=a['teacher_prompt_sha256'],
            reproduction_teacher_prompt_sha256=config['teacher_prompt_sha256'],
            student_identity_matches=a['student_identity_sha256']==config['student_identity_sha256']))
    assert len(rows)==98 and len({r['case_id'] for r in rows})==49
    gallery_path=Q/'original_robolab_gallery.json';gallery=read(gallery_path)['cases']
    for task in sorted({r['task'] for r in current if r['cohort']=='robolab'}):
        for alias,method in [('pure_astra','gpt_only'),('astra_pi05','pi05_plus_gpt')]:
            a=[r for r in gallery if r['task']==task and r['method']==alias]
            b=[r for r in current if r['cohort']=='robolab' and r['task']==task and r['method']==method]
            assert len(a)==len(b)==5 and {r['trial'] for r in a}==set(range(5))
            assert all(r['frames']==r['steps']+1 for r in a)
            configs=[bound_run(r,'robolab')[1] for r in b]
            horizons={r['limit'] for r in a};caps={r['max_episode_steps'] for r in configs}
            assert len(horizons)==len(caps)==1
            lab.append(dict(task=task,method=method,original_control_horizon=next(iter(horizons)),
                reproduction_control_horizon=next(iter(caps)),control_horizon_matches=horizons==caps,
                original_successes=sum(r['status']=='success' for r in a),
                original_final_slots=5,original_slots_are_seed_identities=False,
                historical_per_slot_decision_caps_verified=False))
    assert len(lab)==20 and all(r['control_horizon_matches'] for r in lab)
    names=sorted({name for r in proof['records'] for name in r['normalized_frozen_source_sha256']})
    variants={name:dict(distinct_present_hashes=len({r['normalized_frozen_source_sha256'][name] for r in proof['records'] if name in r['normalized_frozen_source_sha256']}),
        records_with_file=sum(name in r['normalized_frozen_source_sha256'] for r in proof['records'])) for name in names}
    value=dict(schema='gpt_policy_recovered_historical_comparison.v1',verified=True,
        verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        native_certificate_sha256=sha(gate_path.read_bytes()),original_record_recount_sha256=sha(proof_path.read_bytes()),
        original_gallery_sha256=sha(gallery_path.read_bytes()),files_sha256=inputs,
        input_binding_scope='Audit/run SHA are bound to the original native gate; sim fingerprint/config files are separately captured here, not retroactively added to that gate.',
        robodojo=dict(summary=summarize(rows),cases=rows),robolab=dict(task_method_control_horizons=lab),
        original_frozen_source_variants=variants,historical_full_physics_state_verified=False,
        limitations=['Robot/EEF fingerprints cover recorded fields only, not complete physics state.',
          'Different joint/quaternion or prompt hashes do not alone identify the cause of outcome changes.',
          'Equal configuration/horizon does not prove identical installed runtime, model or initial scene state.',
          'RoboLab final gallery slots are not paired reset seeds or per-slot decision-cap evidence.'])
    (Q/'recovered_comparison.json').write_text(json.dumps(value,indent=2)+'\n')
    print(json.dumps(value['robodojo']['summary']))
    print(json.dumps(dict(robolab_control_horizon_matches=20,files_sha256=len(inputs),
        original_source_files=len(variants),original_source_files_with_multiple_hashes=sum(r['distinct_present_hashes']>1 for r in variants.values()))))

if __name__=='__main__':main()
