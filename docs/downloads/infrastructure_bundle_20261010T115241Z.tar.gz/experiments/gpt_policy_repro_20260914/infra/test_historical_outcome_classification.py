import unittest
from run_historical_pair import classify_outcome

class HistoricalOutcomes(unittest.TestCase):
    def test_input_limit_exit_remains_incomplete(self):
        self.assertEqual(classify_outcome(1,dict(complete=False,success=False),dict(complete=False,valid_for_success_rate=False,status='incomplete')),'controller_incomplete')
    def test_native_failure_kept_for_audit_even_if_controller_fails_afterward(self):
        self.assertEqual(classify_outcome(1,dict(complete=True,terminated=True,success=False),dict(complete=True,valid_for_success_rate=True,native_success=False)),'native_complete_pending_audit')
    def test_complete_flag_without_native_end_not_accepted(self):
        self.assertEqual(classify_outcome(0,dict(complete=True),dict(complete=True,valid_for_success_rate=True)),'incomplete_pending_review')
    def test_invalid_layout_cannot_be_scored(self):
        self.assertEqual(classify_outcome(0,dict(complete=True,truncated=True),dict(status='invalid_native_layout',complete=True,valid_for_success_rate=False)),'invalid_native_layout')
    def test_native_outcome_missing_keeps_pending(self):
        self.assertEqual(classify_outcome(0,dict(complete=True,truncated=True),{}),'incomplete_pending_review')

if __name__=='__main__':unittest.main()
