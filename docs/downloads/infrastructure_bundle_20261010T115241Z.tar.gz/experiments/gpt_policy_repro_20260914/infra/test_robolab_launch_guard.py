import json
from pathlib import Path
import socket
import tempfile
import unittest
from unittest.mock import patch
from datetime import datetime, timezone, timedelta

from robolab_launch_guard import probe_ports, health_ready, nonphysical_release


class LaunchGuardTests(unittest.TestCase):
    def test_time_wait_is_not_a_live_listener(self):
        server=socket.socket();server.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        server.bind(('127.0.0.1',0));port=server.getsockname()[1];server.listen()
        client=socket.create_connection(('127.0.0.1',port));peer,_=server.accept()
        peer.close();client.recv(1);client.close();server.close()
        probe_ports([port])

    def test_live_listener_is_denied(self):
        with socket.socket() as server:
            server.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
            server.bind(('127.0.0.1',0));server.listen()
            with self.assertRaises(OSError):probe_ports([server.getsockname()[1]])

    def health(self, **changes):
        value=dict(verified=True,model='gpt-6-astra',reasoning_effort='xhigh',
            verified_utc=datetime.now(timezone.utc).isoformat(),no_simulator_calls=True,
            no_episode_actions=True,profile_sha256='profile',binary_sha256='binary')
        value.update(changes);return value

    def test_only_fresh_exact_policy_health_authorizes_launch(self):
        self.assertTrue(health_ready(self.health(),'profile','binary'))
        for changes in (dict(verified=False),dict(model='other'),dict(reasoning_effort='high'),
                        dict(no_episode_actions=False),dict(profile_sha256='other'),
                        dict(verified_utc=(datetime.now(timezone.utc)-timedelta(minutes=16)).isoformat()),
                        dict(verified_utc=(datetime.now(timezone.utc)+timedelta(minutes=2)).isoformat()),
                        dict(verified_utc='invalid')):
            self.assertFalse(health_ready(self.health(**changes),'profile','binary'))
        self.assertFalse(health_ready(None,'profile','binary'))

    def test_nonphysical_release_never_releases_an_ambiguous_remote_launch(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);lease=dict(task='Task',seed=0,method='gpt_only',attempt='direct',slot=0,
                supervisor_identity={'pid':1})
            record=dict(task='Task',seed=0,method='gpt_only',attempt='direct',worker_slot=0,
                supervisor_identity={'pid':1},finished_utc='now',remote_launch_attempted=False)
            absent=lambda _:dict(verified=True,directory_exists=False,manager_log_exists=False,matching_service_pids=[])
            self.assertTrue(nonphysical_release(p,lease,record,remote_probe=absent,alive=lambda _:False))
            record['remote_launch_attempted']=True
            self.assertFalse(nonphysical_release(p,lease,record,remote_probe=absent,alive=lambda _:False))
            del record['remote_launch_attempted']
            self.assertFalse(nonphysical_release(p,lease,record,remote_probe=absent,alive=lambda _:False))

    def test_live_original_or_physical_artifacts_deny_release(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);lease=dict(task='Task',seed=0,method='gpt_only',attempt='direct',slot=0,supervisor_identity={'pid':1})
            record=dict(task='Task',seed=0,method='gpt_only',attempt='direct',worker_slot=0,
                supervisor_identity={'pid':1},finished_utc='now',remote_launch_attempted=False)
            absent=lambda _:dict(verified=True,directory_exists=False,manager_log_exists=False,matching_service_pids=[])
            self.assertFalse(nonphysical_release(p,lease,record,remote_probe=absent,alive=lambda _:True))
            (p/'rollout').mkdir()
            self.assertFalse(nonphysical_release(p,lease,record,remote_probe=absent,alive=lambda _:False))

    def test_any_remote_evidence_denies_release(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);lease=dict(task='Task',seed=0,method='gpt_only',attempt='direct',slot=0,supervisor_identity={'pid':1})
            record=dict(task='Task',seed=0,method='gpt_only',attempt='direct',worker_slot=0,
                supervisor_identity={'pid':1},finished_utc='now',remote_launch_attempted=False)
            for changes in (dict(directory_exists=True),dict(manager_log_exists=True),dict(matching_service_pids=[123]),dict(verified=False)):
                proof=dict(verified=True,directory_exists=False,manager_log_exists=False,matching_service_pids=[]);proof.update(changes)
                self.assertFalse(nonphysical_release(p,lease,record,remote_probe=lambda _:proof,alive=lambda _:False))

    def test_supervisor_preserves_port_failure_before_any_remote_mutation(self):
        import run_robolab_remote_v5_20261007 as supervisor
        with tempfile.TemporaryDirectory(dir=supervisor.ROOT) as tmp:
            root=Path(tmp);art=root/'artifact';(art/'fixtures').mkdir(parents=True)
            (art/'fixtures/robolab_task_files.json').write_text(json.dumps({'tasks':['BlocksInBinTask']}))
            (art/'infra/robolab_direct_skill').mkdir(parents=True)
            for name in ('archive_robolab_attempt.py','robolab_parallel_state.py','local_robolab_runtime.py',
                         'robolab_launch_guard.py','run_mainskill_robolab_services_v3_20261006.py',
                         'robolab_direct_tools.py','run_robolab_direct_controller.py','trace_robolab_rpc.py'):
                (art/'infra'/name).write_text('# test fixture\n')
            workspace=root/'runtime';workspace.mkdir()
            attempt='direct_20261007T000000Z_BlocksInBinTask_seed0'
            args=['supervisor','--worker-slot','0','--attempt',attempt,'--task','BlocksInBinTask',
                  '--method','gpt_only','--sim-port','20700','--policy-port','20710']
            with patch.object(supervisor,'ARTIFACTS',art),patch.object(supervisor,'validate_root',return_value=workspace),\
                 patch.object(supervisor.sys,'argv',args),patch.object(supervisor,'probe_ports',side_effect=OSError(98,'occupied')),\
                 patch.object(supervisor,'remote') as remote,patch.object(supervisor.subprocess,'run') as spawn:
                self.assertEqual(supervisor.main(),1)
                remote.assert_not_called();spawn.assert_not_called()
            record=json.loads((art/'robolab_gpt_campaign'/attempt/'attempt.json').read_text())
            self.assertFalse(record['remote_launch_attempted']);self.assertFalse(record['completed'])
            self.assertEqual(record['status'],'startup_failed_before_remote_launch')
            self.assertIn('finished_utc',record)


if __name__=='__main__':unittest.main()
