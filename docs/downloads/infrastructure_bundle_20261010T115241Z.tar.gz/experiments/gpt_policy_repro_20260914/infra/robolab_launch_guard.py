"""Pre-physics readiness and proven nonphysical failure release; no RPC replay."""
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import socket
import stat

from robolab_parallel_state import identity_alive, reconcile
from transfer_checkpoint_chunks import remote


def probe_ports(ports):
    for port in ports:
        with socket.socket() as sock:
            # Stopped SSH connections can retain TIME_WAIT. A live listener still
            # rejects this bind; SO_REUSEPORT is deliberately never enabled.
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind(('127.0.0.1', port))


def runtime_identity():
    home=Path(os.environ['CODEX_HOME']).resolve()
    binary=Path(os.environ['CODEX_BIN']).resolve()
    return hashlib.sha256(str(home).encode()).hexdigest(), hashlib.sha256(binary.read_bytes()).hexdigest()


def health_ready(proof, profile_sha256, binary_sha256, *, now=None):
    try:
        if not isinstance(proof,dict):return False
        stamp=datetime.fromisoformat(proof['verified_utc'])
        age=((now or datetime.now(timezone.utc))-stamp).total_seconds()
        return (proof.get('verified') is True and proof.get('model')=='gpt-6-astra'
            and proof.get('reasoning_effort')=='xhigh' and proof.get('no_simulator_calls') is True
            and proof.get('no_episode_actions') is True and proof.get('profile_sha256')==profile_sha256
            and proof.get('binary_sha256')==binary_sha256 and 0<=age<=900)
    except (KeyError,ValueError,TypeError):return False


REMOTE_ABSENCE='''import json,pathlib,sys,os
root=pathlib.Path(sys.argv[1]);name=root.name;pids=[]
for p in pathlib.Path('/proc').iterdir():
 if not p.name.isdecimal():continue
 if int(p.name)==os.getpid():continue
 try:argv=[a.decode(errors='replace') for a in (p/'cmdline').read_bytes().split(b'\\0') if a]
 except (FileNotFoundError,ProcessLookupError,PermissionError):continue
 # Exact argument matching excludes this read-only -c probe and its SSH parent.
 if name in argv or str(root) in argv:pids.append(int(p.name))
print(json.dumps(dict(verified=True,directory_exists=root.exists() or root.is_symlink(),
 manager_log_exists=(root.parent/(name+'.manager.log')).exists(),matching_service_pids=pids)))
'''


def remote_absence(record):
    return json.loads(remote(REMOTE_ABSENCE,(record['remote_output'],),timeout=30))


def absent(proof):
    return (proof.get('verified') is True and proof.get('directory_exists') is False
        and proof.get('manager_log_exists') is False and proof.get('matching_service_pids')==[])


def nonphysical_release(path, lease, record, *, remote_probe=remote_absence, alive=identity_alive):
    if not record or record.get('remote_launch_attempted') is not False or not record.get('finished_utc'):
        return False
    expected=tuple(lease.get(k) for k in ('task','seed','method','attempt','slot'))
    if tuple(record.get(k) for k in ('task','seed','method','attempt','worker_slot'))!=expected:
        return False
    if record.get('supervisor_identity')!=lease.get('supervisor_identity') or not lease.get('supervisor_identity'):
        return False
    if alive(lease['supervisor_identity']) or any(record.get(k) for k in ('remote_manager_pid','controller_pid','tunnel_pid')):
        return False
    path=Path(path)
    if any((path/n).exists() or (path/n).is_symlink() for n in ('rollout','remote','remote_services.json','controller.log','tunnel.log')):
        return False
    return absent(remote_probe(record))


def reconcile_guarded(path, lease, record, *, allowed_sources):
    status=reconcile(lease,record)
    if status!='blocked_cleanup_unproven' or not record or record.get('remote_launch_attempted') is not False:
        return status
    # Only a reviewed supervisor snapshot or the evidence-bound recovery of a
    # reviewed pre-output failure may establish that no SSH launch was invoked.
    bindings=record.get('controller_source_sha256',{})
    bound=False
    for relative,sha in bindings.items():
        if Path(relative).name not in allowed_sources or allowed_sources[Path(relative).name]!=sha:continue
        snapshot=Path(path)/'source_snapshot'/relative
        if snapshot.is_file() and not snapshot.is_symlink() and hashlib.sha256(snapshot.read_bytes()).hexdigest()==sha:
            bound=True
    if not bound:return status
    proof_path=Path(path)/'startup_recovery.json'
    if record.get('metadata_reconstructed'):
        if (not proof_path.is_file() or proof_path.is_symlink()
            or hashlib.sha256(proof_path.read_bytes()).hexdigest()!=record.get('startup_recovery_sha256')):return status
        proof=json.loads(proof_path.read_text())
        if not proof.get('verified') or proof.get('lease')!=lease or not absent(proof.get('fresh_remote_absence',{})):return status
    fd=os.open(f"/tmp/gpt-policy-robolab-controller-slot{lease['slot']}.lock",os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'a') as lock:
        info=os.fstat(lock.fileno())
        if info.st_uid!=os.getuid() or not stat.S_ISREG(info.st_mode):raise ValueError('Owned regular slot lock required')
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:return status
        if nonphysical_release(path,lease,record):return 'released'
    return status
