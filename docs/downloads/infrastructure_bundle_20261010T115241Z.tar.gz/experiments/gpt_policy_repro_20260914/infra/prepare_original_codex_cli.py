"""Install an isolated official CLI pin without npm hooks or touching existing login."""
import base64,datetime,hashlib,json,os,stat,subprocess,tarfile,urllib.request
from pathlib import Path,PurePosixPath
from urllib.parse import urlsplit

ART=Path(__file__).resolve().parents[1]
OUT=ART/'publication_checks/worker_fidelity_20261008'
DEST=ART/'toolchains/codex_cli_0_153_4'
NODE=Path('/home/liyufeng/.nvm/versions/node/v22.22.2/bin/node')
SPECS=[('0.153.4','codex'),('0.153.4-linux-x64','codex-linux-x64')]

def safe_members(tar):
    members=tar.getmembers();names=[m.name for m in members]
    if len(names)!=len(set(names)) or len(names)>64:raise ValueError('Duplicate or excessive package members')
    if sum(m.size for m in members)>512*1024**2:raise ValueError('Package exceeds decompression budget')
    for m in members:
        p=PurePosixPath(m.name)
        if not p.parts or p.is_absolute() or '..' in p.parts or '\\' in m.name or ':' in m.name or p.parts[0]!='package':
            raise ValueError('Invalid package path')
        if not(m.isdir() or m.isfile()) or m.mode&(stat.S_ISUID|stat.S_ISGID):raise ValueError('Unsupported package member')
        if m.size<0 or m.size>350*1024**2:raise ValueError('Package member exceeds budget')
    return members

def verify_extracted_package(archive,target,version):
    """On reuse, trust archive-verified bytes, never an existing executable's version."""
    if target.is_symlink() or target.resolve()!=target.absolute():raise ValueError('Package destination contains a symlink')
    expected={}
    with tarfile.open(archive) as tar:
        for m in safe_members(tar):
            if not m.isfile():continue
            relative=PurePosixPath(m.name).relative_to('package')
            if not relative.parts:raise ValueError('Package root cannot be a file')
            expected[str(relative)]=hashlib.sha256(tar.extractfile(m).read()).hexdigest()
    actual={}
    for path in target.rglob('*'):
        if path.is_symlink():raise ValueError('Extracted package contains a symlink')
        if path.is_file():actual[str(path.relative_to(target))]=hashlib.sha256(path.read_bytes()).hexdigest()
        elif not path.is_dir():raise ValueError('Extracted package contains a special file')
    if actual!=expected:raise ValueError('Extracted package differs from verified tarball')
    pkg=json.loads((target/'package.json').read_text())
    if pkg['name']!='@openai/codex' or pkg['version']!=version or pkg.get('scripts'):
        raise ValueError('Unexpected extracted package metadata')
    return actual

def check_tarball_url(url,version):
    p=urlsplit(url)
    if p.scheme!='https' or p.netloc!='registry.npmjs.org' or p.query or p.fragment or p.path!='/@openai/codex/-/codex-'+version+'.tgz':
        raise ValueError('Unexpected package tarball URL')

def main():
    OUT.mkdir(exist_ok=True);DEST.mkdir(parents=True,exist_ok=True);receipts=[]
    for version,name in SPECS:
        url='https://registry.npmjs.org/@openai%2Fcodex/'+version
        with urllib.request.urlopen(url,timeout=30) as response:metadata=json.load(response)
        assert metadata['name']=='@openai/codex' and metadata['version']==version and not metadata.get('scripts')
        assert metadata['license']=='Apache-2.0'
        dist=metadata['dist'];check_tarball_url(dist['tarball'],version)
        integrity=dist['integrity'];algorithm,expected=integrity.split('-',1);assert algorithm=='sha512'
        archive=DEST/(name+'-'+version+'.tgz')
        if not archive.exists():
            partial=archive.with_suffix('.tgz.part');size=0
            with urllib.request.urlopen(dist['tarball'],timeout=60) as response,partial.open('xb') as stream:
                assert response.url==dist['tarball']
                while True:
                    block=response.read(1024**2)
                    if not block:break
                    size+=len(block);assert size<=350*1024**2;stream.write(block)
            assert base64.b64encode(hashlib.sha512(partial.read_bytes()).digest()).decode()==expected
            partial.rename(archive)
        data=archive.read_bytes();assert base64.b64encode(hashlib.sha512(data).digest()).decode()==expected
        target=DEST/'node_modules/@openai'/name
        if not target.exists():
            stage=target.with_name(name+'.stage');assert not stage.exists();stage.mkdir(parents=True)
            with tarfile.open(archive) as tar:
                members=safe_members(tar)
                for m in members:
                    relative=PurePosixPath(m.name).relative_to('package');path=stage/relative
                    if m.isdir():path.mkdir(parents=True,exist_ok=True);continue
                    path.parent.mkdir(parents=True,exist_ok=True)
                    with path.open('xb') as stream:stream.write(tar.extractfile(m).read())
                    path.chmod(0o755 if m.mode&0o111 else 0o644)
            pkg=json.loads((stage/'package.json').read_text());assert pkg['version']==version and not pkg.get('scripts')
            stage.rename(target)
        verified_files=verify_extracted_package(archive,target,version)
        files={str(target.relative_to(DEST)/name):digest for name,digest in sorted(verified_files.items())}
        receipts.append(dict(version=version,registry_url=url,tarball_url=dist['tarball'],tarball_sha256=hashlib.sha256(data).hexdigest(),
            tarball_bytes=len(data),integrity=integrity,integrity_verified=True,license=metadata['license'],files_sha256=files))
    cli=DEST/'node_modules/@openai/codex/bin/codex.js'
    response=subprocess.run([str(NODE),str(cli),'--version'],capture_output=True,text=True,timeout=30,check=True)
    assert response.stdout.strip()=='codex-cli 0.153.4'
    launcher=DEST/'codex';content='#!/usr/bin/env bash\nset -euo pipefail\nexec '+str(NODE)+' '+str(cli)+' "$@"\n'
    if launcher.exists():assert launcher.read_text()==content
    else:launcher.write_text(content);launcher.chmod(0o755)
    proof=dict(schema='gpt_policy_isolated_original_cli.v1',verified=True,verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        version=response.stdout.strip(),launcher=str(launcher.relative_to(ART)),launcher_sha256=hashlib.sha256(launcher.read_bytes()).hexdigest(),
        packages=receipts,global_cli_replaced=False,authentication_copied=False,model_calls=0,
        provenance_scope='Official npm release metadata and SHA512 SRI verified. Registry signatures/attestations are captured by the source metadata, not independently signature-verified here.')
    (OUT/'original_cli_toolchain.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({k:v for k,v in proof.items() if k!='packages'}),flush=True)

if __name__=='__main__':main()
