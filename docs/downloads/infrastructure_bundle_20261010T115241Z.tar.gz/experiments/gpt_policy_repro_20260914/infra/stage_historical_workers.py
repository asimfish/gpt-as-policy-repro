"""Reconstruct reviewed, immutable historical source profiles in a separate tree.

Staging never imports the downloaded Python, starts a model, or resets a simulator.
The only added code bridges an absent gateway-settings module to the current
authorized runtime; that explicit limitation is carried into every manifest.
"""
import ast
from collections import Counter
import datetime
import hashlib
import json
import re
import stat
import zipfile
from pathlib import Path, PurePosixPath
from inspect_historical_worker_protocol import rejection_stop
from verify_original_robodojo_records import checked_zip

ART=Path(__file__).resolve().parents[1]
Q=ART/'publication_checks/worker_fidelity_20261008'
RECOUNT=ART/'publication_checks/historical_protocol_20261008/original_record_recount.json'
DEST=ART/'fixtures/historical_worker_profiles'
SOURCE_ROOT=ART.parents[1]/'gpt-as-policy'
RECOUNT_SHA='711c0bc1d4d2978bb49143a83cf027ea6a1f38516250ee4fa6cf335118c4b779'
REVIEWED_PROFILES=frozenset(('3486581698d536d5708eeee0980553ccd2f12374468f00d69dae7604aa139e95',
 '4bed06723c034bb0397ead2e064eefe62dd9576c756f32fa30ae5b76498b7464',
 'a6df3c7605db25b267362bb5edea0306024d9522837ad8787f614c7698cc8bb4',
 '840372bd4b10fe0bba0eb46a08112374dae46c1ebca49ed561ee893f11f7cfe3',
 '96bfcedebf9afd4aafdc488dd9496408151c7a2b249af08093f2dcbc87a1c37c'))
BRIDGE={
 'codex_backend/__init__.py':b'"""Explicit current-runtime bridge, absent from original frozen source."""\n',
 'codex_backend/profiles.py':b'"""Reuse authorized runtime settings; do not copy login or claim service parity."""\nfrom hybrid_rollout.robodojo.codex_backend.profiles import profile\n'}

def sha(data):return hashlib.sha256(data).hexdigest()
def profile_id(files):return sha(json.dumps(files,sort_keys=True).encode())

def checked_relative(name):
    p=PurePosixPath(name)
    if not p.parts or p.is_absolute() or '..' in p.parts or '\\' in name or ':' in name or str(p)!=name:
        raise ValueError('Noncanonical source path')
    if p.suffix not in ('.py','.sh','.md'):raise ValueError('Unexpected source extension')
    return p

def verify_tree(root,files):
    if root.is_symlink() or root.resolve()!=root.absolute():raise ValueError('Source tree path contains a symlink')
    actual={}
    for path in root.rglob('*'):
        if path.is_symlink():raise ValueError('Source tree contains a symlink')
        if path.is_file():actual[str(path.relative_to(root))]=sha(path.read_bytes())
        elif not path.is_dir():raise ValueError('Source tree contains a special file')
    if actual!=files:raise ValueError('Source tree differs from reviewed manifest')

def stage_profile(record):
    files=record['normalized_frozen_source_sha256'];pid=profile_id(files)
    if pid not in REVIEWED_PROFILES or not 41<=len(files)<=42:raise ValueError('Unreviewed source profile')
    worker=files['skill/run.py'];cap=rejection_stop(worker)
    archive=ART/'original_public_rollouts/astra_robodojo_bf8d15ea/core'/(record['episode_id']+'.core.zip')
    if sha(archive.read_bytes())!=record['core_sha256']:raise ValueError('Representative archive SHA changed')
    source={}
    with zipfile.ZipFile(archive) as z:
        checked_zip(z)
        available={n.removeprefix('frozen_control_source/') for n in z.namelist() if n.startswith('frozen_control_source/')}
        if available!=set(files):raise ValueError('Frozen file inventory changed')
        for name,digest in files.items():
            checked_relative(name);data=z.read('frozen_control_source/'+name)
            if len(data)>256*1024 or sha(data)!=digest:raise ValueError('Frozen source identity changed')
            if name.endswith('.py'):ast.parse(data,filename=name)
            source[name]=data
    if set(source)&set(BRIDGE):raise ValueError('Bridge would overwrite historical source')
    expected={**files,**{name:sha(data) for name,data in BRIDGE.items()}}
    root=DEST/pid/'historical_robodojo'
    if not root.exists():
        stage=root.parent.with_name(pid+'.stage')
        stage.mkdir(parents=True,exist_ok=False)
        package=stage/'historical_robodojo';package.mkdir()
        for name,data in {**source,**BRIDGE}.items():
            path=package/checked_relative(name);path.parent.mkdir(parents=True,exist_ok=True)
            with path.open('xb') as stream:stream.write(data)
            path.chmod(0o444)
        verify_tree(package,expected)
        for path in sorted(package.rglob('*'),reverse=True):
            if path.is_dir():path.chmod(0o555)
        package.chmod(0o555);stage.rename(root.parent)
    verify_tree(root,expected)
    run=source['skill/run.py'].decode()
    return dict(profile_id=pid,package_root=str(root.relative_to(ART)),representative_episode=record['episode_id'],
        representative_core_sha256=record['core_sha256'],frozen_files_sha256=files,
        added_runtime_bridge_sha256={name:sha(data) for name,data in BRIDGE.items()},
        cumulative_input_rejection_stop=cap,same_thread_network_continue_supported='def _network_continue(' in run,
        controller_source_sha256=worker,original_source_bytes_unchanged=True)

def main():
    raw=RECOUNT.read_bytes()
    if sha(raw)!=RECOUNT_SHA:raise ValueError('Original recount identity changed')
    recount=json.loads(raw);records=recount['records']
    if recount['verified'] is not True or len(records)!=100:raise ValueError('Original records incomplete')
    Q.mkdir(exist_ok=True);DEST.mkdir(parents=True,exist_ok=True)
    representatives={profile_id(r['normalized_frozen_source_sha256']):r for r in reversed(records)}
    if set(representatives)!=REVIEWED_PROFILES:raise ValueError('Historical profile selection changed')
    profiles=[stage_profile(representatives[pid]) for pid in sorted(representatives)]
    cases=[]
    for r in records:
        if not re.fullmatch(r'[a-z0-9_]+',r['episode_id']):raise ValueError('Unexpected episode identity')
        with zipfile.ZipFile(ART/'original_public_rollouts/astra_robodojo_bf8d15ea/core'/(r['episode_id']+'.core.zip')) as z:
            checked_zip(z);episode=json.loads(z.read('episode.json'));case=episode['case'];worker=episode['worker']
        if case['case_id']!=r['case_id'] or worker['codex_version']!='codex-cli 0.153.4':raise ValueError('Original case/CLI identity changed')
        if episode['method']!=r['method']:raise ValueError('Original method identity changed')
        method={'direct':'gpt_only','hybrid':'pi05_plus_gpt'}[episode['method']]
        if episode['run'].get('evaluation_method',method)!=method:raise ValueError('Conflicting original run method')
        cases.append(dict(episode_id=r['episode_id'],case_id=r['case_id'],method=method,
            profile_id=profile_id(r['normalized_frozen_source_sha256']),core_sha256=r['core_sha256'],
            runtime_task=case['runtime_task'],variant=case['variant'],eval_seed=case['eval_seed'],layout_id=case['layout_id'],
            reset_seed=case['reset_seed'],simulator_initial_seed=case['simulator_initial_seed'],policy_rng_seed=case['policy_rng_seed'],
            layout=case['layout'],native_support_trajectories=case.get('native_support_trajectories',[]),
            max_episode_steps=r['max_episode_steps'],control_dt=r['control_dt'],max_decisions=r['max_decisions'],
            context_version=r['context_version'],student_identity_sha256=r['student_identity_sha256'],
            original_native_complete=r['native_complete']))
    toolchain=json.loads((Q/'original_cli_toolchain.json').read_text())
    if toolchain['verified'] is not True or toolchain['version']!='codex-cli 0.153.4':raise ValueError('Original CLI not prepared')
    bridge_backend=SOURCE_ROOT/'hybrid_rollout/robodojo/codex_backend/profiles.py'
    manifest=dict(schema='gpt_policy_historical_worker_reconstruction.v1',verified=True,
        verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),original_record_recount_sha256=RECOUNT_SHA,
        source_profiles=profiles,cases=cases,profile_case_counts=dict(Counter(r['profile_id'] for r in cases)),
        cli=dict(version=toolchain['version'],launcher=toolchain['launcher'],launcher_sha256=toolchain['launcher_sha256'],
            toolchain_receipt_sha256=sha((Q/'original_cli_toolchain.json').read_bytes())),
        current_gateway_bridge=dict(backend_sha256=sha(bridge_backend.read_bytes()),configuration_values_published=False,
            original_gateway_source_recovered=False,original_model_service_snapshot_recovered=False),
        source_execution_performed=False,model_calls=0,simulator_steps=0,
        historical_protocol_equivalence=False,full_blog_reproduction_complete=False,
        scope='Exact historical source profiles (41 or 42 files) and original CLI pin; explicit current authorized gateway bridge. '
            'A fresh run cannot establish hidden physics, original service state, or selected-attempt parity.')
    (Q/'historical_worker_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps(dict(verified=True,source_profiles=len(profiles),historical_cases=len(cases),model_calls=0,simulator_steps=0)),flush=True)

if __name__=='__main__':main()
