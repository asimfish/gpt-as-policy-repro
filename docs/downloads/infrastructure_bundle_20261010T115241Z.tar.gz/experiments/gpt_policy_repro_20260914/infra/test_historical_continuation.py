"""Continuation must not replay claims or admit stale/foreign model availability."""
import datetime
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from continue_historical_cohort import validate_probe, capacity_errors, retained_prefix, finalize_first_attempt


class HistoricalContinuationTests(unittest.TestCase):
    def probe(self):
        now = datetime.datetime.now(datetime.timezone.utc)
        plan = dict(model='gpt-6-astra', reasoning_effort='xhigh', cli_version='codex-cli 0.153.4',
                    receipt_sha256={'historical_worker_manifest.json':'m'})
        proof = dict(verified=True, checked_utc=now.isoformat(), model_available=True,
                     model=plan['model'], reasoning_effort=plan['reasoning_effort'], cli_version=plan['cli_version'],
                     turn_status='completed', reply_exact_ok=True, model_turn_start_calls=1,
                     service_tools_registered=0, simulator_steps=0, authentication_copied=False,
                     manifest_sha256='m')
        return proof, plan, now

    def test_current_same_model_probe_can_admit_even_if_unrelated_bucket_is_full(self):
        proof, plan, now = self.probe()
        proof['rate_limits']=[dict(limit_id='codex',windows={'primary':{'usedPercent':100}})]
        validate_probe(proof, plan, now)

    def test_stale_future_wrong_model_and_nonexecution_probes_are_denied(self):
        for changes in ({'checked_utc':'2026-01-01T00:00:00+00:00'}, {'checked_utc':'2030-01-01T00:00:00+00:00'},
                        {'model':'different'}, {'model_available':None}, {'model_turn_start_calls':0},
                        {'service_tools_registered':1}, {'authentication_copied':True},
                        {'manifest_sha256':'different'}, {'error_code':'usageLimitExceeded'}):
            with self.subTest(changes=changes):
                proof,plan,now=self.probe();proof.update(changes)
                with self.assertRaises(ValueError):validate_probe(proof,plan,now)

    def test_capacity_errors_are_bound_to_worker_thread_and_terminal_retry_state(self):
        with tempfile.TemporaryDirectory() as temporary:
            run=Path(temporary);workspace=run/'rollout/codex_workspace';workspace.mkdir(parents=True)
            (workspace/'worker.json').write_text(json.dumps({'thread_id':'own'}))
            events=[dict(method='error',params=dict(threadId='foreign',willRetry=False,error={'codexErrorInfo':'rateLimitExceeded'})),
                    dict(method='error',params=dict(threadId='own',willRetry=True,error={'codexErrorInfo':'rateLimitExceeded'})),
                    dict(method='error',params=dict(threadId='own',willRetry=False,error={'codexErrorInfo':'usageLimitExceeded'})),
                    dict(method='turn/completed',params=dict(threadId='own',turn=dict(status='failed',error={'codexErrorInfo':'usageLimitExceeded'})))]
            (workspace/'rpc_out.jsonl').write_text(''.join(json.dumps(e)+'\n' for e in events))
            self.assertEqual(capacity_errors(run),['usageLimitExceeded'])

    def test_verified_prefix_retained_and_only_unclaimed_rows_selected(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary);row1=dict(episode_id='one');row2=dict(episode_id='two')
            plan={'pairs':[{'cases':[row1,row2]}]};gate={'episode_id':'one','status':'startup_failed_no_execution'}
            with patch('continue_historical_cohort.original.next_action',side_effect=['retain','launch']), \
                 patch('continue_historical_cohort.original.verify_retained',return_value=gate) as verify:
                retained,pending=retained_prefix(root,plan)
                self.assertEqual(retained,[gate]);self.assertEqual(pending,[row2]);verify.assert_called_once()

    def test_unreviewed_claim_or_out_of_order_gate_stops_before_execution(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary);plan={'pairs':[{'cases':[dict(episode_id='one'),dict(episode_id='two')]}]}
            for actions in (['review_stopped_attempt'],['launch','retain']):
                with patch('continue_historical_cohort.original.next_action',side_effect=actions):
                    with self.assertRaises(ValueError):retained_prefix(root,plan)

    def test_existing_gate_never_replaced_or_regular_auditor_replayed(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary);(root/'evidence_gate.json').write_text('{"verified":true}')
            with patch('continue_historical_cohort.original.finalize') as regular:
                with self.assertRaises(ValueError):finalize_first_attempt(root,root,{}, {})
                regular.assert_not_called()

    def test_started_episode_keeps_regular_audit(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary);(root/'rollout').mkdir();(root/'rollout/run.json').write_text('{}')
            with patch('continue_historical_cohort.original.finalize',return_value={'verified':True}) as regular, \
                 patch('continue_historical_cohort.audit_startup_failure') as startup:
                self.assertEqual(finalize_first_attempt(root,root,{},{}),{'verified':True})
                regular.assert_called_once();startup.assert_not_called()


if __name__=='__main__':unittest.main()
