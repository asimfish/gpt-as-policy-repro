"""Evidence-bound recovery of three v4 port-bind exits before output creation."""
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat

from local_robolab_runtime import LOCAL_ROOT, validate_root
from robolab_launch_guard import remote_absence, absent
from robolab_parallel_state import identity_alive, atomic_json

ARTIFACTS=Path(__file__).resolve().parents[1]
ROOT=Path(__file__).resolve().parents[3]
EVIDENCE=ARTIFACTS/'publication_checks/launch_recovery_20261007'
ATTEMPTS=frozenset(('hybrid_20261006T155253Z_YogurtInBowlTask_seed3',
    'hybrid_20261006T155541Z_YogurtInBowlTask_seed4','hybrid_20261006T163900Z_RubiksCubeTask_seed2'))


def require(value, message):
    if not value:raise ValueError(message)


def main():
    validate_root(LOCAL_ROOT)
    initial=json.loads((EVIDENCE/'robolab_gpt_parallel_leases.json').read_text())['leases']
    require({row['attempt'] for row in initial}==ATTEMPTS,'Only the three witnessed pre-output exits are recoverable')
    manifest=json.loads((ARTIFACTS/'robolab_queue_scheduler_v4_manifest.json').read_text())
    source=ARTIFACTS/'infra/run_robolab_remote_v4_20261006.py'
    sha=hashlib.sha256(source.read_bytes()).hexdigest()
    require(sha==manifest['files_sha256'][source.name], 'Original supervisor source differs')
    require(sha==json.loads((EVIDENCE/'initial_sources.json').read_text())[source.name], 'Initial source witness differs')
    frozen=json.loads((ARTIFACTS/'fixtures/robolab_two_methods_frozen.json').read_text())
    require(hashlib.sha256((ARTIFACTS/'fixtures/robolab_two_methods_frozen.json').read_bytes()).hexdigest()==manifest['frozen_sha256'], 'Frozen identities differ')
    results=[]
    for lease in initial:
        current=json.loads((ARTIFACTS/'robolab_gpt_parallel_leases.json').read_text())['leases']
        require(lease in current,'Original reserved process or identity changed')
        require(any(tuple(r[k] for k in ('task','seed','method'))==tuple(lease[k] for k in ('task','seed','method')) for r in frozen['entries']),'Foreign task identity')
        path=ARTIFACTS/'robolab_gpt_campaign'/lease['attempt']
        if path.exists():
            record=json.loads((path/'attempt.json').read_text())
            require(record.get('metadata_reconstructed') is True and record.get('startup_recovery_sha256')==hashlib.sha256((path/'startup_recovery.json').read_bytes()).hexdigest(),'Preserve any existing original attempt')
            results.append(dict(attempt=lease['attempt'],status='already_recorded'));continue
        require(not path.is_symlink(),'Output path is a link')
        require(not identity_alive(lease['supervisor_identity']), 'Original supervisor remains alive')
        workspace=LOCAL_ROOT/('gpt-policy-robolab-'+lease['attempt'])
        require(not workspace.exists() and not workspace.is_symlink(),'Original workspace exists; investigate its evidence')
        fd=os.open(f"/tmp/gpt-policy-robolab-controller-slot{lease['slot']}.lock",os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW,0o600)
        with os.fdopen(fd,'a') as lock:
            require(os.fstat(lock.fileno()).st_uid==os.getuid() and stat.S_ISREG(os.fstat(lock.fileno()).st_mode),'Owned regular lock required')
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            record=dict(schema='gpt_policy_robolab_attempt.v1',attempt=lease['attempt'],
                task=lease['task'],seed=lease['seed'],method=lease['method'],worker_slot=lease['slot'],
                supervisor_identity=lease['supervisor_identity'],local_workspace=str(workspace),
                remote_output='/home/dataset-assist-0/liyufeng/agentic_robot/experiments/gpt_policy_repro_20260914/robolab_gpt_campaign/'+lease['attempt'],
                status='startup_failed_before_remote_launch',completed=False,metadata_reconstructed=True,
                started_utc=lease['reserved_utc'],finished_utc=datetime.now(timezone.utc).isoformat(),
                remote_launch_attempted=False,remote_archive_verified=False,
                remote_launch_attempted_evidence='Pinned v4 binds ports before creating output/workspace and before any SSH launch; both directories absent; fresh remote absence verified',
                error='Original v4 local port bind exited before metadata creation; queue traceback errno98',
                controller_source_sha256={str(source.relative_to(ROOT)):sha})
            fresh=remote_absence(record);require(absent(fresh),'Remote launch cannot be excluded')
            require(not identity_alive(lease['supervisor_identity']) and not path.exists() and not workspace.exists(),'Original state changed during probe')
            proof=dict(schema='gpt_policy_robolab_preoutput_recovery.v1',verified=True,
                lease=lease,supervisor_source_sha256=sha,fresh_remote_absence=fresh,
                verified_utc=record['finished_utc'],no_model_or_simulator_calls=True,no_lease_mutation=True,
                no_native_results_modified=True,metadata_is_reconstructed=True,
                initial_lease_snapshot_sha256=hashlib.sha256((EVIDENCE/'robolab_gpt_parallel_leases.json').read_bytes()).hexdigest())
            staging=ARTIFACTS/'startup_recovery_staging'/lease['attempt']
            staging.mkdir(parents=True,exist_ok=True)
            snapshot=staging/'source_snapshot'/source.relative_to(ROOT);snapshot.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(source,snapshot);atomic_json(staging/'startup_recovery.json',proof)
            record['startup_recovery_sha256']=hashlib.sha256((staging/'startup_recovery.json').read_bytes()).hexdigest()
            atomic_json(staging/'attempt.json',record)
            require(not path.exists(),'Preserve concurrently created output')
            staging.rename(path)
            results.append(dict(attempt=lease['attempt'],status='recorded_nonphysical_failure',proof_sha256=record['startup_recovery_sha256']))
    atomic_json(EVIDENCE/'preoutput_recovery.json',dict(verified=True,results=results,no_lease_mutation=True,
        no_model_or_simulator_calls=True,no_native_results_modified=True))
    print(json.dumps(results),flush=True)


if __name__=='__main__':main()
