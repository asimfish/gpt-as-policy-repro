#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/env.sh"
export ROLLOUT_AUTH_PROFILE=codex_a
export PYTHONDONTWRITEBYTECODE=1
export PATH="$(dirname "$ROBO_PYTHON"):$PATH"
exec "$ROBO_PYTHON" "$(dirname "$0")/run_historical_cohort.py" "$@"
