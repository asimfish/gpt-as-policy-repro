# Historical worker reconstruction, 2026-10-08

The user requires full reproduction of the original blog. The completed native
200-case cohort and its sealed certificate remain immutable. This next cohort
will use the original selected RoboDojo controller source profile and Codex CLI
0.153.4, instead of silently changing the completed experiments.

The 100 SHA-verified public core archives contain 41 or 42 frozen source files per
episode (42 paths in their union). There are five complete file profiles, four `skill/run.py` versions, and
54 unique file bodies. The profiles are explicitly allowlisted by the SHA-256 of
their sorted file-hash maps. Exact original bytes are reconstructed into a
separate read-only tree; source staging itself does not import or execute them.

Static review compared Python syntax trees and inspected changed code. Three
legacy worker versions stop after five cumulative `InputError` rejections. The
newer version provides enhanced correction feedback without that stop. Two
legacy versions support same-thread network continuation, and one does not.
Malformed JSON is fatal in legacy versions. The hybrid snapshots' older Direct
joint-action branch is unused in hybrid evaluation. Recorded action validators,
kinematics, session, client, context and configuration source match the current
copies. Other changed files govern panel selection, atomic JSON writes, or video
presentation. The old fixed temporary filename writer is exercised only in a
private single-writer workspace; it is not substituted into shared publishers.

The original settings module imports a gateway profile module that the public
archives do not contain. Two separately hashed adapter files bridge this import
to the existing authorized current runtime. No original source file is edited.
No login is copied, no credential values are included in receipts, and the
original model service snapshot remains unrecovered. This adapter is a declared
limitation, not evidence of historical backend equivalence.

The official CLI wrapper and Linux binary are installed in an isolated directory
from exact npm release artifacts. SHA-512 SRI is verified before extraction;
links, path traversal, special files and excessive allocation are rejected.
Reused executable files must match the verified tarball inventory. No npm hooks,
global replacement, account change or authentication copy is permitted. Registry
signature verification is not claimed.

Reviewed original Python may now be imported only after profile identity checks,
for bounded offline protocol tests and a zero-model app-server compatibility
probe. Tests use synthetic public events in private local workspaces. They must
prove cumulative rejection stopping, malformed-input behavior, active tool
schemas, wrong-thread rejection and network-continuation branching. The
compatibility probe may initialize and create a thread but must never issue
`turn/start`; its separate SQLite state and logs stay on a local filesystem.
Raw RPC output and stderr remain private and are never included in publication.

A live experiment is a later, separately admitted step. Its exact source/CLI,
case layout, reset and simulator seeds, student identity, native horizon,
decision bound, image size, context and endpoints must be recorded. Every first
attempt is retained; input-limit exits are incomplete controller outcomes,
not fabricated native failures. The original layout-4 validation discrepancy
is retained explicitly. Retry selection, full hidden physics, the historical
service snapshot, and the missing RoboLab Direct source/budget map are still
unresolved. No test or adapter here certifies full historical equivalence.
