const fs=require('fs'),path=require('path'),crypto=require('crypto');
const {chromium}=require('/mnt/nas/data/lyf/agentic_robot/gpt-policy-report-site/node_modules/playwright');
const base=(process.env.BASE_URL||'http://127.0.0.1:20880').replace(/\/$/,'');const online=base.startsWith('https:');
(async()=>{const browser=await chromium.launch({executablePath:'/usr/bin/google-chrome',headless:true,args:['--no-sandbox'],...(online?{proxy:{server:'http://127.0.0.1:7897'}}:{})});const p=await browser.newPage();const errors=[],views=[],screens=[];
p.on('pageerror',e=>errors.push(String(e)));p.on('response',r=>{if(r.status()>=400)errors.push(r.status()+' '+r.url())});
for(const width of [1440,768,390,320]){await p.setViewportSize({width,height:width>390?1100:844});for(const [name,url] of [['home','scenes.html'],['dojo','gpt-methods-valid.html'],['comparison','blog-comparison.html'],['lab','robolab-methods.html']]){
 await p.goto(base+'/'+url,{waitUntil:'networkidle',timeout:60000});
 if(await p.locator('.page-navigation a[aria-current="page"]').count()!==1)throw Error('Missing current-page navigation '+name);
 const dims=await p.evaluate(()=>({viewport:innerWidth,scroll:document.documentElement.scrollWidth,theme:document.documentElement.dataset.theme}));
 if(dims.scroll>width||dims.theme!=='light')throw Error('Responsive layout or default theme '+name+' '+width);
 if(name==='home'){
  const selected=await p.evaluate(async()=>await(await fetch('data/gpt-methods-valid-progress.json')).json());const lab=await p.evaluate(async()=>await(await fetch('data/robolab-methods-progress.json')).json());
  const counts=await p.locator('.paper-summary').innerText();if(!counts.includes((selected.episodes.length+lab.episodes.length)+' 个完整回合'))throw Error('Native summary denominator');
  const expected=[selected,lab].flatMap(d=>['gpt_only','pi05_plus_gpt'].map(m=>(d.summary.methods[m].all_completed.success_rate*100).toFixed(1)));
  if(JSON.stringify(await p.locator('#native-success-chart .chart-row>b').allTextContents())!==JSON.stringify(expected))throw Error('Chart/native data mismatch');
  if(await p.locator('.auxiliary-archive').getAttribute('open')!==null)throw Error('Auxiliary archive dominates main report');
  if(await p.locator('#reference-links a').count()!==3)throw Error('Reference attribution links');
 }
 if(name==='dojo'){
  const d=await p.evaluate(async()=>await(await fetch('data/gpt-methods-valid-progress.json')).json());if(await p.locator('.gpt-episode').count()!==d.episodes.length)throw Error('Lost native video');
  await p.selectOption('#gpt-method','gpt_only');await p.selectOption('#gpt-status','failure');if(await p.locator('.gpt-episode:visible').count()!==d.episodes.filter(e=>e.method==='gpt_only'&&!e.success).length)throw Error('Native failure filter');
  await p.getByRole('button',{name:'重置',exact:true}).click();await p.waitForTimeout(100);
  await p.locator('details:has(#gpt-case-matrix)>summary').click();if(await p.locator('#gpt-case-matrix tbody tr').count()!==50)throw Error('Paired matrix changed');
  if(width===390){await p.locator('#gpt-rollouts').scrollIntoViewIfNeeded();await p.screenshot({path:path.join(__dirname,(online?'online':'local')+'_gallery_'+width+'.png')});await p.evaluate(()=>window.scrollTo(0,0));}
 }
 if(name==='comparison'){
  const value=await p.evaluate(async()=>await(await fetch('data/blog-comparison.json')).json());if(value.reproduction_episodes.length!==200||value.historical_equivalence_verified!==false)throw Error('Completion boundary changed');
  if(await p.locator('table').count()!==5||await p.locator('tbody tr').count()!==144)throw Error('Lost comparison rows');
  const scoreLabel=p.locator('#comparison-score-chart .chart-row .chart-label').last();
  if(!(await scoreLabel.innerText()).includes('Hybrid · 本次独立运行')||await scoreLabel.locator('small').innerText()!=='有得分的记录 n=50')throw Error('Score denominator label');
 }
 if(width===1440||width===390){const file=(online?'online':'local')+'_'+name+'_'+width+'.png';await p.screenshot({path:path.join(__dirname,file)});screens.push({file,sha256:crypto.createHash('sha256').update(fs.readFileSync(path.join(__dirname,file))).digest('hex')});}
 views.push({name,width,...dims});
 }}
 await p.goto(base+'/scenes.html',{waitUntil:'networkidle'});await p.locator('#theme-toggle').focus();const outline=await p.locator('#theme-toggle').evaluate(e=>getComputedStyle(e).outlineStyle);if(outline==='none')throw Error('No visible keyboard focus');await p.locator('#theme-toggle').click();if(await p.locator('html').getAttribute('data-theme')!=='dark')throw Error('Dark theme');await p.reload({waitUntil:'networkidle'});if(await p.locator('html').getAttribute('data-theme')!=='dark')throw Error('Theme persistence');await p.locator('#theme-toggle').click();
 if(errors.length)throw Error(errors.join('\n'));const result={verified:true,base,verified_utc:new Date().toISOString(),pages:4,viewport_widths:[1440,768,390,320],views,screens,chart_data_verified:true,native_failure_filter_verified:true,comparison_rows_preserved:144,native_episode_denominators_preserved:true,auxiliary_archive_retained:true,theme_persistence:true,keyboard_focus_visible:true,errors};fs.writeFileSync(path.join(__dirname,'browser_'+(online?'online':'local')+'.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));await browser.close();})().catch(e=>{console.error(e);process.exit(1)});
