"""Check unchanged evidence against the sealed native certificate; no policy calls."""
import datetime,hashlib,json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[4]
ART=ROOT/'experiments/gpt_policy_repro_20260914'
OUT=Path(__file__).resolve().parent

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

certificate=ART/'final_verification/5d7a430557ba91da93a16b5b174305ded275bf39/certificate.json'
expected='cc38b42cfcf0c098c2ad58a3af9a2e265fc1bd3b6e92ddeeae7208f18e4b3ee9'
assert digest(certificate)==expected
assert certificate.read_bytes()==(ART/'full_reproduction_verification.json').read_bytes()
gate=json.loads(certificate.read_text());sources=json.loads((ART/'robolab_queue_scheduler_v5_manifest.json').read_text())['files_sha256']
for name,sha in sources.items():assert digest(ART/'infra'/name)==sha,name
pins={
 'experiments/gpt_policy_repro_20260914/infra/verify_reproduction_completion.py':'91f6510774f28ef4a5ec44e6a140fbb48ffe86b01b035eaae4fd12d7d9a6ea61',
 'gpt-policy-report-site/tools/build_gpt_site.py':'085c42197a2d4ffe66f5f5fcff8db7842b6ffb9deccf6174b6b9fab5aaa31cf6',
 'gpt-policy-report-site/tools/build_robolab_methods.py':'85b085adc2df85e720e063b93c3bc7ed3e0fd1418f721cd55f359c6511c0fbd9'}
for name,sha in pins.items():assert digest(ROOT/name)==sha,name
audits=[]
for row in gate['original_episodes']:
    if row['cohort']=='robolab':path=ART/'robolab_gpt_campaign'/row['run_id']/'complete_action_audit.json'
    else:path=ART/'gpt_pair_campaign'/row['run_id']/row['method']/'complete_action_audit.json'
    assert digest(path)==row['audit_sha256'];audits.append(str(path.relative_to(ROOT)))
for row in gate['retained_original_episodes']:
    path=ART/'gpt_pair_campaign'/row['run_id']/'gpt_only/complete_action_audit.json'
    assert digest(path)==row['audit_sha256'];audits.append(str(path.relative_to(ROOT)))
prefixes=('data/gpt-episodes/','media/gpt-episodes/','data/robolab-method-episodes/','media/robolab-methods/')
assets=[row for row in gate['public_files'] if row['path'].startswith(prefixes)]
assert len(assets)==804 and len(audits)==201
for row in assets:
    path=ROOT/'gpt-policy-report-site/docs'/row['path']
    assert path.stat().st_size==row['bytes'] and digest(path)==row['sha256'],row['path']
result=dict(verified=True,verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 certificate_sha256=expected,native_original_audit_proofs_unchanged=len(audits),
 native_public_assets_unchanged=len(assets),frozen_scheduler_sources_unchanged=len(sources),
 pinned_gate_and_builders_unchanged=3,scope='Audit proof SHA and all native public assets checked against sealed certificate; no repeat of the already completed 232427-input raw scan.',
 native_completion_commit=gate['published_commit'],files_sha256={**{str((ART/'infra'/name).relative_to(ROOT)):sha for name,sha in sources.items()},**pins})
(OUT/'preserved_native_evidence.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='files_sha256'}),flush=True)
