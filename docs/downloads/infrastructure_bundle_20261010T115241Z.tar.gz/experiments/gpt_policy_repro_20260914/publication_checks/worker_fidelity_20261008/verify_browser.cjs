const fs=require('fs'),path=require('path'),crypto=require('crypto');
const root=path.resolve(__dirname,'../../../..');
const {chromium}=require(path.join(root,'gpt-policy-report-site/node_modules/playwright'));
const base=(process.env.BASE_URL||'http://127.0.0.1:20880').replace(/\/$/,'');
const online=base.startsWith('https:');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/google-chrome',headless:true,args:['--no-sandbox'],...(online?{proxy:{server:'http://127.0.0.1:7897'}}:{})});
 const page=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[],views=[],screens=[];
 page.on('pageerror',e=>errors.push(String(e)));
 page.on('response',r=>{if(r.status()>=400)errors.push(r.status()+' '+r.url())});
 for(const width of [1440,390]){
  await page.setViewportSize({width,height:width===390?844:1000});
  await page.goto(base+'/scenes.html',{waitUntil:'networkidle'});
  if(await page.locator('#blog-comparison-summary').count()!==1)throw Error('Duplicated comparison entry');
  await page.locator('#blog-comparison-summary a[href="blog-comparison.html"]').click();
  await page.waitForURL('**/blog-comparison.html');
  const value=await page.evaluate(async()=>await(await fetch('data/blog-comparison.json')).json());
  if(value.historical_equivalence_verified!==false||value.reproduction_episodes.length!==200||value.robodojo.case_alignment.common_method_runs!==98)throw Error('Comparison identity');
  if(value.original_record_recovery.core_archives_verified!==100||value.original_record_recovery.original_control_steps_verified!==80971)throw Error('Original record recovery');
  if(await page.locator('#original-record-recovery').count()!==1)throw Error('Recovery panel missing');
  if(await page.locator('#historical-worker-fidelity').count()!==1||value.historical_worker_fidelity.common_summary.crosses_original_five_rejection_stop!==11||value.historical_worker_fidelity.compatibility_probe_model_calls!==0)throw Error('Historical worker boundary');
  if(await page.locator('table').count()!==5||await page.locator('tbody tr').count()!==144)throw Error('Comparison denominators');
  const text=await page.locator('main').innerText();
  for(const expected of ['累计5次','30项离线','0.153.4','0.969–1.130','100000','180','500','尚未终止不计为失败','RoboLab缺少独立用量汇总','13/49','11/49','80,971','48条原生完整','初始关节状态哈希0/98','末端位置98/98','姿态四元数哈希0/98','prompt哈希0/98','3.253e-18','1.490e-08','98/98条归档prompt'])if(!text.includes(expected))throw Error('Missing boundary label: '+expected);
  await page.locator('details summary').click();
  if(await page.locator('details tbody tr').count()!==98||await page.locator('details a').count()!==98)throw Error('Common case evidence links');
  const first=value.robodojo.case_alignment.cases[0];
  const response=await page.request.get(base+'/'+first.evidence);if(!response.ok())throw Error('Case evidence unavailable');
  const evidence=await response.json();
  if(evidence.case_id!==first.case_id||evidence.method!==first.method||evidence.success!==first.reproduction_success)throw Error('Case evidence drift');
  const dims=await page.evaluate(()=>({viewport:innerWidth,scroll:document.documentElement.scrollWidth,tableScrollable:[...document.querySelectorAll('.scroll')].map(e=>e.scrollWidth>e.clientWidth)}));
  if(dims.scroll>dims.viewport)throw Error('Page overflow');
  if(width===390&&!dims.tableScrollable.every(Boolean))throw Error('Mobile comparison tables not scrollable');
  const image=path.join(__dirname,(online?'online':'local')+'_'+width+'.png');
  await page.evaluate(()=>window.scrollTo(0,0));
  await page.screenshot({path:image});screens.push({file:path.basename(image),sha256:crypto.createHash('sha256').update(fs.readFileSync(image)).digest('hex')});
  views.push({width,...dims,case_evidence_verified:true});
 }
 for(const name of ['gpt-methods.html','gpt-methods-valid.html']){
  await page.goto(base+'/'+name,{waitUntil:'networkidle'});
  if(await page.locator('#blog-comparison-summary').count()!==1||await page.locator('#blog-comparison-summary a[href="blog-comparison.html"]').count()!==1)throw Error('Method page entry: '+name);
 }
 if(errors.length)throw Error(errors.join('\n'));
 const result={verified:true,base,verified_utc:new Date().toISOString(),comparison_methods:2,native_episodes:200,original_core_archives:100,original_control_steps:80971,common_method_runs:98,table_rows:144,views,screens,errors};
 fs.writeFileSync(path.join(__dirname,'browser_'+(online?'online':'local')+'.json'),JSON.stringify(result,null,2)+'\n');
 console.log(JSON.stringify(result));await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
