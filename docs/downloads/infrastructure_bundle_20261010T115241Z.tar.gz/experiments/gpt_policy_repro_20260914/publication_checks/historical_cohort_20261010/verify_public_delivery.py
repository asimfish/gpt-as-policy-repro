"""Verify the new comparison delivery without changing the original native gate."""
import datetime,hashlib,io,json,subprocess,sys,tarfile,time,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[4]
ART=ROOT/'experiments/gpt_policy_repro_20260914';WORKER=ART/'publication_checks/worker_fidelity_20261008';REPO=ROOT/'gpt-policy-report-site';OUT=Path(__file__).resolve().parent
sys.path[:0]=[str(ART/'infra'),str(REPO/'tools')]
from verify_reproduction_completion import verify_ci
from export_infra_bundle import SECRET,validate_completion_certificate
from blog_comparison import verify_public

def get(name,commit):
    url='https://asimfish.github.io/gpt-as-policy-repro/'+name+'?commit='+commit+'&verify='+str(time.time_ns())
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'gpt-policy-blog-comparison-verifier'}),timeout=45) as response:
        assert response.status==200
        return response.read()

def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def sha(data):return hashlib.sha256(data).hexdigest()

commit=subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip()
receipt=json.loads((ART/'online_publication.json').read_text())
assert receipt['status']=='published_and_http_verified' and receipt['commit']==commit
ci=verify_ci(commit)
for row in receipt['files']:
    assert row['matches'] is True and row['local_sha256']==row['online_sha256']
    expected=subprocess.check_output(['git','-C',str(REPO),'show',commit+':docs/'+row['file']])
    assert sha(expected)==row['online_sha256']
assert len(receipt['files'])==17
comparison=get('data/blog-comparison.json',commit)
assert comparison==(REPO/'docs/data/blog-comparison.json').read_bytes()
value=json.loads(comparison);assert value['historical_equivalence_verified'] is False
verify_public(REPO/'docs')
public_bundle=json.loads(get('data/infrastructure-bundle.json',commit))
assert public_bundle['full_reproduction_complete'] is True and public_bundle['contents_verified'] is True
archive=get(public_bundle['archive'],commit)
assert len(archive)==public_bundle['bytes'] and sha(archive)==public_bundle['sha256']
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
    members=tar.getmembers();names=[m.name for m in members]
    manifest=json.loads(tar.extractfile('manifest.json').read())
    assert len(names)==len(set(names)) and all(m.isfile() for m in members)
    assert set(names)=={'manifest.json'}|{r['path'] for r in manifest['files']}
    assert len(manifest['files'])==public_bundle['files'] and manifest['full_reproduction_complete'] is True
    for row in manifest['files']:
        name=Path(row['path']);assert not name.is_absolute() and '..' not in name.parts
        data=tar.extractfile(row['path']).read()
        assert len(data)==row['size'] and sha(data)==row['sha256'] and not SECRET.search(data),row['path']
    alignment=manifest['blog_comparison'];assert alignment['historical_equivalence_verified'] is False
    assert tar.extractfile(alignment['path']).read()==comparison and alignment['sha256']==sha(comparison)
    recovered=manifest['original_record_recovery']
    recount=tar.extractfile(recovered['path']).read()
    assert recovered['original_core_archives_verified']==100 and recovered['original_control_steps_verified']==80971
    assert recovered['historical_full_physics_state_verified'] is False
    assert sha(recount)==recovered['sha256']==value['original_record_recovery']['original_record_recount_sha256']
    original=json.loads(recount)
    assert original['verified'] is True and len(original['records'])==100
    for name,key in [('recovered_comparison.json','configuration_comparison'),('initial_difference_inspection.json','recorded_initial_difference_inspection')]:
        data=tar.extractfile(str((ART/'publication_checks/historical_protocol_20261008').relative_to(ROOT))+'/'+name).read()
        assert json.loads(data)==value['original_record_recovery'][key]
    statistics=json.loads(tar.extractfile(str((ART/'publication_checks/blog_alignment_20261008').relative_to(ROOT))+'/statistics_audit.json').read())
    assert statistics['verified'] is True and statistics['comparison_sha256']==sha(comparison)
    worker=manifest['historical_worker_reconstruction']
    assert worker['source_profiles']==5 and worker['worker_versions']==4 and worker['case_assignments']==100
    assert worker['historical_protocol_equivalence'] is False and worker['full_blog_reproduction_complete'] is False
    fidelity=value['historical_worker_fidelity'];assert fidelity['common_summary']['crosses_original_five_rejection_stop']==11
    for name,digest in fidelity['evidence_sha256'].items():
        data=tar.extractfile(str(WORKER.relative_to(ROOT))+'/'+name).read()
        assert sha(data)==digest
    staged=json.loads(tar.extractfile(str(WORKER.relative_to(ROOT))+'/historical_worker_manifest.json').read())
    for profile in staged['source_profiles']:
        for name,digest in {**profile['frozen_files_sha256'],**profile['added_runtime_bridge_sha256']}.items():
            member=str(ART.relative_to(ROOT))+'/'+profile['package_root']+'/'+name
            assert sha(tar.extractfile(member).read())==digest
    execution=value['historical_worker_fidelity']['original_version_execution']
    from blog_comparison import validate_historical_execution
    validate_historical_execution(execution)
    extra=manifest['historical_original_version_execution']
    assert extra['canary_complete_native_audited']==2 and extra['remaining_episodes_planned']==98
    assert extra['pilot_included_in_benchmark'] is False and extra['full_blog_reproduction_complete'] is False
    for name,digest in execution['evidence_sha256'].items():
        member=str((ART/'publication_checks').relative_to(ROOT))+'/'+name
        assert sha(tar.extractfile(member).read())==digest
    gate=json.loads(tar.extractfile(str(WORKER.relative_to(ROOT))+'/historical_canary_evidence_gate.json').read())
    for row in gate['results']:
        member=str(ART.relative_to(ROOT))+'/'+gate['cohort']+'/'+row['method']+'/complete_action_audit.json'
        assert sha(tar.extractfile(member).read())==row['complete_action_audit_sha256']
    binding=manifest['completion_certificate'];sealed=tar.extractfile(binding['path']).read()
    proof=validate_completion_certificate(sealed,binding)
    assert sealed==(ROOT/binding['path']).read_bytes()==get('data/reproduction-completion.json',commit)
    assert proof['published_commit']=='5d7a430557ba91da93a16b5b174305ded275bf39'
    source_commit=manifest['source_commits']['report_site']
    for name in ('blog_comparison.py','test_blog_comparison.py','render_gpt_progress.py','publish_gpt_progress.py','verify_site.py'):
        published_source=subprocess.check_output(['git','-C',str(REPO),'show',source_commit+':tools/'+name])
        assert tar.extractfile('gpt-policy-report-site/tools/'+name).read()==published_source
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
save('exact_commit_ci.json',dict(verified=True,commit=commit,runs=ci,verified_utc=now))
save('publication_http.json',dict(verified=True,commit=commit,files=receipt['files'],verified_utc=receipt['verified_utc']))
result=dict(schema='gpt_policy_blog_alignment_public_delivery.v1',verified=True,commit=commit,verified_utc=now,
 independent_evaluation_complete=True,historical_equivalence_verified=False,
 archive=public_bundle['archive'],archive_sha256=public_bundle['sha256'],archive_bytes=len(archive),
 manifested_files=len(manifest['files']),all_payload_member_hashes_verified=True,published_files_verified=len(receipt['files']),
 native_completion_commit=proof['published_commit'],certificate_sha256=binding['sha256'],public_certificate_exact_bytes=True,
 comparison_sha256=sha(comparison),statistics_inputs=len(statistics['files_sha256']),
 original_core_archives_verified=100,original_control_steps_verified=80971,
 original_record_recount_sha256=recovered['sha256'],
 recorded_initial_numeric_and_prompt_evidence_exact=True,source_commit=source_commit,exact_commit_ci=ci)
save('public_bundle_verified.json',result);print(json.dumps(result),flush=True)
