# Data and documentation license

Copyright (c) 2026 Jiayi Su, Yixin Zheng, Mi Yan, Li Yi, Zhizheng Zhang, and He Wang.

The authors' contributions to the rollout records, annotations, dataset indexes
and documentation are licensed under the Creative Commons Attribution 4.0
International License (CC BY 4.0):
https://creativecommons.org/licenses/by/4.0/

Provide attribution, a link to this license, and indicate changes when sharing
or adapting these contributions. Cite the report and pin the dataset revision
for scientific reproducibility. Do not imply author or company endorsement.

This license does not relicense third-party RoboDojo/Isaac Sim/OpenPI/π₀.₅
software, model weights, simulator assets, brands or other third-party content.
Those remain subject to their original terms. Original simulator assets and
model weights are not bundled; scene references and generated observation
records are supplied for research reproducibility. No additional rights to
third-party content are asserted. Reader/validator/example code is MIT licensed
as specified in LICENSE. Third-party notices in frozen source retain effect.
