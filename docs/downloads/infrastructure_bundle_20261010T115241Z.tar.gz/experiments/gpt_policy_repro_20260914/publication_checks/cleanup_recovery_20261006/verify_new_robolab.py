"""Read-only native evidence and HTTP verification of new completed RoboLab episodes."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[4]
ART=ROOT/'experiments/gpt_policy_repro_20260914'
REPO=ROOT/'gpt-policy-report-site'
HERE=Path(__file__).parent
sys.path[:0]=[str(ART/'infra'),str(REPO/'tools')]
import verify_reproduction_completion as gate
import build_robolab_methods as lab


def committed(commit,name):
    return subprocess.check_output(['git','-C',str(REPO),'show',commit+':docs/'+name],timeout=180)


def original_scene(e):
    run=ART/'robolab_gpt_campaign'/e['run_id'];audit=gate.read(run/'complete_action_audit.json')
    names=[n for n in audit['files_sha256'] if n.startswith('remote/sim/') and n.endswith('/initial_scene.json')]
    gate.require(len(names)==1,'Missing original initial scene')
    path=gate.relative(run,names[0]);sha=gate.digest(path);gate.require(sha==audit['files_sha256'][names[0]],'Changed initial scene record')
    scene=gate.read(path);gate.require(scene['state_sha256']==e['initial_state_hash']==audit['initial_state_hash'] and scene['step_id']==0,'Initial scene differs from report')
    return dict(run_id=e['run_id'],record_sha256=sha,state_sha256=scene['state_sha256'],scope=scene['scope'])


def main():
    receipt=gate.read(ART/'online_publication.json');commit=receipt['commit']
    baseline='a67cfc7187f1981b5b5d3c590b1fdb048addf0c1';name='data/robolab-methods-progress.json'
    old=json.loads(committed(baseline,name));raw=committed(commit,name);doc=json.loads(raw)
    expected,frozen_sha=gate.frozen_inputs(ART);coverage=gate.matrix(doc,expected['robolab'])
    before={e['run_id'] for e in old['episodes']};gate.require(before<={e['run_id'] for e in doc['episodes']},'An earlier episode disappeared')
    new=[e for e in doc['episodes'] if e['run_id'] not in before]
    first=gate.first_native_runs(ART/'robolab_gpt_campaign',False)
    for e in new:gate.require(first[e['case_id'],e['method']].name==e['run_id'],'First native failure or audit gap was bypassed')
    (HERE/'robolab_snapshot.json').write_bytes(raw)
    sources={str(p.relative_to(ROOT)):gate.digest(p) for p in [Path(__file__),ART/'infra/verify_reproduction_completion.py',REPO/'tools/build_robolab_methods.py',REPO/'tools/build_gpt_site.py']}
    state=dict(status='verifying',baseline_commit=baseline,published_commit=commit,coverage=coverage,
        delta_episodes=len(new),verified=0,proofs=[],frozen_sha256=frozen_sha,execution_source_sha256=sources,full_reproduction_complete=False)
    def persist():
        state['updated_utc']=datetime.now(timezone.utc).isoformat();gate.atomic_json(HERE/'new_native_progress.json',state)
    persist();print(json.dumps({k:state[k] for k in ['published_commit','coverage','delta_episodes']}),flush=True)
    def verify(e):
        print(json.dumps({'episode_start':e['run_id']}),flush=True)
        run=ART/'robolab_gpt_campaign'/e['run_id'];proof=gate.verify_original(run,e,expected['robolab'][e['case_id']],False,{'lab':lab})
        videos=[run/'remote/sim/sensors.mp4',gate.relative(REPO/'docs',e['video'])]
        for video in videos:subprocess.run(['ffmpeg','-nostdin','-v','error','-xerror','-threads','2','-i',str(video),'-f','null','-'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,timeout=300)
        paths=[e['evidence'],e['audit'],e['video'],e['poster']]
        http=[gate.verify_http(REPO/'docs',p,commit) for p in paths]
        proof.update(case_id=e['case_id'],method=e['method'],success=e['success'],control_steps=e['control_steps'],raw_and_exported_video_decoded=True,public_files=http,initial_scene=original_scene(e))
        return proof
    with ThreadPoolExecutor(max_workers=2) as pool:
        pending=[pool.submit(verify,e) for e in new]
        for future in as_completed(pending):
            try:proof=future.result()
            except BaseException as error:
                state.update(status='failed',error_type=type(error).__name__);persist();print(json.dumps({'failed':type(error).__name__}),flush=True)
                for other in pending:other.cancel()
                raise
            state['proofs'].append(proof);state['verified']=len(state['proofs']);persist()
            print(json.dumps({'verified':state['verified'],'run_id':proof['run_id'],'audit_inputs':proof['audit_inputs']}),flush=True)
    pairs=[];lookup={(e['case_id'],e['method']):e for e in doc['episodes']}
    for c in doc['cases']:
        if not c['paired_complete']:continue
        rows=[original_scene(lookup[c['case_id'],m]) for m in gate.METHODS]
        gate.require(rows[0]['state_sha256']==rows[1]['state_sha256'],'Paired recorded initial scene differs')
        pairs.append(dict(case_id=c['case_id'],originals=rows,recorded_initial_state_equal=True))
    for name,sha in sources.items():gate.require(gate.digest(ROOT/name)==sha,'Verification source changed during execution')
    state.update(status='delta_verified_full_reproduction_pending',verified=True,verified_delta_episodes=len(new),
        audit_inputs=sum(p['audit_inputs'] for p in state['proofs']),public_files_verified=sum(len(p['public_files']) for p in state['proofs']),paired_initial_scene_proofs=pairs,pairs_verified=len(pairs),complete_checkpoint_equivalence_claimed=False,exact_commit_ci=gate.verify_ci(commit),finished_utc=datetime.now(timezone.utc).isoformat())
    gate.atomic_json(HERE/'new_native_certificate.json',state)
    print(json.dumps({k:v for k,v in state.items() if k not in ['proofs','paired_initial_scene_proofs','execution_source_sha256']}),flush=True)


if __name__=='__main__':main()
