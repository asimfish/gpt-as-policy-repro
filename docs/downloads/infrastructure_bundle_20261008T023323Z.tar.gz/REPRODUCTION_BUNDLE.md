# 复现实验基建快照

包含运行脚本、调度器、逐步动作审计、回归测试、冻结案例与依赖锁、报告解读、运行手册和 GPT-as-Policy 源码补丁。按归档中的相对路径解压到工作区；先按 RUNBOOK.md 准备固定版本上游仓库与环境，再应用源码补丁。

运行入口：experiments/gpt_policy_repro_20260914/RUNBOOK.md。

环境配置保留本项目工作区与 mainskill 部署路径；迁移到其他机器时需调整 infra/env.sh 和部署脚本中的根路径、Python 路径及 SSH alias。模型权重、大型资产、SSH 密钥、API 凭据不在包内，下载清单和校验逻辑保留。用户已授权复用现有 Codex CLI 登录态：配置 CODEX_HOME/CODEX_BIN 与 ROLLOUT_USE_CURRENT_CODEX_HOME=1，由 CLI 自身读取认证，禁止复制或公开 auth.json。unit_templates 提供去掉私有环境的 systemd 模板，runtime.env 由部署者自行在本机以0600权限创建。所选两套评测的200回合和100对已通过原始证据、完整视频、815个线上文件及同提交CI终验。包内封存原始完成证明 experiments/gpt_policy_repro_20260914/final_verification/5d7a430557ba91da93a16b5b174305ded275bf39/certificate.json；验收绑定原报告提交 5d7a430557ba91da93a16b5b174305ded275bf39，保留原验收时间。后续交付提交只发布该证明与基础设施，不能改写历史完成证明或声称历史逐位环境等价。详细结果和限制见 COMPLETION_20261007.md。

当前有效范围只包含 GPT Direct 与 π0.5 + GPT Hybrid。遗留基线辅助脚本仅用于追溯，不应据此启动额外方法。RoboLab Direct 是本项目 EEF 适配器，历史实现未公开；当前完整结果、验证门和队列状态见GOAL.md。SSH传输缓解、只读归档补传及完整审计说明均在包内，前缀或连接中断不得计入完整成绩。

包含两种环境的SSD容量维护脚本与定时服务：完整审计后，对RoboLab整工作区、RoboDojo封存Codex状态逐文件SHA256核验，归档到私有NAS，活动SQLite只使用本机ext4（早期/tmp，新RoboLab回合使用第二SSD）；不得放入NAS；运行数据库和日志冷归档不在公开包内。主实验维护使用哈希固定的v5原资格函数，安装和恢复边界见RUNBOOK.md。

manifest.json 给出每个文件的 SHA256 与固定源码提交（包括在线报告源码版本）。大型实验轨迹和在线站点源码留在工作区及报告 GitHub 仓库。

原blog逐任务与共同案例对照见BLOG_ALIGNMENT_20261008.md和包内gpt-policy-report-site/docs/blog-comparison.html。所选200回合执行完成不代表严格历史等价；manifest.blog_comparison.historical_equivalence_verified保持false。RoboLab决策预算和Direct实现差异、缺失历史证据及900项统计输入SHA均分列。预算前缀只记录已终止/尚未终止，不补失败，也不是新的限预算评测。
