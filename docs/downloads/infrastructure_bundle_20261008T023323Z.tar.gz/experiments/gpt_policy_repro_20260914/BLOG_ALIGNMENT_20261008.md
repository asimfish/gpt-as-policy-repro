# 原 blog 对照与尚缺证据（2026-10-08）

所选 Direct/Hybrid 的200个原生回合已完成并通过封存终验；严格历史等价性仍未证明。本轮只读取既有原始结果与作者公开快照，补齐逐任务、49个共同案例、统计口径和预算协议对照，不重跑完整失败，不修改已封存证明。

公开对照入口：https://asimfish.github.io/gpt-as-policy-repro/blog-comparison.html 。机器数据：`data/blog-comparison.json`。新的统计证据见 `publication_checks/blog_alignment_20261008/statistics_audit.json`，缺失历史证据清单见同目录 `missing_evidence.json`。

## 来源与范围

作者源码快照 `8f3d362b077d8efb77e2a7274d5b2c20e2243846`；作者网站数据快照 `6ead090465d3b0fb19e90eb70569689c19f73d00`。三个原始数据文件与本地原公开快照逐字节相同，URL、大小和SHA保存在 `original_sources.json`。当前限定两方法；π0.5、Cosmos、DreamZero全量基线不计入该范围。用户本轮尚未回答可选范围问题，继续沿此前两方法授权工作。

## 已确认差异

| RoboDojo指标 | 原Direct | 本次Direct | 原Hybrid | 本次Hybrid |
|---|---:|---:|---:|---:|
| 成功数 / 50 | 13 | 13 | 24 | 21 |
| 平均score | 0.378125，n=48 | 0.395，n=50 | 0.626，n=50 | 0.548，n=50 |
| 原生控制步 | 38221 | 45259 | 42750 | 42993 |
| 已执行段 | 7729 | 9581 | 3776 | 4004 |
| 纠错控制步 | 0 | 0 | 6174 | 7799 |
| 最后记录的累计Token | 1132343772 | 1469027502 | 624762828 | 755959377 |

Hybrid实际执行的edit/EEF纠错步比例从原14.4421%变为本次18.1402%。Token包含缓存输入，不能直接换算账单或时延；已执行段只计 `executed_steps > 0`，沿用作者提取口径。原Direct缺失的两条score保持缺失，不补零；成功率分母仍为50。

49个共同案例、98条方法回合的案例ID和五个种子字段完全相同；Direct有13条、Hybrid有11条成功判定不同。原layout4与新增layout5分列，不能当作相同案例，也不能将两个重叠面板相加。种子相同不证明完整历史物理初态等价。

RoboLab总成功数双方同为Direct49/50、Hybrid46/50，失败任务分布不同。本次Direct失败在ReorientRedMug，原Direct失败在LargerObjectRaisinBox。本次Hybrid失败分布为ClutterPumpkin两条、BlockStacking一条、Yogurt一条；原Hybrid分别在ClutterPumpkin、BlockStacking、ReorientRedMug、LargerObjectRaisinBox各一条。历史与本次初态未逐seed配对，只有逐任务对照，不计算逐回合一致率。RoboLab未记录独立Token用量汇总，公开值保持未知。

## 预算与实现缺口

本次全部100条RoboLab运行配置为 `max_decisions=100000`，主要受原生控制时域约束。作者公开注释说明其表格包含保留历史结果与授权重试，最后两条BlocksInBin Direct重试从180决策扩为500，因此原表本身也不是统一预算的新鲜单次配对评测。这是明确的协议差异，不能仅凭总成功数相同称为原实验复现。

新页面对180/500决策只截看既有轨迹：已成功终止、已原生失败、仍未终止。仍未终止保持删失状态，不补成失败；此表不是重新运行的限预算策略成绩，不能用它估计改变预算的因果效果。

当前Direct适配器要求决策预算超过原生物理时域。若要实际运行历史限预算协议，须建立独立版本的适配器和独立队列/资格规则，明确预算终止与原生失败的区别，不能更改冻结执行代码或重标当前结果。原历史Direct代码/prompt、逐槽重试与预算映射、完整物理初态/构建版本和模型服务修订尚未恢复；所需材料与验收条件逐项列于 `missing_evidence.json`。未向作者发送消息，也未启动新模型或仿真回合。

## 证据边界

新的统计提取绑定200份原审计证明、200份结果、200份运行配置、200份history和100份主实验Token汇总，共900个输入SHA。其中150个统计输入未列于较早原审计manifest，单独捕获当前SHA，并用原审计的原生控制步与纠错计数核对，不追溯声称它们属于原终验输入。

原终验证明仍绑定提交 `5d7a430557ba91da93a16b5b174305ded275bf39`，SHA256 `cc38b42cfcf0c098c2ad58a3af9a2e265fc1bd3b6e92ddeeae7208f18e4b3ee9`。本轮公开交付的源码、测试、浏览器、CI、HTTP字节与新不可变基建包验收另存，不覆盖原证书或修改其时间。
