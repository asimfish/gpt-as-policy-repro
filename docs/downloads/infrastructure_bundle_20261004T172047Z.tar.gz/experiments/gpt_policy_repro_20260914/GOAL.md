# GPT-as-Policy 两种方法复现目标

## Outcome

按用户 2026-09-16 的范围修正，主要复现报告自己的两种方法：GPT Direct 与 π0.5 + GPT（Hybrid）。交付我们自己运行生成的在线报告、完整轨迹和可复用基础设施。

## In scope

- GPT Direct：使用原仓库的持久 GPT 控制器与 GPTOnlyTools，观察图像和状态，直接生成并执行短段末端控制，不调用 π0.5。
- Hybrid：使用原仓库 RoboDojoTools；π0.5 提议动作，GPT 根据观测与反馈接受前缀、修改或接管，保留完整闭环历史。
- 优先 RoboDojo 主实验：同一冻结面板50个案例，每个案例分别运行两方法，共100条轨迹。
- RoboLab 补充实验：10任务×5种子×两方法，共100条新固定种子轨迹；不扩展其他模型基线。
- 保留原生终止条件、输入输出、prompt、工具调用、模型身份、token、初态、视频与失败证据。

## Out of scope for active work

Cosmos、DreamZero、独立 π0.5 全量基线、prefix/chunk 对照扩展。已获得的结果和资产保留为历史辅助材料，不能当作 Direct/Hybrid 复现成绩。π0.5 推理服务继续保留，作为 Hybrid 必需组件。

## Acceptance

- [x] 原生仿真与 π0.5 推理链路验证。
- [x] 原仓库持久控制器启动入口已准备；2026-09-16两方法真实app-server握手/工具注册及原生工具预检通过（零模型调用）。
- [x] 用户授权当前Codex CLI后，gpt-6-astra/xhigh真实模型响应验证通过；证据astra_live_probe_20260916。
- [x] 同一个冻结案例完成 Direct 与 Hybrid 两条完整轨迹并审计；截至 2026-10-05 已有 37 个主实验完整配对，另有 1 个 RoboLab 补充配对。
- [ ] RoboDojo 两方法100条配对轨迹完成，失败和基础设施中断区分。
- [x] 在线报告以两方法自己的结果为主；公开数字与已有基线分开（v2 自动生成主板已发布、字节与浏览器验收通过）。
- [ ] 完成两方法 RoboLab 补充评测并明确历史环境等价性限制。

## Current frontier

2026-10-04T17:20:36.656077+00:00：报告提交 `08ca73eb2ab0dca14bf617a23a7df4656b5d1b88` 已完成线上精确字节核验。
RoboDojo为79/100完整审计回合、37/50配对；RoboLab为4/100、1/50配对。
这些是当前已完成子集，两套200条轨迹尚未全量完成。主实验当前继续
pack_objects_into_box / standard / layout1 Direct；RoboLab继续
BlockStackingSpecifiedOrderTask / seed2 Direct。当前物理回合保持原生运行。

已恢复发布事务：遗留9项自有暂存和无人持有的index.lock已保存诊断证据并恢复提交；
发布器的事务回执绑定HEAD、索引树和路径，仍拒绝并发用户暂存变化。
10分钟自动发布已恢复，线上文件分别核验。30项站点测试和实际桌面/手机浏览器验证通过。

RoboLab最早原生完整回合共12条，其中4条通过完整审计，8条待补齐归档。
Hybrid seed2原回合2003文件/262490257字节已补齐并通过原审计：1621步、135决策、原生成功；
线上108.133秒完整视频实际播放通过。recover_robolab_archives.py及10分钟timer继续恢复余下原回合。
服务退出后遗留ready元数据仅在原STOP存在、全部原PID与进程组消失时允许只读归档，原元数据不改写。
传输分4组互不重叠文件列表、每组1200秒/次、最多3次，最终所有尺寸/SHA256必须一致。
缺审计不能计分，不能新跑物理回合绕过原完整结果。

后续远端启动使用已核验2228文件的完整RoboLab资产目录，全部Python源码与旧runtime逐文件一致；
旧USD的LFS指针导致初始化失败。按原显存门槛选空闲独立GPU，不停止其他任务。
RubiksCubeTask零动作重置和主/腕相机检查通过，step_id=0，不计分。后端47项回归通过。

v2冻结调度器及SHA256见robolab_queue_scheduler_v2_manifest.json；修复前全部尝试保留，
修复后最多3次新基础设施尝试。原生完整与资格函数AST和v1相同，首次完整失败跨全部历史保留。
gpt-policy-robolab-queue-handover-20261005.service等待当前控制器及归档锁释放后切换，当前尚未接管。

主实验9项基础设施重试中，多项为NAS加载或Git状态检查超时；服务就绪等待从600秒延长为1200秒，
仅适用于后续尝试，模型/动作/种子/原生步数和12小时回合看护均不变。11项配对/退出/队列回归通过。
另一个1600步完整终止回合因原生invalid_native_layout被拒绝计分；相同冻结布局的Direct已有原生有效结果。
保留无效布局证据，按基础设施重试，不能把前缀审计升级为完整成绩。

下一前沿：补齐8条旧归档并运行原审计，在真实空闲边界验证v2接管，继续两套冻结矩阵与定时发布，
直到各100/100且各50/50配齐并全部上线。活动SQLite留本机，已审计冷归档和容量维护timer继续。
692文件基建包已公开下载并逐成员hash核验，后续代码更新形成新的不可变快照。
RoboLab Direct仍为本项目EEF适配器，历史源码/完整初态未公开；不声称逐位环境等价，也未独立重算IK。
旧运行和SSH AES-GCM缓解证据见PROGRESS_20261002.md、ROBOLAB_RPC_DIAGNOSIS.md和ROBOLAB_ARCHIVE_DIAGNOSIS.md。

## Decisions

- 2026-09-16：用户明确“主要复现这个文档自己的两种方法就行”；优先级覆盖此前全模型扩展范围。
- 停止继续运行独立π0.5基线队列和额外模型传输；不删除已下载资产和历史结果。
- 2026-09-16追加授权：用户明确要求直接使用当前Codex CLI的GPT-6 Astra。通过CLI自身认证复用当前登录态，不复制、不输出凭据；SQLite运行状态保持每次实验独立。该决定覆盖此前要求单独实验账号的限制。
- 既有历史目标保存在 GOAL_before_scope_correction_20260916.md，仅供追溯。

## Evidence

report_interpretation_zh.md、infra/run_original_controller.sh、现有仿真与π0.5审计记录。在线报告：https://asimfish.github.io/gpt-as-policy-repro/scenes.html 。当前在线报告已以两种主方法的自有结果为主；50 个配对与 RoboLab 补充仍未全量完成。
