"""Create a local, hash-verified handoff of experiment infrastructure and frozen inputs."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile
from datetime import datetime,timezone

ROOT=Path(__file__).resolve().parents[3]
ART=ROOT/'experiments/gpt_policy_repro_20260914'


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--date',default=datetime.now(timezone.utc).strftime('%Y%m%d'))
    args=parser.parse_args();assert re.fullmatch(r'20[0-9]{6}(?:T[0-9]{6}Z)?',args.date)
    files=[p for p in (ART/'infra').iterdir() if p.is_file() and p.suffix in {'.py','.sh','.txt','.json'}]
    files += list((ART/'infra/robolab_direct_skill').rglob('*.md'))
    files += [p for p in (ART/'fixtures').rglob('*') if p.is_file() and p.suffix in {'.json','.lock'}]
    files += [ART/name for name in ['GOAL.md','RUNBOOK.md','scope_matrix.md','baseline_protocol_audit.md','report_interpretation_zh.md','additional_baseline_sources.json','ROBOLAB_DIRECT_ADR.md','ROBOLAB_RPC_DIAGNOSIS.md','ROBOLAB_ARCHIVE_DIAGNOSIS.md','ROBOLAB_PARALLEL_ADR.md','ROBOLAB_LOCAL_STORAGE_ADR.md','ROBOLAB_LAUNCH_GUARD_ADR.md','ROBODOJO_NATIVE_LAYOUT_DIAGNOSIS.md','PROGRESS_20261002.md']]
    files += [p for p in (ART/'queue_scheduler_v5_manifest.json',ART/'queue_scheduler_v6_manifest.json',ART/'robolab_queue_scheduler_v1_manifest.json',ART/'robolab_queue_scheduler_v2_manifest.json',ART/'robolab_queue_scheduler_v3_manifest.json',ART/'robolab_queue_scheduler_v4_manifest.json',ART/'robolab_queue_scheduler_v5_manifest.json',ART/'robolab_parallel_deployment_receipt.json') if p.exists()]
    diagnosis=ART/'publication_checks/native_layout_20261005'
    files += [diagnosis/name for name in ('probe_server.py','probe_client.py','run_probe.sh',
        'support_trajectory_identities.json','watch_asset_identity.json','replacement_proposal.json',
        'replacement_activation_20261006.json',
        'mix__imitate_sorting_sequence__standard__g0__l5.json',
        'hold_seed4/diagnostic_progress.json','hold_seed4/sim/support_validation.json',
        'hold_seed4/sim/evaluation_outcome.json',
        'hold_seed4/sim/resolved_config.json','hold_seed4/diagnostic_integrity.json',
        'hold_seed5/diagnostic_progress.json','hold_seed5/sim/support_validation.json',
        'hold_seed5/sim/evaluation_outcome.json',
        'hold_seed5/sim/resolved_config.json','hold_seed5/diagnostic_integrity.json') if (diagnosis/name).is_file()]
    milestone=ART/'publication_checks/robodojo_completed_20261006'
    # Completed-cohort evidence contains hashes and public paths only; neither
    # runtime logs nor an unfinished progress state belongs in this snapshot.
    certificate=milestone/'certificate.json'
    if certificate.is_file():
        proof=json.loads(certificate.read_text())
        assert proof['cohort_verified'] is True and proof['full_reproduction_complete'] is False
        assert proof['status']=='cohort_verified_full_reproduction_pending'
        assert proof['verified_selected_episodes']==100 and proof['verified_retained_original_episodes']==1
        files += [milestone/name for name in ('verify_completed_robodojo.py','certificate.json',
            'execution_sources.json','execution_sources_after_restart.json','paired_initial_states.json',
            'new_parallel_native_originals.json','serial_boundary_native_original.json') if (milestone/name).is_file()]
    recovery=ART/'publication_checks/cleanup_recovery_20261006'
    delta=recovery/'new_native_certificate.json'
    if delta.is_file():
        proof=json.loads(delta.read_text())
        assert proof['verified'] is True and proof['full_reproduction_complete'] is False
        assert proof['status']=='delta_verified_full_reproduction_pending'
        assert proof['verified_delta_episodes']==proof['delta_episodes']
        assert proof['public_files_verified']==4*proof['delta_episodes']
        files += [recovery/name for name in ('verify_new_robolab.py','new_native_certificate.json',
            'diagnosis.json','live_reconciliation.json','cleanup_reconciliation.json',
            'activation.json','implementation_checks.json') if (recovery/name).is_file()]
    local_ssd=ART/'publication_checks/local_ssd_20261006'
    activation=local_ssd/'activation.json'
    if activation.is_file():
        proof=json.loads(activation.read_text())
        assert proof['verified'] is True and proof['live_workspaces_relocated'] is False
        files += [local_ssd/name for name in ('preflight.json','activation.json') if (local_ssd/name).is_file()]
    launch=ART/'publication_checks/launch_recovery_20261007'
    activation=launch/'activation.json'
    if activation.is_file():
        proof=json.loads(activation.read_text())
        assert proof['verified'] is True and proof['full_reproduction_complete'] is False
        assert proof['existing_authorized_login_preserved'] is True
        assert len(proof['verified_nonphysical_releases'])==3
        files += [launch/name for name in ('diagnosis.json','initial_sources.json',
            'robolab_gpt_parallel_leases.json','preoutput_recovery.json','activation.json',
            'implementation_checks.json','runtime_verified.json') if (launch/name).is_file()]
        for lease in proof['verified_nonphysical_releases']:
            run=ART/'robolab_gpt_campaign'/lease['attempt']
            record=json.loads((run/'attempt.json').read_text())
            assert record['metadata_reconstructed'] is True and record['completed'] is False
            assert record['remote_launch_attempted'] is False
            files += [run/'attempt.json',run/'startup_recovery.json']
        delta=launch/'new_native_certificate.json'
        if delta.is_file():
            proof=json.loads(delta.read_text())
            assert proof['verified'] is True and proof['full_reproduction_complete'] is False
            assert proof['verified_delta_episodes']==proof['delta_episodes']
            assert proof['public_files_verified']==4*proof['delta_episodes']
            files += [delta,launch/'verify_new_robolab.py']
    ssd_native=ART/'publication_checks/ssd_native_complete_20261007'
    delta=ssd_native/'new_native_certificate.json'
    if delta.is_file():
        proof=json.loads(delta.read_text())
        assert proof['verified'] is True and proof['full_reproduction_complete'] is False
        assert proof['verified_delta_episodes']==proof['delta_episodes']>=3
        assert proof['public_files_verified']==4*proof['delta_episodes']
        assert {'hybrid_20261007T045112Z_RubiksCubeTask_seed3',
            'hybrid_20261007T045112Z_RubiksCubeTask_seed4',
            'direct_20261007T045112Z_RubiksCubeTask_seed0'} <= {p['run_id'] for p in proof['proofs']}
        files += [delta,ssd_native/'verify_new_robolab.py']
    payload={str(p.relative_to(ROOT)):p.read_bytes() for p in sorted(set(files))}
    # Installed unit environments are private machine configuration. Publish templates
    # with a user-owned, private EnvironmentFile rather than account paths or values.
    units=ART/'infra/report-progress-units'
    for path in sorted(units.glob('*')):
        lines=path.read_text().splitlines();had_environment=any(x.startswith(('Environment=','EnvironmentFile=')) for x in lines)
        data='\n'.join(x for x in lines if not x.startswith('Environment=') and not x.startswith('EnvironmentFile='))+'\n'
        if had_environment:data=data.replace('[Service]\n','[Service]\nEnvironmentFile=%h/.config/gpt-policy/runtime.env\n')
        data=data.replace(str(ROOT),'/absolute/path/to/agentic_robot')
        payload['unit_templates/'+path.name]=data.encode()
    payload['unit_templates/runtime.env.example']=b'CODEX_HOME=/absolute/path/to/existing/authorized/codex/home\nCODEX_BIN=/absolute/path/to/codex\nPATH=/absolute/path/to/node/bin:/usr/local/bin:/usr/bin:/bin\n# Optional: HTTP_PROXY, HTTPS_PROXY, ALL_PROXY. Never put auth.json in this bundle.\n'

    for name,data in payload.items():
        assert not re.search(rb'-----BEGIN (?:OPENSSH |RSA |EC )?PRIVATE KEY-----|github_pat_[A-Za-z0-9_]{30,}|ghp_[A-Za-z0-9]{30,}',data),name
    patch=subprocess.check_output(['git','-C',str(ROOT/'gpt-as-policy'),'diff','--','hybrid_rollout/robolab/robolab_server/scene_recording.py','hybrid_rollout/robolab/robolab_server/server.py','hybrid_rollout/robolab/robolab_server/session.py'])
    payload['source_patches/gpt-as-policy.patch']=patch
    payload['REPRODUCTION_BUNDLE.md']='''# 复现实验基建快照

包含运行脚本、调度器、逐步动作审计、回归测试、冻结案例与依赖锁、报告解读、运行手册和 GPT-as-Policy 源码补丁。按归档中的相对路径解压到工作区；先按 RUNBOOK.md 准备固定版本上游仓库与环境，再应用源码补丁。

运行入口：experiments/gpt_policy_repro_20260914/RUNBOOK.md。

环境配置保留本项目工作区与 mainskill 部署路径；迁移到其他机器时需调整 infra/env.sh 和部署脚本中的根路径、Python 路径及 SSH alias。模型权重、大型资产、SSH 密钥、API 凭据不在包内，下载清单和校验逻辑保留。用户已授权复用现有 Codex CLI 登录态：配置 CODEX_HOME/CODEX_BIN 与 ROLLOUT_USE_CURRENT_CODEX_HOME=1，由 CLI 自身读取认证，禁止复制或公开 auth.json。unit_templates 提供去掉私有环境的 systemd 模板，runtime.env 由部署者自行在本机以0600权限创建。此包是可审阅的基建快照，不表示全量实验已经完成。

当前有效范围只包含 GPT Direct 与 π0.5 + GPT Hybrid。遗留基线辅助脚本仅用于追溯，不应据此启动额外方法。RoboLab Direct 是本项目 EEF 适配器，历史实现未公开；当前完整结果、验证门和队列状态见GOAL.md。SSH传输缓解、只读归档补传及完整审计说明均在包内，前缀或连接中断不得计入完整成绩。\n\n包含两种环境的SSD容量维护脚本与定时服务：完整审计后，对RoboLab整工作区、RoboDojo封存Codex状态逐文件SHA256核验，归档到私有NAS，活动SQLite只使用本机ext4（早期/tmp，新RoboLab回合使用第二SSD）；不得放入NAS；运行数据库和日志冷归档不在公开包内。主实验维护使用哈希固定的v5原资格函数，安装和恢复边界见RUNBOOK.md。\n\nmanifest.json 给出每个文件的 SHA256 与固定源码提交（包括在线报告源码版本）。大型实验轨迹和在线站点源码留在工作区及报告 GitHub 仓库。
'''.encode()
    pins={name:subprocess.check_output(['git','-C',str(ROOT/path),'rev-parse','HEAD'],text=True).strip() for name,path in {'gpt-as-policy':'gpt-as-policy','RoboDojo':'upstream/RoboDojo','RoboLab':'upstream/RoboLab','openpi-robolab':'upstream/openpi-robolab','cosmos-framework':'upstream/cosmos-framework','dreamzero':'upstream/dreamzero','report_site':'gpt-policy-report-site'}.items()}
    manifest=dict(active_methods=['gpt_only','pi05_plus_gpt'],full_reproduction_complete=False,created_utc=datetime.now(timezone.utc).isoformat(),source_commits=pins,files=[dict(path=k,size=len(v),sha256=hashlib.sha256(v).hexdigest()) for k,v in payload.items()])
    payload['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
    out=ART/'deliverables';out.mkdir(exist_ok=True);archive=out/('infrastructure_bundle_'+args.date+'.tar.gz')
    assert not archive.exists(),'A dated bundle is immutable; choose a fresh date/snapshot name'
    with tarfile.open(archive,'w:gz') as tar:
        for name,data in payload.items():
            info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o755 if name.endswith('.sh') else 0o644;tar.addfile(info,io.BytesIO(data))
    with tarfile.open(archive) as tar:
        for row in manifest['files']:
            data=tar.extractfile(row['path']).read();assert len(data)==row['size'] and hashlib.sha256(data).hexdigest()==row['sha256']
    result=dict(path=str(archive.relative_to(ART)),files=len(manifest['files']),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),contents_verified=True)
    receipt=out/'infrastructure_bundle_verification.json';temporary=receipt.with_suffix('.tmp')
    temporary.write_text(json.dumps(result,indent=2)+'\n');temporary.replace(receipt);print(json.dumps(result))


if __name__=='__main__':main()
