"""A native full failure opens validation; transport or prefix evidence alone does not."""
import json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import advance_robolab_validated_queue as gate


class ValidationGate(unittest.TestCase):
    def test_full_native_failure_is_accepted(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp);(path/'attempt.json').write_text(json.dumps(dict(task='BlocksInBinTask',seed=0,method='gpt_only',ssh_cipher=gate.CIPHER)))
            with patch.object(gate,'native_complete',return_value=True),patch.object(gate,'qualified',return_value={'success':False}) as qualify:
                self.assertFalse(gate.validate_first(path,'gpt_only')['success']);qualify.assert_called_once()
    def test_prefix_or_wrong_transport_never_reaches_full_qualification(self):
        for complete,cipher in ((False,gate.CIPHER),(True,'default')):
            with self.subTest(complete=complete),tempfile.TemporaryDirectory() as tmp:
                path=Path(tmp);(path/'attempt.json').write_text(json.dumps(dict(task='BlocksInBinTask',seed=0,method='gpt_only',ssh_cipher=cipher)))
                with patch.object(gate,'native_complete',return_value=complete),patch.object(gate,'qualified') as qualify:
                    with self.assertRaises(AssertionError):gate.validate_first(path,'gpt_only')
                    qualify.assert_not_called()


if __name__=='__main__':unittest.main()
