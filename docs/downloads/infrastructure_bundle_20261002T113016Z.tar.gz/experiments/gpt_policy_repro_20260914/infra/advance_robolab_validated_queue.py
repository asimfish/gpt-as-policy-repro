"""After full Direct and Hybrid audits, enter the frozen 100-run RoboLab queue."""
import argparse
from datetime import datetime,timezone
import fcntl
import hashlib
import json
from pathlib import Path
import signal
import subprocess
import sys
from queue_robolab_two_methods import qualified,native_complete,write,read

ARTIFACTS=Path(__file__).resolve().parents[1]
CIPHER='aes128-gcm@openssh.com'


def validate_first(path,method):
    record=read(path/'attempt.json')
    assert (record['task'],record['seed'],record['method'])==('BlocksInBinTask',0,method)
    assert record.get('ssh_cipher')==CIPHER,'Only the validated transport may enter the queue'
    assert native_complete(path),'A prefix or infrastructure interruption cannot open the full queue'
    return qualified(path,dict(task='BlocksInBinTask',seed=0,method=method))


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--direct-attempt',required=True);a=p.parse_args()
    assert Path(a.direct_attempt).name==a.direct_attempt and a.direct_attempt.startswith('direct_')
    direct=ARTIFACTS/'robolab_gpt_campaign'/a.direct_attempt
    state=dict(schema='gpt_policy_robolab_validation_gate.v1',status='awaiting_complete_direct_audit',direct_attempt=a.direct_attempt,planned_method_runs=100,ssh_cipher=CIPHER)
    proc=None
    def persist():
        state['updated_utc']=datetime.now(timezone.utc).isoformat();write(ARTIFACTS/'robolab_validation_gate.json',state)
    def stop(*_):raise KeyboardInterrupt('Stopping this validation gate and its own child')
    signal.signal(signal.SIGTERM,stop)
    with Path('/tmp/gpt-policy-robolab-validation-gate.lock').open('a') as owner:
        fcntl.flock(owner,fcntl.LOCK_EX|fcntl.LOCK_NB);persist()
        try:
            # Wait through the current controller's archival boundary. No action,
            # connection, reset, or model invocation happens while it owns the lock.
            with Path('/tmp/gpt-policy-robolab-hybrid-controller.lock').open('a') as active:
                fcntl.flock(active,fcntl.LOCK_EX)
                validate_first(direct,'gpt_only')
            state.update(status='validating_first_hybrid',direct_audit_verified=True);persist()
            command=[sys.executable,str(ARTIFACTS/'infra/run_robolab_hybrid_remote.py'),
                '--method','pi05_plus_gpt','--task','BlocksInBinTask','--seed','0',
                '--sim-port','20600','--policy-port','20610','--policy-gpu','0','--sim-gpu','6','--ssh-cipher',CIPHER]
            proc=subprocess.Popen(command);code=proc.wait();proc=None
            state['hybrid_controller_exit']=code
            current=read(ARTIFACTS/'robolab_gpt_active.json')
            hybrid=ARTIFACTS/'robolab_gpt_campaign'/current['attempt']
            validate_first(hybrid,'pi05_plus_gpt')
            state.update(status='full_queue_enabled',hybrid_attempt=hybrid.name,hybrid_audit_verified=True);persist()
            frozen=ARTIFACTS/'infra/queue_robolab_two_methods_v1_20261002.py'
            manifest=read(ARTIFACTS/'robolab_queue_scheduler_v1_manifest.json')
            assert hashlib.sha256(frozen.read_bytes()).hexdigest()==manifest['sha256']
            command=[sys.executable,str(frozen)]
            proc=subprocess.Popen(command);code=proc.wait();proc=None
            assert code==0,'Full queue did not complete'
            final=read(ARTIFACTS/'robolab_gpt_queue_state.json')
            assert final['status']=='complete' and final['complete_method_runs']==100
            state.update(status='complete');persist()
        except BaseException as error:
            state.update(status='validation_interrupted',error_type=type(error).__name__,complete=False);persist()
            raise
        finally:
            if proc is not None and proc.poll() is None:
                proc.terminate()
                try:proc.wait(timeout=160)
                except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=10)


if __name__=='__main__':main()
