# RoboLab RPC 连接中断：当前证据

Observed：真实 Hybrid 在完成 7 轮 / 105 个 student 动作后，首轮 EEF 接管发送 chunk_step 时连接中断；两次 Direct 在首轮同一边界中断。模型身份、启动和 EEF 求解已经成功，动作回执未确认。三个尝试均归档，不计分，不重发不确定动作。

Expected：每次 EEF 求解后，下一条 H1 chunk_step 必须被服务端接收，执行一个原生控制步并返回匹配 episode_id、step_id 和 request_id 的回执。无回执立即作基础设施中断，不能按原生失败计分。

Scope：mainskill 上 pinned RoboLab / IsaacSim 5.1；原版二进制 lossless RPC，经本机 SSH loopback 转发；原始 Hybrid 与自有 Direct EEF 接口。主机自己的 RoboDojo 两方法队列不受该问题影响，继续运行。

## 首个已定位的不正确转换

`direct_20261002T095735Z_BlocksInBinTask_seed0` 的服务端记录：record_codex_decision 正常返回；eef_joint_target 在约 0.018 秒内返回且 wire_send_done；之后停在 receive_packet 的 `_read_exact(sock, 4)`。客户端堆栈停在 chunk_step 发包后的 receive_packet；SSH 隧道随后心跳超时。服务端没有收到该 chunk_step 的四字节头。因此目前无法把故障归因于 env.step 或 IK 求解。

两端单调时钟不同，不按日志墙钟邻接强行建立跨机因果；同一连接的请求顺序、RPC request_id、操作名和源端堆栈构成当前部分顺序证据。

## 可判别的假设与探针

| 假设 | 支持与边界 | 判别证据 |
| --- | --- | --- |
| 原生 EEF/单步运行时异常 | 故障紧邻 EEF；但服务端停在收包前，尚未执行该动作 | 原生 loopback EEF 求解→H1 执行通过，削弱此假设；与有组合来源/模型上下文的真实流程仍不完全等价 |
| SSH 转发、空闲或通道窗口问题 | SSH 自身心跳同时失效，服务器未收到请求 | 独立 echo、大帧往返通过；下一探针在真实运行时中等待90秒再求解并执行 EEF |
| 真实模型会话与宿主调度的交互 | 无模型探针与真实工作流不同 | 若 SSH 空闲探针通过，继续捕获真实模型会话的 SSH 通道事件与 TCP 队列，不能以探针通过替代真实回合验收 |

## 已通过的诊断

- `robolab_rpc_canary.json`：合成约2.7MB观测及15/1/5行动作包 SSH 往返一致，没有 GPU、模型或物理动作。
- `rpc_hold_loopback_20261002T102607Z`：原生1步与15步 hold 控制通过，共16步，不计分。
- `robolab_rpc_diagnostics/rpc_eef_loopback_20261002T103207Z/evidence.json`：原生 EEF 求解、H1 控制、finish 全部通过；没有 GPT、π0.5 或完整回合。动作链与仿真都真实，诊断身份 `diagnostic_hold` 明确排除成绩。

- `robolab_rpc_diagnostics/rpc_eef_ssh_20261002T103706Z/evidence.json`：真实仿真 + SSH +90秒空闲后 EEF 求解→H1 执行通过，动作约1.49秒。它削弱“空闲90秒必然失败”的假设，不能排除更长空闲、多通道/模型宿主交互或偶发网络故障。

下一条真实会话：`direct_20261002T104514Z_BlocksInBinTask_seed0`。同一适配器、模型和任务，没有修改控制策略；新增客户端只记录送出/读入字节数、操作名与 TCP_INFO，不读取包内容；SSH -vv 仅私有保存通道诊断。两个本地传输回归验证回包透明、丢 ACK 仍关闭且不重试。

诊断运行独占与正式 RoboLab 相同的远端服务锁；新进程、新目录、75秒 RPC 超时、唯一 STOP 标记，只清理自己启动的进程组。独立诊断服务只暴露原生无物理步 EEF 求解钩子，不伪造模型、组合来源、π0.5 身份或请求回执。诊断不使用正式案例结果目录。

Verdict：尚未 DIAGNOSED/FIXED。已排除一些简单假设，但确切根因未证明；100项 RoboLab 正式队列仍不启用。修改 SSH 心跳次数只是诊断设置，已经证明不能解决原来的故障。

## 10:53 UTC：首次明确传输层分歧

第三次真实 Direct 已在同一边界复现。客户端 wire 记录 H1 chunk_step 总长229字节 send_done，随后等4字节响应头。本机 loopback TCP 已收到1397字节，远端 loopback只收到1168字节，差额恰为229。外网 SSH TCP Send-Q 非零，unacked=1，持续重传，rto退避到32128ms；远端仿真未接收动作。快照见该 attempt 的 transport_snapshot.json；已停止自己的失败尝试，没有重发动作。

连接的 tos:0x10，存在后续 SACK/ACK 但第一个缺口没有填补。证据足以将当前问题定位到外网连接数据交付；尚不能断言是 QoS、中间设备、驱动/offload 或特定网络路径。下一对照为同一真实会话采用 SSH IPQoS=none，保留收发边界记录。即使对照通过，也先称传输缓解，不能直接称根因修复。

## 11:21 UTC：可运行的传输缓解与真实验证

零GPU/零模型 echo 已复现默认连接失败两次（tag 6a9f07e7355c424692ae212217bee90e、045cc14366cd483194260fcf8cdb405b）；包结构采用32字节episode/request ID和实际浮点动作，与早先短ID探针不同。默认协商算法从真实SSH日志核对为chacha20-poly1305@openssh.com。第一失败包约231字节，服务端未接收到。

AES128-GCM对照 tag 1bb9b3f6db7d4953b665401659233144：45个不同包长231–262字节全部ACK，大帧、H15/H1/H5也通过。随后再次运行默认策略，首个同类包仍失败。账本 robolab_rpc_transport_canaries/；复现命令 `safeduo/bin/python infra/check_robolab_ssh_rpc.py --packet-sweep [--cipher aes128-gcm@openssh.com]`。

仅为本实验SSH连接固定现代AES-GCM，不修改模型/任务/动作/协议，没有关闭host key校验、复制密钥或降低认证边界。真实 Direct attempt direct_20261002T111156Z_BlocksInBinTask_seed0 已完成至少65原生步。首1轮/5步prefix证明见 robolab_gpt_prefix_audits 对应不可变快照，PI调用0，完整成绩0；初始状态hash与原版Hybrid seed0相同，但hash本身不证明物理等价。

Verdict：MITIGATED。现有证据足以证明这条WAN路径的默认SSH小包交付故障，以及AES-GCM对本复现链路的缓解；不能指认具体设备、驱动或通用密码实现缺陷。全原生回合仍待完成。客户端字节计数纯观测、无payload内容，丢ACK关闭且不重试的两个契约测试通过。运行和门控均仅清理自己启动的进程组。
