import errno
import unittest
from unittest.mock import patch
from queue_student_campaign import campaign_busy

class QueueTests(unittest.TestCase):
    def test_lock_contention_linux_and_nfs(self):
        for code in (errno.EACCES,errno.EAGAIN):
            with patch('queue_student_campaign.fcntl.flock',side_effect=OSError(code,'busy')):
                self.assertTrue(campaign_busy(object()))
        with patch('queue_student_campaign.fcntl.flock'):
            self.assertFalse(campaign_busy(object()))

    def test_other_lock_errors_propagate(self):
        with patch('queue_student_campaign.fcntl.flock',side_effect=OSError(errno.EIO,'I/O failure')):
            with self.assertRaises(OSError):campaign_busy(object())
