"""Exercise current-login opt-in at the real shell launch boundary."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest


class CurrentCodexLaunchTest(unittest.TestCase):
    def launch(self, method, authorized):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            script = root/'run_original_controller.sh'
            shutil.copyfile(Path(__file__).with_name(script.name), script)
            python = root/'bin/python'
            python.parent.mkdir()
            python.write_text('''#!/usr/bin/python3
import json,os,sys
print(json.dumps({'args':sys.argv[1:],'home':os.environ['CODEX_HOME'],'profile':os.environ['ROLLOUT_AUTH_PROFILE'],'state':os.environ['ROLLOUT_CODEX_STATE_DIR'],'path':os.environ['PATH']}))
''')
            python.chmod(0o755)
            (root/'env.sh').write_text(f'export ROBO_PYTHON="{python}"\nexport PI05_CHECKPOINT="/fixture/checkpoint"\n')
            home = root/'login'
            home.mkdir()
            config = home/'config.toml'
            config.write_text('model="gpt-6-astra"\n')
            before = config.read_bytes()
            env = {k:v for k,v in os.environ.items() if not k.startswith('ROLLOUT_')}
            env.update(CODEX_HOME=str(home), CODEX_BIN='/usr/bin/true',
                       ROLLOUT_USE_CURRENT_CODEX_HOME='1' if authorized else '0')
            result = subprocess.run(['bash', str(script), method, str(root/'output'), 'fixture_task'],
                                    env=env, text=True, capture_output=True, timeout=10)
            self.assertEqual(config.read_bytes(), before)
            if not authorized:
                self.assertNotEqual(result.returncode, 0)
                return
            self.assertEqual(result.returncode, 0, result.stderr)
            data = json.loads(result.stdout)
            self.assertEqual(data['home'], str(home))
            self.assertEqual(data['profile'], 'codex_a')
            self.assertEqual(data['path'].split(':')[0], str(python.parent))
            state = Path(data['state'])
            self.assertEqual(state.parent, Path('/tmp'))
            self.assertEqual(state.stat().st_mode & 0o777, 0o700)
            state.rmdir()
            self.assertEqual('--checkpoint' in data['args'], method == 'pi05_plus_gpt')
            self.assertEqual(data['args'][data['args'].index('--max-decisions')+1], '0')

    def test_current_login_requires_explicit_opt_in(self):
        self.launch('gpt_only', False)

    def test_direct_uses_authorized_login_without_student(self):
        self.launch('gpt_only', True)

    def test_hybrid_keeps_checkpoint_and_native_horizon(self):
        self.launch('pi05_plus_gpt', True)
