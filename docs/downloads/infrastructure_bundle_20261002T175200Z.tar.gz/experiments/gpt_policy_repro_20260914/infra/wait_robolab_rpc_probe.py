"""Own a diagnostic service lifetime without consuming its single RPC connection."""
import argparse,json,time
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--output',type=Path,required=True);p.add_argument('--task');p.add_argument('--seed');p.add_argument('--port');p.add_argument('--eef',action='store_true')
a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
(a.output/'waiting.json').write_text(json.dumps(dict(benchmark_eligible=False,waiting=True))+'\n')
for _ in range(600):
    if (a.output/'STOP').exists():break
    time.sleep(1)
else:raise TimeoutError('Diagnostic owner timeout')
