#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../../.." && pwd)"
SOURCE="$ROOT/upstream/checkpoints/pi05_droid_jointpos"
SSH=(ssh -o BatchMode=yes -o UserKnownHostsFile=/home/liyufeng/.ssh/known_hosts_a100 -o StrictHostKeyChecking=yes -o ServerAliveInterval=60 -o ServerAliveCountMax=10)
MANIFEST_HASH=$(sha256sum "$SOURCE/download_manifest.json" | cut -d' ' -f1)
rsync -a --partial --append-verify --timeout=300 --stats -e 'ssh -o BatchMode=yes -o UserKnownHostsFile=/home/liyufeng/.ssh/known_hosts_a100 -o StrictHostKeyChecking=yes -o ServerAliveInterval=60 -o ServerAliveCountMax=10' "$SOURCE/" mainskill:/home/dataset-assist-0/liyufeng/agentic_robot/upstream/checkpoints/pi05_droid_jointpos/
"${SSH[@]}" mainskill python3 - "$MANIFEST_HASH" <<'PY'
from pathlib import Path,PurePosixPath
import hashlib,json,sys
root=Path('/home/dataset-assist-0/liyufeng/agentic_robot/upstream/checkpoints/pi05_droid_jointpos').resolve()
raw=(root/'download_manifest.json').read_bytes()
assert hashlib.sha256(raw).hexdigest()==sys.argv[1]
m=json.loads(raw)
assert m['source']=='gs://openpi-assets-simeval/pi05_droid_jointpos'
for item in m['files']:
 relative=PurePosixPath(item['path'])
 assert not relative.is_absolute() and '..' not in relative.parts
 p=(root/relative).resolve();p.relative_to(root)
 assert p.stat().st_size==item['size'],p
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
 assert h.hexdigest()==item['sha256'],p
 print('VERIFIED',item['path'],flush=True)
(root/'transfer_verification.json').write_text(json.dumps({'verified':True,'files':len(m['files']),'manifest_sha256':sys.argv[1],'source':m['source']},indent=2)+'\n')
print('CHECKPOINT_TRANSFER_VERIFIED',flush=True)
PY
