"""Bind original RoboLab model decisions and pi05/EEF actions to native recorder chunks."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np


def read(path):
    return json.loads(path.read_text())


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(8*1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def audit(run, decisions=None):
    out, sim = run/'rollout', run/'remote/sim'
    workspace = out/'codex_workspace'
    worker, identity = read(workspace/'worker.json'), read(out/'run.json')
    assert worker['model'] == identity['teacher_model'] == 'gpt-6-astra'
    assert worker['reasoning_effort'] == identity['teacher_reasoning_effort'] == 'xhigh'
    assert worker['prompt_sha256'] == identity['teacher_prompt_sha256'] == digest(workspace/'PROMPT.md')
    config = read(workspace/'launch.json')['config']
    assert config['model'] == 'gpt-6-astra' and config['model_reasoning_effort'] == 'xhigh'
    direct=identity.get('evaluation_method')=='gpt_only'
    assert worker['tools'] == (['robolab_start','robolab_execute'] if direct else ['robolab_start','pi05_infer','robolab_execute'])
    policy=None
    if direct:
        assert worker['pi05_enabled'] is identity['pi05_enabled'] is False
        assert identity['pi05_inference_calls']==0 and identity['checkpoint'] is None
        assert identity['student_backend'] is identity['student_identity_sha256'] is None
        assert not (run/'remote/policy_identity.json').exists()
        assert not list(out.glob('proposal_*.npz'))
    else:
        policy = read(run/'remote/policy_identity.json')
        assert policy['config'] == identity['config'] == 'pi05_droid_jointpos_polaris'
        assert policy['backend'] == identity['student_backend'] == 'OpenPI/JAX'
        assert policy['checkpoint_sha256'] == identity['student_identity_sha256']
        assert identity['student_server_metadata']['inferences'] == policy['inferences'] == 0
    assert identity['no_rollback'] is True
    history = read(out/'history.json')
    complete = decisions is None
    if not complete:
        assert type(decisions) is int and 0 < decisions <= len(history)
        history = history[:decisions]
    assert history
    directories = list(sim.glob('*/initial_scene.json'))
    assert len(directories) == 1
    native, initial = directories[0].parent, read(directories[0])
    assert initial['state_sha256'] == identity['initial_state_hash']
    assert initial['episode_id'] == native.name
    calls = {}
    for path in sorted(workspace.glob('call_*_request.json')):
        request = read(path)
        result = path.with_name(path.name.replace('_request.json','_result.json'))
        if request['tool'] != 'robolab_execute' or not result.is_file() or read(result).get('no_execution'):
            continue
        args = request['arguments']
        if isinstance(args,str):
            args = json.loads(args)
        key = args['response']['request_id']
        assert key not in calls, 'Duplicate accepted physical decision'
        calls[key] = (request,args,path,result)
    needed = {calls[h['response']['request_id']][0]['call_id'] for h in history}
    events = {}
    with (workspace/'rpc_out.jsonl').open() as stream:
        for line in stream:
            # An in-flight trailing line is immaterial to an already completed prefix.
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                if complete:
                    raise
                continue
            params = event.get('params',{})
            if event.get('method') == 'item/tool/call' and params.get('callId') in needed:
                assert params['callId'] not in events
                events[params['callId']] = event
    assert needed == set(events), 'Accepted physical request lacks model thread origin'
    files = [out/'run.json',out/'history.json',workspace/'rpc_out.jsonl',workspace/'worker.json',workspace/'launch.json',
             workspace/'PROMPT.md',directories[0]]
    if not direct:files.append(run/'remote/policy_identity.json')
    count = chunk_index = 0
    totals = dict(student=0,edit=0,eef=0)
    event_hashes = []
    last = None
    for index,h in enumerate(history):
        assert h['decision'] == index and h['start_tick'] == count
        request_path, response_path = out/f'request_{index:03d}.json', out/f'response_{index:03d}.json'
        request,response = read(request_path),read(response_path)
        assert response == h['response'] and response['request_id'] == request['request_id']
        assert request['step_id'] == count and request['episode_id'] == native.name
        if not direct:assert request['inference_index'] == index
        else:assert request['prediction_id'] is None and h['prediction_id'] is None
        assert request['prediction_id'] == h['prediction_id']
        call,args,call_path,result_path = calls[response['request_id']]
        event = events[call['call_id']]
        assert event['params']['threadId'] == worker['thread_id']
        assert event['params']['tool'] == 'robolab_execute'
        rpc_args = event['params']['arguments']
        if isinstance(rpc_args,str):
            rpc_args=json.loads(rpc_args)
        assert rpc_args == args
        event_hashes.append(hashlib.sha256(json.dumps(event,sort_keys=True).encode()).hexdigest())
        receipt_path = native/'codex_decisions'/f'{index:03d}.json'
        receipt = read(receipt_path)
        assert receipt['response'] == response and receipt['step_id'] == count
        assert receipt['episode_id'] == native.name and receipt['prediction_id'] == h['prediction_id']
        assert h['simulator_decision_receipt']['physical_steps'] == 0
        mode = response['mode']
        assert mode in totals
        if direct:assert mode=='eef'
        execution,proposal = out/f'execution_{index:03d}.npz',out/f'proposal_{index:03d}.npz'
        input_path=out/'observations'/f'{index:03d}'/'observation.npz' if direct else proposal
        with np.load(execution,allow_pickle=False) as x,np.load(input_path,allow_pickle=False) as p:
            actions,states = x['actions'],x['states']
            n = len(actions)
            assert 0 < n == h['executed_steps'] <= response['steps'] <= (15 if mode=='student' else 5)
            assert actions.shape == states.shape == (n,8)
            assert np.isfinite(actions).all() and np.isfinite(states).all()
            if not direct:
                assert p['actions'].shape == p['raw_actions'].shape == (15,8)
                assert np.isfinite(p['raw_actions']).all()
                transformed = p['raw_actions'].copy()
                transformed[:,-1] = (transformed[:,-1]>.5).astype(np.float32)
                assert np.array_equal(transformed,p['actions'])
            if mode == 'student':
                assert np.array_equal(actions,p['actions'][:n])
            else:
                edit_path=out/f'edit_{index:03d}.json'
                edits=[e for e in read(edit_path) if e['valid']]
                assert len(edits)==n and np.array_equal(actions,[e['executed_action'] for e in edits])
                files.append(edit_path)
            offset=0
            while offset < n:
                path = native/f'chunk_{chunk_index:05d}.npz'
                with np.load(path,allow_pickle=False) as z:
                    length=len(z['step_id'])
                    assert length>0 and length<=(n-offset) and (mode=='student' or length==1)
                    assert np.array_equal(z['step_id'],np.arange(count,count+length))
                    assert np.array_equal(z['action'],actions[offset:offset+length])
                    assert np.array_equal(z['proposed'],z['action'])
                    assert str(z['episode_id'])==native.name
                    assert str(z['initial_state_hash'])==initial['state_sha256']
                    assert str(z['student_policy_sha256'])==('' if direct else policy['checkpoint_sha256'])
                    assert str(z['source'])==('student' if mode=='student' else 'gpt_eef')
                    assert str(z['student_prediction_id'])==(h['prediction_id'] if mode=='student' else '')
                    assert str(z['teacher_request_id'])==('' if mode=='student' else response['request_id'])
                    if offset==0:
                        for key in ('main_images','wrist_images','states'):
                            assert np.array_equal(z[key][0],p[key]), 'Policy input differs from native pre-action observation'
                    post_states=np.concatenate([z['states'][1:],z['final_states'][None]],axis=0)
                    assert np.array_equal(post_states,states[offset:offset+length])
                    assert not np.any(z['terminated'][:-1]) and not np.any(z['truncated'][:-1])
                    last={k:bool(z[k][-1]) for k in ('terminated','truncated','success')}
                    if index<len(history)-1 or offset+length<n:
                        assert not last['terminated'] and not last['truncated']
                files.append(path)
                count+=length;offset+=length;chunk_index+=1
            assert h['end_tick']==count
        totals[mode]+=n
        files.extend([request_path,response_path,call_path,result_path,receipt_path,execution,input_path])
    if complete:
        result_path,summary_path = out/'result.json',native/'summary.json'
        result,summary = read(result_path),read(summary_path)
        assert result['complete'] is True and summary['complete'] is True
        assert last['terminated'] or last['truncated']
        assert result['step_id']==summary['control_steps']==count
        assert result['decisions']==len(history)
        assert result['predictions']==(0 if direct else len(history))
        assert totals==dict(student=result['student_steps'],edit=result['edited_steps'],
                           eef=result['gpt_eef_steps'] if direct else result['recovery_steps'])
        if direct:assert result['pi05_inference_calls']==0
        assert all(result[k]==summary[k]==v for k,v in last.items())
        assert identity['max_episode_steps']==summary['native_max_episode_steps']==summary['max_episode_steps']
        assert (identity['task'],identity['seed'])==(summary['task'],summary['seed'])
        assert len(list(native.glob('chunk_*.npz')))==chunk_index
        files.extend([result_path,summary_path])
    prefix_scope='completed_robolab_direct_decision_prefix_only' if direct else 'completed_robolab_hybrid_decision_prefix_only'
    return dict(verified=True,complete_episode=complete,scope='complete_native_episode' if complete else prefix_scope,
        method='gpt_only' if direct else 'pi05_plus_gpt',model=worker['model'],reasoning_effort='xhigh',decisions=len(history),native_actions=count,
        pi05_inference_calls=0 if direct else len(history),actions_by_mode=totals,terminal=last,max_absolute_action_error=0,
        initial_state_hash=initial['state_sha256'],student_identity_sha256=None if direct else policy['checkpoint_sha256'],
        limitation='Recorded actions and decision provenance checked; no independent IK or physics recomputation; new fixed-seed cohort.',
        model_tool_event_sha256=event_hashes,files_sha256={str(p.relative_to(run)):digest(p) for p in files})


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run',type=Path);parser.add_argument('--decisions',type=int)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();proof=audit(args.run,args.decisions)
    args.output.write_text(json.dumps(proof,indent=2)+'\n')
    print(json.dumps({k:v for k,v in proof.items() if k not in ('files_sha256','model_tool_event_sha256')}))
