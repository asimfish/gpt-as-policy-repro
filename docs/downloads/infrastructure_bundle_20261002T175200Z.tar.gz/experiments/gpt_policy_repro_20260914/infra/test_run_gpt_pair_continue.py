import os
from pathlib import Path

def test_continue_flag_is_exposed():
    text=Path(__file__).with_name("run_gpt_pair.py").read_text()
    assert "--continue-after-failure" in text
    assert "not a.continue_after_failure" in text
