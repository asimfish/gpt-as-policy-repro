#!/usr/bin/env bash
set -euo pipefail
ROOT=/home/dataset-assist-0/liyufeng/agentic_robot
ART="$ROOT/experiments/gpt_policy_repro_20260914"
ENV="$ROOT/venvs/dreamzero"
export HTTPS_PROXY=http://127.0.0.1:18997 HTTP_PROXY=http://127.0.0.1:18997 NO_PROXY=127.0.0.1,localhost
export UV_CACHE_DIR="$ROOT/uv-cache" UV_PYTHON_INSTALL_DIR="$ROOT/uv-python"
export UV_HTTP_TIMEOUT=300 UV_CONCURRENT_DOWNLOADS=3
export TMPDIR="$ROOT/build-tmp/dreamzero"
mkdir -p "$TMPDIR" "$ROOT/venvs"
exec 9>"$ROOT/venvs/dreamzero-bootstrap.lock"
flock -n 9
lock="$ART/fixtures/dreamzero_runtime.lock"
[[ $(sha256sum "$lock" | cut -d ' ' -f1) == a4fd4213df935225bd0184055cdec3d657153e3a5cbba261445e4c6b3ea74d4b ]]
if [[ ! -x "$ENV/bin/python" ]]; then
 /home/batchcom/.local/bin/uv venv --python /home/batchcom/gpt-policy-runtime/robolab51/bin/python "$ENV"
fi
# This is our recorded hash lock, generated from the pinned upstream pyproject.
# Package versions and CUDA 12.9 torch selection must remain fixed.
/home/batchcom/.local/bin/uv pip sync --python "$ENV/bin/python" --require-hashes \
 --torch-backend cu129 "$lock"
cd "$ROOT/upstream/dreamzero"
/home/batchcom/.local/bin/uv pip install --python "$ENV/bin/python" --no-deps .
"$ENV/bin/python" - <<'PY'
import importlib.metadata as m,json
from pathlib import Path
import torch
p=Path('/home/dataset-assist-0/liyufeng/agentic_robot/experiments/gpt_policy_repro_20260914/mainskill/dreamzero_environment.json')
p.write_text(json.dumps({'dependencies_installed':True,'inference_verified':False,'source_commit':'ab790c198fbce33503358efbbd4187ce9a89adf3','lock_sha256':'a4fd4213df935225bd0184055cdec3d657153e3a5cbba261445e4c6b3ea74d4b','torch_cuda':torch.version.cuda,'versions':{k:m.version(k) for k in ['dreamzero','torch','torchvision','numpy']}},indent=2)+'\n')
print(p.read_text())
PY
