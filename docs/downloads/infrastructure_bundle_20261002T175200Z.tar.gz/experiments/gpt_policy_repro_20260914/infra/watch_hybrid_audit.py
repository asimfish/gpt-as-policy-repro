"""Persist a full audit at native completion, or an explicitly incomplete prefix on interruption."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import time
from audit_hybrid_actions import audit


def main():
    p=argparse.ArgumentParser();p.add_argument('run',type=Path);a=p.parse_args()
    deadline=time.monotonic()+13*3600
    while time.monotonic()<deadline:
        result_path=a.run/'rollout/result.json';attempt_path=a.run/'attempt.json'
        result=json.loads(result_path.read_text()) if result_path.exists() else {}
        attempt=json.loads(attempt_path.read_text()) if attempt_path.exists() else {}
        complete=result.get('complete') is True and (result.get('terminated') or result.get('truncated'))
        stopped=attempt.get('status') not in (None,'starting','running')
        if complete or stopped:
            history_path=a.run/'rollout/history.json'
            history=json.loads(history_path.read_text()) if history_path.exists() else []
            if not history:
                proof=dict(verified=False,complete_episode=False,reason='No completed decisions to audit')
            else:
                proof=audit(a.run, None if complete else len(history))
            name='complete_action_audit.json' if complete else 'interrupted_prefix_audit.json'
            temp=a.run/(name+'.tmp');temp.write_text(json.dumps(proof,indent=2)+'\n');temp.replace(a.run/name)
            summary={k:v for k,v in proof.items() if k not in ('files_sha256','model_tool_event_sha256')}
            summary['observed_utc']=datetime.now(timezone.utc).isoformat()
            print(json.dumps(summary),flush=True)
            return
        time.sleep(20)
    raise TimeoutError('No terminal result or stopped supervisor within 13 hours')


if __name__=='__main__':main()
