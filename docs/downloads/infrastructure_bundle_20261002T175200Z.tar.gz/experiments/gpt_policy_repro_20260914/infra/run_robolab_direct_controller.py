"""Owned RoboLab Direct bootstrap with the upstream persistent Codex event loop."""
import argparse
import hashlib
import json
from pathlib import Path
import signal
import subprocess
import traceback

from hybrid_rollout.robolab.io import write_json
from hybrid_rollout.robolab.settings import MODEL,EFFORT
from hybrid_rollout.robolab.skill.run import CodexPolicy,agent_config,toml_value
from hybrid_rollout.robolab.skill.schema import _obj
from hybrid_rollout.robolab.skill.transport import StdioAppServer
from hybrid_rollout.robolab.skill.workspace import prepare_workspace
from robolab_direct_tools import DirectTools

SKILL_ROOT=Path(__file__).parent/'robolab_direct_skill'


def tool_specs():
    number={'type':'number'}
    string={'type':'string'}
    target=_obj(dict(position=dict(type='array',items=number,minItems=3,maxItems=3),
        quaternion_wxyz=dict(type='array',items=number,minItems=4,maxItems=4),
        gripper_closed={'type':'boolean'}))
    response=_obj(dict(request_id=string,mode=dict(type='string',enum=['eef']),
        steps=dict(type='integer',minimum=1,maximum=5),reason=string,target=target))
    return [dict(type='function',name='robolab_start',description='Start one fresh Direct episode and return RGB/proprio.',
                 inputSchema=_obj(dict(task=string,output_dir=string))),
            dict(type='function',name='robolab_execute',description='Execute one bounded Direct EEF segment and return actual observation and native terminal status.',
                 inputSchema=_obj(dict(observation_path=string,response=response,output_dir=string)))]


class DirectPolicy(CodexPolicy):
    def __init__(self,workspace,codex,*,timeout=900,transport_factory=StdioAppServer):
        self.workspace=Path(workspace)
        self.workspace.mkdir(parents=True,exist_ok=False)
        self.agent_workspace=prepare_workspace(self.workspace,SKILL_ROOT)
        config_path=self.agent_workspace/'workspace.json'
        config=json.loads(config_path.read_text())
        config.update(source_root=str(Path(__file__).resolve().parents[3]/'gpt-as-policy'),
            adapter_root=str(Path(__file__).parent),evaluation_method='gpt_only',proposals_path=None)
        write_json(config_path,config)
        agents=self.agent_workspace/'AGENTS.md'
        agents.write_text(agents.read_text().replace('Three additional tools','Two additional tools'))
        self.timeout=timeout
        skill=(SKILL_ROOT/'SKILL.md').read_text()
        gate=(SKILL_ROOT/'gate_prompt.md').read_text()
        context=(SKILL_ROOT/'context/teacher_context.md').read_text()
        self.prompt=skill+'\n\n# Direct observation-to-action context\n\n'+gate+'\n\n'+context+'\n\nAgent working directory: '+str(self.agent_workspace)
        self.prompt_sha256=hashlib.sha256(self.prompt.encode()).hexdigest()
        (self.workspace/'PROMPT.md').write_text(self.prompt)
        (self.workspace/'SKILL.md').write_text(skill)
        specs=tool_specs();write_json(self.workspace/'tools.json',specs)
        version=subprocess.run([codex,'--version'],capture_output=True,text=True,check=True).stdout.strip()
        config=agent_config(self.workspace,self.agent_workspace)
        argv=[codex,'app-server','--stdio','--strict-config']
        for key,value in config.items():
            argv+=['-c',key+'='+toml_value(value)]
        write_json(self.workspace/'launch.json',dict(argv=argv,config=config))
        self.transport=transport_factory(argv,self.workspace)
        try:
            self.transport.request('initialize',dict(clientInfo=dict(name='robolab-direct-policy',version='1'),
                capabilities=dict(experimentalApi=True)),timeout)
            self.transport.notify('initialized',{})
            response=self.transport.request('thread/start',dict(cwd=str(self.agent_workspace),model=MODEL,
                modelProvider='openai',config=dict(model_reasoning_effort=EFFORT),developerInstructions=self.prompt,
                dynamicTools=specs,ephemeral=False,allowProviderModelFallback=False,approvalPolicy='never',
                approvalsReviewer='auto_review',permissions='rollout_agent',
                runtimeWorkspaceRoots=[str(self.agent_workspace)]),timeout)
            if response.get('model')!=MODEL or response.get('reasoningEffort')!=EFFORT:
                raise RuntimeError('Codex Direct model/effort identity mismatch')
            self.thread_id=response['thread']['id']
            write_json(self.workspace/'worker.json',dict(model=MODEL,reasoning_effort=EFFORT,
                model_provider='openai',evaluation_method='gpt_only',codex_version=version,
                thread_id=self.thread_id,pid=self.transport.process.pid,prompt_sha256=self.prompt_sha256,
                tools=[s['name'] for s in specs],no_rollback=True,pi05_enabled=False,
                implementation='owned_EEF_adapter_on_upstream_RoboLab',
                baseline_full_conversation_available=False,historical_Direct_source_and_prompt_recovered=False))
        except BaseException:
            self.close()
            raise

    def _turn(self,text):
        return super()._turn(text.replace('the three rollout service tools','the two Direct rollout service tools'))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True);parser.add_argument('--task',required=True)
    parser.add_argument('--codex',required=True);parser.add_argument('--sim-port',type=int,default=20600)
    parser.add_argument('--trace-rpc',action='store_true');parser.add_argument('--seed',type=int,default=0);parser.add_argument('--max-decisions',type=int,default=100000)
    args=parser.parse_args();output=args.output.resolve();output.mkdir(parents=True,exist_ok=False)
    worker=rollout=None
    def terminate(*_):
        raise KeyboardInterrupt('Stopping this owned Direct rollout')
    signal.signal(signal.SIGTERM,terminate)
    try:
        worker=DirectPolicy(output/'codex_workspace',args.codex)
        rpc_options={}
        if args.trace_rpc:
            from trace_robolab_rpc import trace_factory
            rpc_options['rpc_factory']=trace_factory(output/'rpc_wire_trace.jsonl')
        rollout=DirectTools(output,args.task,sim_port=args.sim_port,seed=args.seed,**rpc_options,
            max_decisions=args.max_decisions,prompt_sha256=worker.prompt_sha256)
        worker.run(rollout)
    except BaseException:
        write_json(output/'failure.json',dict(error=traceback.format_exc(),completed=False,
            step_id=rollout.tick if rollout else 0))
        if rollout and rollout.episode and rollout.phase!='done':
            try:rollout.finish('controller_error')
            except Exception:pass  # No reconnect or uncertain action retry.
        raise
    finally:
        if rollout:rollout.close()
        if worker:worker.close()


if __name__=='__main__':main()
