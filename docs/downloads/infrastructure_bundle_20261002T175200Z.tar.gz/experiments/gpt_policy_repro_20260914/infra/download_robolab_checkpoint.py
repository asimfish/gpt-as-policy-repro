"""Download the official public GCS checkpoint with generation and MD5 verification."""
import argparse
import base64
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path, PurePosixPath
import urllib.parse
import urllib.request


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--manifest',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    data=json.loads(args.manifest.read_text())
    if data.get('nextPageToken'): raise ValueError('Incomplete object manifest')
    args.output.mkdir(parents=True,exist_ok=True)
    def download(item):
        name=PurePosixPath(item['name'])
        if name.is_absolute() or '..' in name.parts or name.parts[0]!='pi05_droid_jointpos':
            raise ValueError('Unexpected object path')
        target=args.output.joinpath(*name.parts[1:])
        target.parent.mkdir(parents=True,exist_ok=True)
        def verify(path):
            md5,sha=hashlib.md5(),hashlib.sha256()
            size=0
            with path.open('rb') as source:
                for chunk in iter(lambda:source.read(8*1024*1024),b''):
                    md5.update(chunk);sha.update(chunk);size+=len(chunk)
            if size!=int(item['size']) or base64.b64encode(md5.digest()).decode()!=item['md5Hash']:
                raise ValueError(f'Object checksum/size mismatch: {name}')
            return sha.hexdigest()
        if not target.exists():
            url='https://storage.googleapis.com/download/storage/v1/b/openpi-assets-simeval/o/'+urllib.parse.quote(str(name),safe='')+'?alt=media&generation='+item['generation']
            partial=target.with_name(target.name+'.partial')
            with urllib.request.urlopen(url,timeout=120) as response, partial.open('wb') as out:
                while chunk:=response.read(8*1024*1024): out.write(chunk)
            digest=verify(partial)
            partial.replace(target)
        else:
            digest=verify(target)
        row=dict(path=str(target.relative_to(args.output)),sha256=digest,size=int(item['size']),generation=item['generation'])
        print(json.dumps(row),flush=True)
        return row
    with ThreadPoolExecutor(max_workers=4) as pool:
        rows=list(pool.map(download,data['items']))
    (args.output/'download_manifest.json').write_text(json.dumps(dict(source='gs://openpi-assets-simeval/pi05_droid_jointpos',files=rows),indent=2)+'\n')

if __name__=='__main__': main()
