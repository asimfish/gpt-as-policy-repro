#!/usr/bin/env bash
set -euo pipefail
ROOT=/mnt/nas/data/lyf/agentic_robot
INFRA="$ROOT/experiments/gpt_policy_repro_20260914/infra"
for i in $(seq 1 720); do
 [[ -f "$ROOT/upstream/checkpoints/openpi-wheels/download_manifest.json" ]] && break
 sleep 10
done
[[ -f "$ROOT/upstream/checkpoints/openpi-wheels/download_manifest.json" ]]
python3 "$INFRA/transfer_checkpoint_chunks.py" --checkpoint openpi-wheels
ssh -o BatchMode=yes -o ConnectTimeout=15 -o UserKnownHostsFile=/home/liyufeng/.ssh/known_hosts_a100 -o StrictHostKeyChecking=yes mainskill 'bash -s' <<'REMOTE'
set -euo pipefail
ROOT=/home/dataset-assist-0/liyufeng/agentic_robot
export UV_CACHE_DIR="$ROOT/uv-cache"
export UV_HTTP_TIMEOUT=300 UV_CONCURRENT_DOWNLOADS=3
exec 9>"$ROOT/venvs/openpi-bootstrap.lock"
flock 9
/home/batchcom/.local/bin/uv pip install --python "$ROOT/venvs/openpi-robolab/bin/python" --no-deps --no-index --find-links "$ROOT/upstream/checkpoints/openpi-wheels" --find-links "$ROOT/upstream/checkpoints/openpi-build-wheels" --requirements "$ROOT/upstream/checkpoints/openpi-wheels/requirements.txt"
flock -u 9
nohup bash "$ROOT/experiments/gpt_policy_repro_20260914/infra/bootstrap_mainskill_openpi.sh" >> "$ROOT/experiments/gpt_policy_repro_20260914/mainskill/openpi_bootstrap.log" 2>&1 < /dev/null &
echo "OpenPI restart PID: $!"
REMOTE
