"""Resume a bounded 50-case student cohort, one fresh native episode at a time."""
import errno
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parents[1]
METHOD=os.environ.get('CAMPAIGN_METHOD','pi05_prefix15')
if METHOD not in ('pi05_prefix15','pi05_chunk50'):
    raise ValueError('Unsupported campaign method')
OUTPUT=ROOT/('chunk50_control' if METHOD=='pi05_chunk50' else 'student_native_campaign')


def emit(event, **fields):
    print(json.dumps(dict(event=event,utc=datetime.now(timezone.utc).isoformat(),**fields)),flush=True)


def pending():
    completed={json.loads(p.read_text())['case'] for p in OUTPUT.glob('**/attempt.json')
               if json.loads(p.read_text()).get('status') in ('complete','invalid_native_layout')}
    return [p for p in sorted((ROOT/'fixtures/cases').glob('mix__*.json')) if p.stem not in completed]


def campaign_busy(handle):
    try:
        fcntl.flock(handle,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except OSError as error:
        if error.errno in (errno.EACCES,errno.EAGAIN):
            return True
        raise
    return False


def main():
    OUTPUT.mkdir(exist_ok=True)
    lock=(OUTPUT/'.queue.lock').open('a')
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    for _ in range(50):
        while True:
            cases=pending()
            if not cases:
                emit('cohort_finished');return
            with (OUTPUT/'.campaign.lock').open('a') as campaign:
                if campaign_busy(campaign):
                    emit('waiting_for_current_campaign')
                    time.sleep(30)
                    continue
            gpu=os.environ.get('CAMPAIGN_GPU','0')
            if gpu=='auto':
                available=subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.free','--format=csv,noheader,nounits'],text=True)
                candidates=[line.split(',') for line in available.strip().splitlines()]
                gpu=max(candidates,key=lambda row:int(row[1]))[0].strip()
            info=subprocess.check_output(['nvidia-smi','--id='+gpu,'--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True)
            free=int(info.strip())
            if free<20000:
                emit('waiting_for_gpu',gpu=gpu,free_mib=free,required_mib=20000)
                time.sleep(30);continue
            break
        os.environ.update(CUDA_VISIBLE_DEVICES=gpu,SIM_GPU=gpu)
        before=set(OUTPUT.glob('**/attempt.json'))
        emit('launching',case=cases[0].stem,method=METHOD,gpu=gpu)
        subprocess.run([sys.executable,str(ROOT/'infra/run_batch_student.py'),
            '--method',METHOD,'--cases',str(ROOT/'fixtures/cases'),'--output',str(OUTPUT),
            '--sim-wrapper',str(ROOT/'infra/run_sim_server.sh'),
            '--policy-wrapper',str(ROOT/'infra/run_pi05_server.sh'),
            '--checkpoint',os.environ['PI05_CHECKPOINT'],
            '--eval-manifest',str(ROOT/'fixtures/evaluation_manifest.json'),
            '--limit','1','--skip-completed','--max-decisions','0','--base-port',('19600' if METHOD=='pi05_chunk50' else '19400')],check=True)
        new=set(OUTPUT.glob('**/attempt.json'))-before
        attempts=[json.loads(p.read_text()) for p in new]
        for script in ('build_reproduction_report.py','render_dashboard.py'):
            subprocess.run([sys.executable,str(ROOT/'infra'/script),str(ROOT)],check=True)
        report=json.loads((ROOT/'independent_report.json').read_text())
        metrics=report['summary'].get('pi05_prefix15',{})
        method_metrics=report['summary'].get(METHOD,{})
        status_path=ROOT/'reproduction_status.json'
        status=json.loads(status_path.read_text())
        status.update(updated_utc=datetime.now(timezone.utc).isoformat(),
                      independent_completed_episodes=metrics.get('completed',0),
                      independent_verified_successes=metrics.get('successes',0))
        temp=status_path.with_suffix('.tmp');temp.write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n');temp.replace(status_path)
        if len(attempts)!=1 or attempts[0].get('status') not in ('complete','invalid_native_layout'):
            emit('stopped_for_review',attempts=[a.get('status') for a in attempts])
            raise SystemExit(1)
        emit('attempt_finished',case=attempts[0]['case'],status=attempts[0]['status'],method=METHOD,completed=method_metrics.get('completed'))
    emit('bounded_queue_limit_reached')


if __name__=='__main__':main()
