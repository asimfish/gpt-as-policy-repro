"""Observe original RPC boundaries only; do not alter native actions or algorithms."""
from datetime import datetime,timezone
import faulthandler
import json
import sys
import time
from hybrid_rollout.robolab.robolab_server import server as upstream
from hybrid_rollout.robolab.robolab_server import session as native_session


def observe_wire():
    receive,send=native_session.receive_packet,native_session.send_packet
    def observed_receive(sock):
        print(json.dumps(dict(event='wire_receive_start',monotonic=time.monotonic())),flush=True)
        faulthandler.dump_traceback_later(45,repeat=True,file=sys.stderr)
        try:
            result=receive(sock)
        finally:
            faulthandler.cancel_dump_traceback_later()
        print(json.dumps(dict(event='wire_receive_done',op=result.get('op'),monotonic=time.monotonic())),flush=True)
        return result
    def observed_send(sock,value):
        print(json.dumps(dict(event='wire_send_start',monotonic=time.monotonic())),flush=True)
        send(sock,value)
        print(json.dumps(dict(event='wire_send_done',monotonic=time.monotonic())),flush=True)
    native_session.receive_packet=observed_receive
    native_session.send_packet=observed_send


class ObservedSession(upstream.EditEnvironmentSession):
    def dispatch(self,op,args):
        started=time.monotonic()
        print(json.dumps(dict(event='rpc_start',op=op,step_id=self.step_id,
            utc=datetime.now(timezone.utc).isoformat(),monotonic=started)),flush=True)
        try:
            result=super().dispatch(op,args)
        except BaseException:
            print(json.dumps(dict(event='rpc_failed',op=op,step_id=self.step_id,
                elapsed=time.monotonic()-started)),flush=True)
            raise
        print(json.dumps(dict(event='rpc_done',op=op,step_id=self.step_id,
            elapsed=time.monotonic()-started)),flush=True)
        return result


if __name__=='__main__':
    observe_wire()
    upstream.EditEnvironmentSession=ObservedSession
    upstream.main()
