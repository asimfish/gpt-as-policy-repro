"""Owned Direct protocol adapter; native RoboLab recorder and EEF controller stay upstream."""
import re
import uuid
from hybrid_rollout.robolab.robolab_server import server as upstream
from robolab_instrumented_server import ObservedSession,observe_wire


class DirectEnvironmentSession(ObservedSession):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.metadata.update(evaluation_method='gpt_only', supports_direct=True,
            supports_online_combination=False, pi05_enabled=False,
            policy_identity_source='identified_Codex_Direct_controller; no student model')

    def begin_direct(self,episode_id,step_id,teacher_model,prompt_sha256):
        self._check_identity(episode_id,step_id)
        if (self.step_id!=0 or self.source!='diagnostic_hold' or self.combination
                or self.branch or self.terminated or self.truncated):
            raise ValueError('Direct must begin once after a fresh hold reset at tick zero')
        if teacher_model!='gpt-6-astra' or not re.fullmatch('[a-f0-9]{64}',prompt_sha256):
            raise ValueError('Identified Direct model and prompt required')
        if not self.record_scene_state or not self.initial_state_hash:
            raise ValueError('Direct requires initial physical-state recording')
        self.source='gpt_eef'
        self.combination=dict(schema='gpt_policy_robolab.direct.v1',combination_id=uuid.uuid4().hex,
            episode_id=self.episode_id,initial_state_hash=self.initial_state_hash,
            evaluation_method='gpt_only',teacher_variant='gpt_eef',teacher_model=teacher_model,
            prompt_sha256=prompt_sha256,student_policy_version=None,student_policy_sha256='',
            pi05_enabled=False,pi05_inference_calls=0,
            policy_identity_source='identified_Codex_Direct_controller; no student model',
            max_episode_steps=self.max_steps,control_epoch=0,rewind_enabled=False,
            transitions=[dict(control_epoch=0,step_id=0,previous_source='diagnostic_hold',
                             source='gpt_eef',reason='begin_direct_no_student')],
            chunks=[],student_prediction_ids=[])
        self._persist_combination()
        return self._combination_ack(changed=True)

    def dispatch(self,op,args):
        if op=='begin_direct':
            return self.begin_direct(**args)
        if op=='reset':
            if args.get('source')!='diagnostic_hold' or args.get('policy_version')!='gpt_only':
                raise ValueError('Direct requires hold reset with no student model')
        if op not in ('metadata','reset','teacher_observation','eef_joint_target',
                       'chunk_step','finish_pilot','record_codex_decision'):
            raise ValueError('Operation is unavailable in the Direct adapter')
        if op=='record_codex_decision':
            if args.get('prediction_id') is not None or args['response'].get('mode')!='eef':
                raise ValueError('Direct accepts EEF decisions without student predictions only')
        if op=='chunk_step' and (not self.combination or self.source!='gpt_eef'):
            raise ValueError('Physical actions require begin_direct and EEF source')
        return super().dispatch(op,args)


if __name__=='__main__':
    observe_wire()
    # Dependency injection is confined to this standalone process; no source file changes.
    upstream.EditEnvironmentSession=DirectEnvironmentSession
    upstream.main()
