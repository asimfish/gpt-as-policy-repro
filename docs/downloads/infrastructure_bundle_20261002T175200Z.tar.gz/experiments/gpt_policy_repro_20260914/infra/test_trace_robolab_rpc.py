"""Tracing preserves packet behavior, closes lost ACKs and omits payload contents."""
import json
from pathlib import Path
import socket
import tempfile
import threading
import unittest
from hybrid_rollout.robolab.robolab_server.protocol import VERSION,receive_packet,send_packet
from trace_robolab_rpc import trace_factory


class TraceContract(unittest.TestCase):
    def exercise(self,reply):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'trace.jsonl';seen=[]
            listener=socket.socket();listener.bind(('127.0.0.1',0));listener.listen(1)
            def server():
                c,_=listener.accept()
                with c:
                    request=receive_packet(c);seen.append(request)
                    if reply:send_packet(c,dict(version=VERSION,request_id=request['request_id'],ok=True,result=request['args']))
            thread=threading.Thread(target=server);thread.start()
            client=trace_factory(path)('127.0.0.1',listener.getsockname()[1],timeout=2)
            try:
                if reply:self.assertEqual(client.request('test',value='PAYLOAD_MUST_STAY_PRIVATE'),dict(value='PAYLOAD_MUST_STAY_PRIVATE'))
                else:
                    with self.assertRaises(EOFError):client.request('chunk_step',value='PAYLOAD_MUST_STAY_PRIVATE')
                    self.assertIsNone(client.sock)
                    with self.assertRaises(RuntimeError):client.request('chunk_step',value='again')
                thread.join(timeout=3);self.assertFalse(thread.is_alive());self.assertEqual(len(seen),1)
                log=path.read_text();self.assertNotIn('PAYLOAD_MUST_STAY_PRIVATE',log)
                events=[json.loads(line)['event'] for line in log.splitlines()]
                self.assertIn('send_done',events)
                self.assertIn('request_done' if reply else 'request_error',events)
            finally:
                client.close();listener.close()

    def test_transparent_reply(self):self.exercise(True)
    def test_lost_ack_is_not_retried(self):self.exercise(False)


if __name__=='__main__':unittest.main()
