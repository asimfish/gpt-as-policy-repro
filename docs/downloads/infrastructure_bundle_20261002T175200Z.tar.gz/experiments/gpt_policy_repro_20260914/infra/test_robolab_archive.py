"""Partial copies and same-size corruption must never become verified archives."""
import hashlib
import json
from pathlib import Path
import tempfile
import subprocess
import sys
import unittest
from archive_robolab_attempt import verify_archive, REMOTE_MANIFEST


class ArchiveIntegrity(unittest.TestCase):
    def manifest(self, name='episode/initial_scene.json', data=b'known bytes'):
        return dict(schema='gpt_policy_robolab_remote_archive.v1', files={name:dict(size=len(data), sha256=hashlib.sha256(data).hexdigest())})

    def test_resumed_exact_bytes_pass_and_missing_or_corrupt_bytes_fail(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); path = root/'episode/initial_scene.json'
            with self.assertRaises(AssertionError):verify_archive(root, self.manifest())
            path.parent.mkdir();path.write_bytes(b'known bytes')
            self.assertTrue(verify_archive(root, self.manifest())['verified'])
            path.write_bytes(b'other bytes')
            with self.assertRaisesRegex(AssertionError, 'bytes differ'):verify_archive(root, self.manifest())

    def test_path_escape_and_symlinks_are_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for name in ('../outside', '/tmp/outside', 'episode/../outside'):
                with self.subTest(name=name), self.assertRaises(AssertionError):verify_archive(root, self.manifest(name))
            (root/'real').write_bytes(b'known bytes');(root/'alias').symlink_to(root/'real')
            with self.assertRaises(AssertionError):verify_archive(root, self.manifest('alias'))

    def test_live_or_unflushed_recorder_cannot_be_archived(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            for state in (dict(status='starting'),dict(status='ready'),dict(status='service_failed'),dict(status='stopped',finished_utc='sealed')):
                with self.subTest(state=state):
                    (root/'services.json').write_text(json.dumps(state))
                    result=subprocess.run([sys.executable,'-c',REMOTE_MANIFEST,str(root)],capture_output=True,text=True)
                    if state.get('finished_utc'):
                        self.assertEqual(result.returncode,0)
                        self.assertTrue(verify_archive(root,json.loads(result.stdout))['verified'])
                    else:self.assertNotEqual(result.returncode,0)


if __name__ == '__main__':unittest.main()
