import unittest
import numpy as np
from run_robolab_pi05_episode import checked_actions, policy_request


class RoboLabPolicyContractTest(unittest.TestCase):
    def test_request_preserves_joint_and_gripper_order(self):
        obs = dict(states=np.arange(8, dtype=np.float32), main_images=np.zeros((224,224,3),np.uint8),
                   wrist_images=np.ones((224,224,3),np.uint8), task_description='put blocks in bin')
        request = policy_request(obs)
        np.testing.assert_array_equal(request['observation/joint_position'], np.arange(7))
        np.testing.assert_array_equal(request['observation/gripper_position'], [7])
        self.assertIs(request['observation/exterior_image_1_left'], obs['main_images'])
        self.assertIs(request['observation/wrist_image_left'], obs['wrist_images'])
        self.assertEqual(request['prompt'], 'put blocks in bin')

    def test_actions_match_official_threshold_without_mutating_prediction(self):
        actions = np.arange(120, dtype=np.float32).reshape(15, 8)
        actions[:3, -1] = [.49, .5, .51]
        original = actions.copy()
        raw, executed = checked_actions({'actions': actions})
        np.testing.assert_array_equal(raw, original)
        np.testing.assert_array_equal(executed[:, :7], original[:, :7])
        np.testing.assert_array_equal(executed[:3, -1], [0, 0, 1])

    def test_rejects_wrong_model_shape_and_nonfinite_values(self):
        for actions in (np.zeros((50,14)), np.zeros((15,7)), np.full((15,8), np.nan)):
            with self.subTest(shape=actions.shape), self.assertRaises(ValueError):
                checked_actions({'actions': actions})


if __name__ == '__main__':
    unittest.main()
