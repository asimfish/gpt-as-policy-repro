"""Independent RoboDojo full-chunk control: one prediction, 15+15+15+5 RPC steps."""
import argparse
import json
from pathlib import Path
import numpy as np


def execute_prediction(sim, episode, step, actions, prediction_id):
    """Do not query policy or retry physical actions between transport slices."""
    receipts = []
    for offset in range(0, len(actions), 15):
        chunk = actions[offset:offset+15]
        ack = sim.request('chunk_step', episode_id=episode, step_id=step, actions=chunk,
                          student_prediction_id=prediction_id, prediction_offset=offset)
        valid = [row for row in ack['steps'] if row['valid']]
        if not valid or ack['step_id'] != step + len(valid):
            raise RuntimeError('Native execution count mismatch')
        step = ack['step_id']
        last = valid[-1]
        receipts.append(dict(offset=offset, count=len(valid), step_id=step,
                             terminated=bool(last['terminated']), truncated=bool(last['truncated']),
                             success=bool(last['success'])))
        if last['terminated'] or last['truncated']:
            break
    return step, receipts


def main():
    from hybrid_rollout.robodojo.pi05_server.client import Pi05Client
    from hybrid_rollout.robodojo.robodojo_server.protocol import RPCClient
    p = argparse.ArgumentParser()
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--task', required=True)
    p.add_argument('--sim-port', type=int, required=True)
    p.add_argument('--policy-port', type=int, required=True)
    p.add_argument('--checkpoint', type=Path, required=True)
    p.add_argument('--seed', type=int, default=0)
    p.add_argument('--max-decisions', type=int, default=0)
    a = p.parse_args()
    assert a.max_decisions == 0, 'Chunk-50 control requires native horizon'
    a.output.mkdir(parents=True, exist_ok=False)
    (a.output/'reproduction.json').write_text(json.dumps(dict(method='pi05_chunk50',
        controller='cached_full_chunk', benchmark_eligible=True, teacher_invoked=False,
        protocol_scope='independent full-chunk control; not proof of bitwise upstream equivalence'),indent=2)+'\n')
    policy = Pi05Client(a.policy_port, str(a.checkpoint))
    sim = RPCClient('127.0.0.1', a.sim_port, timeout=600)
    try:
        meta = sim.request('metadata');assert meta['task'] == a.task
        reset = sim.request('reset', seed=a.seed, source='student',
                            policy_version=policy.metadata['checkpoint_sha256'])
        episode, step = reset['episode_id'], 0
        run = dict(task=a.task, seed=a.seed, evaluation_case=reset['metadata'].get('evaluation_case'),
                   student_server_metadata=policy.metadata, teacher_off=True, action_horizon=50,
                   transport_slice_max=15, reset_metadata=reset['metadata'])
        (a.output/'run.json').write_text(json.dumps(run,indent=2)+'\n')
        history = []
        for index in range(int(meta['max_episode_steps'])+1):
            obs = sim.request('teacher_observation', episode_id=episode, step_id=step)
            out = a.output/'predictions'/f'{index:05d}';out.mkdir(parents=True)
            actions, identity = policy.infer(obs, out/'prediction.npz')
            assert actions.shape == (50,14) and np.isfinite(actions).all()
            step, receipts = execute_prediction(sim, episode, step, actions, identity['prediction_id'])
            record = dict(**identity, end_tick=step, executed_steps=sum(r['count'] for r in receipts),
                          receipts=receipts)
            history.append(record)
            (out/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
            (a.output/'history.json').write_text(json.dumps(history,indent=2)+'\n')
            print(json.dumps(record),flush=True)
            if receipts[-1]['terminated'] or receipts[-1]['truncated']: break
        if not (receipts[-1]['terminated'] or receipts[-1]['truncated']):
            raise RuntimeError('Native terminal was not reached')
        final = sim.request('finish_pilot', episode_id=episode, step_id=step, reason='terminal')
        final.update(complete=True, student_steps=step, predictions=len(history), decisions=len(history))
        (a.output/'result.json').write_text(json.dumps(final,indent=2)+'\n')
    finally:
        sim.close();policy.close()


if __name__ == '__main__':main()
