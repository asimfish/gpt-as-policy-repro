"""Account for every frozen case, including invalid resets and failed attempts."""
import json
from pathlib import Path
from datetime import datetime, timezone

root = Path(__file__).resolve().parents[1]
rows = []
for case in sorted((root/'fixtures/cases').glob('mix__*.json')):
    attempts=[]
    for path in sorted((root/'student_native_campaign'/case.stem).glob('*/attempt.json')):
        item=json.loads(path.read_text());item['evidence']=str(path.relative_to(root));attempts.append(item)
    native=[a for a in attempts if a['status'] in ('complete','invalid_native_layout')]
    selected=native[-1] if native else attempts[-1] if attempts else {}
    outcome_path=root/selected['evidence'] if selected else None
    outcome_path=outcome_path.parent/'sim/evaluation_outcome.json' if outcome_path else None
    outcome=json.loads(outcome_path.read_text()) if outcome_path and outcome_path.exists() else {}
    rows.append(dict(case=case.stem,status=selected.get('status','pending'),attempts=len(attempts),
        evidence=selected.get('evidence'),native_complete=outcome.get('complete') is True,
        eligible=outcome.get('complete') is True and outcome.get('valid_for_success_rate') is True,
        native_status=outcome.get('status'),success=outcome.get('native_success'),score=outcome.get('native_score')))
valid=[r for r in rows if r['eligible']]
report=dict(generated_utc=datetime.now(timezone.utc).isoformat(),method='pi05_prefix15',planned_cases=len(rows),
    resolved_cases=sum(r['status'] in ('complete','invalid_native_layout') for r in rows),
    native_completed=sum(r['native_complete'] for r in rows),eligible_cases=len(valid),
    successes=sum(r['success'] is True for r in valid),
    success_rate=sum(r['success'] is True for r in valid)/len(valid) if valid else None,
    excluded_cases=[r for r in rows if r['status'] in ('complete','invalid_native_layout') and not r['eligible']],cases=rows)
(root/'prefix15_cohort_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='cases'},ensure_ascii=False,indent=2))
