#!/usr/bin/env bash
set -euo pipefail
ROOT=/home/dataset-assist-0/liyufeng/agentic_robot
RUNTIME=/home/batchcom/gpt-policy-runtime
ARTIFACT="$ROOT/experiments/gpt_policy_repro_20260914"
mkdir -p "$RUNTIME" "$ARTIFACT/mainskill"
exec 9>"$RUNTIME/bootstrap.lock"
flock -n 9 || exit 0
cd "$RUNTIME/robolab-spec"
export UV_CACHE_DIR="$ROOT/uv-cache" UV_PROJECT_ENVIRONMENT="$RUNTIME/robolab51"
/home/batchcom/.local/bin/uv sync --frozen --extra isaac51 --no-install-project --python 3.11
export CUDA_VISIBLE_DEVICES=0 CUDA_MPS_PIPE_DIRECTORY="/tmp/gpt-policy-no-mps-$$"
export VK_ICD_FILENAMES=/etc/vulkan/icd.d/nvidia_icd.json OMNI_KIT_ACCEPT_EULA=Y
export XDG_RUNTIME_DIR="$RUNTIME/xdg/runtime" XDG_CACHE_HOME="$RUNTIME/xdg/cache"
export XDG_DATA_HOME="$RUNTIME/xdg/data" XDG_CONFIG_HOME="$RUNTIME/xdg/config"
mkdir -p "$XDG_RUNTIME_DIR" "$XDG_CACHE_HOME" "$XDG_DATA_HOME" "$XDG_CONFIG_HOME"
chmod 700 "$XDG_RUNTIME_DIR"
RUN="$ARTIFACT/mainskill/render_$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$RUN"
"$RUNTIME/robolab51/bin/python" -c 'import importlib.metadata as m,json;print(json.dumps({p:m.version(p) for p in ("isaacsim","isaaclab","torch","numpy")}))' > "$RUN/versions.json"
timeout -k 30 1200 "$RUNTIME/robolab51/bin/python" "$ARTIFACT/infra/a100_render_smoke.py" --output "$RUN/frames" > "$RUN/render.log" 2>&1
if grep -qE 'ERROR_OUT_OF_DEVICE_MEMORY|Failed to create any GPU devices|switching to software|Failed to create raytracing pipeline' "$RUN/render.log"; then
  echo "Renderer/GPU failure in $RUN/render.log" >&2;exit 1
fi
"$RUNTIME/robolab51/bin/python" -c 'import json,sys;assert json.load(open(sys.argv[1]))["passed"] is True' "$RUN/frames/render_result.json"
cp "$RUN/frames/render_result.json" "$ARTIFACT/mainskill/render_ready.json"
echo "RENDER_PASSED $RUN"
