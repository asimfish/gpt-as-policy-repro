#!/usr/bin/env bash
set -euo pipefail

export REPRO_ROOT="${REPRO_ROOT:-/mnt/nas/data/lyf/agentic_robot}"
export GPT_POLICY_ROOT="${GPT_POLICY_ROOT:-$REPRO_ROOT/gpt-as-policy}"
export ROBO_ROOT="${ROBO_ROOT:-$REPRO_ROOT/upstream/RoboDojo}"
export ROBO_PYTHON="${ROBO_PYTHON:-/home/liyufeng/miniforge3/envs/safeduo/bin/python}"
export OPENPI_PYTHON="${OPENPI_PYTHON:-/home/liyufeng/pi/openpi/.venv/bin/python}"
export PI05_CHECKPOINT="${PI05_CHECKPOINT:-$ROBO_ROOT/.cache/robodojo_ckpt_huggingface_repo/ckpt/RoboDojo/Pi_05/RoboDojo-sim-arx_x5-joint-0/59999}"
export CUROBO_SITE="${CUROBO_SITE:-/home/liyufeng/venvs/curobo_t1/lib/python3.11/site-packages}"
export ROBO_EXTRA_PYTHONPATH="${ROBO_EXTRA_PYTHONPATH:-/home/liyufeng/.cache/gpt-policy-repro/sim-extra}"
export ISAACLAB_SOURCE="$ROBO_ROOT/third_party/IsaacLab/source/isaaclab"

export PYTHONPATH="$ROBO_ROOT/XPolicyLab/policy/Pi_05/openpi/packages/openpi-client/src:$ROBO_EXTRA_PYTHONPATH:$GPT_POLICY_ROOT:$ROBO_ROOT:$ROBO_ROOT/XPolicyLab:$ISAACLAB_SOURCE:$ROBO_ROOT/third_party/curobo${PYTHONPATH:+:$PYTHONPATH}"
export OMNI_KIT_ACCEPT_EULA="${OMNI_KIT_ACCEPT_EULA:-Y}"
export XDG_RUNTIME_DIR="${XDG_RUNTIME_DIR:-/tmp/robodojo-xdg-lyf}"
export MPLCONFIGDIR="${MPLCONFIGDIR:-/tmp/robodojo-mplconfig-lyf}"
mkdir -p "$XDG_RUNTIME_DIR" "$MPLCONFIGDIR"
