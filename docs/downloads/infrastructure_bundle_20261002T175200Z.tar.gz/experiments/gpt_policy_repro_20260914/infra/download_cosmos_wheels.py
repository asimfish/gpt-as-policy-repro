"""Mirror the A100 CPython 3.13 Cosmos resolution with frozen upstream hashes."""
import concurrent.futures
import hashlib
import json
from pathlib import Path
import re
import time
import tomllib
import urllib.request
import urllib.error
from urllib.parse import unquote
from packaging.utils import parse_wheel_filename

ROOT=Path(__file__).resolve().parents[3]
ART=ROOT/'experiments/gpt_policy_repro_20260914'
OUT=ROOT/'upstream/checkpoints/cosmos-wheels'


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for b in iter(lambda:stream.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()


def fetch(row):
    filename=unquote(row['url'].rsplit('/',1)[1]);assert '/' not in filename
    target=OUT/filename;partial=target.with_suffix('.partial');expected=row['hash'].removeprefix('sha256:')
    download_url=row['url']
    if not(target.exists() and sha(target)==expected):
        for attempt in range(5):
            try:
                offset=partial.stat().st_size if partial.exists() else 0
                request=urllib.request.Request(download_url,headers={'Range':f'bytes={offset}-'})
                with urllib.request.urlopen(request,timeout=90) as response:
                    if offset and response.status!=206:offset=0
                    with partial.open('ab' if offset else 'wb') as stream:
                        while data:=response.read(4*1024*1024):stream.write(data)
                assert sha(partial)==expected,filename
                partial.replace(target);break
            except Exception as exc:
                print(json.dumps(dict(file=filename,attempt=attempt,error=type(exc).__name__)),flush=True)
                if isinstance(exc,urllib.error.HTTPError) and exc.code==403 and download_url.startswith('https://download-r2.pytorch.org/'):
                    download_url=download_url.replace('https://download-r2.pytorch.org/','https://download.pytorch.org/',1)
                    print(json.dumps(dict(event='official_pytorch_host_fallback',file=filename,sha256_unchanged=expected)),flush=True)
                if attempt==4:raise
                time.sleep(3)
    result=dict(path=filename,size=target.stat().st_size,sha256=expected,name=row['name'],version=row['version'],locked_url=row['url'],download_url=download_url)
    print(json.dumps(dict(event='verified',**result)),flush=True)
    return result


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    raw=(ROOT/'upstream/cosmos-framework/uv.lock').read_bytes();lock=tomllib.loads(raw.decode())
    dry=(ART/'mainskill/cosmos_dry_run.log').read_text()
    wanted=dict(re.findall(r'^ \+ ([\w-]+)==([^\s]+)',dry,re.M))
    source_names=set(re.findall(r'^ \+ ([\w-]+) @ ',dry,re.M))
    tags=set(json.loads((ART/'fixtures/mainskill_cp313_tags.json').read_text()))
    selected={};sources=[]
    for package in lock['package']:
        name=package['name']
        if name in source_names and 'registry' not in package['source']:
            sources.append(dict(name=name,version=package['version'],source=package['source']));continue
        if wanted.get(name)!=package['version']:continue
        if 'registry' not in package['source']:
            sources.append(dict(name=name,version=package['version'],source=package['source']));continue
        candidates=[w for w in package.get('wheels',[]) if {str(t) for t in parse_wheel_filename(unquote(w['url'].rsplit('/',1)[1]))[3]} & tags]
        artifact=candidates[0] if candidates else package.get('sdist')
        assert artifact is not None,(name,'no compatible distribution')
        row=dict(artifact,name=name,version=package['version'])
        assert name not in selected or selected[name]['hash']==row['hash'],(name,'ambiguous sources')
        selected[name]=row
    assert set(selected)==set(wanted)
    assert {r['name'] for r in sources}==source_names
    (OUT/'source_dependencies.json').write_text(json.dumps(sources,indent=2)+'\n')
    (OUT/'selected_artifacts.json').write_text(json.dumps(list(selected.values()),indent=2)+'\n')
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(fetch,selected.values()))
    req=OUT/'requirements.txt';req.write_text(''.join(f"{r['name']}=={r['version']}\n" for r in sorted(rows,key=lambda r:r['name'])))
    rows.append(dict(path=req.name,size=req.stat().st_size,sha256=sha(req)))
    (OUT/'download_manifest.json').write_text(json.dumps(dict(source='cosmos-frozen-lock-wheels',lock_sha256=hashlib.sha256(raw).hexdigest(),verified=True,files=rows),indent=2)+'\n')


if __name__=='__main__':main()
