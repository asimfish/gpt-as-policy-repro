"""Validate ten pinned RoboLab task resets in fresh A100 processes, no policy actions."""
import fcntl
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/home/dataset-assist-0/liyufeng/agentic_robot')
ART = ROOT/'experiments/gpt_policy_repro_20260914'
TARGET = ROOT/'upstream/RoboLab-ad45-full-assets'


def main():
    out=ART/'mainskill_robolab_scene_validation';out.mkdir(parents=True,exist_ok=True)
    with (out/'queue.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        for _ in range(2880):
            if (TARGET/'assets_verification.json').exists():break
            time.sleep(15)
        marker=json.loads((TARGET/'assets_verification.json').read_text())
        assert marker['verified'] is True and marker['source_commit']=='ad45d4f974725d020f82c2b0d77d78533aeba2b3' and marker['files']==2228
        tasks=json.loads((ART/'fixtures/robolab_task_files.json').read_text())['tasks']
        status_path=out/'status.json'
        rows=json.loads(status_path.read_text())['tasks'] if status_path.exists() else {}
        for task in tasks:
            if task in rows:continue  # Preserve both failures and successful attempts for review.
            free=int(subprocess.check_output(['nvidia-smi','-i','4','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
            if free<20000:raise RuntimeError('GPU 4 requires 20000 MiB free; no unrelated process is stopped')
            started=time.time()
            env=dict(os.environ,ROBO_LAB_ROOT=str(TARGET),ROBO_LAB_TASK=task,ROBO_LAB_SEED='0',
                     ROBO_LAB_GPU='4',ROBO_LAB_SIM_PORT='19700',ROBO_LAB_RECORD_SCENE_STATE='1',
                     ROBO_LAB_CAMPAIGN='mainskill_robolab_scene_validation/'+task)
            env.pop('ROBO_LAB_POLICY_PORT',None)
            with (out/(task+'.log')).open('a') as log:
                run=subprocess.run(['bash',str(ART/'infra/run_mainskill_robolab_smoke.sh')],env=env,stdout=log,stderr=subprocess.STDOUT)
            attempts=sorted((out/task).glob('*'))
            evidence=attempts[-1] if attempts else None
            proof=evidence/'rollout/observations/000/render_validation.json' if evidence else None
            passed=run.returncode==0 and proof is not None and proof.is_file()
            rows[task]=dict(reset_render_passed=passed,exit_code=run.returncode,seed=0,native_controls=0,
                            elapsed_seconds=time.time()-started,evidence=str(evidence.relative_to(ART)) if evidence else None)
            payload=dict(scope='ten-task fresh reset/render validation, seed 0, no policy performance',tasks=rows,
                         passed=sum(r['reset_render_passed'] for r in rows.values()),attempted=len(rows))
            temp=status_path.with_suffix('.tmp');temp.write_text(json.dumps(payload,indent=2)+'\n');temp.replace(status_path)
            print(json.dumps(dict(task=task,**rows[task])),flush=True)


if __name__=='__main__':main()
