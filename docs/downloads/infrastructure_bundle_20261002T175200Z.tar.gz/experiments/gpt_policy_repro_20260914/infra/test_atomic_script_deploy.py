import base64
import hashlib
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import zlib
from deploy_mainskill_script import PUBLISH


class AtomicScriptDeployTest(unittest.TestCase):
    def test_live_reader_keeps_old_inode_and_new_launch_gets_new_code(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'worker.sh';gate=Path(tmp)/'continue'
            old='#!/bin/bash\necho ready\nwhile [[ ! -f "$1" ]]; do sleep .01; done\n'+'# padding\n'*1000+'echo old\n'
            p.write_text(old);p.chmod(0o750)
            running=subprocess.Popen(['bash',str(p),str(gate)],stdout=subprocess.PIPE,text=True)
            try:
                self.assertEqual(running.stdout.readline().strip(),'ready')
                new=b'#!/bin/bash\necho new\n'
                subprocess.run([sys.executable,'-c',PUBLISH,str(p),base64.b64encode(zlib.compress(new)).decode(),hashlib.sha256(new).hexdigest()],check=True,stdout=subprocess.DEVNULL)
                gate.touch();stdout,_=running.communicate(timeout=5)
                self.assertEqual(stdout.strip(),'old')
                self.assertEqual(subprocess.check_output(['bash',str(p)],text=True).strip(),'new')
                self.assertEqual(p.stat().st_mode&0o777,0o750)
            finally:
                if running.poll() is None:running.kill();running.wait()

    def test_invalid_shell_does_not_replace_existing_script(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'worker.sh';old=b'echo valid\n';p.write_bytes(old)
            bad=b'if then\n'
            result=subprocess.run([sys.executable,'-c',PUBLISH,str(p),base64.b64encode(zlib.compress(bad)).decode(),hashlib.sha256(bad).hexdigest()],capture_output=True)
            self.assertNotEqual(result.returncode,0);self.assertEqual(p.read_bytes(),old)
