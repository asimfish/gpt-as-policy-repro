"""A non-default task/seed reaches both real supervisor launch boundaries."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest


class RoboLabTaskRoutingTest(unittest.TestCase):
    def test_server_and_policy_client_receive_same_nondefault_case(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);infra=root/'infra';infra.mkdir()
            supervisor=infra/'run_robolab_smoke.sh'
            shutil.copyfile(Path(__file__).with_name(supervisor.name),supervisor)
            server=infra/'run_robolab_server.sh'
            server.write_text('''#!/usr/bin/env python3
import json,signal,sys,time
from pathlib import Path
Path(sys.argv[2]).parent.joinpath('server_args.json').write_text(json.dumps(sys.argv[1:]))
signal.signal(signal.SIGINT,lambda *_:sys.exit(0))
print('{"event": "ready"}',flush=True)
while True:time.sleep(.1)
''');server.chmod(0o755)
            client=infra/'run_robolab_pi05_episode.py'
            client.write_text('''import json,sys
from pathlib import Path
args=sys.argv[1:];Path(args[args.index('--output')+1]).parent.joinpath('client_args.json').write_text(json.dumps(args))
''')
            output=root/'run'
            subprocess.run(['bash',str(supervisor),str(output),'19600'],check=True,timeout=15,
                env=dict(os.environ,ROBO_LAB_TASK='YogurtInBowlTask',ROBO_LAB_SEED='4',
                         ROBO_LAB_POLICY_PORT='19610',ROBO_LAB_PYTHON=shutil.which('python3')))
            server_args=json.loads((output/'server_args.json').read_text())
            client_args=json.loads((output/'client_args.json').read_text())
            self.assertEqual(server_args,[ 'YogurtInBowlTask',str(output/'sim'),'19600','4'])
            for key,value in [('--task','YogurtInBowlTask'),('--seed','4'),('--port','19600'),('--policy-port','19610')]:
                self.assertEqual(client_args[client_args.index(key)+1],value)
