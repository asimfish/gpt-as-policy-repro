"""Take a private immutable audit snapshot of completed live Direct/Hybrid decisions, without RPC."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import shlex
import shutil
import subprocess

from transfer_checkpoint_chunks import SSH
from audit_robolab_gpt_actions import audit

ARTIFACTS=Path(__file__).resolve().parents[1]


def prefix_includes(rollout,decisions,direct):
    history=json.loads((rollout/'history.json').read_text())
    assert type(decisions) is int and 0<decisions<=len(history)
    episode=json.loads((rollout/'request_000.json').read_text())['episode_id']
    assert Path(episode).name==episode and episode and episode.isascii() and all(c.isalnum() or c in '_-' for c in episode)
    native='/sim/'+episode
    chunks=0
    for item in history[:decisions]:
        mode=item['response']['mode'];assert mode in ('student','edit','eef')
        if direct:assert mode=='eef'
        assert type(item['executed_steps']) is int and item['executed_steps']>0
        chunks+=1 if mode=='student' else item['executed_steps']
    includes=([] if direct else ['/policy_identity.json'])+['/sim/',native+'/',native+'/initial_scene.json',native+'/codex_decisions/']
    includes += [native+'/chunk_'+f'{i:05d}'+'.npz' for i in range(chunks)]
    includes += [native+'/codex_decisions/'+f'{i:03d}'+'.json' for i in range(decisions)]
    return includes


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--decisions',type=int,required=True)
    parser.add_argument('--no-publish-latest',action='store_true')
    parser.add_argument('--resume-snapshot',help='Resume a private snapshot basename; never recopies or replays model decisions')
    args=parser.parse_args()
    active=json.loads((ARTIFACTS/'robolab_gpt_active.json').read_text())
    assert active['method'] in ('pi05_plus_gpt','gpt_only') and active['status']=='controller_running'
    prefix='hybrid_' if active['method']=='pi05_plus_gpt' else 'direct_'
    assert active['attempt'].startswith(prefix) and Path(active['attempt']).name==active['attempt']
    workspace=Path(active['local_workspace'])
    assert workspace.parent==Path('/tmp') and workspace.name=='gpt-policy-robolab-'+active['attempt']
    snapshot_prefix=active['attempt']+'_d'+str(args.decisions)+'_'
    if args.resume_snapshot:
        assert Path(args.resume_snapshot).name==args.resume_snapshot and args.resume_snapshot.startswith(snapshot_prefix)
        destination=ARTIFACTS/'robolab_gpt_prefix_audits'/args.resume_snapshot
        assert destination.is_dir() and not destination.is_symlink() and not (destination/'action_audit_prefix.json').exists()
    else:
        destination=ARTIFACTS/'robolab_gpt_prefix_audits'/(snapshot_prefix+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
        destination.mkdir(parents=True,exist_ok=False)
        shutil.copytree(workspace/'rollout',destination/'rollout',ignore=shutil.ignore_patterns('runtime_db','runtime_logs'))
    remote_output=active['remote_output']
    assert remote_output=='/home/dataset-assist-0/liyufeng/agentic_robot/experiments/gpt_policy_repro_20260914/robolab_gpt_campaign/'+active['attempt']
    includes=prefix_includes(destination/'rollout',args.decisions,active['method']=='gpt_only')
    cipher=active.get('ssh_cipher','default')
    assert cipher in ('default','aes128-gcm@openssh.com')
    ssh=[*SSH[:-1], *(['-o','Ciphers='+cipher] if cipher!='default' else [])]
    argv=['rsync','-az','--partial','--timeout=90','-e',shlex.join(ssh)]
    argv += ['--include='+p for p in includes]+['--exclude=*','mainskill:'+remote_output+'/',str(destination/'remote')+'/']
    subprocess.run(argv,check=True,timeout=1200)
    proof=audit(destination,args.decisions)
    (destination/'action_audit_prefix.json').write_text(json.dumps(proof,indent=2)+'\n')
    latest=dict(proof)
    latest.update(attempt=active['attempt'],snapshot=str(destination),audited_utc=datetime.now(timezone.utc).isoformat())
    if not args.no_publish_latest:(ARTIFACTS/'robolab_gpt_latest_prefix_audit.json').write_text(json.dumps(latest,indent=2)+'\n')
    print(json.dumps({k:v for k,v in latest.items() if k not in ('snapshot','files_sha256','model_tool_event_sha256')}))


if __name__=='__main__':main()
