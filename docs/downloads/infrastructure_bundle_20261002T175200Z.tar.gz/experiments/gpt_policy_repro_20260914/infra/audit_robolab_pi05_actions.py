"""Audit official Pi05 predictions against independent native RoboLab chunk records."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np


def audit(run, query_limit=None):
    identity=json.loads((run/'rollout/policy_identity.json').read_text())
    assert identity['config']=='pi05_droid_jointpos' and identity['action_horizon']==15
    queries=sorted((run/'rollout/queries').glob('*/ack.json'))
    if query_limit is not None:
        assert query_limit>0 and len(queries)>=query_limit
        queries=queries[:query_limit]
    assert queries,'No completed predictions'
    native_dirs=list((run/'sim').glob('*/initial_scene.json'));assert len(native_dirs)==1
    native_dir=native_dirs[0].parent;initial=json.loads(native_dirs[0].read_text())
    count=0;files=[run/'rollout/policy_identity.json',native_dirs[0]]
    last=None
    for index,ack_path in enumerate(queries):
        ack=json.loads(ack_path.read_text());assert ack['query']==index
        prediction=ack_path.with_name('prediction.npz');native_path=native_dir/f'chunk_{index:05d}.npz'
        assert hashlib.sha256(prediction.read_bytes()).hexdigest()==ack['prediction_sha256']
        with np.load(prediction,allow_pickle=False) as pred,np.load(native_path,allow_pickle=False) as native:
            raw=pred['proposed'];executed=raw.copy();executed[:,-1]=(raw[:,-1]>.5).astype(np.float32)
            assert raw.shape==(15,8) and np.isfinite(raw).all()
            assert np.array_equal(pred['executed'],executed),'Client transform mismatch'
            n=len(native['step_id']);assert 0<n<=15 and ack['valid_steps']==n
            assert np.array_equal(native['step_id'],np.arange(count,count+n)),'Native step gap'
            assert np.array_equal(native['action'],executed[:n]),'Native action mismatch'
            assert np.array_equal(native['proposed'],executed[:n]),'Submitted action mismatch'
            for key in ('main_images','wrist_images','states'):
                assert np.array_equal(native[key][0],pred[key]),'Policy input differs from native pre-action observation'
            assert str(native['source'])=='student'
            assert str(native['policy_version'])==identity['checkpoint_manifest_sha256']
            assert str(native['initial_state_hash'])==initial['state_sha256']
            assert str(native['episode_id'])==initial['episode_id']
            last={key:bool(native[key][-1]) for key in ('terminated','truncated','success')}
            assert all(ack[k]==v for k,v in last.items())
            assert not np.any(native['terminated'][:-1]) and not np.any(native['truncated'][:-1])
            if index<len(queries)-1:assert not last['terminated'] and not last['truncated']
            count+=n;assert ack['step_id']==count
        files.extend([ack_path,prediction,native_path])
    complete=query_limit is None
    if complete:
        result=json.loads((run/'rollout/result.json').read_text())
        assert result['complete'] and result['control_steps']==count
        assert last['terminated'] or last['truncated']
        assert all(result[k]==v for k,v in last.items())
        assert len(list(native_dir.glob('chunk_*.npz')))==len(queries)
        files.append(run/'rollout/result.json')
    return dict(verified=True,scope='complete_native_episode' if complete else 'completed_query_prefix_only',
        complete_episode=complete,queries=len(queries),native_actions=count,max_absolute_action_error=0,
        initial_state_sha256=initial['state_sha256'],checkpoint_manifest_sha256=identity['checkpoint_manifest_sha256'],
        terminal=last,files_sha256={str(p.relative_to(run)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files})


def main():
    p=argparse.ArgumentParser();p.add_argument('run',type=Path);p.add_argument('--queries',type=int);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    result=audit(a.run,a.queries);a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='files_sha256'}))


if __name__=='__main__':main()
