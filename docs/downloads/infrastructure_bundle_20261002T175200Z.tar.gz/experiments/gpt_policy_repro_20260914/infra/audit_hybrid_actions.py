"""Cross-check model decisions, student prefixes and corrections against native records."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np


def read(path):
    return json.loads(path.read_text())


def audit(run, decisions=None):
    out = run/'rollout'; workspace = out/'codex_workspace'
    worker, identity = read(workspace/'worker.json'), read(out/'run.json')
    assert worker['evaluation_method'] == 'pi05_plus_gpt'
    assert worker['model'] == identity['teacher_model'] == 'gpt-6-astra'
    assert worker['reasoning_effort'] == identity['teacher_reasoning_effort'] == 'xhigh'
    assert worker['model_provider'] == 'openai'
    history = read(out/'history.json')
    complete = decisions is None
    if not complete:
        assert 0 < decisions <= len(history)
        history = history[:decisions]
    assert history
    native = list((run/'sim').glob('*/action_000000.json'))
    assert len(native) == 1
    native = native[0].parent
    calls = []
    for p in workspace.glob('call_*_request.json'):
        request = read(p); result = p.with_name(p.name.replace('_request', '_result'))
        if request['tool'] != 'robodojo_execute' or not result.exists(): continue
        if read(result).get('no_execution') is True: continue
        args = request['arguments']
        if isinstance(args, str): args = json.loads(args)
        calls.append((request, args, p))
    events = {}
    with (workspace/'rpc_out.jsonl').open() as stream:
        for line in stream:
            event = json.loads(line); params = event.get('params', {})
            if event.get('method') == 'item/tool/call' and params.get('tool') == 'robodojo_execute':
                events[params['callId']] = event
    files = [out/'run.json', workspace/'worker.json']
    count = 0; totals = dict(student=0, edit=0, eef=0); event_hashes = []
    for index, h in enumerate(history):
        assert h['decision'] == index and h['start_tick'] == count
        response = read(out/f'response_{index:03d}.json')
        request = read(out/f'request_{index:03d}.json')
        assert response == h['response'] and request['step_id'] == count
        assert response['request_id'] == request['request_id']
        assert request['prediction_id'] == h['prediction_id'] and request['episode_id'] == native.name
        matching = [c for c in calls if c[1]['response'] == response]
        assert len(matching) == 1
        call, args, call_path = matching[0]; event = events[call['call_id']]
        assert event['params']['threadId'] == worker['thread_id']
        rpc_args = event['params']['arguments']
        if isinstance(rpc_args, str): rpc_args = json.loads(rpc_args)
        assert rpc_args == args
        event_hashes.append(hashlib.sha256(json.dumps(event, sort_keys=True).encode()).hexdigest())
        decision_path = native/'codex_decisions'/f'{index:03d}.json'
        decision = read(decision_path)
        assert decision['response'] == response and decision['step_id'] == count
        assert decision['prediction_id'] == h['prediction_id'] and decision['episode_id'] == native.name
        mode = response['mode']; assert mode in totals
        execution = out/f'execution_{index:03d}.npz'; proposal = out/f'proposal_{index:03d}.npz'
        edits = None
        if mode != 'student':
            edit_path = out/f'edit_{index:03d}.json'; edits = read(edit_path); files.append(edit_path)
            edits = [e for e in edits if e['valid']]
        with np.load(execution, allow_pickle=False) as x, np.load(proposal, allow_pickle=False) as p:
            n = len(x['actions']); assert n == h['executed_steps'] and 0 < n <= response['steps']
            assert x['actions'].shape == (n,14) and np.isfinite(x['actions']).all()
            assert p['actions'].shape == (50,14) and np.isfinite(p['actions']).all()
            if mode == 'student': assert np.array_equal(x['actions'], p['actions'][:n])
            else:
                assert len(edits) == n
                assert np.array_equal(x['actions'], [e['executed_action'] for e in edits])
            for offset in range(n):
                path = native/f'action_{count:06d}.json'; row = read(path)
                assert row['valid'] and row['step_id'] == count+1
                assert row['source'] == ('student' if mode == 'student' else 'gpt_eef')
                if mode == 'student': assert row['student_prediction_id'] == h['prediction_id']
                else: assert row['teacher_request_id'] == response['request_id']
                assert np.array_equal(row['executed_action'], x['actions'][offset])
                assert np.array_equal(row['obs']['states'], x['states'][offset])
                files.append(path); count += 1
                if index < len(history)-1 or offset < n-1:
                    assert not row['terminated'] and not row['truncated']
            last = row
        assert h['end_tick'] == count
        totals[mode] += n
        files.extend([call_path, decision_path, execution, proposal,
                      out/f'response_{index:03d}.json', out/f'request_{index:03d}.json'])
    if complete:
        result = read(out/'result.json'); outcome = read(run/'sim/evaluation_outcome.json')
        assert result['complete'] and (last['terminated'] or last['truncated'])
        assert outcome['complete'] and outcome['valid_for_success_rate']
        assert outcome['native_control_steps'] == count and outcome['native_success'] == result['success'] == last['success']
        assert len(list(native.glob('action_*.json'))) == count
        assert totals == dict(student=result['student_steps'], edit=result['edited_steps'], eef=result['recovery_steps'])
        files.extend([out/'result.json', run/'sim/evaluation_outcome.json'])
    return dict(verified=True, complete_episode=complete,
                scope='complete_native_episode' if complete else 'completed_hybrid_decision_prefix_only',
                model=worker['model'], reasoning_effort='xhigh', decisions=len(history), native_actions=count,
                actions_by_mode=totals, max_absolute_action_error=0, initial_state_hash=identity['initial_state_hash'],
                limitation='Checks recorded correction-to-joint-action mapping, not an independent IK recomputation.',
                model_tool_event_sha256=event_hashes,
                files_sha256={str(p.relative_to(run)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files})


if __name__ == '__main__':
    p=argparse.ArgumentParser();p.add_argument('run',type=Path);p.add_argument('--decisions',type=int)
    p.add_argument('--output',type=Path,required=True);a=p.parse_args();proof=audit(a.run,a.decisions)
    a.output.write_text(json.dumps(proof,indent=2)+'\n')
    print(json.dumps({k:v for k,v in proof.items() if k not in ('files_sha256','model_tool_event_sha256')}))
