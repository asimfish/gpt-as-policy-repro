import hashlib,select,subprocess,sys,tempfile,unittest
from pathlib import Path
from transfer_checkpoint_chunks import WRITE
class ChunkStreamTest(unittest.TestCase):
 def test_ack_does_not_wait_for_stdin_eof(self):
  payload=b'verified-block'*200
  with tempfile.TemporaryDirectory() as folder:
   target=Path(folder)/'partial'
   proc=subprocess.Popen([sys.executable,'-c',WRITE,str(target),'0',hashlib.sha256(payload).hexdigest(),str(len(payload))],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
   try:
    proc.stdin.write(payload);proc.stdin.flush()
    self.assertTrue(select.select([proc.stdout],[],[],3)[0],'Writer waited for EOF instead of the declared chunk length')
    self.assertEqual(int(proc.stdout.readline()),len(payload));self.assertEqual(target.read_bytes(),payload)
   finally:
    proc.stdin.close();proc.wait(timeout=3);proc.stdout.close();proc.stderr.close()
if __name__=='__main__':unittest.main()
