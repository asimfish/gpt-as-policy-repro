#!/usr/bin/env bash
set -euo pipefail
ROOT=/home/dataset-assist-0/liyufeng/agentic_robot
OUT="$ROOT/experiments/gpt_policy_repro_20260914/mainskill"
exec 9>"$OUT/cosmos_server.lock"
flock -n 9
for i in $(seq 1 720); do
 [[ -f "$OUT/cosmos_environment.json" ]] && break
 sleep 10
done
[[ -f "$OUT/cosmos_environment.json" ]]
export CUDA_VISIBLE_DEVICES=4
free=$(nvidia-smi -i 4 --query-gpu=memory.free --format=csv,noheader,nounits)
[[ "$free" -ge 70000 ]] || { echo 'GPU4 needs 70000 MiB free'; exit 1; }
export NVRTC_HOME="$ROOT/venvs/cosmos-policy/lib/python3.13/site-packages/nvidia/cuda_nvrtc"
export LD_LIBRARY_PATH='' HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export HF_HOME="$ROOT/huggingface" TORCH_HOME="$ROOT/torch-cache"
export TORCHINDUCTOR_CACHE_DIR="$ROOT/torchinductor-cache/cosmos" TRITON_CACHE_DIR="$ROOT/triton-cache/cosmos"
cd "$ROOT/upstream/cosmos-framework"
"$ROOT/venvs/cosmos-policy/bin/python" - <<'PY'
import hashlib,json
from pathlib import Path
p=Path('/home/dataset-assist-0/liyufeng/agentic_robot/upstream/checkpoints/Cosmos3-Nano-Policy-DROID')
v=json.loads((p/'transfer_verification.json').read_text())
assert v['verified'] and v['files']==43 and v['source']=='nvidia/Cosmos3-Nano-Policy-DROID'
assert v['manifest_sha256']==hashlib.sha256((p/'download_manifest.json').read_bytes()).hexdigest()
print(json.dumps(v),flush=True)
PY
exec "$ROOT/venvs/cosmos-policy/bin/python" -u -m cosmos_framework.scripts.action_policy_server_robolab \
 --checkpoint-path "$ROOT/upstream/checkpoints/Cosmos3-Nano-Policy-DROID" \
 --host 127.0.0.1 --port 19810 --output-dir "$OUT/cosmos_server_output"
