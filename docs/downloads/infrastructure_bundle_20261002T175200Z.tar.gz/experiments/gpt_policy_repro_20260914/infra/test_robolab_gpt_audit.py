"""Synthetic native terminal fixture; test corruption and partial/full scoring boundaries."""
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
import numpy as np
from audit_robolab_gpt_actions import audit


def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value)+'\n')


def fixture(root,mode='student'):
    out=root/'rollout';workspace=out/'codex_workspace';workspace.mkdir(parents=True)
    prompt='Directly recorded synthetic public prompt.';(workspace/'PROMPT.md').write_text(prompt)
    sha=hashlib.sha256(prompt.encode()).hexdigest()
    policy=dict(config='pi05_droid_jointpos_polaris',backend='OpenPI/JAX',checkpoint_sha256='b'*64,inferences=0)
    write(root/'remote/policy_identity.json',policy)
    write(workspace/'worker.json',dict(model='gpt-6-astra',reasoning_effort='xhigh',prompt_sha256=sha,
        thread_id='thread',tools=['robolab_start','pi05_infer','robolab_execute']))
    write(workspace/'launch.json',dict(config=dict(model='gpt-6-astra',model_reasoning_effort='xhigh')))
    write(out/'run.json',dict(teacher_model='gpt-6-astra',teacher_reasoning_effort='xhigh',teacher_prompt_sha256=sha,
        config=policy['config'],student_backend=policy['backend'],student_identity_sha256=policy['checkpoint_sha256'],
        student_server_metadata=policy,initial_state_hash='a'*64,no_rollback=True,max_episode_steps=3,task='blocks',seed=0))
    native=root/'remote/sim/episode'
    write(native/'initial_scene.json',dict(state_sha256='a'*64,episode_id='episode'))
    response=dict(request_id='request',mode=mode,steps=3,reason='Synthetic visible evidence.')
    request=dict(request_id='request',step_id=0,episode_id='episode',inference_index=0,prediction_id='prediction')
    write(out/'request_000.json',request);write(out/'response_000.json',response)
    write(out/'history.json',[dict(decision=0,start_tick=0,end_tick=3,response=response,
        prediction_id='prediction',executed_steps=3,simulator_decision_receipt=dict(physical_steps=0))])
    write(native/'codex_decisions/000.json',dict(response=response,step_id=0,episode_id='episode',prediction_id='prediction'))
    args=dict(response=response,proposal_path='proposal',output_dir='next')
    write(workspace/'call_0000_request.json',dict(tool='robolab_execute',call_id='call',arguments=args))
    write(workspace/'call_0000_result.json',dict(step_id=3))
    write(workspace/'rpc_out.jsonl',dict(method='item/tool/call',params=dict(threadId='thread',callId='call',tool='robolab_execute',arguments=args)))
    raw=np.zeros((15,8),np.float32);raw[:,-1]=.6;actions=raw.copy();actions[:,-1]=1
    images=np.zeros((2,2,3),np.uint8);wrist=np.ones((2,2,3),np.uint8)
    states=np.repeat(np.arange(4,dtype=np.float32)[:,None],8,axis=1)
    np.savez_compressed(out/'proposal_000.npz',raw_actions=raw,actions=actions,
        states=states[0],main_images=images,wrist_images=wrist)
    np.savez_compressed(out/'execution_000.npz',actions=actions[:3],states=states[1:])
    if mode!='student':
        write(out/'edit_000.json',[dict(valid=True,executed_action=a.tolist()) for a in actions[:3]])
    for i,(start,n) in enumerate([(0,3)] if mode=='student' else [(0,1),(1,1),(2,1)]):
        np.savez_compressed(native/f'chunk_{i:05d}.npz',step_id=np.arange(start,start+n),action=actions[start:start+n],
            proposed=actions[start:start+n],states=states[start:start+n],final_states=states[start+n],
            main_images=np.stack([images]*n),wrist_images=np.stack([wrist]*n),episode_id='episode',initial_state_hash='a'*64,
            student_policy_sha256='b'*64,source='student' if mode=='student' else 'gpt_eef',
            student_prediction_id='prediction' if mode=='student' else '',teacher_request_id='' if mode=='student' else 'request',
            terminated=np.zeros(n,bool),truncated=np.arange(start,start+n)==2,success=np.zeros(n,bool))
    result=dict(complete=True,step_id=3,decisions=1,predictions=1,terminated=False,truncated=True,success=False,
        student_steps=3 if mode=='student' else 0,edited_steps=0,recovery_steps=0 if mode=='student' else 3)
    write(out/'result.json',result)
    write(native/'summary.json',dict(complete=True,control_steps=3,terminated=False,truncated=True,success=False,
        native_max_episode_steps=3,max_episode_steps=3,task='blocks',seed=0))
    return native


class RoboLabGPTAuditTests(unittest.TestCase):
    def test_direct_terminal_has_no_student_identity_or_proposal(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);native=fixture(root,'eef');out=root/'rollout';workspace=out/'codex_workspace'
            identity=json.loads((out/'run.json').read_text());identity.update(evaluation_method='gpt_only',
                pi05_enabled=False,pi05_inference_calls=0,checkpoint=None,student_backend=None,student_identity_sha256=None)
            write(out/'run.json',identity)
            worker=json.loads((workspace/'worker.json').read_text());worker.update(pi05_enabled=False,tools=['robolab_start','robolab_execute'])
            write(workspace/'worker.json',worker)
            with np.load(out/'proposal_000.npz',allow_pickle=False) as z:
                observed={k:z[k] for k in ['main_images','wrist_images','states']}
            (out/'proposal_000.npz').unlink();(root/'remote/policy_identity.json').unlink()
            (out/'observations/000').mkdir(parents=True);np.savez_compressed(out/'observations/000/observation.npz',**observed)
            request=json.loads((out/'request_000.json').read_text());request['prediction_id']=None;write(out/'request_000.json',request)
            history=json.loads((out/'history.json').read_text());history[0]['prediction_id']=None;write(out/'history.json',history)
            receipt=json.loads((native/'codex_decisions/000.json').read_text());receipt['prediction_id']=None;write(native/'codex_decisions/000.json',receipt)
            result=json.loads((out/'result.json').read_text());result.update(predictions=0,gpt_eef_steps=3,pi05_inference_calls=0,recovery_steps=0);write(out/'result.json',result)
            for path in native.glob('chunk_*.npz'):
                with np.load(path,allow_pickle=False) as z:data=dict(z)
                data['student_policy_sha256']='';np.savez_compressed(path,**data)
            proof=audit(root)
            self.assertEqual(proof['method'],'gpt_only');self.assertEqual(proof['pi05_inference_calls'],0)
            self.assertIsNone(proof['student_identity_sha256']);self.assertTrue(proof['complete_episode'])
            write(root/'remote/policy_identity.json',{'invented':'student'})
            with self.assertRaises(AssertionError):audit(root)

    def test_native_failure_and_eef_are_audited_as_full_episodes(self):
        for mode in ('student','eef'):
            with self.subTest(mode=mode),tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp);fixture(root,mode);proof=audit(root)
                self.assertTrue(proof['complete_episode']);self.assertEqual(proof['native_actions'],3)
                self.assertFalse(proof['terminal']['success'])

    def test_partial_without_terminal_file_never_becomes_completed(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);fixture(root);(root/'rollout/result.json').unlink()
            self.assertFalse(audit(root,1)['complete_episode'])
            with self.assertRaises(FileNotFoundError):audit(root)

    def test_corrupted_native_action_observation_and_request_identity_are_rejected(self):
        for key in ('action','states','main_images','teacher_request_id'):
            with self.subTest(key=key),tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp);native=fixture(root);p=native/'chunk_00000.npz'
                with np.load(p,allow_pickle=False) as z:data=dict(z)
                if key=='teacher_request_id':data[key]='wrong'
                else:data[key].flat[0]+=1
                np.savez_compressed(p,**data)
                with self.assertRaises(AssertionError):audit(root)

    def test_missing_model_event_and_prompt_mismatch_are_rejected(self):
        for file in ('rpc_out.jsonl','PROMPT.md'):
            with self.subTest(file=file),tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp);fixture(root)
                (root/'rollout/codex_workspace'/file).write_text('')
                with self.assertRaises(AssertionError):audit(root)

    def test_early_termination_or_non_native_horizon_is_rejected(self):
        for key in ('terminated','native_max_episode_steps'):
            with self.subTest(key=key),tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp);native=fixture(root)
                if key=='terminated':
                    p=native/'chunk_00000.npz'
                    with np.load(p,allow_pickle=False) as z:data=dict(z)
                    data['terminated'][0]=True;np.savez_compressed(p,**data)
                else:
                    p=native/'summary.json';x=json.loads(p.read_text());x[key]=4;write(p,x)
                with self.assertRaises(AssertionError):audit(root)


if __name__=='__main__':unittest.main()
