import json
from pathlib import Path
import tempfile
import unittest
from queue_robolab_two_methods import classify,choose


class RoboLabQueueTests(unittest.TestCase):
    def test_first_full_failure_is_kept_and_later_success_cannot_replace_it(self):
        with tempfile.TemporaryDirectory() as tmp:
            paths=[Path(tmp)/name for name in ('first','later')]
            for path in paths:
                (path/'rollout').mkdir(parents=True)
                (path/'rollout/result.json').write_text(json.dumps(dict(complete=True,terminated=False,truncated=True)))
            attempts=[(p,dict(started_utc=str(i))) for i,p in enumerate(paths)]
            row=dict(task='blocks',seed=0,method='gpt_only')
            result=classify(row,attempts,lambda p,r:dict(success=p.name=='later',step_id=3))
            self.assertEqual(result['attempt'],'first');self.assertFalse(result['success'])

    def test_native_terminal_with_invalid_audit_blocks_physical_retry(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp);(path/'rollout').mkdir()
            (path/'rollout/result.json').write_text(json.dumps(dict(complete=True,terminated=True,truncated=False)))
            def reject(*_):raise AssertionError('wrong native action')
            result=classify(dict(task='blocks',seed=0,method='gpt_only'),[(path,dict(started_utc='0'))],reject)
            self.assertEqual(result['status'],'audit_failed');self.assertIsNone(choose([result]))

    def test_untried_jobs_precede_infra_retry_and_exhaustion_is_not_complete(self):
        row=dict(task='blocks',seed=0,method='pi05_plus_gpt')
        with tempfile.TemporaryDirectory() as tmp:
            attempts=[(Path(tmp),dict(started_utc=str(i))) for i in range(3)]
            exhausted=classify(row,attempts)
            self.assertEqual(exhausted['status'],'infrastructure_retry_exhausted')
            retry=dict(status='pending',attempts=2,id='retry');untried=dict(status='pending',attempts=0,id='first')
            self.assertEqual(choose([retry,untried,exhausted]),untried)


if __name__=='__main__':unittest.main()
