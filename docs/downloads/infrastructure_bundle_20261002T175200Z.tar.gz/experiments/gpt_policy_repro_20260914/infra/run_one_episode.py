"""Run one auditable π0.5-backed episode with an injectable teacher response source.

The default ``student`` mode is an infrastructure smoke: it accepts each π0.5
proposal and records the exact simulator receipt. A real GPT teacher can be
added by supplying a callable response provider without changing simulator or
policy-server code.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from hybrid_rollout.robodojo.pi05_server.client import Pi05Client
from hybrid_rollout.robodojo.robodojo_server.client import RoboDojoTools
from teacher_backend import OpenAICompatibleTeacher


def student_response(request, proposal):
    step = int(request["step_id"])
    assessment = {
        "task_progress": {
            "verified_completed": [],
            "currently_attempting": "Continue the current task from the observed scene",
            "remaining": ["Complete the task instruction"],
        },
        "current_subgoal": "Continue the current task from the observed scene",
        "execution_status": "not_started" if step == 0 else "uncertain",
        "execution_evidence": "No previous control chunk exists." if step == 0 else "The previous chunk has no verified native outcome in this smoke runner.",
        "expected_next_intent": "Continue the current student action proposal.",
        "predicted_next_intent": "The student proposal continues the task from the current observation.",
        "intent_status": "aligned",
        "intent_evidence": "The smoke runner does not override the student proposal.",
    }
    return {
        "request_id": request["request_id"],
        "mode": "student",
        "steps": min(15, len(proposal["actions"])) ,
        "reason": "The infrastructure smoke runner accepts the π0.5 proposal without teacher takeover.",
        "assessment": assessment,
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--task", required=True)
    p.add_argument("--sim-port", type=int, default=19130)
    p.add_argument("--policy-port", type=int, default=18830)
    p.add_argument("--checkpoint", type=Path, required=True)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--max-decisions", type=int, default=1)
    p.add_argument("--eval-manifest", type=Path)
    p.add_argument("--case-file", type=Path)
    p.add_argument("--teacher-config", type=Path)
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    provenance = {"method": "experimental_api_teacher" if args.teacher_config else "pi05_prefix15",
                  "controller": "responses_adapter" if args.teacher_config else "handwritten_accept_student",
                  "benchmark_eligible": args.max_decisions == 0 and not args.teacher_config,
                  "teacher_invoked": bool(args.teacher_config), "max_decisions": args.max_decisions}
    (args.output / "reproduction.json").write_text(json.dumps(provenance, indent=2) + "\n")
    student = Pi05Client(args.policy_port, str(args.checkpoint))
    teacher = OpenAICompatibleTeacher(args.teacher_config) if args.teacher_config else None
    tools = RoboDojoTools(args.output, args.task, student, sim_port=args.sim_port,
                          seed=args.seed, max_decisions=args.max_decisions)
    try:
        start = tools.next_call(); start.pop("tool")
        packet = tools.start(**start)
        while packet.get("next_call"):
            if tools.phase == "infer":
                call = tools.next_call(); call.pop("tool")
                packet = tools.infer(**call)
            elif tools.phase == "execute":
                response = teacher(tools.request, {"actions": tools.actions}) if teacher else student_response(tools.request, {"actions": tools.actions})
                call = tools.next_call(); call.pop("tool"); call["response"] = response
                packet = tools.execute(**call)
            else:
                break
        print(json.dumps({"output": str(args.output), "phase": tools.phase,
                          "history": len(tools.history)}, ensure_ascii=False))
    finally:
        try:
            tools.close()
        finally:
            student.close()


if __name__ == "__main__":
    main()
