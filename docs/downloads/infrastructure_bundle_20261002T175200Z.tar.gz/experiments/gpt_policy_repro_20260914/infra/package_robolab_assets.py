"""Verify all tracked RoboLab assets against the pinned Git/LFS objects and bundle them."""
import concurrent.futures,hashlib,io,json,subprocess,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
REPO=ROOT/'upstream/RoboLab'
OUT=ROOT/'upstream/checkpoints/robolab-assets'
PIN='ad45d4f974725d020f82c2b0d77d78533aeba2b3'

def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args])
def digest(path,algorithm='sha256',prefix=b''):
 h=hashlib.new(algorithm);h.update(prefix)
 with path.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def main():
 assert git('rev-parse','HEAD').decode().strip()==PIN
 OUT.mkdir(parents=True,exist_ok=True)
 entries=[]
 for line in git('ls-tree','-rlz',PIN,'assets').split(b'\0'):
  if not line:continue
  header,path=line.split(b'\t',1);mode,kind,oid,size=header.decode().split()
  assert mode=='100644' or mode=='100755';assert kind=='blob'
  entries.append(dict(path=path.decode(),git_oid=oid,blob_size=int(size)))
 small=[e['git_oid'] for e in entries if e['blob_size']<300]
 data=subprocess.run(['git','-C',str(REPO),'cat-file','--batch'],input=('\n'.join(small)+'\n').encode(),capture_output=True,check=True).stdout
 stream=io.BytesIO(data);blobs={}
 for _ in small:
  oid,kind,size=stream.readline().decode().split();blobs[oid]=stream.read(int(size));assert stream.read(1)==b'\n'
 def verify(e):
  p=REPO/e['path'];assert p.is_file() and not p.is_symlink()
  blob=blobs.get(e['git_oid'],b'')
  if blob.startswith(b'version https://git-lfs.github.com/spec/v1\n'):
   fields=dict(line.split(' ',1) for line in blob.decode().splitlines());expected=fields['oid'].removeprefix('sha256:')
   assert p.stat().st_size==int(fields['size']),e['path'];sha=digest(p);assert sha==expected,e['path']
  else:
   assert p.stat().st_size==e['blob_size'],e['path']
   assert digest(p,'sha1',f"blob {e['blob_size']}\0".encode())==e['git_oid'],e['path'];sha=digest(p)
  return dict(path=e['path'],size=p.stat().st_size,sha256=sha,git_oid=e['git_oid'])
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(verify,entries))
 manifest=OUT/'assets_manifest.json';manifest.write_text(json.dumps(dict(source_commit=PIN,verified=True,files=rows),indent=2)+'\n')
 print(json.dumps({'assets_verified':len(rows),'bytes':sum(r['size'] for r in rows)}),flush=True)
 archive=OUT/'assets.tar.gz';temp=archive.with_suffix('.partial')
 with tarfile.open(temp,'w:gz',compresslevel=1) as tf:
  for row in rows:tf.add(REPO/row['path'],arcname=row['path'],recursive=False)
 temp.replace(archive)
 source=OUT/'source.tar.gz';subprocess.run(['git','-C',str(REPO),'archive','--format=tar.gz','--output='+str(source),PIN,'robolab','pyproject.toml'],check=True)
 files=[dict(path=p.name,size=p.stat().st_size,sha256=digest(p)) for p in (archive,source,manifest)]
 (OUT/'download_manifest.json').write_text(json.dumps(dict(source='RoboLab-pinned-assets',source_commit=PIN,verified=True,files=files),indent=2)+'\n')
 print(json.dumps({'bundle_verified':True,'files':files}),flush=True)
if __name__=='__main__':main()
