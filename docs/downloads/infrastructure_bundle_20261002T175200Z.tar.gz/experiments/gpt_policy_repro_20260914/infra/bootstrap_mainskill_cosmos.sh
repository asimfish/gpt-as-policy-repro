#!/usr/bin/env bash
set -euo pipefail
ROOT=/home/dataset-assist-0/liyufeng/agentic_robot
OUT="$ROOT/experiments/gpt_policy_repro_20260914/mainskill"
export HTTPS_PROXY="${OPENPI_DOWNLOAD_PROXY:-http://127.0.0.1:18997}"
export HTTP_PROXY="$HTTPS_PROXY" NO_PROXY=127.0.0.1,localhost
export UV_CACHE_DIR="$ROOT/uv-cache" UV_PROJECT_ENVIRONMENT="$ROOT/venvs/cosmos-policy"
export UV_PYTHON_INSTALL_DIR="$ROOT/uv-python" UV_HTTP_TIMEOUT=300 UV_CONCURRENT_DOWNLOADS=3
export GIT_LFS_SKIP_SMUDGE=1 LD_LIBRARY_PATH=''
mkdir -p "$ROOT/venvs" "$OUT"
exec 9>"$ROOT/venvs/cosmos-bootstrap.lock"
flock -n 9
# Prioritize the already-running OpenPI environment and native validation.
for i in $(seq 1 1440); do
 [[ -f "$OUT/openpi_environment.json" ]] && break
 sleep 15
done
[[ -f "$OUT/openpi_environment.json" ]]
if [[ -f "$ROOT/upstream/source-mirrors/cosmos_git_verification.json" ]]; then
 export GIT_CONFIG_COUNT=2
 export GIT_CONFIG_KEY_0="url.file://$ROOT/upstream/source-mirrors/lerobot.git.insteadOf"
 export GIT_CONFIG_VALUE_0=https://github.com/mli0603/lerobot.git
 export GIT_CONFIG_KEY_1="url.file://$ROOT/upstream/source-mirrors/megatron-core.git.insteadOf"
 export GIT_CONFIG_VALUE_1=https://github.com/NVIDIA/Megatron-LM.git
fi
cd "$ROOT/upstream/cosmos-framework"
# The pinned Ampere FlashAttention wheel is cp313; CUDA 12.8 is an official group.
/home/batchcom/.local/bin/uv sync --frozen --no-dev --extra train --extra guardrail --group cu128-train --group policy-server --python 3.13 --find-links "$ROOT/upstream/checkpoints/cosmos-wheels" --find-links "$ROOT/upstream/checkpoints/openpi-build-wheels"
# TE 2.12's no-toolkit branch searches cuda_cudart rather than cuda_runtime.
# Its supported NVRTC_HOME override locates the existing locked CUDA 12.8 wheel
# and avoids that branch, without modifying packages or dependency versions.
export NVRTC_HOME="$UV_PROJECT_ENVIRONMENT/lib/python3.13/site-packages/nvidia/cuda_nvrtc"
[[ -d "$NVRTC_HOME/lib" ]]
"$UV_PROJECT_ENVIRONMENT/bin/python" - <<'PY'
import importlib.metadata as m,json,os
from pathlib import Path
import cosmos_framework.scripts.action_policy_server_robolab
import cosmos_framework.auxiliary.guardrail.common.presets
p=Path('/home/dataset-assist-0/liyufeng/agentic_robot/experiments/gpt_policy_repro_20260914/mainskill/cosmos_environment.json')
p.write_text(json.dumps({'server_import_verified':True,'source_commit':'2a8339d46a6e10e96f26c98509e6080d04ead490','dependency_groups':['train','guardrail','cu128-train','policy-server'],'runtime_environment':{'NVRTC_HOME':os.environ['NVRTC_HOME'],'LD_LIBRARY_PATH':''},'versions':{k:m.version(k) for k in ['torch','numpy','flash-attn','cosmos-framework','transformer-engine','nvidia-cuda-runtime-cu12','nvidia-cuda-nvrtc-cu12']}},indent=2)+'\n')
print(p.read_text())
PY
