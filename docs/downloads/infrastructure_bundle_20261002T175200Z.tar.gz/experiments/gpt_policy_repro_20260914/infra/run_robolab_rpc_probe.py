"""Bounded native RPC diagnostic: hold actions only, never benchmark eligible."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import time
import numpy as np
from hybrid_rollout.robolab.robolab_server.protocol import RPCClient


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--task',default='BlocksInBinTask')
    p.add_argument('--seed',type=int,default=0)
    p.add_argument('--port',type=int,default=20630)
    p.add_argument('--idle-seconds',type=float,default=0)
    p.add_argument('--eef',action='store_true')
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
    evidence=dict(schema='gpt_policy_robolab.rpc_probe.v1',benchmark_eligible=False,
        model_calls=0,pi05_inference_calls=0,task=a.task,seed=a.seed,eef_solver_invoked=a.eef,
        started_utc=datetime.now(timezone.utc).isoformat(),events=[])
    sim=None
    def persist():
        (a.output/'rpc_probe.json').write_text(json.dumps(evidence,indent=2)+'\n')
    def request(op,**args):
        row=dict(op=op,phase='sent',monotonic=time.monotonic())
        evidence['events'].append(row);persist()
        result=sim.request(op,**args)
        row.update(phase='acknowledged',seconds=time.monotonic()-row['monotonic']);persist()
        return result
    try:
        sim=RPCClient('127.0.0.1',a.port,timeout=75)
        meta=request('metadata');assert meta['task']==a.task
        reset=request('reset',seed=a.seed,source='diagnostic_hold',policy_version='infrastructure-rpc-hold')
        episode=reset['episode_id'];tick=reset['step_id']
        assert tick==0
        obs=request('teacher_observation',episode_id=episode,step_id=tick)
        if a.idle_seconds:time.sleep(a.idle_seconds)
        for count in ((1,) if a.eef else (1,15)):
            if a.eef:
                proposal=request('diagnostic_eef_proposal',episode_id=episode,step_id=tick,
                    position=np.asarray(obs['ee_pos']).tolist(),
                    quaternion_wxyz=np.asarray(obs['ee_quat_wxyz']).tolist(),gripper_closed=False)
                actions=np.asarray([proposal['action']],dtype=np.float32)
            else:
                actions=np.tile(np.asarray(obs['states'],dtype=np.float32),(count,1))
                actions[:,-1]=0
            result=request('chunk_step',episode_id=episode,step_id=tick,actions=actions)
            assert result['step_id']==tick+count and len(result['steps'])==count
            tick=result['step_id'];obs=result['steps'][-1]['obs']
            evidence['acknowledged_control_steps']=tick;persist()
        final=request('finish_pilot',episode_id=episode,step_id=tick,reason='infrastructure_rpc_hold')
        evidence.update(passed=True,complete_episode=False,native_terminal=bool(final['terminated'] or final['truncated']))
    except Exception as error:
        evidence.update(passed=False,error_type=type(error).__name__,error=str(error),complete_episode=False)
    finally:
        if sim:sim.close()
        evidence['finished_utc']=datetime.now(timezone.utc).isoformat();persist()
        print(json.dumps(evidence),flush=True)
    return 0 if evidence.get('passed') else 1


if __name__=='__main__':raise SystemExit(main())
