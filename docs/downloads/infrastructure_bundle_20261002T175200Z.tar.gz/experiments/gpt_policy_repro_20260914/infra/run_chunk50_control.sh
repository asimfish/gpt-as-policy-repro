#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/env.sh"
ARTIFACT="$REPRO_ROOT/experiments/gpt_policy_repro_20260914"
export CUDA_VISIBLE_DEVICES=1 SIM_GPU=1
# The prefix campaign releases this shared experiment lock only after its workers exit.
exec 8>"$ARTIFACT/student_native_campaign/.campaign.lock"
flock 8
for i in $(seq 1 120); do
  free_mib=$(nvidia-smi --id=1 --query-gpu=memory.free --format=csv,noheader,nounits)
  if [[ "$free_mib" -ge 20000 ]]; then break; fi
  sleep 15
done
[[ "$free_mib" -ge 20000 ]]
python3 "$ARTIFACT/infra/run_batch_student.py" --method pi05_chunk50 \
 --cases "$ARTIFACT/fixtures/cases" --output "$ARTIFACT/chunk50_control" \
 --sim-wrapper "$ARTIFACT/infra/run_sim_server.sh" --policy-wrapper "$ARTIFACT/infra/run_pi05_server.sh" \
 --checkpoint "$PI05_CHECKPOINT" --eval-manifest "$ARTIFACT/fixtures/evaluation_manifest.json" \
 --case-id put_bottles_into_dustbin__standard__g0__l0 --limit 1 --max-decisions 0 --base-port 19600
python3 "$ARTIFACT/infra/build_reproduction_report.py" "$ARTIFACT"
python3 "$ARTIFACT/infra/render_dashboard.py" "$ARTIFACT"
