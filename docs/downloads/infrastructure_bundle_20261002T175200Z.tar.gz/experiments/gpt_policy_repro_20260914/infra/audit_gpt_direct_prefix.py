"""Audit a completed decision prefix of a live Direct run; never claim episode completion."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np


def audit(run, decisions):
    assert decisions > 0
    rollout = run/'rollout'
    worker = json.loads((rollout/'codex_workspace/worker.json').read_text())
    identity = json.loads((rollout/'run.json').read_text())
    assert worker['model'] == identity['teacher_model'] == 'gpt-6-astra'
    assert worker['reasoning_effort'] == 'xhigh' and worker['model_provider'] == 'openai'
    assert identity['evaluation_method'] == 'gpt_only' and identity['pi05_enabled'] is False
    assert identity['pi05_inference_calls'] == 0
    history = json.loads((rollout/'history.json').read_text())
    assert len(history) >= decisions
    calls = {}
    workspace = rollout/'codex_workspace'
    for p in sorted(workspace.glob('call_*_request.json')):
        d = json.loads(p.read_text())
        if d['tool'] != 'robodojo_act':
            continue
        args = d['arguments']
        if isinstance(args, str): args = json.loads(args)
        result = p.with_name(p.name.replace('_request.json', '_result.json'))
        if not result.exists() or json.loads(result.read_text()).get('no_execution') is True:
            continue
        calls[args['response']['request_id']] = (d, args, p)
    native_dirs = list((run/'sim').glob('*/action_000000.json'))
    assert len(native_dirs) == 1
    native_dir = native_dirs[0].parent
    hashed = [rollout/'run.json', workspace/'worker.json']
    needed_calls = set()
    count = 0
    for i, row in enumerate(history[:decisions]):
        assert row['decision'] == i and row['start_tick'] == count and row['source'] == 'gpt_eef'
        response = json.loads((rollout/f'response_{i:03d}.json').read_text())
        assert response == row['response']
        call, args, path = calls[response['request_id']]
        assert dict(args['response'], evaluation_method='gpt_only') == response
        needed_calls.add(call['call_id'])
        receipt = native_dir/'codex_decisions'/f'{i:03d}.json'
        recorded = json.loads(receipt.read_text())
        assert recorded['response'] == response and recorded['step_id'] == count
        assert recorded['episode_id'] == native_dir.name and recorded['prediction_id'] is None
        execution = rollout/f'execution_{i:03d}.npz'
        with np.load(execution, allow_pickle=False) as x:
            assert x['actions'].shape == (row['executed_steps'], 14)
            for offset, action in enumerate(x['actions']):
                native_path = native_dir/f'action_{count:06d}.json'
                native = json.loads(native_path.read_text())
                assert native['valid'] and native['step_id'] == count+1 and native['source'] == 'gpt_eef'
                assert native['teacher_request_id'] == response['request_id']
                assert np.array_equal(action, native['executed_action'])
                assert np.array_equal(x['states'][offset], native['obs']['states'])
                hashed.append(native_path)
                count += 1
        assert row['end_tick'] == count
        hashed.extend([path, receipt, execution, rollout/f'response_{i:03d}.json'])
    # Confirm each accepted request actually came from this model thread's RPC.
    origin = []
    with (workspace/'rpc_out.jsonl').open() as stream:
        for line in stream:
            event = json.loads(line)
            params = event.get('params', {})
            if event.get('method') == 'item/tool/call' and params.get('callId') in needed_calls:
                assert params['threadId'] == worker['thread_id'] and params['tool'] == 'robodojo_act'
                args = params['arguments']
                if isinstance(args, str): args = json.loads(args)
                assert calls[args['response']['request_id']][1] == args
                needed_calls.remove(params['callId'])
                origin.append(hashlib.sha256(json.dumps(event, sort_keys=True).encode()).hexdigest())
                if not needed_calls: break
    assert not needed_calls
    return dict(verified=True, complete_episode=False, scope='completed_direct_decision_prefix_only',
                model=worker['model'], reasoning_effort='xhigh', decisions=decisions, native_actions=count,
                pi05_inference_calls=0, max_absolute_action_error=0,
                initial_state_hash=identity['initial_state_hash'], model_tool_event_sha256=origin,
                files_sha256={str(p.relative_to(run)): hashlib.sha256(p.read_bytes()).hexdigest() for p in hashed})


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('run', type=Path)
    parser.add_argument('--decisions', type=int, required=True)
    parser.add_argument('--output', type=Path, required=True)
    a = parser.parse_args()
    proof = audit(a.run, a.decisions)
    a.output.write_text(json.dumps(proof, indent=2)+'\n')
    print(json.dumps({k:v for k,v in proof.items() if k != 'files_sha256'}))
