import sys
from pathlib import Path
from types import SimpleNamespace
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[3]/'gpt-as-policy'))
from hybrid_rollout.robolab.robolab_server.scene_recording import capture_scene_state,SceneRecordError

class NativeSceneCompatibility(unittest.TestCase):
 def capture(self,extra):
  state={'articulation':{},'rigid_object':{},'deformable_object':{},**extra}
  scene=SimpleNamespace(articulations={},get_state=lambda **kwargs:state)
  return capture_scene_state(SimpleNamespace(num_envs=1,scene=scene),episode_id='compat',step_id=0,kind='initial')
 def test_empty_surface_gripper_preserves_physical_hash(self):
  native=self.capture({'gripper':{}});legacy=self.capture({})
  self.assertEqual(native['state_sha256'],legacy['state_sha256'])
  self.assertEqual(native['metadata']['empty_native_state_families'],['gripper'])
 def test_nonempty_surface_gripper_cannot_be_discarded(self):
  with self.assertRaisesRegex(SceneRecordError,'Surface-gripper'):self.capture({'gripper':{'suction':[1]}})
 def test_unknown_native_family_is_rejected(self):
  with self.assertRaises(SceneRecordError):self.capture({'unknown':{}})
if __name__=='__main__':unittest.main()
