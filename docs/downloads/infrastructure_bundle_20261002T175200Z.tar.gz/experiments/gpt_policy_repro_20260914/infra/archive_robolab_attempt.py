"""Resume only stopped RoboLab artifacts; verify every archived byte, without RPC or actions."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import shlex
import subprocess
import time

from transfer_checkpoint_chunks import SSH

ARTIFACTS = Path(__file__).resolve().parents[1]
REMOTE_CAMPAIGN = '/home/dataset-assist-0/liyufeng/agentic_robot/experiments/gpt_policy_repro_20260914/robolab_gpt_campaign'
REMOTE_MANIFEST = '''from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1]);services=json.loads((root/'services.json').read_text())
assert services['status'] not in ('starting','ready'), 'Archive only stopped owned services'
assert services.get('finished_utc'), 'Wait until owned process cleanup and recorder flush finish'
files={}
for path in sorted(root.rglob('*')):
 assert not path.is_symlink(), 'Do not archive symbolic links'
 if path.is_file():
  h=hashlib.sha256()
  with path.open('rb') as stream:
   for block in iter(lambda:stream.read(8*1024*1024),b''):h.update(block)
  files[path.relative_to(root).as_posix()]={'size':path.stat().st_size,'sha256':h.hexdigest()}
print(json.dumps({'schema':'gpt_policy_robolab_remote_archive.v1','files':files}))
'''


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(8*1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def verify_archive(root, manifest):
    assert manifest['schema'] == 'gpt_policy_robolab_remote_archive.v1'
    assert manifest['files'], 'An empty transfer cannot qualify'
    total = 0
    for name, expected in manifest['files'].items():
        relative = PurePosixPath(name)
        assert relative.parts and not relative.is_absolute() and '..' not in relative.parts
        assert relative.as_posix() == name
        path = root.joinpath(*relative.parts)
        assert not any(part.is_symlink() for part in [path, *path.parents]), 'Archive paths must not follow links'
        assert path.is_file(), 'Missing archived file: '+name
        assert path.stat().st_size == expected['size'], 'Archived size differs: '+name
        assert digest(path) == expected['sha256'], 'Archived bytes differ: '+name
        total += expected['size']
    return dict(verified=True, files=len(manifest['files']), bytes=total)


def archive_attempt(path, cipher=None):
    record = json.loads((path/'attempt.json').read_text())
    assert path.name == record['attempt'] and Path(path.name).name == path.name
    assert record['remote_output'] == REMOTE_CAMPAIGN+'/'+path.name
    cipher = cipher or record.get('ssh_cipher', 'default')
    assert cipher in ('default', 'aes128-gcm@openssh.com')
    ssh = [*SSH[:-1], *(['-o', 'Ciphers='+cipher] if cipher != 'default' else [])]
    source = subprocess.run([*ssh, SSH[-1], shlex.join(['python3', '-c', REMOTE_MANIFEST, record['remote_output']])],
                            capture_output=True, text=True, check=True, timeout=180)
    manifest = json.loads(source.stdout)
    target = path/'remote'
    target.mkdir(exist_ok=True)
    for attempt in range(3):
        try:
            # Retrying this read-only artifact transfer never reconnects the simulator
            # or replays a control action. Checksums repair incomplete/corrupt copies.
            subprocess.run(['rsync', '-az', '--checksum', '--partial', '--timeout=90', '-e', shlex.join(ssh),
                            SSH[-1]+':'+record['remote_output']+'/', str(target)+'/'], check=True, timeout=1200)
            receipt = verify_archive(target, manifest)
            break
        except (subprocess.TimeoutExpired, subprocess.CalledProcessError):
            if attempt == 2:
                raise
            time.sleep(3)
    (path/'remote_archive_manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
    receipt.update(schema='gpt_policy_robolab_archive_receipt.v1', ssh_cipher=cipher,
                   manifest_sha256=digest(path/'remote_archive_manifest.json'),
                   verified_utc=datetime.now(timezone.utc).isoformat())
    (path/'remote_archive_receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
    return receipt


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('attempt')
    args = parser.parse_args()
    assert Path(args.attempt).name == args.attempt and args.attempt.startswith(('direct_', 'hybrid_'))
    print(json.dumps(archive_attempt(ARTIFACTS/'robolab_gpt_campaign'/args.attempt)))
