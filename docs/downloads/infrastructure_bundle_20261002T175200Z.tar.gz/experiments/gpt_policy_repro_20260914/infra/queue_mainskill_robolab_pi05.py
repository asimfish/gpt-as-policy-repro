"""Run all 50 fresh-seed Pi05 cases after the first complete native pilot is audited."""
import fcntl
import json
import os
from pathlib import Path
import signal
import subprocess
import time

ROOT=Path('/home/dataset-assist-0/liyufeng/agentic_robot')
ART=ROOT/'experiments/gpt_policy_repro_20260914'
ASSETS=ROOT/'upstream/RoboLab-ad45-full-assets'


def main():
    from audit_robolab_pi05_actions import audit
    output=ART/'mainskill_robolab_pi05_campaign';output.mkdir(parents=True,exist_ok=True)
    lock=(output/'queue.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    # The pilot is separate from this predeclared fresh 50-case cohort.
    pilot=None
    for _ in range(5760):
        candidates=sorted((ART/'mainskill_robolab_pi05').glob('*/rollout/result.json'))
        if (ASSETS/'assets_verification.json').exists():
            for path in candidates:
                if json.loads(path.read_text()).get('complete'):
                    pilot=path.parents[1];break
        if pilot is not None:break
        time.sleep(15)
    if pilot is None:raise RuntimeError('Complete native pilot and verified assets not available within 24 hours')
    proof=audit(pilot);(output/'pilot_acceptance.json').write_text(json.dumps(proof,indent=2)+'\n')
    marker=json.loads((ASSETS/'assets_verification.json').read_text())
    assert marker['verified'] is True and marker['files']==2228
    assert marker['source_commit']=='ad45d4f974725d020f82c2b0d77d78533aeba2b3'
    assert proof['checkpoint_manifest_sha256']=='14623e476057b934d9a9fc9a280a0b89e3b378dd48258881e383c93f4342507a'
    cases=[r for r in json.loads((ART/'fixtures/robolab_campaign.json').read_text())['entries'] if r['method']=='pi05_only']
    assert len(cases)==50 and len({(c['task'],c['seed']) for c in cases})==50
    status_path=output/'status.json';rows=json.loads(status_path.read_text())['cases'] if status_path.exists() else {}
    for case in cases:
        key=f"{case['task']}__seed{case['seed']}"
        if key in rows:
            if rows[key]['state']=='complete':continue
            raise RuntimeError(f'{key} requires review of its prior interrupted/failed attempt')
        if (output/key).exists():raise RuntimeError(f'{key} has an unreviewed prior attempt directory')
        # Wait until the prior pilot's owned policy/simulator cleanup releases its lock.
        with (ART/'mainskill/pi05_validation.lock').open('a') as native_lock:
            fcntl.flock(native_lock,fcntl.LOCK_EX)
        env=dict(os.environ,ROBO_LAB_ROOT=str(ASSETS),ROBO_LAB_TASK=case['task'],ROBO_LAB_SEED=str(case['seed']),
                 ROBO_LAB_RECORD_SCENE_STATE='1',ROBO_LAB_CAMPAIGN='mainskill_robolab_pi05_campaign/'+key)
        rows[key]=dict(task=case['task'],seed=case['seed'],state='running',benchmark_eligible=False)
        def save():
            temp=status_path.with_suffix('.tmp');temp.write_text(json.dumps(dict(scope='new fixed-seed cohort; historical raw states unavailable; pairing across methods pending',cases=rows),indent=2)+'\n');temp.replace(status_path)
        save()
        process=None
        with (output/(key+'.log')).open('a') as log:
            process=subprocess.Popen(['bash',str(ART/'infra/run_mainskill_robolab_pi05.sh')],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            def stop(signum,frame):
                os.killpg(process.pid,signal.SIGTERM)
                raise SystemExit(128+signum)
            previous={sig:signal.signal(sig,stop) for sig in (signal.SIGTERM,signal.SIGINT)}
            try:
                code=process.wait(timeout=7200)
            finally:
                if process.poll() is None:
                    os.killpg(process.pid,signal.SIGTERM)
                    try:process.wait(timeout=30)
                    except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
                for sig,handler in previous.items():signal.signal(sig,handler)
        rows[key].update(state='infrastructure_error',exit_code=code)
        runs=sorted((output/key).glob('*/rollout/result.json'))
        if code==0 and len(runs)==1:
            run=runs[0].parents[1];proof=audit(run)
            (run/'action_audit.json').write_text(json.dumps(proof,indent=2)+'\n')
            result=json.loads(runs[0].read_text())
            rows[key].update(state='complete',success=result['success'],control_steps=result['control_steps'],evidence=str(run.relative_to(ART)))
        save();print(json.dumps(rows[key]),flush=True)
        if rows[key]['state']!='complete':raise RuntimeError('Stop for review; no physical episode retry')


if __name__=='__main__':main()
