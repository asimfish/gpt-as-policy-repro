#!/usr/bin/env bash
set -euo pipefail
SSH=(ssh -o BatchMode=yes -o UserKnownHostsFile=/home/liyufeng/.ssh/known_hosts_a100 -o StrictHostKeyChecking=yes -o ServerAliveInterval=60 -o ServerAliveCountMax=10)
ARCHIVE=/tmp/gpt-policy-robolab-smoke-assets.tar.gz
HASH=$(sha256sum "$ARCHIVE" | cut -d' ' -f1)
rsync -a --partial --append-verify --timeout=600 --stats -e 'ssh -o BatchMode=yes -o UserKnownHostsFile=/home/liyufeng/.ssh/known_hosts_a100 -o StrictHostKeyChecking=yes -o ServerAliveInterval=60 -o ServerAliveCountMax=10' "$ARCHIVE" mainskill:/home/batchcom/gpt-policy-runtime/smoke-assets.tar.gz
"${SSH[@]}" mainskill bash -s -- "$HASH" <<'REMOTE'
set -euo pipefail
cd /home/batchcom/gpt-policy-runtime
printf '%s  smoke-assets.tar.gz\n' "$1" | sha256sum -c -
tar --no-same-owner -xzf smoke-assets.tar.gz -C RoboLab-ad45d4f974725d020f82c2b0d77d78533aeba2b3
printf '%s\n' "$1" > smoke_assets_verified.sha256
echo SMOKE_ASSETS_VERIFIED
REMOTE
