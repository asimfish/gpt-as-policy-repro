"""Direct contract tests: fake native RPC, real tools/worker loop, no model/GPU calls."""
import json
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import pytest

from hybrid_rollout.robolab.io import InputError
from robolab_direct_tools import DirectTools
from robolab_direct_server import DirectEnvironmentSession
from run_robolab_direct_controller import DirectPolicy,tool_specs


class Sim:
    def __init__(self,*args,**kwargs):
        self.calls=[];self.tick=0
    def request(self,op,**args):
        self.calls.append((op,args))
        if op=='metadata':
            return dict(task='blocks',supports_direct=True,instruction='put blocks in bin',max_episode_steps=2,control_dt=1/15)
        if op=='reset':
            assert args['source']=='diagnostic_hold' and args['policy_version']=='gpt_only'
            return dict(episode_id='episode',step_id=0,initial_state_hash='a'*64,metadata={})
        if op=='teacher_observation':
            return dict(instruction='put blocks in bin',remaining_steps=2-self.tick,
                states=np.zeros(8),ee_pos=np.zeros(3),ee_quat_wxyz=np.array([1,0,0,0]),
                main_images=np.zeros((4,4,3),np.uint8),wrist_images=np.zeros((4,4,3),np.uint8),
                main_rgb=np.zeros((4,4,3),np.uint8),wrist_rgb=np.zeros((4,4,3),np.uint8))
        if op=='record_codex_decision':
            assert args['prediction_id'] is None
            return dict(physical_steps=0)
        if op=='eef_joint_target':
            return dict(action=np.zeros(8),diagnostics=dict(valid=True))
        if op=='chunk_step':
            assert args['actions'].shape==(1,8) and args['teacher_request_id']
            self.tick+=1
            return dict(step_id=self.tick,steps=[dict(valid=True,terminated=False,truncated=self.tick>=2,
                success=False,executed_action=args['actions'][0],obs=dict(states=np.zeros(8)))])
        if op=='finish_pilot':
            return dict(episode_id='episode',step_id=self.tick,terminated=False,truncated=self.tick>=2,success=False,reason=args['reason'])
        return dict(physical_steps=0)
    def close(self):pass


def make(tmp_path,sim=Sim):
    output=tmp_path/'rollout';output.mkdir()
    return DirectTools(output,'blocks',max_decisions=100000,prompt_sha256='b'*64,rpc_factory=sim)


def response(request):
    return dict(request_id=request['request_id'],mode='eef',steps=5,reason='Visible approach toward the block.',
                target=dict(position=[0,0,.01],quaternion_wxyz=[1,0,0,0],gripper_closed=False))


def invoke(tools,**extra):
    args=tools.next_call().copy();name=args.pop('tool');args.update(extra)
    return dict(robolab_start=tools.start,robolab_execute=tools.execute)[name](**args)


def test_direct_uses_fresh_observation_and_stops_at_native_terminal(tmp_path):
    tools=make(tmp_path);invoke(tools)
    assert tools.tick==0 and tools.student is None
    after=invoke(tools,response=response(tools.request))
    assert after['result']['complete'] is True and after['result']['success'] is False
    assert tools.tick==2 and tools.counters['gpt_eef_steps']==2
    assert tools.counters['predictions']==tools.counters['student_steps']==0
    assert [op for op,_ in tools.sim.calls].count('chunk_step')==2
    assert not list(tools.output.glob('proposal_*.npz'))
    run=json.loads((tools.output/'run.json').read_text())
    assert run['pi05_enabled'] is False and run['checkpoint'] is None


@pytest.mark.parametrize('bad', ['student','stale','distance','steps','nonfinite'])
def test_invalid_direct_response_never_advances_physics(tmp_path,bad):
    tools=make(tmp_path);invoke(tools);decision=response(tools.request)
    if bad=='student':decision['mode']='student'
    elif bad=='stale':decision['request_id']='old'
    elif bad=='distance':decision['target']['position']=[1,0,0]
    elif bad=='steps':decision['steps']=6
    elif bad=='nonfinite':decision['target']['position']=[float('nan'),0,0]
    with pytest.raises(InputError):invoke(tools,response=decision)
    assert tools.tick==0 and not any(op in ('record_codex_decision','eef_joint_target','chunk_step') for op,_ in tools.sim.calls)


def test_missing_direct_simulator_and_pi05_calls_fail_closed(tmp_path):
    class Hybrid(Sim):
        def request(self,op,**args):
            result=super().request(op,**args)
            if op=='metadata':result['supports_direct']=False
            return result
    tools=make(tmp_path,Hybrid)
    with pytest.raises(RuntimeError):invoke(tools)
    assert [op for op,_ in tools.sim.calls]==['metadata']
    with pytest.raises(InputError):tools.infer()


def test_uncertain_action_ack_is_never_retried(tmp_path):
    class LostAck(Sim):
        def request(self,op,**args):
            result=super().request(op,**args)
            if op=='chunk_step':raise ConnectionError('ACK lost after physical execution')
            return result
    tools=make(tmp_path,LostAck);invoke(tools)
    with pytest.raises(ConnectionError):invoke(tools,response=response(tools.request))
    assert [op for op,_ in tools.sim.calls].count('chunk_step')==1 and tools.history==[]


def test_direct_server_declares_no_student_and_rejects_hybrid_operations():
    server=DirectEnvironmentSession.__new__(DirectEnvironmentSession)
    server.episode_id='episode';server.step_id=0;server.poisoned=False;server.source='diagnostic_hold'
    server.combination=server.branch=None;server.terminated=server.truncated=False
    server.record_scene_state=True;server.initial_state_hash='a'*64;server.max_steps=2250
    server._persist_combination=lambda:None
    ack=server.begin_direct('episode',0,'gpt-6-astra','b'*64)
    assert ack['source']=='gpt_eef' and server.combination['pi05_enabled'] is False
    assert server.combination['student_policy_sha256']==''
    for op in ('begin_combination','fk_preview','switch_control_source','pi05_infer'):
        with pytest.raises(ValueError):server.dispatch(op,{})


def test_persistent_worker_registers_only_two_direct_tools(tmp_path,monkeypatch):
    import run_robolab_direct_controller as module
    monkeypatch.setattr(module.subprocess,'run',lambda *a,**k:SimpleNamespace(stdout='codex-fixture'))
    class Transport:
        def __init__(self,*_):self.process=SimpleNamespace(pid=123);self.stage=0;self.packet=None
        def request(self,method,params,timeout):
            if method=='thread/start':
                assert [t['name'] for t in params['dynamicTools']]==['robolab_start','robolab_execute']
                assert params['allowProviderModelFallback'] is False and 'No student model' in params['developerInstructions']
                return dict(thread=dict(id='thread'),model='gpt-6-astra',reasoningEffort='xhigh')
            if method=='turn/start':
                self.first=json.loads(params['input'][0]['text'].split('First call: ')[1])
                return dict(turn=dict(id='turn'))
            return {}
        def notify(self,*_):pass
        def next_message(self,*_):
            if self.stage==2:return dict(method='turn/completed',params=dict(threadId='thread',turn=dict(id='turn',status='completed')))
            args=dict(self.first if self.stage==0 else self.packet['next_call']);name=args.pop('tool')
            if name=='robolab_execute':args['response']=response(self.packet)
            self.stage+=1
            return dict(id=self.stage,method='item/tool/call',params=dict(threadId='thread',turnId='turn',callId=str(self.stage),tool=name,arguments=args))
        def reply(self,identifier,result):
            assert result['success'];self.packet=json.loads(result['contentItems'][0]['text'])
        def close(self):pass
    worker=DirectPolicy(tmp_path/'workspace','codex',transport_factory=Transport)
    tools=make(tmp_path);worker.run(tools)
    assert tools.phase=='done' and tools.counters['predictions']==0
    assert len(tool_specs())==2
