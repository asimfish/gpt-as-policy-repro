"""Small asset-independent RGB probe; not a robotics benchmark or physics test."""
import argparse
from pathlib import Path
import json
import time

p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args()
a.output.mkdir(parents=True,exist_ok=False)
from isaacsim import SimulationApp
started=time.monotonic()
app=SimulationApp({'headless':True,'active_gpu':0,'physics_gpu':0,'multi_gpu':False,'anti_aliasing':1,'renderer':'RaytracedLighting'})
try:
    import numpy as np
    from PIL import Image
    import omni.replicator.core as rep
    with rep.new_layer():
        rep.create.light(light_type='Distant',intensity=1500)
        rep.create.cube(position=(0,0,0),scale=(0.6,0.6,0.6),semantics=[('class','cube')])
        camera=rep.create.camera(position=(2,2,2),look_at=(0,0,0))
    import omni.usd
    from pxr import UsdLux
    stage=omni.usd.get_context().get_stage()
    light_prims=[prim for prim in stage.Traverse() if prim.GetTypeName()=='DistantLight']
    assert len(light_prims)==1
    light_attr=UsdLux.DistantLight(light_prims[0]).GetIntensityAttr()
    previous_intensity=light_attr.Get()
    light_attr.Set(1500.0)
    assert light_attr.Get()==1500.0
    print(json.dumps({'event':'light_intensity_verified','before':previous_intensity,'after':light_attr.Get()}),flush=True)
    product=rep.create.render_product(camera,(320,240))
    rgb=rep.AnnotatorRegistry.get_annotator('rgb')
    rgb.attach([product])
    for _ in range(8):
        rep.orchestrator.step(rt_subframes=4)
    import omni.usd
    omni.usd.get_context().get_stage().Export(str(a.output/'scene.usda'))
    arr=np.asarray(rgb.get_data())
    np.save(a.output/'rgb.npy',arr)
    stats={'light_intensity_before':previous_intensity,'light_intensity_after':light_attr.Get(),'light_type':'Distant','anti_aliasing':'TAA','shape':list(arr.shape),'dtype':str(arr.dtype),'std':float(arr[...,:3].std()) if arr.size else 0,'wall_seconds':time.monotonic()-started,'benchmark_eligible':False,'scope':'RGB rendering only; no task or physics validation'}
    if arr.size:
        Image.fromarray(arr).save(a.output/'rgb.png')
    stats['passed']=arr.ndim==3 and arr.shape[:2]==(240,320) and stats['std']>2
    (a.output/'render_result.json').write_text(json.dumps(stats,indent=2)+'\n')
    print(json.dumps(stats),flush=True)
    if not stats['passed']:
        raise RuntimeError('Empty or uniform camera output')
finally:
    app.close()
