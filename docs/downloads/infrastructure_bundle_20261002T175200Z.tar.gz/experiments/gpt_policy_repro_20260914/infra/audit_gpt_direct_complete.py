"""Require native terminal evidence in addition to the complete Direct action audit."""
import hashlib
import json
from pathlib import Path
from audit_gpt_direct_prefix import audit as audit_prefix


def audit(run):
    run=Path(run)
    result_path=run/'rollout/result.json';outcome_path=run/'sim/evaluation_outcome.json'
    result=json.loads(result_path.read_text());outcome=json.loads(outcome_path.read_text())
    history=json.loads((run/'rollout/history.json').read_text())
    assert result['complete'] is True and (result['terminated'] or result['truncated'])
    assert outcome['complete'] is True and outcome['valid_for_success_rate'] is True
    proof=audit_prefix(run,len(history))
    count=proof['native_actions']
    assert result['step_id']==outcome['native_control_steps']==count
    assert result['decisions']==len(history)
    assert result['pi05_enabled'] is False and result['pi05_inference_calls']==0
    native=run/'sim'/result['episode_id'];paths=sorted(native.glob('action_*.json'))
    assert len(paths)==count
    for i,path in enumerate(paths):
        row=json.loads(path.read_text())
        terminal=bool(row['terminated'] or row['truncated'])
        assert terminal == (i==count-1)
    assert row['success']==result['success']==outcome['native_success']
    assert row['terminated']==result['terminated'] and row['truncated']==result['truncated']
    assert result['evaluation_case']==outcome['evaluation_case']
    proof.update(complete_episode=True,scope='complete_native_episode',
                 terminal={k:result[k] for k in ('success','terminated','truncated')},
                 native_score=outcome['native_score'],
                 limitation='Recorded executed joint actions checked; IK is not independently recomputed.')
    for path in (result_path,outcome_path,run/'rollout/history.json'):
        proof['files_sha256'][str(path.relative_to(run))]=hashlib.sha256(path.read_bytes()).hexdigest()
    return proof
