"""Transfer verified public checkpoint over bounded SSH chunks; resume and SHA256 gate."""
import argparse
import base64
import zlib
import concurrent.futures
import hashlib
import json
import shlex
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
SOURCE = ROOT / 'upstream/checkpoints/pi05_droid_jointpos'
DEST = '/home/dataset-assist-0/liyufeng/agentic_robot/upstream/checkpoints/pi05_droid_jointpos'
SSH = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15', '-o',
       'UserKnownHostsFile=/home/liyufeng/.ssh/known_hosts_a100', '-o', 'StrictHostKeyChecking=yes', 'mainskill']
CHUNK = 4 * 1024 * 1024


def remote(code, args=(), data=None, timeout=90):
    command = shlex.join(['python3', '-c', code, *map(str, args)])
    for attempt in range(5):
        try:
            result = subprocess.run([*SSH, command], input=data, capture_output=True, timeout=timeout, check=True)
            return result.stdout.decode().strip()
        except subprocess.CalledProcessError as error:
            if error.returncode != 255 or attempt == 4:
                raise
        except subprocess.TimeoutExpired:
            if attempt == 4:
                raise
        print(json.dumps({'event':'ssh_transport_retry','attempt':attempt+1}),flush=True)
        time.sleep(2)


def publish_manifest(path, data):
    # Small metadata travels as an argument: this avoids waiting on SSH stdin EOF.
    assert len(data) < 2*1024*1024
    encoded = base64.b64encode(zlib.compress(data)).decode()
    assert len(encoded) < 64000
    code = "import base64,hashlib,sys,zlib;from pathlib import Path;data=zlib.decompress(base64.b64decode(sys.argv[2]));assert hashlib.sha256(data).hexdigest()==sys.argv[3];p=Path(sys.argv[1]);t=p.with_suffix('.tmp');t.write_bytes(data);t.replace(p);print('published')"
    args = (path, encoded, hashlib.sha256(data).hexdigest())
    for attempt in range(5):
        try:
            return remote(code, args, timeout=30)
        except subprocess.SubprocessError:
            if attempt == 4:
                raise
            time.sleep(2)


WRITE = '''import hashlib,sys
from pathlib import Path
p=Path(sys.argv[1]);offset=int(sys.argv[2]);expected=sys.argv[3]
data=sys.stdin.buffer.read(int(sys.argv[4]))
assert hashlib.sha256(data).hexdigest()==expected
p.parent.mkdir(parents=True,exist_ok=True)
with p.open('r+b' if p.exists() else 'w+b') as f:
 f.seek(0,2);assert f.tell()>=offset
 f.seek(offset);f.write(data);f.flush()
print(offset+len(data))
'''
VERIFY = '''import hashlib,sys
from pathlib import Path
p=Path(sys.argv[1]);target=Path(sys.argv[2]);size=int(sys.argv[3]);expected=sys.argv[4]
if not p.exists():p=target
assert p.stat().st_size==size
h=hashlib.sha256()
with p.open('rb') as f:
 for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
assert h.hexdigest()==expected
if p!=target:p.replace(target)
print('verified')
'''


def write_chunk(partial, offset, digest, data):
    args = (partial, offset, digest, len(data))
    if len(data) <= 48000:
        code = "import base64\n" + WRITE.replace("data=sys.stdin.buffer.read(int(sys.argv[4]))", "data=base64.b64decode(sys.argv[5])")
        return remote(code, (*args, base64.b64encode(data).decode()))
    return remote(WRITE, args, data=data)


def transfer(row):
    relative = Path(row['path'])
    assert not relative.is_absolute() and '..' not in relative.parts
    source = SOURCE / relative
    target = DEST + '/' + relative.as_posix()
    partial = target + '.sshchunks'
    # Existing files are accepted only after hashing; an interrupted rsync prefix fails this check.
    code = '''import hashlib,sys
from pathlib import Path
p=Path(sys.argv[1]);partial=Path(sys.argv[2]);expected=sys.argv[3];size=int(sys.argv[4])
ok=False
if p.exists() and p.stat().st_size==size:
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 ok=h.hexdigest()==expected
print('complete' if ok else (partial.stat().st_size if partial.exists() else 0))
'''
    status = remote(code, (target, partial, row['sha256'], row['size']), timeout=180)
    if status == 'complete':
        print(json.dumps({'event': 'already_verified', 'path': str(relative)}), flush=True)
        return
    offset = int(status)
    assert 0 <= offset <= row['size']
    # If interrupted during a remote write, re-send the last partial block.
    offset = offset // CHUNK * CHUNK
    with source.open('rb') as f:
        f.seek(offset)
        while data := f.read(CHUNK):
            digest = hashlib.sha256(data).hexdigest()
            for attempt in range(5):
                try:
                    ack = write_chunk(partial, offset, digest, data)
                    assert int(ack) == offset + len(data)
                    break
                except (subprocess.SubprocessError, AssertionError) as error:
                    print(json.dumps({'event':'retry','path':str(relative),'offset':offset,'attempt':attempt,'error':type(error).__name__}),flush=True)
                    if attempt == 4: raise
                    time.sleep(2)
            offset += len(data)
            print(json.dumps({'event':'progress','path':str(relative),'bytes':offset,'size':row['size']}),flush=True)
    remote(VERIFY, (partial, target, row['size'], row['sha256']), timeout=300)
    print(json.dumps({'event':'verified','path':str(relative)}),flush=True)


def main():
    global SOURCE, DEST
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', choices=('pi05_droid_jointpos','DreamZero-DROID','Cosmos3-Nano-Policy-DROID','openpi-wheels','cosmos-wheels','cosmos-git-sources','robolab-assets'), default='pi05_droid_jointpos')
    args = parser.parse_args()
    SOURCE = ROOT / 'upstream/checkpoints' / args.checkpoint
    DEST = '/home/dataset-assist-0/liyufeng/agentic_robot/upstream/checkpoints/' + args.checkpoint
    raw = (SOURCE / 'download_manifest.json').read_bytes()
    manifest = json.loads(raw)
    expected_sources = {'cosmos-git-sources':'cosmos-pinned-git-dependencies','cosmos-wheels':'cosmos-frozen-lock-wheels','robolab-assets':'RoboLab-pinned-assets','openpi-wheels':'openpi-frozen-lock-wheels','pi05_droid_jointpos':'gs://openpi-assets-simeval/pi05_droid_jointpos',
                        'DreamZero-DROID':'GEAR-Dreams/DreamZero-DROID',
                        'Cosmos3-Nano-Policy-DROID':'nvidia/Cosmos3-Nano-Policy-DROID'}
    assert manifest['source'] == expected_sources[args.checkpoint]
    assert manifest.get('verified') is True
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        list(pool.map(transfer, manifest['files']))
    payload = {'verified': True, 'files': len(manifest['files']), 'manifest_sha256': hashlib.sha256(raw).hexdigest(),
               'source': manifest['source'], 'transport': 'bounded_ssh_chunks_with_per_object_sha256'}
    publish_manifest(DEST+'/download_manifest.json', raw)
    publish_manifest(DEST+'/transfer_verification.json', json.dumps(payload,indent=2).encode())
    print(json.dumps(payload),flush=True)


if __name__ == '__main__': main()
