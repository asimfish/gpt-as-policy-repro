import json
from unittest.mock import Mock
import pytest
from run_gpt_pair import check_pair_simulator


def prepared(tmp_path):
    (tmp_path/'sim').mkdir()
    (tmp_path/'rollout').mkdir()
    (tmp_path/'sim.log').write_text('normal close')
    (tmp_path/'sim/evaluation_outcome.json').write_text(json.dumps({'complete':False,'reason':'controller_error'}))
    (tmp_path/'rollout/failure.json').write_text(json.dumps({'completed':False}))
    return Mock(poll=Mock(return_value=0),returncode=0),tmp_path


def test_incomplete_close_allows_controller_to_finish_video(tmp_path):
    proc,run=prepared(tmp_path)
    assert check_pair_simulator(proc,run,100,None)==100
    assert check_pair_simulator(proc,run,200,100)==100


def test_finalization_is_bounded(tmp_path):
    proc,run=prepared(tmp_path)
    with pytest.raises(TimeoutError):check_pair_simulator(proc,run,701,100)


def test_unexplained_clean_exit_is_failure(tmp_path):
    proc,run=prepared(tmp_path)
    (run/'sim/evaluation_outcome.json').unlink()
    with pytest.raises(RuntimeError):check_pair_simulator(proc,run,100,None)


def test_nonzero_exit_is_failure(tmp_path):
    proc,run=prepared(tmp_path);proc.poll.return_value=1;proc.returncode=1
    with pytest.raises(RuntimeError):check_pair_simulator(proc,run,100,None)
