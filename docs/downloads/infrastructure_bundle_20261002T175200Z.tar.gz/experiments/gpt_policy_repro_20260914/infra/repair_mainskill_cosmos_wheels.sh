#!/usr/bin/env bash
set -euo pipefail
ROOT=/mnt/nas/data/lyf/agentic_robot
INFRA="$ROOT/experiments/gpt_policy_repro_20260914/infra"
export XDG_RUNTIME_DIR=/run/user/1007 DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/1007/bus
for i in $(seq 1 2880); do
 if [[ -f "$ROOT/upstream/checkpoints/cosmos-wheels/download_manifest.json" ]] && ! systemctl --user is-active --quiet gpt-policy-robolab-full-assets.service; then break; fi
 sleep 15
done
[[ -f "$ROOT/upstream/checkpoints/cosmos-wheels/download_manifest.json" ]]
python3 "$INFRA/transfer_checkpoint_chunks.py" --checkpoint cosmos-wheels
ssh -o BatchMode=yes -o ConnectTimeout=15 -o UserKnownHostsFile=/home/liyufeng/.ssh/known_hosts_a100 -o StrictHostKeyChecking=yes mainskill 'bash -s' <<'REMOTE'
set -euo pipefail
ROOT=/home/dataset-assist-0/liyufeng/agentic_robot
export UV_CACHE_DIR="$ROOT/uv-cache"
exec 9>"$ROOT/venvs/cosmos-bootstrap.lock"
flock 9
/home/batchcom/.local/bin/uv pip install --python "$ROOT/venvs/cosmos-policy/bin/python" --no-deps --no-index --find-links "$ROOT/upstream/checkpoints/cosmos-wheels" --find-links "$ROOT/upstream/checkpoints/openpi-build-wheels" --requirements "$ROOT/upstream/checkpoints/cosmos-wheels/requirements.txt"
flock -u 9
nohup bash "$ROOT/experiments/gpt_policy_repro_20260914/infra/bootstrap_mainskill_cosmos.sh" >> "$ROOT/experiments/gpt_policy_repro_20260914/mainskill/cosmos_bootstrap.log" 2>&1 < /dev/null &
echo "Cosmos restart PID: $!"
REMOTE
