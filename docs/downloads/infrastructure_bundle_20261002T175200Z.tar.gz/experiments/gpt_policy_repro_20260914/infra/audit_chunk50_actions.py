"""Compare cached policy predictions against every recorded native action."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np


def audit(run):
    paths=sorted((run/'sim').glob('*/action_*.json'))
    native=[json.loads(p.read_text()) for p in paths]
    predictions=sorted((run/'rollout/predictions').glob('*/prediction.npz'))
    index=0
    assert paths and predictions, 'Missing native actions or predictions'
    for path in predictions:
        receipt=json.loads(path.with_name('execution.json').read_text())
        with np.load(path,allow_pickle=False) as archive:
            actions=archive['actions']
        assert actions.shape==(50,14) and np.isfinite(actions).all()
        assert 0<receipt['executed_steps']<=50
        for offset in range(receipt['executed_steps']):
            row=native[index]
            assert row['valid'] and row['step_id']==index+1, 'Native step sequence mismatch'
            assert row['student_prediction_id']==receipt['prediction_id'], 'Prediction identity mismatch'
            assert row['prediction_offset']==offset//15*15, 'Transport slice mismatch'
            assert np.array_equal(actions[offset],row['executed_action']), 'Executed action mismatch'
            index+=1
        assert receipt['end_tick']==index
    assert index==len(native), 'Unaccounted native actions'
    result=json.loads((run/'rollout/result.json').read_text())
    assert result['complete'] and result['student_steps']==index
    assert native[-1]['terminated'] or native[-1]['truncated'], 'Missing native terminal'
    hashed=paths+list((run/'rollout/predictions').glob('*/*.npz'))+list((run/'rollout/predictions').glob('*/execution.json'))
    return dict(verified=True,native_actions=index,predictions=len(predictions),max_absolute_action_error=0,
                checks=['ordered full-chunk action equality','prediction identity and transport slice offsets','contiguous native steps','native terminal'],
                files_sha256={str(p.relative_to(run)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(hashed)})


def main():
    p=argparse.ArgumentParser();p.add_argument('run',type=Path);p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();data=audit(args.run)
    args.output.write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps({k:v for k,v in data.items() if k!='files_sha256'}))
if __name__=='__main__':main()
