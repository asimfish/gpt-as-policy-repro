"""Report only our measurements; never infer controller identity from upstream defaults."""
import argparse
import html
import json
from collections import defaultdict
from pathlib import Path


def summarize(items):
    scored=[r for r in items if r['eligible']]
    scores=[r['native_score'] for r in scored if isinstance(r['native_score'],(int,float))]
    return dict(attempts=len(items), completed=sum(r['complete'] for r in items),
                evaluated=len(scored), excluded_completed=sum(r['complete'] and not r['eligible'] for r in items),
                successes=sum(r['success'] for r in scored),
                success_rate=sum(r['success'] for r in scored)/len(scored) if scored else None,
                score_samples=len(scores), mean_score=sum(scores)/len(scores) if scores else None,
                observed_steps=sum(r['steps'] for r in items))


def build(root):
    rows, errors = [], []
    for path in sorted(root.glob('**/result.json')):
        try:
            result = json.loads(path.read_text())
            run = json.loads(path.with_name('run.json').read_text())
            provenance_path = path.with_name('reproduction.json')
            provenance = json.loads(provenance_path.read_text()) if provenance_path.exists() else {}
            method = provenance.get('method', 'unknown')
            outcome_path=path.parent.parent/'sim/evaluation_outcome.json'
            outcome=json.loads(outcome_path.read_text()) if outcome_path.exists() else {}
            complete = result.get('complete') is True and (result.get('terminated') is True or result.get('truncated') is True)
            eligible = (complete and provenance.get('benchmark_eligible') is True and method != 'unknown'
                        and isinstance(result.get('success'), bool) and outcome.get('complete') is True
                        and outcome.get('valid_for_success_rate') is True
                        and outcome.get('native_success') is result['success'])
            steps = (int(result.get('control_steps', result.get('native', {}).get('step_id', 0)))
                     if method.startswith('robolab_') else
                     sum(int(result.get(k, 0)) for k in ('student_steps','edited_steps','recovery_steps','gpt_eef_steps')))
            rows.append(dict(directory=str(path.parent.relative_to(root)), task=run.get('task'), method=method,
                             complete=complete, eligible=eligible, success=result.get('success'),
                             reason=result.get('reason'), native_status=outcome.get('status'),
                             steps=steps,
                             case=result.get('evaluation_case'), native_score=outcome.get('native_score') if outcome.get('complete') is True else None, provenance=provenance))
        except (OSError, ValueError, TypeError) as error:
            errors.append(dict(path=str(path), error=str(error)))
    groups = defaultdict(list)
    for row in rows:
        groups[row['method']].append(row)
    summary={method:summarize(items) for method,items in groups.items()}
    task_groups=defaultdict(list)
    for row in rows:
        task_groups[(row['method'],row['task'] or 'unknown')].append(row)
    by_task=[dict(method=method,task=task,**summarize(items))
             for (method,task),items in sorted(task_groups.items())]
    attempts = []
    for path in sorted(root.glob('**/attempt.json')):
        try:
            attempt = json.loads(path.read_text())
            attempt['evidence'] = str(path.relative_to(root))
            attempts.append(attempt)
        except (OSError, ValueError) as error:
            errors.append(dict(path=str(path), error=str(error)))
    return dict(schema='gpt_policy_reproduction.v2', episodes=rows, summary=summary, by_task=by_task, infrastructure_attempts=attempts, artifact_errors=errors)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('root', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    report = build(args.root)
    destination = args.output or args.root/'independent_report.json'
    destination.write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    lines = ['# GPT-as-Policy 独立复现报告', '', '当前仅报告本项目实际执行的轨迹。公开报告复算不作为独立实验结果。', '',
             '只有具有明确控制器来源、原生终止结果且被纳入评估的轨迹进入成功率分母。N/A 表示尚无可计分轨迹。单条样本不能代表整体任务成功率。', '',
             '| 方法 | 已记录轨迹 | 原生完成 | 可计分 | 成功率 | 已执行控制步 |', '|---|---:|---:|---:|---:|---:|']
    for method, row in sorted(report['summary'].items()):
        rate = 'N/A' if row['success_rate'] is None else f"{row['success_rate']:.2%}"
        lines.append(f"| {method} | {row['attempts']} | {row['completed']} | {row['evaluated']} | {rate} | {row['observed_steps']} |")
    lines += ['', '## 按任务分组', '',
              '| 方法 | 任务 | 原生完成 | 可计分 | 成功数 | 成功率 | 平均原生分数 |',
              '|---|---|---:|---:|---:|---:|---:|']
    for row in report['by_task']:
        rate='N/A' if row['success_rate'] is None else f"{row['success_rate']:.2%}"
        score='N/A' if row['mean_score'] is None else f"{row['mean_score']:.4f}"
        lines.append(f"| {row['method']} | {row['task']} | {row['completed']} | {row['evaluated']} | {row['successes']} | {rate} | {score} |")
    lines += ['', '当前队列按案例顺序执行；未跑完的任务分布不均衡，不将阶段性均值解释为完整基准结论。', '', '## 完成但未计分的轨迹', '']
    excluded=[r for r in report['episodes'] if r['complete'] and not r['eligible']]
    for row in excluded:
        lines.append(f"- [{row['directory']}]({row['directory']}/result.json)：原生状态 `{row['native_status']}`；未进入成功率分母。")
    if not excluded:
        lines.append('无。')
    lines += ['', '## 轨迹证据', '']
    for row in report['episodes']:
        lines.append(f"- [{row['directory']}]({row['directory']}/result.json)：{row['method']}，{row['steps']} 步，停止原因 `{row['reason']}`。")
    lines += ['', '## 调度记录', '']
    for attempt in report['infrastructure_attempts']:
        lines.append(f"- [{attempt['case']}]({attempt['evidence']})：{attempt['status']}。")
    lines += ['', '完整 RoboDojo 主实验、GPT Direct、GPT hybrid 和 RoboLab 补充实验尚未完成。短步验证仅证明对应的加载、观测、推理及动作执行链路。']
    markdown = '\n'.join(lines)+'\n'
    destination.with_suffix('.md').write_text(markdown)
    destination.with_suffix('.html').write_text('<!doctype html><meta charset="utf-8"><title>独立复现报告</title><style>body{max-width:1100px;margin:40px auto;font:16px/1.7 sans-serif}pre{white-space:pre-wrap}</style><pre>'+html.escape(markdown)+'</pre>')
    print(json.dumps(report['summary'], ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
