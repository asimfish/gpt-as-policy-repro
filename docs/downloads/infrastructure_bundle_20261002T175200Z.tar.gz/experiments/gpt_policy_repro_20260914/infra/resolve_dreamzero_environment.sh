#!/usr/bin/env bash
set -euo pipefail
ROOT=/mnt/nas/data/lyf/agentic_robot
cd "$ROOT"
# Apply the official CUDA index only to the PyTorch ecosystem. The general
# extra-index path shadows PyPI's requests with an incompatible old version.
exec /home/liyufeng/.local/bin/uv pip compile upstream/dreamzero/pyproject.toml --python-version 3.11 --torch-backend cu129 --generate-hashes --emit-index-annotation --output-file experiments/gpt_policy_repro_20260914/fixtures/dreamzero_runtime.lock
