#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
while pgrep -f 'experiments/gpt_policy_repro_20260914/infra/run_batch_student.py' >/dev/null; do sleep 30; done
id=$(date -u +%Y%m%dT%H%M%SZ)
out="$root/robolab_smoke/$id"
mkdir -p "$root/robolab_smoke"
exec "$root/infra/run_robolab_smoke.sh" "$out" 19500
