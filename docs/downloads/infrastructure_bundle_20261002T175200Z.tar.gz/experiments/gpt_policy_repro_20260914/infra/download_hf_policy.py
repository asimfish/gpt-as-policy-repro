"""Download a pinned public HF policy and verify every file against repository metadata."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
from huggingface_hub import snapshot_download

p=argparse.ArgumentParser()
p.add_argument('--model-info',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--exclude-prefix',action='append',default=[])
a=p.parse_args()
info=json.loads(a.model_info.read_text())
assert info.get('gated') is False and len(info['sha'])==40
rows=[];excluded=[]
for item in info['siblings']:
    path=PurePosixPath(item['rfilename'])
    assert not path.is_absolute() and '..' not in path.parts
    (excluded if any(str(path).startswith(prefix) for prefix in a.exclude_prefix) else rows).append(item)
a.output.mkdir(parents=True,exist_ok=True)
snapshot_download(repo_id=info['id'],revision=info['sha'],token=False,local_dir=a.output,
                  allow_patterns=[r['rfilename'] for r in rows],max_workers=3)
verified=[]
for row in rows:
    path=a.output/row['rfilename'];size=path.stat().st_size
    assert size==row['size'],path
    sha=hashlib.sha256();git=hashlib.sha1(f'blob {size}\0'.encode())
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(8*1024*1024),b''):sha.update(chunk);git.update(chunk)
    if row.get('lfs'):
        assert sha.hexdigest()==row['lfs']['sha256'],path
    else:
        assert git.hexdigest()==row['blobId'],path
    verified.append(dict(path=row['rfilename'],size=size,sha256=sha.hexdigest()))
    print(json.dumps(dict(event='verified',**verified[-1])),flush=True)
manifest=dict(source=info['id'],revision=info['sha'],verified=True,files=verified,
              excluded=[r['rfilename'] for r in excluded],exclude_prefix=a.exclude_prefix)
(a.output/'download_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'event':'download_complete','source':info['id'],'revision':info['sha'],'files':len(verified)}),flush=True)
