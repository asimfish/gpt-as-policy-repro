"""Mirror the four large OpenPI wheels using exact URLs/hashes from the frozen lock."""
import concurrent.futures
import hashlib
import json
import re
from packaging.tags import sys_tags
from packaging.utils import parse_wheel_filename
from urllib.parse import unquote
from pathlib import Path
import time
import tomllib
import urllib.request

ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'upstream/checkpoints/openpi-wheels'
VERSIONS={'torch':'2.7.1','nvidia-cublas-cu12':'12.6.4.1','nvidia-cudnn-cu12':'9.5.1.17','nvidia-cusparse-cu12':'12.5.4.2'}

def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()

def fetch(w):
 p=OUT/w['url'].split('/')[-1];expected=w['hash'].removeprefix('sha256:');partial=p.with_suffix('.partial')
 if not (p.exists() and p.stat().st_size==w['size'] and sha(p)==expected):
  for attempt in range(5):
   try:
    offset=partial.stat().st_size if partial.exists() else 0
    if offset<w['size']:
     req=urllib.request.Request(w['url'],headers={'Range':f'bytes={offset}-'})
     with urllib.request.urlopen(req,timeout=90) as resp:
      if offset and resp.status!=206:offset=0
      with partial.open('ab' if offset else 'wb') as f:
       while b:=resp.read(4*1024*1024):f.write(b)
    assert partial.stat().st_size==w['size'] and sha(partial)==expected
    partial.replace(p);break
   except Exception as e:
    print(json.dumps({'retry':attempt,'file':p.name,'error':type(e).__name__}),flush=True)
    if attempt==4:raise
    time.sleep(3)
 print(json.dumps({'verified':p.name,'size':w['size']}),flush=True)
 return dict(path=p.name,size=w['size'],sha256=expected,name=w['name'],version=w['version'])

def main():
 OUT.mkdir(parents=True,exist_ok=True)
 raw=(ROOT/'upstream/openpi-robolab/uv.lock').read_bytes();lock=tomllib.loads(raw.decode());wheels=[]
 for name,version in VERSIONS.items():
  package=next(p for p in lock['package'] if p['name']==name and p['version']==version)
  candidates=[w for w in package['wheels'] if 'x86_64' in w['url'] and (name!='torch' or 'cp311-cp311' in w['url'])]
  assert candidates;wheels.append(dict(candidates[0],name=name,version=version))
 runtime_log=ROOT/'experiments/gpt_policy_repro_20260914/mainskill/openpi_dry_run.log'
 if runtime_log.exists():
  wanted=dict(re.findall(r'^ \+ ([\w-]+)==([^\s]+)',runtime_log.read_text(),re.M));tags=set(sys_tags())
  for package in lock['package']:
   if wanted.get(package['name'])!=package['version']:continue
   matches=[w for w in package.get('wheels',[]) if parse_wheel_filename(unquote(w['url'].split('/')[-1]))[3]&tags]
   selected=matches[0] if matches else package.get('sdist')
   if selected:wheels.append(dict(selected,name=package['name'],version=package['version']))
 wheels=list({w['url']:w for w in wheels}.values())
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(fetch,wheels))
 requirements=OUT/'requirements.txt';requirements.write_text(''.join(f"{r['name']}=={r['version']}\n" for r in sorted(rows,key=lambda r:r['name'])))
 rows.append(dict(path=requirements.name,size=requirements.stat().st_size,sha256=sha(requirements)))
 (OUT/'download_manifest.json').write_text(json.dumps(dict(source='openpi-frozen-lock-wheels',lock_sha256=hashlib.sha256(raw).hexdigest(),verified=True,files=rows),indent=2)+'\n')
if __name__=='__main__':main()
