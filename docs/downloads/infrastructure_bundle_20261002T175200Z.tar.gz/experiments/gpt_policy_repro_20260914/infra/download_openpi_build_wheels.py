"""Download separately pinned build tools and upstream runtime pytest dependency.

Runtime pytest/iniconfig/pluggy versions match the pinned OpenPI uv.lock.
Every artifact is checked against the primary PyPI SHA256 and recorded.
"""
import urllib.request,json,hashlib
from pathlib import Path
out=Path(__file__).resolve().parents[3]/'upstream/checkpoints/openpi-build-wheels';out.mkdir(parents=True,exist_ok=True)
rows=[]
for name,version in [('hatchling','1.27.0'),('wheel','0.45.1'),('editables','0.5'),('trove-classifiers','2026.6.1.19'),('poetry-core','2.1.3'),('pathspec','0.12.1'),('pluggy','1.6.0'),('pytest','8.3.5'),('iniconfig','2.1.0')]:
 url='https://pypi.org/pypi/'+name+('/'+version if version else '')+'/json'
 with urllib.request.urlopen(url,timeout=30) as r:meta=json.load(r)
 w=next(w for w in meta['urls'] if w['filename'].endswith('py3-none-any.whl'))
 with urllib.request.urlopen(w['url'],timeout=60) as r:data=r.read()
 assert len(data)==w['size'] and hashlib.sha256(data).hexdigest()==w['digests']['sha256']
 (out/w['filename']).write_bytes(data);rows.append(dict(name=name,version=meta['info']['version'],path=w['filename'],size=len(data),sha256=w['digests']['sha256'],source=w['url']))
 print(name,meta['info']['version'],len(data),flush=True)
(out/'manifest.json').write_text(json.dumps(dict(verified=True,files=rows),indent=2)+'\n')
