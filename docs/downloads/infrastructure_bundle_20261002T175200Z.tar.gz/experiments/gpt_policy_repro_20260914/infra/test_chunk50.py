import unittest
import numpy as np
from run_chunk50_episode import execute_prediction


class NativeSimulator:
    def __init__(self, horizon):
        self.horizon=horizon;self.step=0;self.chunks=[]
    def request(self, op, **args):
        assert op=='chunk_step' and args['step_id']==self.step
        self.chunks.append(args['actions'].copy())
        rows=[]
        for action in args['actions']:
            if self.step==self.horizon:break
            self.step+=1
            rows.append(dict(valid=True,terminated=False,truncated=self.step==self.horizon,success=False))
        return dict(step_id=self.step,steps=rows)


class FullChunkTest(unittest.TestCase):
    def test_all_fifty_actions_execute_in_original_order(self):
        actions=np.arange(700,dtype=np.float32).reshape(50,14)
        sim=NativeSimulator(100)
        step,receipts=execute_prediction(sim,'episode',0,actions,'prediction')
        self.assertEqual(step,50)
        self.assertEqual([len(x) for x in sim.chunks],[15,15,15,5])
        np.testing.assert_array_equal(np.concatenate(sim.chunks),actions)
        self.assertEqual([r['offset'] for r in receipts],[0,15,30,45])

    def test_native_terminal_prevents_remaining_transport_calls(self):
        actions=np.arange(700,dtype=np.float32).reshape(50,14)
        sim=NativeSimulator(17)
        step,receipts=execute_prediction(sim,'episode',0,actions,'prediction')
        self.assertEqual(step,17)
        self.assertEqual(len(sim.chunks),2)
        self.assertEqual([r['count'] for r in receipts],[15,2])
        self.assertTrue(receipts[-1]['truncated'])

    def test_bad_step_receipt_aborts_without_resending(self):
        class BadSimulator(NativeSimulator):
            def request(self,*args,**kwargs):
                result=super().request(*args,**kwargs);result['step_id']-=1;return result
        sim=BadSimulator(100)
        with self.assertRaisesRegex(RuntimeError,'count mismatch'):
            execute_prediction(sim,'episode',0,np.zeros((50,14)),'prediction')
        self.assertEqual(len(sim.chunks),1)


if __name__=='__main__':unittest.main()
