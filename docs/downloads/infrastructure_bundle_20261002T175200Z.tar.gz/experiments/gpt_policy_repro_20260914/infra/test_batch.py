import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from run_batch_student import wait_log, terminate, check_simulator, select_cases, invalid_native_reset
import json

class BatchTests(unittest.TestCase):
    def test_only_native_unstable_reset_can_be_excluded(self):
        outcome={'status':'invalid_native_layout','error_type':'UnStableError','complete':False,'valid_for_success_rate':False}
        self.assertTrue(invalid_native_reset(outcome))
        for key,value in [('status','reset_error'),('error_type','RuntimeError'),('complete',True),('valid_for_success_rate',True)]:
            self.assertFalse(invalid_native_reset(dict(outcome,**{key:value})))
        self.assertFalse(invalid_native_reset({}))

    def test_resume_limit_counts_pending_cases(self):
        paths=[Path('mix__a.json'), Path('mix__b.json'), Path('mix__c.json')]
        self.assertEqual(select_cases(paths, {'mix__a'}, 1), [paths[1]])
        self.assertEqual(select_cases(paths, {p.stem for p in paths}, 1), [])

    def test_clean_simulator_exit_after_native_result_allows_video_finalize(self):
        with tempfile.TemporaryDirectory() as tmp:
            log=Path(tmp)/'sim.log';log.write_text('ready')
            result=Path(tmp)/'result.json'
            result.write_text(json.dumps({'complete':True,'terminated':True}))
            proc=subprocess.Popen([sys.executable,'-c','pass'],start_new_session=True)
            proc.wait()
            check_simulator(proc,log,result)
            result.write_text(json.dumps({'complete':False}))
            with self.assertRaisesRegex(RuntimeError,'process exited 0'):
                check_simulator(proc,log,result)

    def test_dead_server_fails_without_waiting_for_readiness_timeout(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'server.log';path.write_text('')
            proc=subprocess.Popen([sys.executable,'-c','raise SystemExit(7)'], start_new_session=True)
            proc.wait()
            with self.assertRaisesRegex(RuntimeError,'process exited 7'):
                wait_log(proc,path,'ready',timeout=100)

    def test_gpu_scene_failure_fails_even_when_ready_marker_exists(self):
        from unittest.mock import Mock
        from run_batch_student import check
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'server.log'
            for marker in ('PxgCudaDeviceMemoryAllocator failed to allocate memory', 'PhysX error: Unable to create scene.'):
                path.write_text('ready\n'+marker)
                with self.subTest(marker=marker), self.assertRaisesRegex(RuntimeError,'fatal renderer'):
                    check(Mock(),path)

    def test_renderer_error_fails_even_when_ready_marker_exists(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'server.log';path.write_text('ready\nFailed to create raytracing pipeline')
            proc=subprocess.Popen([sys.executable,'-c','import time; time.sleep(60)'],start_new_session=True)
            try:
                with self.assertRaisesRegex(RuntimeError,'fatal renderer'):
                    wait_log(proc,path,'ready')
            finally:
                terminate(proc)
            self.assertIsNotNone(proc.poll())

if __name__=='__main__': unittest.main()
