#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/env.sh"

task="${1:?task required}"
output="${2:?output directory required}"
port="${3:-19130}"
seed="${4:-0}"
mkdir -p "$output"
output="$(realpath "$output")"
if [[ -n "${EVAL_MANIFEST:-}" ]]; then EVAL_MANIFEST="$(realpath "$EVAL_MANIFEST")"; fi
if [[ -n "${CASE_FILE:-}" ]]; then CASE_FILE="$(realpath "$CASE_FILE")"; fi
cd "$ROBO_ROOT"
extra=()
if [[ -n "${EVAL_MANIFEST:-}" ]]; then extra+=(--eval-manifest "$EVAL_MANIFEST"); fi
if [[ -n "${CASE_FILE:-}" ]]; then extra+=(--case-file "$CASE_FILE"); fi
exec "$ROBO_PYTHON" -m hybrid_rollout.robodojo.robodojo_server.server \
  --task "$task" --output "$output" --port "$port" --eval-seed "$seed" "${extra[@]}" \
  --kit_args="--/renderer/multiGpu/enabled=false --/renderer/multiGpu/autoEnable=false --/renderer/activeGpu=${SIM_GPU:-0}"
