#!/usr/bin/env bash
set -euo pipefail
ROOT=/mnt/nas/data/lyf/agentic_robot
for i in $(seq 1 2880); do
 [[ -f "$ROOT/upstream/checkpoints/cosmos-git-sources/download_manifest.json" ]] && break
 sleep 15
done
[[ -f "$ROOT/upstream/checkpoints/cosmos-git-sources/download_manifest.json" ]]
python3 "$ROOT/experiments/gpt_policy_repro_20260914/infra/transfer_checkpoint_chunks.py" --checkpoint cosmos-git-sources
ssh -o BatchMode=yes -o ConnectTimeout=15 -o UserKnownHostsFile=/home/liyufeng/.ssh/known_hosts_a100 -o StrictHostKeyChecking=yes mainskill 'bash -s' <<'REMOTE'
set -euo pipefail
ROOT=/home/dataset-assist-0/liyufeng/agentic_robot
mkdir -p "$ROOT/upstream/source-mirrors"
for name in lerobot megatron-core; do
 tar --no-same-owner --no-same-permissions -xzf "$ROOT/upstream/checkpoints/cosmos-git-sources/$name.git.tar.gz" -C "$ROOT/upstream/source-mirrors"
 git --git-dir "$ROOT/upstream/source-mirrors/$name.git" fsck --full
done
python3 - "$ROOT" <<'PYVERIFY'
import json,subprocess,sys
from pathlib import Path
root=Path(sys.argv[1]);manifest=json.loads((root/'upstream/checkpoints/cosmos-git-sources/download_manifest.json').read_text())
for row in manifest['files']:
 name=row['path'].removesuffix('.tar.gz')
 subprocess.run(['git','--git-dir',str(root/'upstream/source-mirrors'/name),'cat-file','-e',row['pinned_commit']+'^{commit}'],check=True)
result=dict(verified=True,sources=[dict(repository=r['repository'],commit=r['pinned_commit']) for r in manifest['files']])
p=root/'upstream/source-mirrors/cosmos_git_verification.json';p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
PYVERIFY
REMOTE
