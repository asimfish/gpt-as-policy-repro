"""GPU-free RPC echo canary through a separate owned mainskill SSH tunnel."""
import argparse
import base64
import json
import os
from pathlib import Path
import shlex
import socket
import subprocess
import sys
import time
import uuid
import numpy as np
from transfer_checkpoint_chunks import SSH,remote

ROOT=Path(__file__).resolve().parents[3]
ARTIFACTS=Path(__file__).resolve().parents[1]

SERVER='''import json,socket,numpy as np,hashlib
from hybrid_rollout.robolab.robolab_server.protocol import receive_packet,send_packet
with socket.socket() as s:
 s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);s.bind(('127.0.0.1',20620));s.listen(1);s.settimeout(60)
 print('canary_ready',flush=True)
 c,_=s.accept()
 with c:
  c.settimeout(60)
  for i in range(70):
   try:p=receive_packet(c)
   except EOFError:break
   print(json.dumps({'event':'received','index':i}),flush=True)
   result=p['args']
   if i==0:
    data=np.random.default_rng(0).integers(0,256,size=(2,504,896,3),dtype=np.uint8)
    result={'synthetic_observation':data,'sha256':hashlib.sha256(data.tobytes()).hexdigest()}
   send_packet(c,{'version':p['version'],'request_id':p['request_id'],'ok':True,'result':result})
   print(json.dumps({'event':'sent','index':i}),flush=True)
'''


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--packet-sweep',action='store_true');parser.add_argument('--cipher',choices=('default','aes128-gcm@openssh.com'),default='default');args=parser.parse_args()
    sys.path.insert(0,str(ROOT/'gpt-as-policy'))
    from hybrid_rollout.robolab.robolab_server.protocol import RPCClient
    tag=uuid.uuid4().hex
    script='/tmp/gpt-policy-rpc-canary-'+tag+'.py';log='/tmp/gpt-policy-rpc-canary-'+tag+'.log'
    env={'PYTHONPATH':'/home/dataset-assist-0/liyufeng/agentic_robot/gpt-as-policy'}
    code='''import base64,pathlib,os,subprocess,sys
p=pathlib.Path(sys.argv[1]);p.write_bytes(base64.b64decode(sys.argv[2]))
env=os.environ.copy();env['PYTHONPATH']=sys.argv[4]
with open(sys.argv[3],'w') as log:
 proc=subprocess.Popen(['/home/batchcom/gpt-policy-runtime/robolab51/bin/python','-u',str(p)],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
print(proc.pid)
'''.replace('\n+','\n')
    result=subprocess.run([*SSH,shlex.join(['python3','-c',code,script,base64.b64encode(SERVER.encode()).decode(),log,env['PYTHONPATH']])],capture_output=True,text=True,check=True,timeout=30)
    pid=int(result.stdout.strip());tunnel=client=None
    evidence=dict(tag=tag,gpu_calls=0,model_calls=0,physical_steps=0,echoes=[],cipher=args.cipher)
    try:
        deadline=time.monotonic()+30
        while 'canary_ready' not in remote('from pathlib import Path;import sys;print(Path(sys.argv[1]).read_text())',(log,),timeout=15):
            if time.monotonic()>deadline:raise TimeoutError('Echo server startup')
            time.sleep(1)
        with (ARTIFACTS/'rpc_canary_tunnel.log').open('w') as stream:
            tunnel=subprocess.Popen([*SSH[:-1], *(['-o','Ciphers='+args.cipher] if args.cipher!='default' else []),'-o','ExitOnForwardFailure=yes','-o','ServerAliveInterval=30',
                '-o','ServerAliveCountMax=10','-N','-L','127.0.0.1:20620:127.0.0.1:20620',SSH[-1]],stdout=stream,stderr=subprocess.STDOUT)
        time.sleep(2)
        client=RPCClient('127.0.0.1',20620,timeout=10)
        import hashlib
        started=time.monotonic();large=client.request('teacher_observation')
        assert hashlib.sha256(large['synthetic_observation'].tobytes()).hexdigest()==large['sha256']
        evidence['synthetic_observation']=dict(bytes=large['synthetic_observation'].nbytes,
            seconds=time.monotonic()-started,matches=True)
        for horizon in (15,1,5):
            action=np.tile(np.asarray([.2,-.4,.3,-1.7,.1,1.8,.6,0],np.float32),(horizon,1))
            started=time.monotonic();reply=client.request('chunk_step',actions=action,
                episode_id='episode',step_id=0,teacher_request_id='request')
            assert np.array_equal(reply['actions'],action)
            evidence['echoes'].append(dict(horizon=horizon,seconds=time.monotonic()-started,matches=True))
        if args.packet_sweep:
            import msgpack,zlib,struct
            from hybrid_rollout.robolab.robolab_server.protocol import _encode,send_packet,receive_packet,VERSION
            evidence['packet_sweep']=[]
            for extra in range(45):
                request_id=uuid.uuid4().hex
                action=np.random.default_rng(extra).normal(size=(1,8)).astype(np.float32)
                packet=dict(version=VERSION,request_id=request_id,op='chunk_step',args=dict(actions=action,
                    episode_id=uuid.uuid4().hex,step_id=0,teacher_request_id=uuid.uuid4().hex+''.join(np.random.default_rng(extra).choice(list('abcdef0123456789'),size=extra))))
                size=4+len(zlib.compress(msgpack.packb(packet,default=_encode,use_bin_type=True),level=1))
                record=dict(extra=extra,rpc_bytes=size,acknowledged=False);evidence['packet_sweep'].append(record)
                (ARTIFACTS/'robolab_rpc_packet_sweep_active.json').write_text(json.dumps(evidence,indent=2)+'\n')
                started=time.monotonic();send_packet(client.sock,packet);reply=receive_packet(client.sock)
                assert reply['request_id']==request_id and reply['ok'] and np.array_equal(reply['result']['actions'],action)
                record.update(acknowledged=True,seconds=time.monotonic()-started)
        evidence['passed']=True
    except Exception as error:
        evidence.update(passed=False,error_type=type(error).__name__,error=str(error))
    finally:
        if client:client.close()
        if tunnel and tunnel.poll() is None:tunnel.terminate();tunnel.wait(timeout=10)
        evidence['server_log']=remote('from pathlib import Path;import sys;print(Path(sys.argv[1]).read_text())',(log,),timeout=15)
        cleanup='''import pathlib,os,signal,sys
pid=sys.argv[1];script=sys.argv[2]
try:
 cmd=pathlib.Path('/proc/'+pid+'/cmdline').read_text()
 if script in cmd:os.kill(int(pid),signal.SIGTERM)
except FileNotFoundError:pass
print('owned canary cleanup')
'''
        remote(cleanup,(pid,script),timeout=15)
        (ARTIFACTS/('robolab_rpc_packet_sweep.json' if args.packet_sweep else 'robolab_rpc_canary.json')).write_text(json.dumps(evidence,indent=2)+'\n')
        archive=ARTIFACTS/'robolab_rpc_transport_canaries';archive.mkdir(exist_ok=True)
        (archive/(tag+'.json')).write_text(json.dumps(evidence,indent=2)+'\n')
        print(json.dumps(dict(tag=tag,cipher=args.cipher,passed=evidence.get('passed'),gpu_calls=0,model_calls=0,physical_steps=0,packet_cases=len(evidence.get('packet_sweep',[])),packet_acknowledged=sum(x['acknowledged'] for x in evidence.get('packet_sweep',[])),error_type=evidence.get('error_type'))))
    return 0 if evidence.get('passed') else 1


if __name__=='__main__':raise SystemExit(main())
