#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/env.sh"
export CAMPAIGN_GPU="${CAMPAIGN_GPU:-0}"
export CUDA_VISIBLE_DEVICES="$CAMPAIGN_GPU"
export SIM_GPU="$CAMPAIGN_GPU"
exec python3 "$(dirname "$0")/queue_student_campaign.py"
