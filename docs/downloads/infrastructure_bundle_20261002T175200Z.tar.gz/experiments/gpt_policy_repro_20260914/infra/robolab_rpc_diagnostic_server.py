"""Diagnostic-only native EEF solver probe; never an evaluation service."""
from robolab_instrumented_server import ObservedSession,observe_wire,upstream


class DiagnosticSession(ObservedSession):
    def dispatch(self,op,args):
        if op=='diagnostic_eef_proposal':
            self._check_identity(args['episode_id'],args['step_id'])
            if self.source!='diagnostic_hold' or self.combination or self.branch:
                raise ValueError('Diagnostic solver requires an unscored hold episode')
            from hybrid_rollout.robolab.robolab_server.eef_controller import build_eef_proposal
            result=build_eef_proposal(self.env,args['position'],args['quaternion_wxyz'],args['gripper_closed'])
            return dict(result,episode_id=self.episode_id,step_id=self.step_id,benchmark_eligible=False)
        return super().dispatch(op,args)


if __name__=='__main__':
    observe_wire()
    upstream.EditEnvironmentSession=DiagnosticSession
    upstream.main()
