#!/usr/bin/env bash
set -euo pipefail
RUNTIME=/home/batchcom/gpt-policy-runtime
REV=ad45d4f974725d020f82c2b0d77d78533aeba2b3
cd "$RUNTIME"
curl --fail --location --retry 3 --connect-timeout 30 --max-time 3600 -o "RoboLab-$REV.tar.gz.part" "https://codeload.github.com/NVlabs/RoboLab/tar.gz/$REV"
mv "RoboLab-$REV.tar.gz.part" "RoboLab-$REV.tar.gz"
sha256sum "RoboLab-$REV.tar.gz" > robolab_archive.sha256
mkdir -p "RoboLab-$REV"
tar --no-same-owner -xzf "RoboLab-$REV.tar.gz" -C "RoboLab-$REV" --strip-components=1
printf '%s\n' "$REV" > "RoboLab-$REV/.reproduction_source_commit"
echo "SOURCE_READY $RUNTIME/RoboLab-$REV"
