"""Bounded remote-loopback vs SSH native RPC probe, excluded from all scores."""
import argparse
from datetime import datetime,timezone
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import time
from transfer_checkpoint_chunks import SSH,remote

ROOT=Path(__file__).resolve().parents[3]
ART=Path(__file__).resolve().parents[1]
REMOTE='/home/dataset-assist-0/liyufeng/agentic_robot/experiments/gpt_policy_repro_20260914'

LAUNCH=r'''import os,subprocess,sys,socket,json
from pathlib import Path
root=Path(sys.argv[1]);name=sys.argv[2]
inv=subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.free','--format=csv,noheader,nounits'],text=True)
free={int(x.split(',')[0]):int(x.split(',')[1]) for x in inv.splitlines()};assert free[6]>15000
with socket.socket() as sock:sock.bind(('127.0.0.1',20630))
log=root/'mainskill'/(name+'.log');log.parent.mkdir(exist_ok=True)
env=dict(os.environ,ROBO_LAB_GPU='6',ROBO_LAB_CLIENT=sys.argv[3],ROBO_LAB_SIM_PORT='20630',ROBO_LAB_CAMPAIGN=name,ROBO_LAB_RECORD_SCENE_STATE='1',ROBO_LAB_RPC_DIAGNOSTIC='1',ROBO_LAB_RPC_EEF_PROBE=sys.argv[4])
with log.open('x') as stream:
 proc=subprocess.Popen(['flock','-n','/tmp/gpt-policy-robolab-hybrid-services.lock','timeout','1200','bash',str(root/'infra/run_mainskill_robolab_smoke.sh')],env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
print(json.dumps(dict(name=name,pid=proc.pid,log=str(log))))
'''
PROBE=r'''import sys,json
from pathlib import Path
root=Path(sys.argv[1])/sys.argv[2]
rows=list(root.glob('*/rollout/'+sys.argv[3]))
print(json.dumps(dict(found=bool(rows),path=str(rows[0]) if rows else None,data=json.loads(rows[0].read_text()) if rows else None)))
'''


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--transport',choices=('loopback','ssh'),required=True)
    p.add_argument('--eef',action='store_true');p.add_argument('--idle-seconds',type=int,default=0)
    a=p.parse_args()
    name='rpc_'+('eef' if a.eef else 'hold')+'_'+a.transport+'_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    out=ART/'robolab_rpc_diagnostics'/name;out.mkdir(parents=True,exist_ok=False)
    client='wait_robolab_rpc_probe.py' if a.transport=='ssh' else 'run_robolab_rpc_probe.py'
    started=subprocess.run([*SSH,shlex.join(['python3','-c',LAUNCH,REMOTE,name,client,'1' if a.eef else '0'])],capture_output=True,text=True,check=True,timeout=30)
    evidence=dict(benchmark_eligible=False,transport=a.transport,eef=a.eef,remote=json.loads(started.stdout))
    (out/'launch.json').write_text(json.dumps(evidence,indent=2)+'\n')
    tunnel=None;waiting=None
    try:
        filename='waiting.json' if a.transport=='ssh' else 'rpc_probe.json'
        deadline=time.monotonic()+850
        while True:
            state=json.loads(remote(PROBE,(REMOTE,name,filename),timeout=20))
            if state['found'] and (a.transport=='ssh' or 'passed' in state['data']):break
            if time.monotonic()>deadline:raise TimeoutError('Diagnostic startup/execution timeout')
            time.sleep(10)
        if a.transport=='ssh':
            waiting=state['path']
            with (out/'ssh_verbose.log').open('w') as log:
                tunnel=subprocess.Popen([*SSH[:-1],'-vv','-o','ExitOnForwardFailure=yes','-o','ServerAliveInterval=15','-o','ServerAliveCountMax=10','-N','-L','127.0.0.1:20630:127.0.0.1:20630',SSH[-1]],stdout=log,stderr=subprocess.STDOUT)
            time.sleep(2)
            env=dict(os.environ,PYTHONPATH=str(ROOT/'gpt-as-policy'))
            args=['/home/liyufeng/miniforge3/envs/safeduo/bin/python',str(ART/'infra/run_robolab_rpc_probe.py'),'--output',str(out/'client'),'--port','20630','--idle-seconds',str(a.idle_seconds)]
            if a.eef:args.append('--eef')
            with (out/'client.log').open('w') as log:subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=a.idle_seconds+210,check=False)
            evidence['result']=json.loads((out/'client/rpc_probe.json').read_text())
        else:evidence['result']=state['data']
    finally:
        if tunnel and tunnel.poll() is None:tunnel.terminate();tunnel.wait(timeout=15)
        if waiting:remote("from pathlib import Path;import sys;(Path(sys.argv[1]).parent/'STOP').touch();print('owned diagnostic stop')",(waiting,),timeout=20)
        time.sleep(5)
        subprocess.run(['rsync','-az','--timeout=60','-e',shlex.join(SSH[:-1]),'mainskill:'+REMOTE+'/'+name+'/',str(out/'remote')+'/'],timeout=180,check=True)
        (out/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
    print(json.dumps(dict(name=name,transport=a.transport,eef=a.eef,result=evidence.get('result'))),flush=True)
    return 0 if evidence.get('result',{}).get('passed') else 1


if __name__=='__main__':raise SystemExit(main())
