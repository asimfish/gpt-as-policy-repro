"""Reset/observation contract smoke without fabricating a scene-state snapshot."""
import argparse,json
from pathlib import Path
import numpy as np
from PIL import Image
from hybrid_rollout.robolab.robolab_server.protocol import RPCClient

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--task',default='BlocksInBinTask');p.add_argument('--port',type=int,default=19500);p.add_argument('--seed',type=int,default=0);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
 (a.output/'reproduction.json').write_text(json.dumps({'method':'robolab_reset_observation_smoke','controller':'none','benchmark_eligible':False,'teacher_invoked':False},indent=2)+'\n')
 (a.output/'run.json').write_text(json.dumps({'task':a.task,'evaluation_method':'infrastructure_observation_smoke'},indent=2)+'\n')
 sim=RPCClient('127.0.0.1',a.port,timeout=600)
 meta=sim.request('metadata'); assert meta['task']==a.task
 reset=sim.request('reset',seed=a.seed,source='student',policy_version='infrastructure-smoke')
 obs=sim.request('teacher_observation',episode_id=reset['episode_id'],step_id=reset['step_id'])
 out=a.output/'observations'/'000';out.mkdir(parents=True)
 np.savez_compressed(out/'observation.npz',main_images=obs['main_images'],wrist_images=obs['wrist_images'],states=obs['states'],ee_pos=obs['ee_pos'],ee_quat_wxyz=obs['ee_quat_wxyz'])
 image_stats={}
 for name in ('main_rgb','wrist_rgb'):
  arr=np.asarray(obs[name])
  image_stats[name]={'shape':list(arr.shape),'dtype':str(arr.dtype),'min':int(arr.min()),'max':int(arr.max()),'std':float(arr.std())}
  Image.fromarray(arr).save(out/f'{name}.png')
 (out/'render_validation.json').write_text(json.dumps(image_stats,indent=2)+'\n')
 if any(row['std']<2.0 or len(row['shape'])!=3 for row in image_stats.values()):
  raise RuntimeError('Camera output is empty/uniform or not RGB; inspect saved images')
 (out/'observation.json').write_text(json.dumps({'task':a.task,'episode_id':reset['episode_id'],'step_id':0,'instruction':obs['instruction'],'remaining_steps':obs['remaining_steps'],'images':[f'{name}.png' for name in ('main_rgb','wrist_rgb')]},indent=2)+'\n')
 final=sim.request('finish_pilot',episode_id=reset['episode_id'],step_id=0,reason='infrastructure_observation_smoke')
 (a.output/'result.json').write_text(json.dumps({'complete':False,'success':False,'native':final,'benchmark_eligible':False},indent=2)+'\n')
 sim.close();print(json.dumps({'output':str(a.output),'task':a.task,'episode_id':reset['episode_id']}))
if __name__=='__main__':main()
