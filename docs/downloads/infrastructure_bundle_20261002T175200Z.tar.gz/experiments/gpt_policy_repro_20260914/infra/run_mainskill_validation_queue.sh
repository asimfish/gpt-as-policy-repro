#!/usr/bin/env bash
set -euo pipefail
ROOT=/home/dataset-assist-0/liyufeng/agentic_robot
RUNTIME=/home/batchcom/gpt-policy-runtime
ARTIFACT="$ROOT/experiments/gpt_policy_repro_20260914"
exec 9>"$RUNTIME/validation-queue.lock"
flock -n 9 || exit 0
for i in $(seq 1 360); do
  if [[ -f "$RUNTIME/RoboLab-ad45d4f974725d020f82c2b0d77d78533aeba2b3/.block_textures_verified.json" && -f "$RUNTIME/smoke_assets_verified.sha256" && -f "$RUNTIME/RoboLab-ad45d4f974725d020f82c2b0d77d78533aeba2b3/.home_office_verified.json" && -f "$ARTIFACT/mainskill/render_ready.json" ]]; then
    "$RUNTIME/robolab51/bin/python" -c 'import json,sys;assert json.load(open(sys.argv[1]))["passed"] is True' "$ARTIFACT/mainskill/render_ready.json"
    echo "PREREQUISITES_VERIFIED $(date -u +%FT%TZ)"
    exec bash "$ARTIFACT/infra/run_mainskill_robolab_smoke.sh"
  fi
  if (( i % 6 == 1 )); then echo "WAITING_FOR_VERIFIED_RENDER_AND_ASSETS $(date -u +%FT%TZ)"; fi
  sleep 10
done
echo 'Prerequisites did not pass within one hour; no scene experiment started.' >&2
exit 1
