import hashlib,json,tempfile,unittest
from pathlib import Path
import numpy as np
from audit_robolab_pi05_actions import audit


class RoboLabActionAuditTest(unittest.TestCase):
    def fixture(self,root):
        q=root/'rollout/queries/00000';q.mkdir(parents=True)
        native=root/'sim/episode';native.mkdir(parents=True)
        (root/'rollout/policy_identity.json').write_text(json.dumps(dict(config='pi05_droid_jointpos',action_horizon=15,checkpoint_manifest_sha256='checkpoint')))
        (native/'initial_scene.json').write_text(json.dumps(dict(state_sha256='state',episode_id='episode')))
        raw=np.zeros((15,8),np.float32);raw[:,-1]=.6;executed=raw.copy();executed[:,-1]=1
        obs=dict(main_images=np.zeros((2,2,3),np.uint8),wrist_images=np.ones((2,2,3),np.uint8),states=np.arange(8,dtype=np.float32))
        np.savez_compressed(q/'prediction.npz',proposed=raw,executed=executed,**obs)
        np.savez_compressed(native/'chunk_00000.npz',action=executed[:3],proposed=executed[:3],step_id=np.arange(3),
            terminated=[False,False,True],truncated=[False]*3,success=[False,False,True],source='student',policy_version='checkpoint',initial_state_hash='state',episode_id='episode',**{k:np.stack([v]*3) for k,v in obs.items()})
        (q/'ack.json').write_text(json.dumps(dict(query=0,valid_steps=3,step_id=3,terminated=True,truncated=False,success=True,prediction_sha256=hashlib.sha256((q/'prediction.npz').read_bytes()).hexdigest())))
        (root/'rollout/result.json').write_text(json.dumps(dict(complete=True,control_steps=3,terminated=True,truncated=False,success=True)))
        return native/'chunk_00000.npz'

    def test_native_early_success_and_prefix_are_distinct(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);self.fixture(root)
            result=audit(root);self.assertTrue(result['complete_episode']);self.assertEqual(result['native_actions'],3)
            prefix=audit(root,1);self.assertFalse(prefix['complete_episode'])

    def test_corrupt_action_or_policy_input_is_rejected(self):
        for key in ['action','states']:
            with self.subTest(key=key),tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp);path=self.fixture(root)
                with np.load(path) as z:data=dict(z)
                data[key][0,0]+=1;np.savez_compressed(path,**data)
                with self.assertRaises(AssertionError):audit(root)

    def test_no_terminal_cannot_be_claimed_complete(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);self.fixture(root);(root/'rollout/result.json').unlink()
            with self.assertRaises(FileNotFoundError):audit(root)
            self.assertFalse(audit(root,1)['complete_episode'])
