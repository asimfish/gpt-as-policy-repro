#!/usr/bin/env bash
set -euo pipefail
ARTIFACT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ROOT="$(cd "$ARTIFACT_ROOT/../.." && pwd)"
ROBO_LAB_ROOT="${ROBO_LAB_ROOT:-$ROOT/upstream/RoboLab}"
ROBO_LAB_PYTHON="${ROBO_LAB_PYTHON:-/home/liyufeng/venvs/gpt-policy-robolab51/bin/python}"
TASK="${1:?RoboLab task class required}"
OUTPUT="${2:?output required}"
PORT="${3:-19500}"
SEED="${4:-0}"
mkdir -p "$OUTPUT"
export OMNI_KIT_ACCEPT_EULA=Y
export PYTHONPATH="$ROOT/gpt-as-policy:$ROBO_LAB_ROOT:$ROOT/upstream/openpi-robolab/packages/openpi-client/src${PYTHONPATH:+:$PYTHONPATH}"
export XDG_RUNTIME_DIR="${XDG_RUNTIME_DIR:-/tmp/robodojo-xdg-lyf}"
extra=()
if [[ "${ROBO_LAB_RECORD_SCENE_STATE:-0}" == 1 ]]; then extra+=(--record-scene-state); fi
if [[ -n "${ROBO_LAB_TASK_FILE:-}" ]]; then extra+=(--task-file "$ROBO_LAB_TASK_FILE"); fi
server=(-m hybrid_rollout.robolab.robolab_server.server)
if [[ "${ROBO_LAB_RPC_DIAGNOSTIC:-0}" == 1 ]]; then
 server=("$ARTIFACT_ROOT/infra/robolab_rpc_diagnostic_server.py")
fi
exec "$ROBO_LAB_PYTHON" "${server[@]}" --task "$TASK" --output "$(realpath "$OUTPUT")" --port "$PORT" --seed "$SEED" "${extra[@]}" --kit_args="--/renderer/multiGpu/enabled=false --/renderer/multiGpu/autoEnable=false --/renderer/activeGpu=${SIM_GPU:-0}"
