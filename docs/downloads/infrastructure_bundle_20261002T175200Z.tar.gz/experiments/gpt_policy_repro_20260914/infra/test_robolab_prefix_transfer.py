"""A sealed prefix must not fetch growing future chunks or student identity for Direct."""
import json
from pathlib import Path
import tempfile
import unittest
from snapshot_robolab_gpt_prefix import prefix_includes


class PrefixTransfer(unittest.TestCase):
    def fixture(self,root,modes,episode='episode'):
        (root/'history.json').write_text(json.dumps([dict(response=dict(mode=mode),executed_steps=n) for mode,n in modes]))
        (root/'request_000.json').write_text(json.dumps(dict(episode_id=episode)))

    def test_mixed_prefix_fetches_exact_native_chunks_and_receipts(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);self.fixture(root,[('student',15),('edit',3),('eef',5)])
            paths=prefix_includes(root,2,False)
            self.assertIn('/policy_identity.json',paths)
            self.assertEqual([p for p in paths if p.endswith('.npz')],['/sim/episode/chunk_'+f'{i:05d}'+'.npz' for i in range(4)])
            self.assertIn('/sim/episode/codex_decisions/001.json',paths)
            self.assertNotIn('/sim/episode/codex_decisions/002.json',paths)
            self.assertFalse(any('*' in p for p in paths))

    def test_direct_prefix_has_only_eef_steps_and_no_student_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);self.fixture(root,[('eef',5),('eef',2)])
            paths=prefix_includes(root,2,True)
            self.assertNotIn('/policy_identity.json',paths)
            self.assertEqual(len([p for p in paths if p.endswith('.npz')]),7)
            self.fixture(root,[('student',15)])
            with self.assertRaises(AssertionError):prefix_includes(root,1,True)

    def test_nonexistent_prefix_and_episode_path_escape_are_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);self.fixture(root,[('eef',1)])
            for count in (0,2,-1):
                with self.subTest(count=count),self.assertRaises(AssertionError):prefix_includes(root,count,True)
            for episode in ('../outside','episode*','episode[0]'):
                with self.subTest(episode=episode):
                    self.fixture(root,[('eef',1)],episode)
                    with self.assertRaises(AssertionError):prefix_includes(root,1,True)
