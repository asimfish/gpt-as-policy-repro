"""Switch only this campaign's queue after its owned physical-execution lock is free."""
import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--expected-source-sha256', required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    snapshot = root / 'infra/run_all_gpt_pairs_v5_20261002.py'
    old, new = 'gpt-policy-all-pairs-20261001-v4.service', 'gpt-policy-all-pairs-v5.service'
    env = dict(os.environ, XDG_RUNTIME_DIR='/run/user/1007', DBUS_SESSION_BUS_ADDRESS='unix:path=/run/user/1007/bus')
    def evidence(status):
        path = root / 'queue_handover_20261002.json'
        temp = path.with_suffix('.tmp')
        temp.write_text(json.dumps(dict(status=status, old_unit=old, new_unit=new,
                        tested_source_sha256=args.expected_source_sha256,
                        observed_utc=datetime.now(timezone.utc).isoformat()), indent=2)+'\n')
        temp.replace(path)
    evidence('waiting_for_current_physical_episode_to_release_lock')
    with open('/tmp/gpt-policy-all-pairs.lock', 'a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        assert hashlib.sha256(snapshot.read_bytes()).hexdigest() == args.expected_source_sha256, 'Tested queue snapshot changed'
        # Holding the same execution lock rules out a live physical rollout in
        # this queue. Stop/cleanup only its unit; a waiting next attempt has no robot.
        subprocess.run(['systemctl', '--user', 'stop', old], check=True, env=env)
        subprocess.run(['systemctl', '--user', 'enable', new], check=True, env=env)
        subprocess.run(['systemctl', '--user', 'start', new], check=True, env=env)
        evidence('switched_at_execution_lock_boundary')
    print('Queue handover completed at a physical-episode boundary.', flush=True)


if __name__ == '__main__':
    main()
