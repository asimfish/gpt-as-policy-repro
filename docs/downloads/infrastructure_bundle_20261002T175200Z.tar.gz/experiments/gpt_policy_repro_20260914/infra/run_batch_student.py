"""Sequential native-horizon π0.5 prefix-15 baseline (not GPT hybrid or chunk-50)."""
import argparse
import fcntl
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import signal
import subprocess
import time

FATAL = ('ERROR_INITIALIZATION_FAILED', 'Failed to create raytracing pipeline',
         'PxgCudaDeviceMemoryAllocator failed to allocate memory', 'PhysX error: Unable to create scene.')


def write(path, data):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n')
    temporary.replace(path)


def check(proc, log):
    content = log.read_text(errors='replace') if log.exists() else ''
    if any(marker in content for marker in FATAL):
        raise RuntimeError(f'fatal renderer error: {log}')
    if proc.poll() is not None:
        raise RuntimeError(f'process exited {proc.returncode}: {log}')
    return content


def wait_log(proc, path, marker, timeout=300):
    deadline = time.monotonic()+timeout
    while time.monotonic() < deadline:
        if marker in check(proc, path):
            return
        time.sleep(1)
    raise TimeoutError(f'{path}: no readiness marker {marker!r}')


def check_simulator(proc, log, result_path):
    # finish_pilot closes the native server before offline video rendering ends.
    if proc.poll() == 0 and result_path.exists():
        result=json.loads(result_path.read_text())
        if result.get('complete') is True and (result.get('terminated') is True or result.get('truncated') is True):
            return
    check(proc, log)


def terminate(proc):
    if proc is None:
        return
    for sig, timeout in ((signal.SIGINT,10),(signal.SIGTERM,5),(signal.SIGKILL,5)):
        try:
            os.killpg(proc.pid, sig)
        except ProcessLookupError:
            break
        try:
            proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            continue
        # A child can outlive the leader; kill remaining members of our own group.
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        break


def invalid_native_reset(outcome):
    return (outcome.get('status')=='invalid_native_layout'
            and outcome.get('error_type')=='UnStableError'
            and outcome.get('complete') is False
            and outcome.get('valid_for_success_rate') is False)


def select_cases(paths, completed, limit):
    return [path for path in sorted(paths) if path.stem not in completed][:limit]


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('cases','output','sim-wrapper','policy-wrapper','checkpoint','eval-manifest'):
        p.add_argument('--'+name,type=Path,required=True)
    p.add_argument('--method',choices=('pi05_prefix15','pi05_chunk50'),default='pi05_prefix15')
    p.add_argument('--limit',type=int,default=1)
    p.add_argument('--skip-completed',action='store_true')
    p.add_argument('--case-id', help='Exact case ID without mix__ prefix')
    p.add_argument('--base-port',type=int,default=19300)
    p.add_argument('--max-decisions',type=int,default=0)
    p.add_argument('--episode-timeout',type=int,default=7200)
    args=p.parse_args()
    for name in ('cases','output','sim_wrapper','policy_wrapper','checkpoint','eval_manifest'):
        setattr(args,name,getattr(args,name).resolve())
    subprocess.run([os.environ['ROBO_PYTHON'], '-c', 'from openpi_client.websocket_client_policy import WebsocketClientPolicy; from hybrid_rollout.robodojo.robodojo_server.client import RoboDojoTools; from curobo.batch_motion_planner import BatchMotionPlanner'], check=True)
    args.output.mkdir(parents=True,exist_ok=True)
    campaign_lock=(args.output/'.campaign.lock').open('a')
    fcntl.flock(campaign_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    pattern = f'mix__{args.case_id}.json' if args.case_id else 'mix__*.json'
    cases=sorted(args.cases.glob(pattern))
    if not cases:
        p.error('No matching cases')
    completed=set()
    if args.skip_completed:
        completed={json.loads(path.read_text())['case'] for path in args.output.glob('**/attempt.json') if json.loads(path.read_text()).get('status') in ('complete','invalid_native_layout')}
    cases=select_cases(cases, completed, args.limit)
    print(json.dumps({'event':'batch_selected','pending_count':len(cases),
                      'cases':[path.stem for path in cases]}), flush=True)
    def interrupted(signum, frame):
        # A second supervisor signal must not interrupt owned-process cleanup.
        signal.signal(signum, signal.SIG_IGN)
        raise KeyboardInterrupt(f'signal {signum}')
    signal.signal(signal.SIGTERM, interrupted)
    rows=[]
    for index, case_file in enumerate(cases):
        case=json.loads(case_file.read_text())['case']
        destination=args.output/case_file.stem/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
        destination.mkdir(parents=True,exist_ok=False)
        row=dict(case=case_file.stem,method=args.method,output=str(destination),status='starting')
        rows.append(row)
        state=destination/'attempt.json'
        write(state,row)
        env=dict(os.environ,EVAL_MANIFEST=str(args.eval_manifest),CASE_FILE=str(case_file),PI05_CHECKPOINT=str(args.checkpoint))
        sim_port,policy_port=args.base_port+index*2,args.base_port+index*2+1
        processes=[]
        handles=[]
        def start(command, log):
            handle=log.open('x'); handles.append(handle)
            proc=subprocess.Popen(command,env=env,stdout=handle,stderr=subprocess.STDOUT,start_new_session=True)
            processes.append(proc)
            return proc
        try:
            policy_log=destination/'policy_server.log'
            policy=start([str(args.policy_wrapper),str(policy_port),str(destination/'policy_identity.json')],policy_log)
            wait_log(policy,policy_log,'server listening')
            sim_log=destination/'sim_server.log'
            sim=start([str(args.sim_wrapper),case['runtime_task'],str(destination/'sim'),str(sim_port),str(case['eval_seed'])],sim_log)
            # The simulator has exactly one RPC client slot: no socket probe.
            wait_log(sim,sim_log,'"event": "ready"')
            runner=start([os.environ['ROBO_PYTHON'],str(Path(__file__).with_name('run_chunk50_episode.py' if args.method=='pi05_chunk50' else 'run_one_episode.py')),
                          '--output',str(destination/'rollout'),'--task',case['runtime_task'],
                          '--sim-port',str(sim_port),'--policy-port',str(policy_port),
                          '--checkpoint',str(args.checkpoint),'--seed',str(case['reset_seed']),
                          '--max-decisions',str(args.max_decisions)],destination/'runner.log')
            row.update(status='running',pids=[proc.pid for proc in processes]); write(state,row)
            deadline=time.monotonic()+args.episode_timeout
            while runner.poll() is None:
                check_simulator(sim,sim_log,destination/'rollout/result.json'); check(policy,policy_log)
                if time.monotonic()>deadline:
                    raise TimeoutError('episode wall time budget exceeded')
                time.sleep(2)
            result_path=destination/'rollout/result.json'
            result=json.loads(result_path.read_text()) if result_path.exists() else {}
            native=result.get('complete') is True and (result.get('terminated') is True or result.get('truncated') is True)
            row.update(status=('complete' if native else 'incomplete') if runner.returncode==0 else 'runner_failed',
                       returncode=runner.returncode,result=result)
            outcome_path=destination/'sim/evaluation_outcome.json'
            outcome=json.loads(outcome_path.read_text()) if outcome_path.exists() else {}
            if invalid_native_reset(outcome):
                row.update(status='invalid_native_layout',native_outcome=outcome)
        except BaseException as error:
            row.update(status='interrupted' if isinstance(error,KeyboardInterrupt) else 'infrastructure_failed',error=f'{type(error).__name__}: {error}')
            if isinstance(error,KeyboardInterrupt):
                raise
        finally:
            for proc in reversed(processes): terminate(proc)
            for handle in handles: handle.close()
            row['finished_utc']=datetime.now(timezone.utc).isoformat()
            write(state,row); write(args.output/'batch_progress.json',[json.loads(path.read_text()) for path in sorted(args.output.glob('**/attempt.json'))])
            print(json.dumps(row,ensure_ascii=False),flush=True)

if __name__=='__main__': main()
