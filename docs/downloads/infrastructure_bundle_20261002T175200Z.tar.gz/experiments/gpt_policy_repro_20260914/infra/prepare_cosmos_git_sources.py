"""Cache exact public Git dependencies without changing upstream lock identities."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile

ROOT=Path(__file__).resolve().parents[3]
REPOS=[('lerobot','https://github.com/mli0603/lerobot.git','1a4316c6845330bc552fb982dbc44bdb4f66f2f1'),
       ('megatron-core','https://github.com/NVIDIA/Megatron-LM.git','de56227b26ba56de885897361272513697de7dc6')]


def main():
    out=ROOT/'upstream/checkpoints/cosmos-git-sources';out.mkdir(parents=True,exist_ok=True)
    mirrors=ROOT/'upstream/source-mirrors';mirrors.mkdir(parents=True,exist_ok=True)
    rows=[]
    for name,url,commit in REPOS:
        target=mirrors/(name+'.git')
        if not target.exists():subprocess.run(['git','clone','--mirror',url,str(target)],check=True,timeout=1200)
        subprocess.run(['git','--git-dir',str(target),'cat-file','-e',commit+'^{commit}'],check=True)
        subprocess.run(['git','--git-dir',str(target),'fsck','--full'],check=True,stdout=subprocess.DEVNULL)
        archive=out/(name+'.git.tar.gz')
        with tarfile.open(archive,'w:gz') as tar:tar.add(target,arcname=target.name)
        h=hashlib.sha256()
        with archive.open('rb') as src:
            for b in iter(lambda:src.read(8*1024*1024),b''):h.update(b)
        row=dict(path=archive.name,size=archive.stat().st_size,sha256=h.hexdigest(),repository=url,pinned_commit=commit)
        rows.append(row);print(json.dumps(row),flush=True)
    (out/'download_manifest.json').write_text(json.dumps(dict(source='cosmos-pinned-git-dependencies',verified=True,files=rows),indent=2)+'\n')


if __name__=='__main__':main()
