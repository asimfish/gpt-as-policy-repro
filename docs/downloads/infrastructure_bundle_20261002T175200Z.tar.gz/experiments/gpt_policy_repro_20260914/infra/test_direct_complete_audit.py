import json
import pytest
from test_gpt_direct_audit import fixture,write
from audit_gpt_direct_complete import audit


def complete_fixture(root,success=True):
    fixture(root)
    p=root/'sim/episode/action_000000.json';d=json.loads(p.read_text());d.update(terminated=success,truncated=not success,success=success);write(p,d)
    write(root/'rollout/result.json',dict(episode_id='episode',complete=True,terminated=success,truncated=not success,success=success,step_id=1,decisions=1,pi05_enabled=False,pi05_inference_calls=0,evaluation_case={'case_id':'fixture'}))
    write(root/'sim/evaluation_outcome.json',dict(complete=True,valid_for_success_rate=True,native_control_steps=1,native_success=success,native_score=int(success),evaluation_case={'case_id':'fixture'}))


@pytest.mark.parametrize('success',[True,False])
def test_native_success_and_failure_both_audited(tmp_path,success):
    complete_fixture(tmp_path,success)
    p=audit(tmp_path);assert p['complete_episode'] and p['terminal']['success']==success


@pytest.mark.parametrize('mutation',['missing_terminal','outcome_mismatch','extra_action','incomplete'])
def test_invalid_completion_rejected(tmp_path,mutation):
    complete_fixture(tmp_path)
    if mutation=='extra_action':
        p=tmp_path/'sim/episode/action_000001.json';write(p,{})
    else:
        name='sim/episode/action_000000.json' if mutation=='missing_terminal' else 'sim/evaluation_outcome.json'
        p=tmp_path/name;d=json.loads(p.read_text())
        if mutation=='missing_terminal':d['terminated']=False
        elif mutation=='outcome_mismatch':d['native_success']=False
        else:d['complete']=False
        write(p,d)
    with pytest.raises(AssertionError):audit(tmp_path)
