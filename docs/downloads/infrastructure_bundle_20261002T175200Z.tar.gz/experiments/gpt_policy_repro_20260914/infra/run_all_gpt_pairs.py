"""Long-lived fresh-attempt queue for every frozen Direct/Hybrid case."""
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ART = Path(__file__).resolve().parents[1]
CASES = ART / 'fixtures/cases'
CAMPAIGN = ART / 'gpt_pair_campaign'
LOCK_PATH = Path('/tmp/gpt-policy-all-pairs.lock')
MAX_INFRA_ATTEMPTS = int(os.environ.get('GPT_QUEUE_MAX_INFRA_ATTEMPTS', '1000'))
RETRY_SECONDS = int(os.environ.get('GPT_QUEUE_RETRY_SECONDS', '90'))
GPU = os.environ.get('GPT_QUEUE_GPU', '1')


def utc_stamp():
    return datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')


def case_ids():
    ids = []
    for path in sorted(CASES.glob('gpt__*.json')):
        case_id = path.name.removeprefix('gpt__').removesuffix('.json')
        if (CASES / f'mix__{case_id}.json').is_file():
            ids.append(case_id)
    assert len(ids) == 50, len(ids)
    return ids


def attempts(case_id, method):
    prefix = f'{method}/attempt.json'
    for parent in sorted(CAMPAIGN.glob('*')):
        p = parent / prefix
        if not p.is_file():
            continue
        try:
            row = json.loads(p.read_text())
        except json.JSONDecodeError:
            continue
        expected = f'{"gpt" if method == "gpt_only" else "mix"}__{case_id}'
        if row.get('case') == expected:
            yield parent, row


def native_terminal(parent, method):
    run = parent / method
    outcome = run / 'sim/evaluation_outcome.json'
    result = run / 'rollout/result.json'
    if not outcome.is_file() or not result.is_file():
        return False
    try:
        o, r = json.loads(outcome.read_text()), json.loads(result.read_text())
    except json.JSONDecodeError:
        return False
    return bool(o.get('complete') is True and o.get('valid_for_success_rate') is True
                and r.get('complete') is True and (r.get('terminated') or r.get('truncated')))


def terminal(parent, method):
    """Native terminal data alone cannot close an audit-required campaign job."""
    if not native_terminal(parent, method):
        return False
    run = parent / method
    try:
        proof = json.loads((run / 'complete_action_audit.json').read_text())
        result = json.loads((run / 'rollout/result.json').read_text())
        outcome = json.loads((run / 'sim/evaluation_outcome.json').read_text())
        identity = result['evaluation_case']
        fixture = json.loads((CASES / ('gpt__' + identity['case_id'] + '.json')).read_text())['identity']
        assert identity == outcome['evaluation_case'] == fixture
        assert proof['verified'] is True and proof['complete_episode'] is True
        assert proof['scope'] == 'complete_native_episode'
        assert (proof['model'], proof['reasoning_effort']) == ('gpt-6-astra', 'xhigh')
        assert proof['native_actions'] == result['step_id'] == outcome['native_control_steps']
        assert proof['decisions'] == result['decisions']
        assert result['success'] == outcome['native_success'] and type(result['success']) is bool
        assert proof['max_absolute_action_error'] == 0
        if 'terminal' in proof:
            assert proof['terminal'] == {k: result[k] for k in ('success', 'terminated', 'truncated')}
        if 'native_score' in proof:
            assert proof['native_score'] == outcome['native_score']
        if method == 'gpt_only':
            assert proof['pi05_inference_calls'] == 0
        else:
            assert proof['actions_by_mode'] == dict(student=result['student_steps'], edit=result['edited_steps'], eef=result['recovery_steps'])
            assert sum(proof['actions_by_mode'].values()) == result['step_id']
        for name in ('rollout/result.json', 'sim/evaluation_outcome.json', 'rollout/run.json', 'rollout/codex_workspace/worker.json'):
            assert proof['files_sha256'][name] == hashlib.sha256((run / name).read_bytes()).hexdigest()
    except (OSError, ValueError, KeyError, AssertionError, TypeError):
        return False
    return True


def inventory():
    """Read each attempt once; retain native-complete failures as terminal candidates."""
    found = {}
    for parent in sorted(CAMPAIGN.iterdir()):
        for method in ('gpt_only', 'pi05_plus_gpt'):
            try:
                row = json.loads((parent / method / 'attempt.json').read_text())
            except (OSError, ValueError):
                continue
            cid = row.get('case', '').removeprefix('gpt__').removeprefix('mix__')
            found.setdefault((cid, method), []).append((parent, row))
    for rows in found.values():
        rows.sort(key=lambda p: (p[1].get('started_utc') or '', p[0].name))
    return found


def choose_next(pending):
    # A repeated infrastructure failure must not starve untried frozen cases.
    return min(pending, key=lambda job: job[2])[:2]


def pair_service_active():
    try:
        env = dict(os.environ, XDG_RUNTIME_DIR='/run/user/1007', DBUS_SESSION_BUS_ADDRESS='unix:path=/run/user/1007/bus')
        out = subprocess.check_output(['systemctl', '--user', 'list-units', '--all', 'gpt-policy-pair-*.service', '--no-legend'], text=True, stderr=subprocess.DEVNULL, env=env)
    except Exception:
        return True
    return any(' active ' in (' ' + line + ' ') for line in out.splitlines() if 'audit-' not in line)


def try_lock():
    handle = LOCK_PATH.open('a')
    try:
        fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        handle.close()
        return None
    return handle


def atomic_json(path, value):
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    temp.replace(path)


def audit_run(parent, method):
    run = parent / method
    history_path = run / 'rollout/history.json'
    if not history_path.is_file():
        return
    try:
        history = json.loads(history_path.read_text())
        sys.path.insert(0, str(ART / 'infra'))
        if method == 'gpt_only':
            from audit_gpt_direct_complete import audit as complete_audit
            from audit_gpt_direct_prefix import audit as prefix_audit
            proof = complete_audit(run) if native_terminal(parent, method) else prefix_audit(run, len(history))
        else:
            from audit_hybrid_actions import audit
            proof = audit(run, None if native_terminal(parent, method) else len(history))
        name = 'complete_action_audit.json' if proof.get('complete_episode') else 'stopped_action_prefix_audit.json'
        atomic_json(run / name, proof)
    except Exception as exc:
        atomic_json(run / 'audit_error.json', {'error': repr(exc), 'observed_utc': datetime.now(timezone.utc).isoformat()})


def run_attempt(case_id, method, parent=None):
    parent = parent or CAMPAIGN / f'queue_{utc_stamp()}_{method}_{re.sub("[^a-zA-Z0-9]+", "_", case_id)}'
    env = dict(os.environ)
    cmd = ['bash', str(ART / 'infra/run_gpt_pair.sh'), '--case', case_id,
           '--output', str(parent), '--gpu', GPU, '--method', method,
           '--continue-after-failure', '--lock-path', str(LOCK_PATH)]
    return subprocess.run(cmd, env=env).returncode, parent


def main():
    state_path = ART / 'gpt_queue_state.json'
    state = {'schema': 'gpt_policy_all_pairs_queue.v2', 'started_utc': datetime.now(timezone.utc).isoformat(), 'cases': {}}
    ids = case_ids()
    for case_id in case_ids():
        state['cases'][case_id] = {'gpt_only': {'status': 'pending', 'attempts': 0}, 'pi05_plus_gpt': {'status': 'pending', 'attempts': 0}}
    atomic_json(state_path, state)
    while True:
        pending = []
        observed = inventory()
        for case_id in ids:
            for method in ('gpt_only', 'pi05_plus_gpt'):
                runs = observed.get((case_id, method), [])
                count = len(runs)
                job = state['cases'][case_id][method]
                job['attempts'] = count
                completed = next((parent for parent, _ in runs if native_terminal(parent, method)), None)
                if completed:
                    if not terminal(completed, method):
                        audit_run(completed, method)
                    job.update(status='complete' if terminal(completed, method) else 'audit_failed', last_output=str(completed))
                    continue
                if count < MAX_INFRA_ATTEMPTS:
                    pending.append((case_id, method, count))
                else:
                    job.update(status='retry_budget_exhausted')
        state['updated_utc'] = datetime.now(timezone.utc).isoformat()
        atomic_json(state_path, state)
        if not pending:
            all_complete = all(job['status'] == 'complete' for methods in state['cases'].values() for job in methods.values())
            state['status'] = 'complete' if all_complete else 'awaiting_audit_or_retry_budget'
            if all_complete:
                state['finished_utc'] = datetime.now(timezone.utc).isoformat()
            atomic_json(state_path, state)
            if all_complete:
                return
            time.sleep(60)
            continue
        case_id, method = choose_next(pending)
        handle = try_lock()
        if handle is None or pair_service_active():
            if handle is not None:
                fcntl.flock(handle, fcntl.LOCK_UN); handle.close()
            time.sleep(30)
            continue
        handle.close()
        parent = CAMPAIGN / f'queue_{utc_stamp()}_{method}_{re.sub("[^a-zA-Z0-9]+", "_", case_id)}'
        state['cases'][case_id][method].update(status='running', last_output=str(parent))
        state['status'] = 'running'
        atomic_json(state_path, state)
        code, parent = run_attempt(case_id, method, parent)
        audit_run(parent, method)
        state['cases'][case_id][method]['last_output'] = str(parent)
        state['cases'][case_id][method]['last_returncode'] = code
        state['cases'][case_id][method]['status'] = 'terminal' if terminal(parent, method) else 'infra_retry'
        atomic_json(state_path, state)
        if not terminal(parent, method):
            time.sleep(RETRY_SECONDS)


if __name__ == '__main__':
    main()
