"""Exercise the actual shell supervisor against a simulator that ignores SIGINT."""
import os
from pathlib import Path
import shutil
import signal
import subprocess
import tempfile
import unittest

class RoboLabCleanupTests(unittest.TestCase):
    def test_unresponsive_owned_server_is_reaped_after_timeout(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);infra=root/'infra';infra.mkdir()
            script=infra/'run_robolab_smoke.sh'
            shutil.copyfile(Path(__file__).with_name(script.name),script)
            fake=infra/'run_robolab_server.sh'
            fake.write_text('''#!/usr/bin/env python3
import os,signal,sys,time
from pathlib import Path
signal.signal(signal.SIGINT,signal.SIG_IGN)
signal.signal(signal.SIGTERM,signal.SIG_IGN)
(Path(sys.argv[2]).parent/'server.pid').write_text(str(os.getpid()))
while True:time.sleep(1)
''')
            fake.chmod(0o755);output=root/'run'
            pid=None
            try:
                result=subprocess.run(['bash',str(script),str(output)],env=dict(os.environ,ROBO_LAB_READY_TIMEOUT='1'),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=25)
                pid=int((output/'server.pid').read_text())
                self.assertNotEqual(result.returncode,0)
                with self.assertRaises(ProcessLookupError):os.kill(pid,0)
            finally:
                if pid is None and (output/'server.pid').exists():pid=int((output/'server.pid').read_text())
                if pid:
                    try:os.killpg(pid,signal.SIGKILL)
                    except ProcessLookupError:pass
