#!/usr/bin/env bash
set -euo pipefail
ROOT=/home/dataset-assist-0/liyufeng/agentic_robot
export GIT_LFS_SKIP_SMUDGE=1
export HTTPS_PROXY="${OPENPI_DOWNLOAD_PROXY:-http://127.0.0.1:18997}"
export HTTP_PROXY="$HTTPS_PROXY" NO_PROXY=127.0.0.1,localhost
export UV_CACHE_DIR="$ROOT/uv-cache"
export UV_PROJECT_ENVIRONMENT="$ROOT/venvs/openpi-robolab"
mkdir -p "$ROOT/venvs" "$ROOT/experiments/gpt_policy_repro_20260914/mainskill"
exec 9>"$ROOT/venvs/openpi-bootstrap.lock"
flock -n 9
cd "$ROOT/upstream/openpi-robolab"
/home/batchcom/.local/bin/uv sync --frozen --no-dev --python 3.11 --offline --find-links "$ROOT/upstream/checkpoints/openpi-wheels" --find-links "$ROOT/upstream/checkpoints/openpi-build-wheels"
# Pinned upstream runtime imports pytest in gemma_pytorch.py despite --no-dev.
# Install only that frozen-lock dependency closure after the exact runtime sync.
/home/batchcom/.local/bin/uv pip install --python "$UV_PROJECT_ENVIRONMENT/bin/python" --no-index --find-links "$ROOT/upstream/checkpoints/openpi-wheels" --find-links "$ROOT/upstream/checkpoints/openpi-build-wheels" pytest==8.3.5 iniconfig==2.1.0 pluggy==1.6.0
"$UV_PROJECT_ENVIRONMENT/bin/python" - <<'PY'
import importlib.metadata as m,json
from pathlib import Path
from openpi.training import config
c=config.get_config('pi05_droid_jointpos')
p=Path('/home/dataset-assist-0/liyufeng/agentic_robot/experiments/gpt_policy_repro_20260914/mainskill/openpi_environment.json')
p.write_text(json.dumps({'config':c.name,'action_horizon':c.model.action_horizon,'versions':{k:m.version(k) for k in ['jax','jaxlib','flax','orbax-checkpoint','torch','numpy']}},indent=2)+'\n')
print(p.read_text())
PY
