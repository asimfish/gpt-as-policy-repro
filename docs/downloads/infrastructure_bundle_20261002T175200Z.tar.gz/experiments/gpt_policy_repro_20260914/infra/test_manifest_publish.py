import json,hashlib,subprocess,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from transfer_checkpoint_chunks import publish_manifest

class ManifestPublishTest(unittest.TestCase):
 def test_large_unicode_manifest_roundtrip_without_stdin(self):
  payload=json.dumps([{'path':'场景/'+str(i),'sha256':hashlib.sha256(str(i).encode()).hexdigest()} for i in range(500)],ensure_ascii=False).encode()
  self.assertGreater(len(payload),48000)
  with tempfile.TemporaryDirectory() as tmp:
   path=Path(tmp)/'complete.json';path.write_text('old')
   def local_remote(code,args=(),data=None,timeout=30):
    self.assertIsNone(data)
    return subprocess.check_output([sys.executable,'-c',code,*args],stdin=subprocess.DEVNULL,timeout=3).decode()
   with patch('transfer_checkpoint_chunks.remote',side_effect=local_remote):publish_manifest(str(path),payload)
   self.assertEqual(path.read_bytes(),payload)
   self.assertFalse(path.with_suffix('.tmp').exists())
if __name__=='__main__':unittest.main()
