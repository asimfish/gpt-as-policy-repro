"""Read-only progress inspection; never contacts a simulator RPC port."""
import json
from pathlib import Path
import sys
root=Path(sys.argv[1])
rows=[]
for attempt in sorted(root.glob('**/attempt.json')):
    row=json.loads(attempt.read_text())
    history=attempt.parent/'rollout/history.json'
    if history.exists():
        data=json.loads(history.read_text())
        row['recorded_decisions']=len(data)
    responses=sorted((attempt.parent/'rollout').glob('response_*.json'))
    row['response_files']=len(responses)
    obs=sorted((attempt.parent/'rollout/observations').glob('*/observation.json'))
    if obs:
        data=json.loads(obs[-1].read_text())
        row['latest_observation']=str(obs[-1])
        row['step_id']=data.get('step_id')
    rows.append(row)
print(json.dumps(rows,ensure_ascii=False,indent=2))
