"""Render an evidence-linked local dashboard from on-disk measurements."""
import argparse
from datetime import datetime, timezone
import html
import json
from pathlib import Path
from urllib.parse import quote
from build_reproduction_report import build


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('root',type=Path)
    args=parser.parse_args();root=args.root.resolve()
    report=build(root)
    esc=lambda value:html.escape(str(value))
    link=lambda path:quote(str(path),safe='/')
    body=['<h1>GPT-as-Policy · 独立复现实验</h1><p class="muted">从本项目原始轨迹生成 · '+datetime.now(timezone.utc).isoformat()+'</p>',
          '<nav><a href="report_interpretation_zh.md">原报告解读</a><a href="independent_report.json">结果 JSON</a><a href="README.md">复现说明</a><a href="GOAL.md">完整验收目标</a><a href="independent_task_results.png">任务结果图（快照）</a></nav>',
          '<section><h2>自有评测结果</h2><p>短步验证、未完成轨迹和缺少方法来源的轨迹不进入成功率分母。公开报告数据不计入本表。单条样本不能代表整体任务成功率。</p>',
          '<table><thead><tr><th>方法</th><th>已记录轨迹</th><th>原生完成</th><th>可计分</th><th>成功率</th><th>控制步</th></tr></thead><tbody>']
    for method,row in sorted(report['summary'].items()):
        rate='N/A' if row['success_rate'] is None else f"{row['success_rate']:.1%}"
        body.append('<tr>'+''.join('<td>'+esc(v)+'</td>' for v in [method,row['attempts'],row['completed'],row['evaluated'],rate,row['observed_steps']])+'</tr>')
    body+=['</tbody></table></section>']
    deployment=root/'mainskill/deployment.json'
    if deployment.exists():
        info=json.loads(deployment.read_text())
        if info.get('robolab_reset_observation_verified') is True:
            observation=(deployment.parent/info['robolab_task_evidence']).resolve()
            observation.relative_to(root)
            body+=['<section><h2>A100 · 真实 RoboLab 场景验证</h2><p>BlocksInBinTask 的 reset 和双相机观测已通过。尚未执行完整策略回合，不计入成功率。</p><div class="cards">']
            for name,label in [('main_rgb.png','主相机'),('wrist_rgb.png','腕相机')]:
                body.append('<article><h3>'+label+'</h3><img loading="lazy" src="'+link((observation/name).relative_to(root))+'" alt="A100 实际仿真图像"></article>')
            body+=['</div><p><a href="mainskill/render_diagnostics.md">配置、失败对照与验证证据</a></p></section>']
    body+=['<section><h2>任务运行与现场观测</h2><div class="cards">']
    for attempt in report['infrastructure_attempts']:
        folder=root/Path(attempt['evidence']).parent
        observations=sorted((folder/'rollout/observations').glob('*/observation.json'))
        body.append('<article><h3>'+esc(attempt['case'])+'</h3><p>'+esc(attempt['method'])+' · '+esc(attempt['status'])+'</p>')
        if observations:
            obs=json.loads(observations[-1].read_text())
            step=obs.get('step_id',0);limit=obs.get('max_episode_steps',0)
            body.append(f'<p>最近观测：{step} / {limit} 控制步</p><progress value="{step}" max="{limit or 1}"></progress>')
            img=observations[-1].with_name('cam_high.png')
            if img.exists():body.append('<img loading="lazy" src="'+link(img.relative_to(root))+'" alt="本项目真实仿真观测">')
        video=folder/'sim/sensors.mp4'
        if video.exists() and attempt['status'] in ('complete','incomplete'):
            body.append('<video controls preload="metadata" src="'+link(video.relative_to(root))+'"></video>')
        body.append('<p><a href="'+link(attempt['evidence'])+'">尝试记录</a> · <a href="'+link((folder/'runner.log').relative_to(root))+'">控制器日志</a></p></article>')
    body+=['</div></section><section><h2>尚待完成</h2><p>主实验的 50 个 GPT Direct 和 50 个 hybrid、完整 π0.5 对照，以及 RoboLab 补充实验。GPT 在线运行仍需指定独立实验模型接入配置。π0.5 prefix-15 对照已完成 50 案例尝试，不含 GPT 调用；48 例可计分，2 例原生无效布局排除。</p></section>']
    style='body{font:16px/1.65 system-ui,sans-serif;background:#f4f6f8;color:#182332;max-width:1200px;margin:40px auto;padding:0 24px}h1{font-size:32px}h2{font-size:22px}h3{font-size:16px;overflow-wrap:anywhere}section,article{background:white;border:1px solid #dde4eb;border-radius:12px;padding:24px;margin:22px 0}article{margin:0;padding:16px}.muted{color:#617084}a{color:#155daf}nav{display:flex;gap:24px;flex-wrap:wrap}table{width:100%;border-collapse:collapse}td,th{text-align:left;padding:12px;border-bottom:1px solid #e3e8ef}.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:20px}img,video{max-width:100%;border-radius:8px}progress{width:100%}'
    (root/'dashboard.html').write_text('<!doctype html><html lang="zh"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>GPT-as-Policy 独立复现</title><style>'+style+'</style><body>'+''.join(body)+'</body></html>')
    print(root/'dashboard.html')

if __name__=='__main__':main()
