"""Read Vulkan device/extension capabilities without creating a GPU workload."""
import ctypes as c
import json

class App(c.Structure):
    _fields_=[('sType',c.c_uint32),('pNext',c.c_void_p),('name',c.c_char_p),('version',c.c_uint32),('engine',c.c_char_p),('engineVersion',c.c_uint32),('apiVersion',c.c_uint32)]
class Create(c.Structure):
    _fields_=[('sType',c.c_uint32),('pNext',c.c_void_p),('flags',c.c_uint32),('app',c.POINTER(App)),('layerCount',c.c_uint32),('layers',c.c_void_p),('extensionCount',c.c_uint32),('extensions',c.c_void_p)]
class Ext(c.Structure):
    _fields_=[('name',c.c_char*256),('version',c.c_uint32)]
vk=c.CDLL('libvulkan.so.1')
vk.vkCreateInstance.argtypes=[c.POINTER(Create),c.c_void_p,c.POINTER(c.c_void_p)]
vk.vkEnumeratePhysicalDevices.argtypes=[c.c_void_p,c.POINTER(c.c_uint32),c.POINTER(c.c_void_p)]
vk.vkGetPhysicalDeviceProperties.argtypes=[c.c_void_p,c.c_void_p]
vk.vkEnumerateDeviceExtensionProperties.argtypes=[c.c_void_p,c.c_char_p,c.POINTER(c.c_uint32),c.POINTER(Ext)]
vk.vkDestroyInstance.argtypes=[c.c_void_p,c.c_void_p]
def check(code):
    if code!=0:raise RuntimeError(f'Vulkan result {code}')
app=App(sType=0,name=b'gpt-policy-probe',apiVersion=(1<<22)|(2<<12))
ci=Create(sType=1,app=c.pointer(app));instance=c.c_void_p()
check(vk.vkCreateInstance(c.byref(ci),None,c.byref(instance)))
try:
    count=c.c_uint32();check(vk.vkEnumeratePhysicalDevices(instance,c.byref(count),None))
    devices=(c.c_void_p*count.value)();check(vk.vkEnumeratePhysicalDevices(instance,c.byref(count),devices))
    rows=[]
    for device in devices:
        properties=c.create_string_buffer(4096);vk.vkGetPhysicalDeviceProperties(device,properties)
        n=c.c_uint32();check(vk.vkEnumerateDeviceExtensionProperties(device,None,c.byref(n),None))
        extensions=(Ext*n.value)();check(vk.vkEnumerateDeviceExtensionProperties(device,None,c.byref(n),extensions))
        names={e.name.decode() for e in extensions}
        rows.append({'device':properties.raw[20:276].split(b'\0')[0].decode(),'ray_tracing_pipeline':'VK_KHR_ray_tracing_pipeline' in names,'acceleration_structure':'VK_KHR_acceleration_structure' in names,'extension_count':len(names)})
    print(json.dumps({'vkCreateInstance':'VK_SUCCESS','devices':rows},indent=2))
finally:vk.vkDestroyInstance(instance,None)
