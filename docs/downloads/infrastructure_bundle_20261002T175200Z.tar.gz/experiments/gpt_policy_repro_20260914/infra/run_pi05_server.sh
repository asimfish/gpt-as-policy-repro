#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/env.sh"

port="${1:-18830}"
identity="${2:-$REPRO_ROOT/experiments/gpt_policy_repro_20260914/pi05_identity_${port}.json}"
cd "$ROBO_ROOT"
CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}" \
XLA_PYTHON_CLIENT_PREALLOCATE=false \
PYTHONPATH="$GPT_POLICY_ROOT:$ROBO_ROOT:$ROBO_ROOT/XPolicyLab/policy/Pi_05/openpi/src:$ROBO_ROOT/XPolicyLab/policy/Pi_05/openpi/packages/openpi-client/src" \
exec "$OPENPI_PYTHON" -m hybrid_rollout.robodojo.pi05_server.server \
  --checkpoint "$PI05_CHECKPOINT" --port "$port" --identity-output "$identity"
