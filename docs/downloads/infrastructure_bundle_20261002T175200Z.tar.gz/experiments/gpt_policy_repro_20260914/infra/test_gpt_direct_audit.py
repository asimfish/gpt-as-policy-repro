import json
from pathlib import Path
import tempfile
import unittest
import numpy as np
from audit_gpt_direct_prefix import audit


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data))


def fixture(root):
    r = root/'rollout'; w = r/'codex_workspace'; n = root/'sim/episode'
    response = dict(mode='eef', request_id='request', steps=1, reason='fixture', target={})
    labelled = dict(response, evaluation_method='gpt_only')
    write(r/'run.json', dict(teacher_model='gpt-6-astra', evaluation_method='gpt_only',
                            pi05_enabled=False, pi05_inference_calls=0, initial_state_hash='fixture'))
    write(w/'worker.json', dict(model='gpt-6-astra', reasoning_effort='xhigh', model_provider='openai', thread_id='thread'))
    write(r/'history.json', [dict(decision=0, start_tick=0, end_tick=1, source='gpt_eef', response=labelled, executed_steps=1)])
    write(r/'response_000.json', labelled)
    args = dict(response=response)
    write(w/'call_0001_request.json', dict(tool='robodojo_act', call_id='call', arguments=args))
    write(w/'call_0001_result.json', dict(step_id=1))
    write(n/'codex_decisions/000.json', dict(response=labelled, step_id=0, episode_id='episode', prediction_id=None))
    write(n/'action_000000.json', dict(valid=True, step_id=1, source='gpt_eef',
          teacher_request_id='request', executed_action=[0.0]*14, obs=dict(states=[1.0]*14)))
    np.savez(r/'execution_000.npz', actions=np.zeros((1,14),dtype=np.float32), states=np.ones((1,14),dtype=np.float32))
    event=dict(method='item/tool/call', params=dict(callId='call', threadId='thread', tool='robodojo_act', arguments=args))
    (w/'rpc_out.jsonl').write_text(json.dumps(event)+'\n')


class DirectAuditTest(unittest.TestCase):
    def test_prefix_proof_never_claims_episode_completion(self):
        with tempfile.TemporaryDirectory() as t:
            r=Path(t);fixture(r);proof=audit(r,1)
            self.assertTrue(proof['verified'])
            self.assertFalse(proof['complete_episode'])
            self.assertEqual(proof['native_actions'],1)

    def test_native_action_corruption_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            r=Path(t);fixture(r);p=r/'sim/episode/action_000000.json'
            d=json.loads(p.read_text());d['executed_action'][0]=.1;write(p,d)
            with self.assertRaises(AssertionError):audit(r,1)

    def test_foreign_model_thread_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            r=Path(t);fixture(r);p=r/'rollout/codex_workspace/rpc_out.jsonl'
            d=json.loads(p.read_text());d['params']['threadId']='other-thread';p.write_text(json.dumps(d)+'\n')
            with self.assertRaises(AssertionError):audit(r,1)
