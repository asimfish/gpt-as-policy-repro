#!/usr/bin/env bash
set -euo pipefail
ROOT=/mnt/nas/data/lyf/agentic_robot
export XDG_RUNTIME_DIR=/run/user/1007 DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/1007/bus
for i in $(seq 1 1440); do
 if [[ -f "$ROOT/upstream/checkpoints/robolab-assets/download_manifest.json" ]] && ! systemctl --user is-active --quiet gpt-policy-openpi-full-wheel-repair.service; then break; fi
 sleep 15
done
[[ -f "$ROOT/upstream/checkpoints/robolab-assets/download_manifest.json" ]]
python3 "$ROOT/experiments/gpt_policy_repro_20260914/infra/transfer_checkpoint_chunks.py" --checkpoint robolab-assets
ssh -o BatchMode=yes -o ConnectTimeout=15 -o UserKnownHostsFile=/home/liyufeng/.ssh/known_hosts_a100 -o StrictHostKeyChecking=yes mainskill 'bash -s' <<'REMOTE'
set -euo pipefail
ROOT=/home/dataset-assist-0/liyufeng/agentic_robot
BUNDLE="$ROOT/upstream/checkpoints/robolab-assets"
TARGET="$ROOT/upstream/RoboLab-ad45-full-assets"
mkdir -p "$TARGET"
tar --no-same-owner --no-same-permissions -xzf "$BUNDLE/source.tar.gz" -C "$TARGET"
tar --no-same-owner --no-same-permissions -xzf "$BUNDLE/assets.tar.gz" -C "$TARGET"
python3 - "$BUNDLE" "$TARGET" <<'PYVERIFY'
import sys,json,hashlib
from pathlib import Path
bundle,target=map(Path,sys.argv[1:]);manifest=json.loads((bundle/'assets_manifest.json').read_text())
for row in manifest['files']:
 p=target/row['path'];assert p.is_file() and not p.is_symlink() and p.stat().st_size==row['size']
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 assert h.hexdigest()==row['sha256'],row['path']
result=dict(verified=True,source_commit=manifest['source_commit'],files=len(manifest['files']),scope='all tracked repository assets; task resets still require validation')
(target/'assets_verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
PYVERIFY
REMOTE
