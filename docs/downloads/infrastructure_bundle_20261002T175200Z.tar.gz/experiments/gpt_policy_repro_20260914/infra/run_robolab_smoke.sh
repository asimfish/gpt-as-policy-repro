#!/usr/bin/env bash
set -euo pipefail
source="$(cd "$(dirname "$0")/.." && pwd)"
code_root="$(cd "$source/../.." && pwd)"
output="${1:?output required}"; port="${2:-19500}"
task="${ROBO_LAB_TASK:-BlocksInBinTask}"; seed="${ROBO_LAB_SEED:-0}"
server_output="$output/sim"; mkdir -p "$output"
setsid "$source/infra/run_robolab_server.sh" "$task" "$server_output" "$port" "$seed" >"$output/server.log" 2>&1 & server_pid=$!
cleanup(){
  kill -INT -- "-$server_pid" 2>/dev/null || true
  for i in $(seq 1 10); do kill -0 "$server_pid" 2>/dev/null || break; sleep 1; done
  if kill -0 "$server_pid" 2>/dev/null; then kill -KILL -- "-$server_pid" 2>/dev/null || true; fi
  wait "$server_pid" 2>/dev/null || true
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
for i in $(seq 1 "${ROBO_LAB_READY_TIMEOUT:-600}"); do
  if grep -qE 'ERROR_OUT_OF_DEVICE_MEMORY|Failed to create any GPU devices|switching to software|Failed to create raytracing pipeline' "$output/server.log"; then
    echo "RoboLab renderer or GPU physics failed; see $output/server.log" >&2; exit 1
  fi
  grep -q '"event": "ready"' "$output/server.log" && break; kill -0 "$server_pid" 2>/dev/null || { cat "$output/server.log"; exit 1; }; sleep 1; done
grep -q '"event": "ready"' "$output/server.log" || { cat "$output/server.log"; exit 1; }
client="${ROBO_LAB_CLIENT:-run_robolab_smoke.py}"
client_args=(--task "$task" --seed "$seed")
if [[ "${ROBO_LAB_RPC_EEF_PROBE:-0}" == 1 ]]; then client_args+=(--eef); fi
if [[ -n "${ROBO_LAB_POLICY_PORT:-}" ]]; then
  client=run_robolab_pi05_episode.py
  client_args+=(--policy-port "$ROBO_LAB_POLICY_PORT")
fi
PYTHONPATH="$code_root/gpt-as-policy:${ROBO_LAB_ROOT:-$code_root/upstream/RoboLab}:$code_root/upstream/openpi-robolab/packages/openpi-client/src" "${ROBO_LAB_PYTHON:-/home/liyufeng/venvs/gpt-policy-robolab51/bin/python}" "$source/infra/$client" --output "$output/rollout" --port "$port" "${client_args[@]}"
