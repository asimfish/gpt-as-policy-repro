"""Export a timestamped task-level plot from the independent report snapshot."""
import argparse
import hashlib
import json
from datetime import datetime,timezone
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

p=argparse.ArgumentParser();p.add_argument('root',type=Path);a=p.parse_args()
source=a.root/'independent_report.json';raw=source.read_bytes();report=json.loads(raw)
rows=[r for r in report['by_task'] if r['method']=='pi05_prefix15' and r['evaluated']]
summary=report['summary']['pi05_prefix15']
audit_path=a.root/'prefix15_cohort_audit.json'
audit=json.loads(audit_path.read_text()) if audit_path.exists() else {}
partial_cohort=not (audit.get('planned_cases')==50 and audit.get('resolved_cases')==50)
cohort_label='partial cohort' if partial_cohort else '50 cases attempted; 2 native invalid layouts excluded'
fig,axes=plt.subplots(1,2,figsize=(13,7),sharey=True,layout='constrained')
y=list(range(len(rows)))
labels=[r['task'].replace('_',' ')+f"  (n={r['evaluated']})" for r in rows]
axes[0].barh(y,[r['success_rate'] for r in rows],color='#2678b7')
axes[1].barh(y,[r['mean_score'] for r in rows],color='#23856d')
axes[0].set_yticks(y,labels);axes[0].invert_yaxis()
for ax,title in zip(axes,['Success rate','Mean native score']):
 ax.set_xlim(0,1.12);ax.set_title(title);ax.set_xlabel('0 to 1');ax.grid(axis='x',alpha=.2);ax.set_axisbelow(True)
for i,r in enumerate(rows):
 axes[0].text(r['success_rate']+.02,i,f"{r['successes']}/{r['evaluated']}",va='center',fontsize=9)
 axes[1].text(r['mean_score']+.02,i,f"{r['mean_score']:.2f}",va='center',fontsize=9)
fig.suptitle(f"Independent Pi0.5 prefix-15 — {cohort_label}\n{summary['evaluated']} scored; {summary['successes']} successes; task sample counts are unequal",fontsize=14)
output=a.root/'independent_task_results.png';fig.savefig(output,dpi=170);plt.close(fig)
output.with_suffix('.json').write_text(json.dumps({'source_sha256':hashlib.sha256(raw).hexdigest(),'generated_utc':datetime.now(timezone.utc).isoformat(),'method':'pi05_prefix15','summary':summary,'partial_cohort':partial_cohort},indent=2)+'\n')
print(output)
