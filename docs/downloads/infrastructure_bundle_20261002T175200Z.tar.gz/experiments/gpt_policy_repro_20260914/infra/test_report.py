import json
import tempfile
import unittest
from pathlib import Path
from build_reproduction_report import build

class ReportTests(unittest.TestCase):
    def episode(self, root, name, result, provenance=None):
        path = root/name
        path.mkdir(parents=True)
        (path/'result.json').write_text(json.dumps(result))
        (path/'run.json').write_text(json.dumps({'evaluation_method':'pi05_plus_gpt'}))
        if provenance is not None:
            (path/'reproduction.json').write_text(json.dumps(provenance))

    def test_unknown_is_not_hybrid(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            self.episode(root, 'unknown', {'complete':True,'terminated':True,'success':True})
            report = build(root)
            self.assertEqual(set(report['summary']), {'unknown'})
            self.assertIsNone(report['summary']['unknown']['success_rate'])

    def test_incomplete_excluded_and_direct_steps_counted(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            provenance = {'method':'gpt_only','benchmark_eligible':True}
            self.episode(root,'cutoff/rollout',{'complete':False,'success':False,'gpt_eef_steps':5},provenance)
            self.episode(root,'native/rollout',{'complete':True,'terminated':True,'success':True,'gpt_eef_steps':10},provenance)
            (root/'native/sim').mkdir()
            (root/'native/sim/evaluation_outcome.json').write_text(json.dumps({'complete':True,'valid_for_success_rate':True,'native_success':True,'native_score':1.0}))
            row = build(root)['summary']['gpt_only']
            self.assertEqual((row['evaluated'],row['success_rate'],row['observed_steps']),(1,1.0,15))

    def test_invalid_or_missing_native_outcome_is_not_scored(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            provenance={'method':'pi05_prefix15','benchmark_eligible':True}
            for name in ('missing','invalid','disagrees'):
                self.episode(root,name+'/rollout',{'complete':True,'terminated':True,'success':True},provenance)
            for name,valid,success in [('invalid',False,True),('disagrees',True,False)]:
                (root/name/'sim').mkdir()
                (root/name/'sim/evaluation_outcome.json').write_text(json.dumps({'complete':True,'valid_for_success_rate':valid,'native_success':success,'native_score':1.0}))
            self.assertEqual(build(root)['summary']['pi05_prefix15']['evaluated'],0)

    def test_task_breakdown_keeps_native_denominators(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            for name,task,success,valid in [('a','task_a',True,True),('b','task_a',False,False),('c','task_b',False,True)]:
                self.episode(root,name+'/rollout',{'complete':True,'terminated':True,'success':success}, {'method':'pi05_prefix15','benchmark_eligible':True})
                (root/name/'rollout/run.json').write_text(json.dumps({'task':task}))
                (root/name/'sim').mkdir()
                (root/name/'sim/evaluation_outcome.json').write_text(json.dumps({'complete':True,'valid_for_success_rate':valid,'native_success':success if valid else None,'native_score':float(success) if valid else None,'status':'native_completed' if valid else 'invalid_native_layout'}))
            report=build(root)
            rows={r['task']:r for r in report['by_task']}
            self.assertEqual((rows['task_a']['completed'],rows['task_a']['evaluated'],rows['task_a']['excluded_completed']),(2,1,1))
            self.assertEqual(rows['task_a']['success_rate'],1.0)
            self.assertEqual(rows['task_b']['success_rate'],0.0)
            self.assertEqual(report['summary']['pi05_prefix15']['success_rate'],0.5)

    def test_smoke_not_scored(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            self.episode(root,'smoke',{'complete':True,'terminated':True,'success':True}, {'method':'pi05_prefix15_smoke','benchmark_eligible':False})
            self.assertEqual(build(root)['summary']['pi05_prefix15_smoke']['evaluated'],0)

    def test_robolab_native_controls_count_without_formal_pairing_claim(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            self.episode(root,'robolab/rollout',dict(complete=True,terminated=False,truncated=True,success=False,control_steps=2250),
                         dict(method='robolab_pi05_native15_fresh',benchmark_eligible=False))
            row=build(root)['summary']['robolab_pi05_native15_fresh']
            self.assertEqual(row['observed_steps'],2250)
            self.assertEqual(row['completed'],1)
            self.assertEqual(row['evaluated'],0)
            self.assertIsNone(row['success_rate'])

if __name__ == '__main__': unittest.main()
