"""Pluggable teacher backend for reproducible GPT decisions.

The backend reads endpoint and environment-variable names from a JSON config;
the config must never contain the secret itself. It expects the model to return
one JSON decision matching the RoboDojo response contract.
"""
from __future__ import annotations

import base64
import json
import os
from pathlib import Path
from urllib.request import Request, urlopen


class OpenAICompatibleTeacher:
    def __init__(self, config_path: Path):
        config = json.loads(Path(config_path).read_text())
        self.endpoint = config["endpoint"].rstrip("/")
        self.model = config.get("model", "gpt-6-astra")
        self.effort = config.get("reasoning_effort", "xhigh")
        self.key = os.environ[config.get("api_key_env", "OPENAI_API_KEY")]
        self.timeout = int(config.get("timeout_seconds", 900))

    @staticmethod
    def _image(path):
        data = base64.b64encode(Path(path).read_bytes()).decode()
        return {"type": "input_image", "image_url": f"data:image/png;base64,{data}"}

    def __call__(self, request, proposal):
        images = [self._image(item["path"]) for item in request.get("images", [])]
        contract = {
            "request_id": request["request_id"],
            "task": request["task"],
            "instruction": request["instruction"],
            "step_id": request["step_id"],
            "current_eef": request["current_eef"],
            "student_eef_trajectory": request["student_eef_trajectory"],
            "action_diagnostics": request.get("action_diagnostics"),
            "fk_check": request.get("fk_check"),
            "previous_result": request.get("previous_result"),
        }
        prompt = (
            "You are the teacher in a RoboDojo embodied-policy experiment. "
            "Return ONLY one JSON object matching the response contract. "
            "Use English public evidence. Follow the gate assessment rules.\n"
            "Allowed mode: student, edit, eef, or stop.\n"
            "Request JSON:\n" + json.dumps(contract, ensure_ascii=False) +
            "\nProposal is a 50x14 joint chunk; select at most 15 student steps."
        )
        payload = {
            "model": self.model,
            "reasoning": {"effort": self.effort},
            "input": [{"role": "user", "content": [{"type": "input_text", "text": prompt}, *images]}],
        }
        req = Request(self.endpoint + "/responses", data=json.dumps(payload).encode(),
                      headers={"Authorization": f"Bearer {self.key}", "Content-Type": "application/json"})
        with urlopen(req, timeout=self.timeout) as response:
            body = json.loads(response.read())
        text = body.get("output_text")
        if not text:
            for item in body.get("output", []):
                for content in item.get("content", []):
                    if content.get("type") in ("output_text", "text"):
                        text = content.get("text")
                        break
        if not text:
            raise ValueError("Teacher response did not contain output text")
        text = text.strip()
        if text.startswith("```"):
            text = text.split("\n", 1)[1].rsplit("```", 1)[0].strip()
        result = json.loads(text)
        if result.get("request_id") != request["request_id"]:
            raise ValueError("Teacher returned a stale request_id")
        return result
