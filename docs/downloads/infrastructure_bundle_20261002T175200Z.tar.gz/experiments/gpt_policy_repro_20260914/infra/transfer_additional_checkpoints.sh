#!/usr/bin/env bash
set -euo pipefail
cd /mnt/nas/data/lyf/agentic_robot
exec 9>experiments/gpt_policy_repro_20260914/mainskill/additional_checkpoints.lock
flock -n 9
for checkpoint in Cosmos3-Nano-Policy-DROID DreamZero-DROID; do
 python3 experiments/gpt_policy_repro_20260914/infra/transfer_checkpoint_chunks.py --checkpoint "$checkpoint"
done
