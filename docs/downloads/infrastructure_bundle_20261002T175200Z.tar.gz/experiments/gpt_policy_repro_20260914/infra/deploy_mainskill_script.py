"""Publish an owned infrastructure script by atomic rename, preserving live readers."""
import argparse
import base64
import hashlib
from pathlib import Path
import zlib
from transfer_checkpoint_chunks import remote

PUBLISH = '''import base64,hashlib,os,subprocess,sys,tempfile,zlib
from pathlib import Path
p=Path(sys.argv[1]);data=zlib.decompress(base64.b64decode(sys.argv[2]));assert hashlib.sha256(data).hexdigest()==sys.argv[3]
fd,name=tempfile.mkstemp(prefix=p.name+'.incoming-',dir=p.parent);t=Path(name)
try:
 with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
 if p.suffix=='.sh':subprocess.run(['bash','-n',str(t)],check=True)
 elif p.suffix=='.py':compile(data,str(p),'exec')
 else:raise ValueError('Only owned .sh/.py infrastructure scripts are supported')
 os.chmod(t,p.stat().st_mode&0o777 if p.exists() else 0o755)
 t.replace(p);print(sys.argv[3])
finally:
 if t.exists():t.unlink()
'''


def main():
    parser=argparse.ArgumentParser();parser.add_argument('name');args=parser.parse_args()
    assert Path(args.name).name==args.name
    path=Path(__file__).parent/args.name;data=path.read_bytes()
    encoded=base64.b64encode(zlib.compress(data)).decode();assert len(encoded)<64000
    target='/home/dataset-assist-0/liyufeng/agentic_robot/experiments/gpt_policy_repro_20260914/infra/'+args.name
    print(remote(PUBLISH,(target,encoded,hashlib.sha256(data).hexdigest())))


if __name__=='__main__':main()
