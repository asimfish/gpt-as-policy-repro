"""Pinned official RoboLab Pi05, localhost only, with checkpoint identity handshake."""
import argparse
import hashlib
import json
import logging
from pathlib import Path


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--checkpoint', type=Path, required=True)
    p.add_argument('--identity-output', type=Path, required=True)
    p.add_argument('--port', type=int, default=19510)
    a = p.parse_args()
    root = a.checkpoint.resolve()
    verification = json.loads((root / 'transfer_verification.json').read_text())
    manifest_hash = hashlib.sha256((root / 'download_manifest.json').read_bytes()).hexdigest()
    assert verification['verified'] is True and verification['files'] == 26
    assert verification['manifest_sha256'] == manifest_hash
    assert verification['source'] == 'gs://openpi-assets-simeval/pi05_droid_jointpos'
    from openpi.policies import policy_config
    from openpi.training import config
    from openpi.serving.websocket_policy_server import WebsocketPolicyServer
    cfg = config.get_config('pi05_droid_jointpos')
    assert cfg.model.action_horizon == 15
    policy = policy_config.create_trained_policy(cfg, str(root))
    identity = dict(config=cfg.name, action_horizon=15, checkpoint_manifest_sha256=manifest_hash,
                    checkpoint_source=verification['source'], checkpoint_path=str(root),
                    openpi_revision='aa64205615295931141608226e5ad155792b272f3')
    a.identity_output.parent.mkdir(parents=True, exist_ok=True)
    a.identity_output.write_text(json.dumps(identity, indent=2) + '\n')
    WebsocketPolicyServer(policy, host='127.0.0.1', port=a.port, metadata=identity).serve_forever()


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, force=True)
    main()
