"""Create frozen per-case inputs from the public five-per-task selection."""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--panel", type=Path, required=True)
    p.add_argument("--public-cases", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    panel = json.loads(args.panel.read_text())
    public = json.loads(args.public_cases.read_text())
    by_id = {c["case_id"]: c for c in panel["cases"]}
    args.output.mkdir(parents=True, exist_ok=True)
    selected = [c for c in public["cases"] if c["method"] in ("mix", "gpt")]
    for public_case in selected:
        case = by_id[public_case["case_id"]]
        identity = dict(panel_id=panel["panel_id"], panel_sha256=panel["panel_sha256"],
                        **{k: case[k] for k in ("case_id", "task", "runtime_task", "variant", "eval_seed", "layout_id", "reset_seed", "simulator_initial_seed", "policy_rng_seed")},
                        layout_sha256=case["layout"]["sha256"])
        payload = {"case": case, "identity": identity, "method": public_case["method"],
                   "public_case_id": public_case["id"]}
        (args.output / f"{public_case['id']}.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"files": len(selected), "output": str(args.output)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
