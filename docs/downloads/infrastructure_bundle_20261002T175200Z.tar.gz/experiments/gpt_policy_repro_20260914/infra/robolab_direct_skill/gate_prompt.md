Choose the next bounded EEF segment from the current observation and same-episode
feedback. Give a brief visible evidence and purpose in reason. Recompute from the
latest measured pose, retain uncertainty about unobserved contact, and check the
next actual observation. There is no student intent to assess or accept.
