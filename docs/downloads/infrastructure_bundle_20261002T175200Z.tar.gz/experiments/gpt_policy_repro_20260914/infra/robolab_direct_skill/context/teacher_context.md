The robot is a single DROID Panda arm with Robotiq gripper. EEF measurements and
targets refer to Robotiq base_link in robot-root coordinates, meters and wxyz.
The nominal open-pad center is base_position + R(base_quaternion) @ [0.1311,0,0].
Rotating the gripper also moves this offset point. This is nominal geometry, not
measured contact at arbitrary finger angles. Estimate object positions from the
allowed RGB observations and compare actual motion in both views.

Each native control is 1/15 second. Five controls are a third of a second toward
one fixed target. IK updates from fresh proprio after each physical ACK; a small
kinematic residual does not prove target arrival. Review edit_NNN.json diagnostics
and compare pre/post measured poses. Keep confirmed/retracted task progress and
remaining geometry in NOTES.md, with calculations and image crops in scratch/.

workspace.json gives exact interpreter, controller and history paths. The host
records observations/NNN, request_NNN.json, response_NNN.json, execution_NNN.npz,
edit_NNN.json, history.json and the native sensor video. No pi05 proposals exist.
The direct methods and original native control source are readable for interface
understanding, but do not inspect task ground-truth coordinates or scene state.
