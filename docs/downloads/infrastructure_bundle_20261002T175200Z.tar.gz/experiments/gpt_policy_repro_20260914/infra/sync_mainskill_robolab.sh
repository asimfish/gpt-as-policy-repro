#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../../.." && pwd)"
exec rsync -az --partial --timeout=600 --stats --exclude=.git --exclude=__pycache__ --exclude=.venv --exclude=docs --exclude=logs --exclude=outputs -e 'ssh -o BatchMode=yes -o UserKnownHostsFile=/home/liyufeng/.ssh/known_hosts_a100 -o StrictHostKeyChecking=yes -o ServerAliveInterval=60 -o ServerAliveCountMax=10' "$ROOT/upstream/RoboLab/" mainskill:/home/dataset-assist-0/liyufeng/agentic_robot/upstream/RoboLab/
