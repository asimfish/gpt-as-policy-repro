#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/env.sh"
export ROLLOUT_USE_CURRENT_CODEX_HOME=1
exec python3 "$(dirname "$0")/run_gpt_pair.py" "$@"
