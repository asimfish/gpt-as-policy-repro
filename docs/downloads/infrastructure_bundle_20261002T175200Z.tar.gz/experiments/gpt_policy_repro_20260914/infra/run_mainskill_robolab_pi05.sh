#!/usr/bin/env bash
set -euo pipefail
ROOT=/home/dataset-assist-0/liyufeng/agentic_robot
OUT="$ROOT/experiments/gpt_policy_repro_20260914/mainskill"
INFRA="$ROOT/experiments/gpt_policy_repro_20260914/infra"
mkdir -p "$OUT"
exec 9>"$OUT/pi05_validation.lock"
flock -n 9
# Prerequisites are verified by the bootstrap and transfer scripts.
for i in $(seq 1 2880); do
  if [[ -f "$OUT/openpi_environment.json" && -f "$ROOT/upstream/checkpoints/pi05_droid_jointpos/transfer_verification.json" ]]; then break; fi
  sleep 15
done
[[ -f "$OUT/openpi_environment.json" && -f "$ROOT/upstream/checkpoints/pi05_droid_jointpos/transfer_verification.json" ]]
free_mib=$(nvidia-smi --query-gpu=memory.free --format=csv,noheader,nounits -i 0)
[[ "$free_mib" -ge 50000 ]] || { echo 'GPU 0 requires 50 GiB free for this validation'; exit 1; }
export CUDA_VISIBLE_DEVICES=0 XLA_PYTHON_CLIENT_PREALLOCATE=false
export HTTPS_PROXY="${OPENPI_DOWNLOAD_PROXY:-http://127.0.0.1:18997}"
export HTTP_PROXY="$HTTPS_PROXY" NO_PROXY=127.0.0.1,localhost
export OPENPI_DATA_HOME="$ROOT/openpi-data"
export PYTHONPATH="$ROOT/upstream/openpi-robolab/src:$ROOT/upstream/openpi-robolab/packages/openpi-client/src"
setsid "$ROOT/venvs/openpi-robolab/bin/python" "$INFRA/serve_robolab_pi05.py" --checkpoint "$ROOT/upstream/checkpoints/pi05_droid_jointpos" --identity-output "$OUT/pi05_identity.json" > "$OUT/pi05_server.log" 2>&1 & policy_pid=$!
cleanup(){
  kill -TERM -- "-$policy_pid" 2>/dev/null || true
  for i in $(seq 1 10); do kill -0 "$policy_pid" 2>/dev/null || break; sleep 1; done
  kill -KILL -- "-$policy_pid" 2>/dev/null || true
  wait "$policy_pid" 2>/dev/null || true
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
for i in $(seq 1 900); do
  kill -0 "$policy_pid" 2>/dev/null || { tail -n 60 "$OUT/pi05_server.log"; exit 1; }
  if curl --silent --fail --max-time 1 http://127.0.0.1:19510/healthz >/dev/null; then break; fi
  sleep 1
done
curl --silent --fail --max-time 2 http://127.0.0.1:19510/healthz
ROBO_LAB_POLICY_PORT=19510 bash "$INFRA/run_mainskill_robolab_smoke.sh"
