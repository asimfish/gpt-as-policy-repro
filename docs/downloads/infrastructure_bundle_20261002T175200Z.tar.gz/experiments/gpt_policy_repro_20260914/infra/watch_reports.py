"""Periodically regenerate local reports while campaigns write immutable attempts."""
import argparse
from pathlib import Path
import subprocess
import sys
import time
p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('--interval',type=int,default=30)
a=p.parse_args()
while True:
    for script in ('build_reproduction_report.py','render_dashboard.py'):
        result=subprocess.run([sys.executable,str(Path(__file__).with_name(script)),str(a.root)],capture_output=True,text=True)
        if result.returncode:print(result.stderr,flush=True)
    time.sleep(a.interval)
