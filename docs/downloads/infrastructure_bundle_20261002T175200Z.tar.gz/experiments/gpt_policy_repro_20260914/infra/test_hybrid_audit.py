import json
from pathlib import Path
import tempfile
import unittest
import numpy as np
from audit_hybrid_actions import audit


def write(p, data):
    p.parent.mkdir(parents=True, exist_ok=True); p.write_text(json.dumps(data))


def fixture(root):
    out=root/'rollout';ws=out/'codex_workspace';native=root/'sim/episode'
    write(ws/'worker.json',dict(evaluation_method='pi05_plus_gpt',model='gpt-6-astra',
          reasoning_effort='xhigh',model_provider='openai',thread_id='thread'))
    write(out/'run.json',dict(teacher_model='gpt-6-astra',teacher_reasoning_effort='xhigh',initial_state_hash='fixture'))
    history=[];events=[]
    for i,mode in enumerate(['student','edit','eef']):
        response=dict(mode=mode,steps=1,request_id=f'request{i}',target={})
        request=dict(step_id=i,request_id=f'request{i}',prediction_id=f'prediction{i}',episode_id='episode')
        write(out/f'request_{i:03d}.json',request);write(out/f'response_{i:03d}.json',response)
        history.append(dict(decision=i,start_tick=i,end_tick=i+1,response=response,prediction_id=f'prediction{i}',executed_steps=1))
        args=dict(response=response)
        write(ws/f'call_{i:04d}_request.json',dict(tool='robodojo_execute',call_id=f'call{i}',arguments=args))
        write(ws/f'call_{i:04d}_result.json',dict(step_id=i+1))
        events.append(dict(method='item/tool/call',params=dict(tool='robodojo_execute',callId=f'call{i}',threadId='thread',arguments=args)))
        write(native/'codex_decisions'/f'{i:03d}.json',dict(response=response,step_id=i,prediction_id=f'prediction{i}',episode_id='episode'))
        action=np.full((1,14),i,dtype=np.float32)
        np.savez(out/f'execution_{i:03d}.npz',actions=action,states=action)
        np.savez(out/f'proposal_{i:03d}.npz',actions=np.zeros((50,14),dtype=np.float32))
        if mode!='student':write(out/f'edit_{i:03d}.json',[dict(valid=True,executed_action=action[0].tolist())])
        write(native/f'action_{i:06d}.json',dict(valid=True,step_id=i+1,source='student' if mode=='student' else 'gpt_eef',
              student_prediction_id=f'prediction{i}',teacher_request_id=f'request{i}',executed_action=action[0].tolist(),
              obs=dict(states=action[0].tolist()),terminated=i==2,truncated=False,success=i==2))
    write(out/'history.json',history)
    (ws/'rpc_out.jsonl').write_text(''.join(json.dumps(e)+'\n' for e in events))
    write(out/'result.json',dict(complete=True,success=True,student_steps=1,edited_steps=1,recovery_steps=1))
    write(root/'sim/evaluation_outcome.json',dict(complete=True,valid_for_success_rate=True,native_control_steps=3,native_success=True))


class HybridAuditTest(unittest.TestCase):
    def test_all_modes_and_complete_vs_prefix(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);fixture(root)
            self.assertFalse(audit(root,2)['complete_episode'])
            proof=audit(root);self.assertTrue(proof['complete_episode'])
            self.assertEqual(proof['actions_by_mode'],dict(student=1,edit=1,eef=1))

    def test_native_correction_corruption_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);fixture(root);p=root/'sim/episode/action_000001.json'
            d=json.loads(p.read_text());d['executed_action'][0]=9;write(p,d)
            with self.assertRaises(AssertionError):audit(root)

    def test_unrecorded_model_decision_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);fixture(root);p=root/'rollout/codex_workspace/rpc_out.jsonl'
            p.write_text(p.read_text().replace('"thread"','"wrong-thread"'))
            with self.assertRaises(AssertionError):audit(root)

    def test_missing_native_terminal_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);fixture(root);p=root/'sim/episode/action_000002.json'
            d=json.loads(p.read_text());d['terminated']=False;write(p,d)
            with self.assertRaises(AssertionError):audit(root)
