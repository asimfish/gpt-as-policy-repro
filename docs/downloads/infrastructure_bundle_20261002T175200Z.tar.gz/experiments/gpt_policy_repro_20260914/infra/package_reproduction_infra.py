"""Create a local, hash-verified handoff of experiment infrastructure and frozen inputs."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile
from datetime import datetime,timezone

ROOT=Path(__file__).resolve().parents[3]
ART=ROOT/'experiments/gpt_policy_repro_20260914'


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--date',default=datetime.now(timezone.utc).strftime('%Y%m%d'))
    args=parser.parse_args();assert re.fullmatch(r'20[0-9]{6}(?:T[0-9]{6}Z)?',args.date)
    files=[p for p in (ART/'infra').iterdir() if p.is_file() and p.suffix in {'.py','.sh','.txt','.json'}]
    files += list((ART/'infra/robolab_direct_skill').rglob('*.md'))
    files += [p for p in (ART/'fixtures').rglob('*') if p.is_file() and p.suffix in {'.json','.lock'}]
    files += [ART/name for name in ['GOAL.md','RUNBOOK.md','scope_matrix.md','baseline_protocol_audit.md','report_interpretation_zh.md','additional_baseline_sources.json','ROBOLAB_DIRECT_ADR.md','ROBOLAB_RPC_DIAGNOSIS.md','ROBOLAB_ARCHIVE_DIAGNOSIS.md','PROGRESS_20261002.md']]
    files += [p for p in (ART/'queue_scheduler_v5_manifest.json',ART/'robolab_queue_scheduler_v1_manifest.json') if p.exists()]
    payload={str(p.relative_to(ROOT)):p.read_bytes() for p in sorted(set(files))}
    # Installed unit environments are private machine configuration. Publish templates
    # with a user-owned, private EnvironmentFile rather than account paths or values.
    units=ART/'infra/report-progress-units'
    for path in sorted(units.glob('*')):
        lines=path.read_text().splitlines();had_environment=any(x.startswith('Environment=') for x in lines)
        data='\n'.join(x for x in lines if not x.startswith('Environment=') and not x.startswith('EnvironmentFile='))+'\n'
        if had_environment:data=data.replace('[Service]\n','[Service]\nEnvironmentFile=%h/.config/gpt-policy/runtime.env\n')
        data=data.replace(str(ROOT),'/absolute/path/to/agentic_robot')
        payload['unit_templates/'+path.name]=data.encode()
    payload['unit_templates/runtime.env.example']=b'CODEX_HOME=/absolute/path/to/existing/authorized/codex/home\nCODEX_BIN=/absolute/path/to/codex\nPATH=/absolute/path/to/node/bin:/usr/local/bin:/usr/bin:/bin\n# Optional: HTTP_PROXY, HTTPS_PROXY, ALL_PROXY. Never put auth.json in this bundle.\n'

    for name,data in payload.items():
        assert not re.search(rb'-----BEGIN (?:OPENSSH |RSA |EC )?PRIVATE KEY-----|github_pat_[A-Za-z0-9_]{30,}|ghp_[A-Za-z0-9]{30,}',data),name
    patch=subprocess.check_output(['git','-C',str(ROOT/'gpt-as-policy'),'diff','--','hybrid_rollout/robolab/robolab_server/scene_recording.py','hybrid_rollout/robolab/robolab_server/server.py','hybrid_rollout/robolab/robolab_server/session.py'])
    payload['source_patches/gpt-as-policy.patch']=patch
    payload['REPRODUCTION_BUNDLE.md']='''# 复现实验基建快照

包含运行脚本、调度器、逐步动作审计、回归测试、冻结案例与依赖锁、报告解读、运行手册和 GPT-as-Policy 源码补丁。按归档中的相对路径解压到工作区；先按 RUNBOOK.md 准备固定版本上游仓库与环境，再应用源码补丁。

运行入口：experiments/gpt_policy_repro_20260914/RUNBOOK.md。

环境配置保留本项目工作区与 mainskill 部署路径；迁移到其他机器时需调整 infra/env.sh 和部署脚本中的根路径、Python 路径及 SSH alias。模型权重、大型资产、SSH 密钥、API 凭据不在包内，下载清单和校验逻辑保留。用户已授权复用现有 Codex CLI 登录态：配置 CODEX_HOME/CODEX_BIN 与 ROLLOUT_USE_CURRENT_CODEX_HOME=1，由 CLI 自身读取认证，禁止复制或公开 auth.json。unit_templates 提供去掉私有环境的 systemd 模板，runtime.env 由部署者自行在本机以0600权限创建。此包是可审阅的基建快照，不表示全量实验已经完成。

当前有效范围只包含 GPT Direct 与 π0.5 + GPT Hybrid。遗留基线辅助脚本仅用于追溯，不应据此启动额外方法。RoboLab Direct 是本项目 EEF 适配器，历史实现未公开；当前完整结果、验证门和队列状态见GOAL.md。SSH传输缓解、只读归档补传及完整审计说明均在包内，前缀或连接中断不得计入完整成绩。\n\nmanifest.json 给出每个文件的 SHA256 与固定源码提交（包括在线报告源码版本）。大型实验轨迹和在线站点源码留在工作区及报告 GitHub 仓库。
'''.encode()
    pins={name:subprocess.check_output(['git','-C',str(ROOT/path),'rev-parse','HEAD'],text=True).strip() for name,path in {'gpt-as-policy':'gpt-as-policy','RoboDojo':'upstream/RoboDojo','RoboLab':'upstream/RoboLab','openpi-robolab':'upstream/openpi-robolab','cosmos-framework':'upstream/cosmos-framework','dreamzero':'upstream/dreamzero','report_site':'gpt-policy-report-site'}.items()}
    manifest=dict(active_methods=['gpt_only','pi05_plus_gpt'],full_reproduction_complete=False,created_utc=datetime.now(timezone.utc).isoformat(),source_commits=pins,files=[dict(path=k,size=len(v),sha256=hashlib.sha256(v).hexdigest()) for k,v in payload.items()])
    payload['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
    out=ART/'deliverables';out.mkdir(exist_ok=True);archive=out/('infrastructure_bundle_'+args.date+'.tar.gz')
    assert not archive.exists(),'A dated bundle is immutable; choose a fresh date/snapshot name'
    with tarfile.open(archive,'w:gz') as tar:
        for name,data in payload.items():
            info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o755 if name.endswith('.sh') else 0o644;tar.addfile(info,io.BytesIO(data))
    with tarfile.open(archive) as tar:
        for row in manifest['files']:
            data=tar.extractfile(row['path']).read();assert len(data)==row['size'] and hashlib.sha256(data).hexdigest()==row['sha256']
    result=dict(path=str(archive.relative_to(ART)),files=len(manifest['files']),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),contents_verified=True)
    receipt=out/'infrastructure_bundle_verification.json';temporary=receipt.with_suffix('.tmp')
    temporary.write_text(json.dumps(result,indent=2)+'\n');temporary.replace(receipt);print(json.dumps(result))


if __name__=='__main__':main()
