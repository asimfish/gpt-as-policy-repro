#!/usr/bin/env bash
set -euo pipefail
export XDG_RUNTIME_DIR=/run/user/1007 DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/1007/bus
failures=0
while true; do
 if timeout 30 ssh -o BatchMode=yes -o ConnectTimeout=10 -o UserKnownHostsFile=/home/liyufeng/.ssh/known_hosts_a100 -o StrictHostKeyChecking=yes mainskill 'curl -fsSI --max-time 12 --proxy http://127.0.0.1:18997 https://pypi.org/simple/ >/dev/null'; then
  failures=0
 else
  failures=$((failures+1))
  echo "$(date -u +%FT%TZ) proxy_health_failure=$failures"
  if [[ "$failures" -ge 2 ]]; then
   systemctl --user restart gpt-policy-mainskill-download-tunnel.service
   echo "$(date -u +%FT%TZ) restarted_owned_download_tunnel"
   failures=0
  fi
 fi
 sleep 30
done
