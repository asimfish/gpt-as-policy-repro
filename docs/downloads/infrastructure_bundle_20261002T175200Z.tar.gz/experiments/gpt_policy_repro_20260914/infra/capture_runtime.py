"""Record code, dependency and hardware identities, without environment secrets."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
p=argparse.ArgumentParser();p.add_argument('output',type=Path);a=p.parse_args()
root=Path(os.environ['REPRO_ROOT'])
def command(argv):
    result=subprocess.run(argv,capture_output=True,text=True,timeout=60)
    return dict(returncode=result.returncode,stdout=result.stdout.strip(),stderr=result.stderr.strip())
report={'created_utc':datetime.now(timezone.utc).isoformat(),'repositories':{},'python_environments':{}}
for repo in ('gpt-as-policy','upstream/RoboDojo','upstream/RoboLab','upstream/openpi-robolab'):
    report['repositories'][repo]=command(['git','-C',str(root/repo),'rev-parse','HEAD'])
for name in ('ROBO_PYTHON','OPENPI_PYTHON'):
    code='import importlib.metadata as m,json,sys; print(json.dumps({"python":sys.version,"packages":sorted([(d.metadata["Name"],d.version) for d in m.distributions() if d.metadata["Name"]])}))'
    env=dict(os.environ)
    if name=='OPENPI_PYTHON': env.pop('PYTHONPATH',None)
    result=subprocess.run([os.environ[name],'-c',code],capture_output=True,text=True,env=env,timeout=60)
    report['python_environments'][name]={'executable':os.environ[name],'inventory':json.loads(result.stdout) if result.returncode==0 else {'error':result.stderr}}
report['gpu']=command(['nvidia-smi','--query-gpu=index,name,uuid,driver_version,memory.total','--format=csv'])
report['infrastructure_sha256']={path.name:hashlib.sha256(path.read_bytes()).hexdigest() for path in Path(__file__).parent.iterdir() if path.is_file()}
report['codex_version']=command(['codex','--version'])
a.output.write_text(json.dumps(report,indent=2)+'\n')
print(a.output)
