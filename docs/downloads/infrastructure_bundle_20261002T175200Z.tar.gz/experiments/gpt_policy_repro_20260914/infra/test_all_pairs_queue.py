"""Queue regressions: audited native failure is terminal; partial evidence is not."""
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import run_all_gpt_pairs as queue


class QueueTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.parent = Path(self.temp.name) / 'run'
        self.run = self.parent / 'gpt_only'
        self.cases = Path(self.temp.name) / 'cases'
        self.cases.mkdir()
        self.identity = {'case_id': 'case', 'layout_sha256': 'a'*64}
        self.write(self.cases/'gpt__case.json', {'identity': self.identity})
        self.write(self.run/'rollout/result.json', dict(complete=True, success=False, terminated=False,
                   truncated=True, step_id=3, decisions=1, evaluation_case=self.identity))
        self.write(self.run/'sim/evaluation_outcome.json', dict(complete=True, valid_for_success_rate=True,
                   native_success=False, native_score=0, native_control_steps=3, evaluation_case=self.identity))
        for name in ('rollout/run.json', 'rollout/codex_workspace/worker.json'):
            self.write(self.run/name, {'model': 'gpt-6-astra'})
        self.proof = dict(verified=True, complete_episode=True, scope='complete_native_episode',
             model='gpt-6-astra', reasoning_effort='xhigh', native_actions=3, decisions=1,
             pi05_inference_calls=0, max_absolute_action_error=0,
             files_sha256={name: hashlib.sha256((self.run/name).read_bytes()).hexdigest() for name in
              ('rollout/result.json', 'sim/evaluation_outcome.json', 'rollout/run.json', 'rollout/codex_workspace/worker.json')})

    def write(self, path, value):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(value))

    def terminal(self):
        with patch.object(queue, 'CASES', self.cases):
            return queue.terminal(self.parent, 'gpt_only')

    def test_native_terminal_without_complete_audit_stays_open(self):
        self.assertTrue(queue.native_terminal(self.parent, 'gpt_only'))
        self.assertFalse(self.terminal())

    def test_native_failure_with_complete_audit_closes_job(self):
        self.write(self.run/'complete_action_audit.json', self.proof)
        self.assertTrue(self.terminal())

    def test_prefix_audit_cannot_close_campaign_job(self):
        self.proof['complete_episode'] = False
        self.write(self.run/'complete_action_audit.json', self.proof)
        self.assertFalse(self.terminal())

    def test_changed_model_identity_reopens_job(self):
        self.write(self.run/'complete_action_audit.json', self.proof)
        self.write(self.run/'rollout/codex_workspace/worker.json', {'model': 'changed'})
        self.assertFalse(self.terminal())

    def test_one_case_retries_do_not_starve_untried_case(self):
        self.assertEqual(queue.choose_next([('broken', 'pi05_plus_gpt', 49), ('new', 'gpt_only', 0)]), ('new', 'gpt_only'))

    def test_equal_retry_counts_preserve_frozen_case_order(self):
        self.assertEqual(queue.choose_next([('a', 'gpt_only', 0), ('a', 'pi05_plus_gpt', 0)]), ('a', 'gpt_only'))


if __name__ == '__main__':
    unittest.main()
