"""Direct observation-to-EEF adapter, reusing the unchanged RoboLab low-level RPC contract."""
import time
import uuid
import numpy as np

from hybrid_rollout.robolab.io import InputError,write_json
from hybrid_rollout.robolab.settings import MODEL,EFFORT
from hybrid_rollout.robolab.robolab_server.client import RolloutTools
from hybrid_rollout.robolab.robolab_server.validation import validate_response


def validate_direct(response,request):
    if not isinstance(response,dict) or set(response)!={'request_id','mode','steps','reason','target'}:
        raise ValueError('Direct response requires request_id/mode/steps/reason/target only')
    if response['mode']!='eef':
        raise ValueError('Direct permits bounded EEF actions only')
    if set(response['target'])!={'position','quaternion_wxyz','gripper_closed'}:
        raise ValueError('Explicit position, wxyz quaternion and boolean gripper required')
    validate_response(response,request)


class DirectTools(RolloutTools):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,student=None,**kwargs)
        self.source='gpt_eef'
        self.counters.update(gpt_eef_steps=0)

    def next_call(self):
        if self.phase=='start':
            return super().next_call()
        if self.phase=='execute':
            return dict(tool='robolab_execute',observation_path=str(self.observation_path),
                output_dir=str(self.output/'observations'/f'{len(self.history)+1:03d}'),
                response='Choose 1..5 bounded EEF controls from the current observation')
        return None

    def infer(self,**_):
        raise InputError('pi05 is not available in Direct')

    def _observation(self,directory,*,result=None):
        packet=super()._observation(directory,result=result)
        packet['evaluation_method']='gpt_only'
        if self.phase!='done':
            self.request=dict(packet,request_id=uuid.uuid4().hex,decision=len(self.history),
                prediction_id=None,gate_policy='gpt_only')
            packet['request_id']=self.request['request_id']
            write_json(self.output/f'request_{len(self.history):03d}.json',self.request)
        write_json(self.observation_path,packet)
        return packet

    def start(self,**arguments):
        directory=self._check('robolab_start',arguments)
        self.sim=self.rpc_factory('127.0.0.1',self.sim_port,timeout=600)
        self.meta=self.sim.request('metadata')
        if self.meta['task']!=self.task or self.meta.get('supports_direct') is not True:
            raise RuntimeError('Identified Direct simulator with the requested task required')
        if not 0 < self.meta['max_episode_steps'] < self.max_decisions:
            raise RuntimeError('Decision budget must exceed the native control horizon')
        reset=self.sim.request('reset',seed=self.seed,source='diagnostic_hold',policy_version='gpt_only')
        self.episode,self.tick=reset['episode_id'],reset['step_id']
        self._rpc('begin_direct',teacher_model=MODEL,prompt_sha256=self.prompt_sha256)
        self.run=dict(schema='gpt_policy_robolab_direct.run.v1',evaluation_method='gpt_only',
            implementation='owned_EEF_adapter_on_upstream_RoboLab',teacher='codex_tools',
            teacher_model=MODEL,teacher_reasoning_effort=EFFORT,task=self.task,
            instruction=self.meta['instruction'],seed=self.seed,pi05_enabled=False,pi05_inference_calls=0,
            checkpoint=None,student_backend=None,student_identity_sha256=None,no_rollback=True,
            action_horizon=5,action_dim=8,action_space='eef_only',gate_policy='gpt_only',
            teacher_prompt_sha256=self.prompt_sha256,initial_state_hash=reset['initial_state_hash'],
            reset_metadata=reset.get('metadata'),max_episode_steps=self.meta['max_episode_steps'],
            control_dt=self.meta['control_dt'],max_decisions=self.max_decisions,
            historical_Direct_source_and_prompt_recovered=False,training_steps=0)
        write_json(self.output/'run.json',self.run)
        write_json(self.output/'history.json',self.history)
        self.phase='execute'
        return self._observation(directory)

    def execute(self,**arguments):
        directory=self._check('robolab_execute',arguments)
        response=arguments.get('response')
        try:
            validate_direct(response,self.request)
        except (ValueError,TypeError,KeyError,AttributeError) as error:
            raise InputError(str(error)) from error
        decision=len(self.history)
        write_json(self.output/f'response_{decision:03d}.json',response)
        receipt=self._rpc('record_codex_decision',decision=decision,prediction_id=None,response=response)
        start_tick=self.tick
        trace=[]
        for _ in range(response['steps']):
            target=response['target']
            proposal=self._rpc('eef_joint_target',position=target['position'],
                quaternion_wxyz=target['quaternion_wxyz'],gripper_closed=target['gripper_closed'])
            result=self._rpc('chunk_step',actions=np.asarray([proposal['action']],np.float32),
                teacher_request_id=self.request['request_id'])
            for row in result['steps']:
                row['edited_target'],row['ik_diagnostics']=target,proposal['diagnostics']
            trace.extend(result['steps']);self.tick=result['step_id']
            if any(row['terminated'] or row['truncated'] for row in result['steps']):
                break
        valid=[row for row in trace if row['valid']]
        n=len(valid)
        self.counters['gpt_eef_steps']+=n
        actions=np.asarray([row['executed_action'] for row in valid],np.float32).reshape(-1,8)
        states=np.asarray([row['obs']['states'] for row in valid],np.float32).reshape(-1,8)
        np.savez_compressed(self.output/f'execution_{decision:03d}.npz',actions=actions,states=states)
        write_json(self.output/f'edit_{decision:03d}.json',[dict(target=row['edited_target'],
            diagnostics=row['ik_diagnostics'],valid=row['valid'],executed_action=np.asarray(row['executed_action']).tolist()) for row in trace])
        done=bool(valid and (valid[-1]['terminated'] or valid[-1]['truncated']))
        self.history.append(dict(decision=decision,start_tick=start_tick,end_tick=self.tick,response=response,
            simulator_decision_receipt=receipt,executed_steps=n,source='gpt_eef',source_detail='eef',
            prediction_id=None,terminal=done,native_success=bool(valid and valid[-1]['success'])))
        write_json(self.output/'history.json',self.history)
        write_json(self.output/'progress.json',dict(episode_id=self.episode,step_id=self.tick,**self.counters))
        final=self.finish('terminal') if done else None
        return self._observation(directory,result=final)

    def finish(self,reason):
        result=self._rpc('finish_pilot',reason=reason)
        self.phase='done'
        result.update(self.counters,decisions=len(self.history),pi05_inference_calls=0,
            evaluation_method='gpt_only',complete=bool(result['terminated'] or result['truncated']),
            wall_seconds=time.monotonic()-self.started)
        write_json(self.output/'result.json',result)
        return result

    def close(self):
        if self.sim is not None:
            self.sim.close()
        # The original debug compositor requires pi05 proposals. Direct uses native
        # sensors.mp4 and its decision/EEF evidence; never manufacture proposals for it.
