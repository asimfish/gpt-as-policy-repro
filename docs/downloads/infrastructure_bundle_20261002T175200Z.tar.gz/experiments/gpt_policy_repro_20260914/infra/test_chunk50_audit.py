import json
from pathlib import Path
import tempfile
import unittest
import numpy as np
from audit_chunk50_actions import audit

class ActionAuditTest(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.native=self.root/'sim/episode';self.native.mkdir(parents=True)
        pred=self.root/'rollout/predictions/00000';pred.mkdir(parents=True)
        self.actions=np.arange(700,dtype=np.float32).reshape(50,14)
        np.savez(pred/'prediction.npz',actions=self.actions)
        (pred/'execution.json').write_text(json.dumps(dict(prediction_id='p',executed_steps=17,end_tick=17)))
        for i in range(17):
            (self.native/f'action_{i:06d}.json').write_text(json.dumps(dict(valid=True,step_id=i+1,student_prediction_id='p',prediction_offset=i//15*15,executed_action=self.actions[i].tolist(),terminated=i==16,truncated=False)))
        (self.root/'rollout/result.json').write_text(json.dumps(dict(complete=True,student_steps=17)))
    def test_native_early_terminal_is_valid(self):
        self.assertEqual(audit(self.root)['native_actions'],17)
    def test_one_corrupted_action_is_rejected(self):
        p=self.native/'action_000012.json';row=json.loads(p.read_text());row['executed_action'][3]+=1;p.write_text(json.dumps(row))
        with self.assertRaisesRegex(AssertionError,'Executed action mismatch'):audit(self.root)
    def test_reordered_prediction_identity_is_rejected(self):
        p=self.native/'action_000015.json';row=json.loads(p.read_text());row['student_prediction_id']='another';p.write_text(json.dumps(row))
        with self.assertRaisesRegex(AssertionError,'Prediction identity mismatch'):audit(self.root)
if __name__=='__main__':unittest.main()
