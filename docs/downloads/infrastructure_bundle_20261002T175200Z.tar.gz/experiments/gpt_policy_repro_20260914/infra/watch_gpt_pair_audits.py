"""Audit completed attempts; Direct remains a prefix claim pending terminal audit."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import time
from audit_gpt_direct_prefix import audit as direct_audit
from audit_gpt_direct_complete import audit as direct_complete_audit
from audit_hybrid_actions import audit as hybrid_audit


def audit_stopped(run):
    history_path=run/'rollout/history.json'
    history=json.loads(history_path.read_text()) if history_path.exists() else []
    if not history:
        return dict(verified=False,complete_episode=False,reason='No completed decisions')
    result_path=run/'rollout/result.json'
    result=json.loads(result_path.read_text()) if result_path.exists() else {}
    complete=result.get('complete') is True and (result.get('terminated') or result.get('truncated'))
    if run.name=='gpt_only':
        return direct_complete_audit(run) if complete else direct_audit(run,len(history))
    return hybrid_audit(run,None if complete else len(history))


def main():
    p=argparse.ArgumentParser();p.add_argument('pair',type=Path);a=p.parse_args()
    deadline=time.monotonic()+25*3600;done=set()
    while time.monotonic()<deadline:
        for method in ('gpt_only','pi05_plus_gpt'):
            if method in done:continue
            run=a.pair/method;attempt_path=run/'attempt.json'
            if not attempt_path.exists():continue
            attempt=json.loads(attempt_path.read_text())
            if attempt['status'] in ('starting','running'):continue
            proof=audit_stopped(run)
            target=run/('complete_action_audit.json' if proof['complete_episode'] else 'stopped_action_prefix_audit.json')
            temp=target.with_suffix('.tmp');temp.write_text(json.dumps(proof,indent=2)+'\n');temp.replace(target)
            print(json.dumps(dict(method=method,observed_utc=datetime.now(timezone.utc).isoformat(),**{k:v for k,v in proof.items() if k not in ('files_sha256','model_tool_event_sha256')})),flush=True)
            done.add(method)
            if attempt['status']!='complete':return  # Supervisor stops this pair on failure.
        if len(done)==2:return
        time.sleep(20)
    raise TimeoutError('Pair audit watcher exceeded 25 hours')


if __name__=='__main__':main()
