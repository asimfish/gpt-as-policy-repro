"""Observe native RPC byte boundaries and kernel state; never inspect packet contents."""
from datetime import datetime,timezone
import json
import socket
import time
from hybrid_rollout.robolab.robolab_server.protocol import RPCClient


class ObservedSocket:
    def __init__(self,sock,emit):self.sock=sock;self.emit=emit
    def __getattr__(self,name):return getattr(self.sock,name)
    def kernel(self):
        return dict(fd=self.sock.fileno(),local=self.sock.getsockname(),peer=self.sock.getpeername(),
            tcp_info_hex=self.sock.getsockopt(socket.IPPROTO_TCP,socket.TCP_INFO,104).hex())
    def sendall(self,value,*args,**kwargs):
        self.emit('send_start',bytes=len(value),**self.kernel())
        result=self.sock.sendall(value,*args,**kwargs)
        self.emit('send_done',bytes=len(value),**self.kernel())
        return result
    def recv(self,count,*args,**kwargs):
        self.emit('receive_start',requested_bytes=count,**self.kernel())
        result=self.sock.recv(count,*args,**kwargs)
        self.emit('receive_done',received_bytes=len(result),**self.kernel())
        return result


def trace_factory(path):
    def create(host,port,timeout):
        current={'op':None}
        def emit(event,**values):
            with path.open('a') as stream:
                stream.write(json.dumps(dict(event=event,op=current['op'],monotonic=time.monotonic(),
                    utc=datetime.now(timezone.utc).isoformat(),**values))+'\n')
        class ObservedClient(RPCClient):
            def request(self,op,**kwargs):
                current['op']=op;emit('request_start')
                try:
                    result=super().request(op,**kwargs)
                except BaseException as error:
                    emit('request_error',error_type=type(error).__name__);raise
                emit('request_done');return result
        client=ObservedClient(host,port,timeout=timeout)
        client.sock=ObservedSocket(client.sock,emit)
        return client
    return create
