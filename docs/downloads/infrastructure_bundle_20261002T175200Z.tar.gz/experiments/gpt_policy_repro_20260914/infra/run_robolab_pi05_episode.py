"""One native-horizon RoboLab Pi05 episode with per-query evidence."""
import argparse
import hashlib
import json
import time
from pathlib import Path

import numpy as np


def policy_request(obs):
    state = np.asarray(obs['states'], dtype=np.float32)
    assert state.shape == (8,) and np.isfinite(state).all()
    return {'observation/exterior_image_1_left': obs['main_images'],
            'observation/wrist_image_left': obs['wrist_images'],
            'observation/joint_position': state[:7],
            'observation/gripper_position': state[7:], 'prompt': obs['task_description']}


def checked_actions(response):
    actions = np.asarray(response['actions'], dtype=np.float32)
    if actions.shape != (15, 8) or not np.isfinite(actions).all():
        raise ValueError(f'Expected finite official 15x8 output, got {actions.shape}')
    executed = actions.copy()
    executed[:, -1] = (executed[:, -1] > .5).astype(np.float32)
    return actions, executed


def main():
    from hybrid_rollout.robolab.robolab_server.protocol import RPCClient
    from openpi_client.websocket_client_policy import WebsocketClientPolicy
    p = argparse.ArgumentParser()
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--port', type=int, default=19500)
    p.add_argument('--policy-port', type=int, default=19510)
    p.add_argument('--seed', type=int, default=0)
    p.add_argument('--task', default='BlocksInBinTask')
    a = p.parse_args()
    a.output.mkdir(parents=True, exist_ok=False)
    policy = WebsocketClientPolicy('127.0.0.1', a.policy_port)
    policy._ws.ping_timeout = None  # First JAX compilation can exceed the client's default timeout.
    identity = policy.get_server_metadata()
    assert identity['config'] == 'pi05_droid_jointpos' and identity['action_horizon'] == 15
    (a.output / 'policy_identity.json').write_text(json.dumps(identity, indent=2) + '\n')
    # Fresh reset, not a paper paired-state replay; keep separate from formal benchmark table.
    (a.output / 'reproduction.json').write_text(json.dumps(dict(method='robolab_pi05_native15_fresh',
        controller='official_openpi_pi05', teacher_invoked=False, benchmark_eligible=False,
        exclusion_reason='fresh reset; formal paired-state protocol not yet verified'), indent=2) + '\n')
    (a.output / 'run.json').write_text(json.dumps(dict(task=a.task, seed=a.seed), indent=2) + '\n')
    sim = RPCClient('127.0.0.1', a.port, timeout=600)
    try:
        meta = sim.request('metadata')
        assert meta['task'] == a.task
        reset = sim.request('reset', seed=a.seed, source='student',
                            policy_version=identity['checkpoint_manifest_sha256'])
        (a.output / 'reset_metadata.json').write_text(json.dumps(reset['metadata'], indent=2) + '\n')
        episode, step, obs = reset['episode_id'], 0, reset['obs']
        native = None
        for query in range(int(meta['max_episode_steps']) + 1):
            request = policy_request(obs)
            start = time.monotonic()
            response = policy.infer(request)
            actions, executed = checked_actions(response)
            query_dir = a.output / 'queries' / f'{query:05d}'
            query_dir.mkdir(parents=True)
            np.savez_compressed(query_dir / 'prediction.npz', proposed=actions, executed=executed,
                                main_images=obs['main_images'], wrist_images=obs['wrist_images'], states=obs['states'])
            ack = sim.request('chunk_step', episode_id=episode, step_id=step, actions=executed)
            valid = [row for row in ack['steps'] if row['valid']]
            if not valid or ack['step_id'] != step + len(valid):
                raise RuntimeError('Native step accounting mismatch')
            step = ack['step_id']
            native = valid[-1]
            obs = native['obs']
            row = dict(query=query, step_id=step, valid_steps=len(valid),
                       wall_seconds=time.monotonic()-start, success=bool(native['success']),
                       terminated=bool(native['terminated']), truncated=bool(native['truncated']),
                       prediction_sha256=hashlib.sha256((query_dir/'prediction.npz').read_bytes()).hexdigest())
            (query_dir / 'ack.json').write_text(json.dumps(row, indent=2) + '\n')
            print(json.dumps(row), flush=True)
            if native['terminated'] or native['truncated']:
                break
        if native is None or not (native['terminated'] or native['truncated']):
            raise RuntimeError('No native terminal result')
        finished = sim.request('finish_pilot', episode_id=episode, step_id=step, reason='native_terminal')
        result = dict(complete=True, success=bool(finished['success']), control_steps=step,
                      terminated=finished['terminated'], truncated=finished['truncated'],
                      native=finished, benchmark_eligible=False)
        (a.output / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    finally:
        sim.close()


if __name__ == '__main__':
    main()
