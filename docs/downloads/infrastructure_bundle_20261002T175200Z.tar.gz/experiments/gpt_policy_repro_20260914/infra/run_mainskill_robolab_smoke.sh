#!/usr/bin/env bash
set -euo pipefail
# Run on mainskill after the pinned RoboLab dependency/asset sync.
ROOT=/home/dataset-assist-0/liyufeng/agentic_robot
RUNTIME=/home/batchcom/gpt-policy-runtime
export ROBO_LAB_ROOT="${ROBO_LAB_ROOT:-$RUNTIME/RoboLab-ad45d4f974725d020f82c2b0d77d78533aeba2b3}"
export ROBO_LAB_TASK="${ROBO_LAB_TASK:-BlocksInBinTask}" ROBO_LAB_SEED="${ROBO_LAB_SEED:-0}"
if [[ -z "${ROBO_LAB_TASK_FILE:-}" ]]; then
 task_relative=$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["tasks"][sys.argv[2]])' "$ROOT/experiments/gpt_policy_repro_20260914/fixtures/robolab_task_files.json" "$ROBO_LAB_TASK")
 export ROBO_LAB_TASK_FILE="$ROBO_LAB_ROOT/$task_relative"
fi
export ROBO_LAB_PYTHON="$RUNTIME/robolab51/bin/python"
export CUDA_VISIBLE_DEVICES="${ROBO_LAB_GPU:-0}" SIM_GPU="${ROBO_LAB_GPU:-0}"
export CUDA_MPS_PIPE_DIRECTORY="/tmp/gpt-policy-no-mps-$$"
export VK_ICD_FILENAMES=/etc/vulkan/icd.d/nvidia_icd.json
export XDG_RUNTIME_DIR="$RUNTIME/xdg/runtime"
export XDG_CACHE_HOME="$RUNTIME/xdg/cache"
export XDG_DATA_HOME="$RUNTIME/xdg/data"
export XDG_CONFIG_HOME="$RUNTIME/xdg/config"
export MPLCONFIGDIR="$RUNTIME/matplotlib"
export OMNI_KIT_ACCEPT_EULA=Y
mkdir -p "$XDG_RUNTIME_DIR" "$XDG_CACHE_HOME" "$XDG_DATA_HOME" "$XDG_CONFIG_HOME" "$MPLCONFIGDIR"
chmod 700 "$XDG_RUNTIME_DIR"
campaign=mainskill_robolab_smoke
if [[ -n "${ROBO_LAB_POLICY_PORT:-}" ]]; then
 campaign=mainskill_robolab_pi05
 export ROBO_LAB_RECORD_SCENE_STATE="${ROBO_LAB_RECORD_SCENE_STATE:-1}"
fi
campaign="${ROBO_LAB_CAMPAIGN:-$campaign}"
output="$ROOT/experiments/gpt_policy_repro_20260914/$campaign/$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$output"
nvidia-smi --query-gpu=index,name,uuid,driver_version,memory.free --format=csv > "$output/gpu_before.csv"
exec bash "$ROOT/experiments/gpt_policy_repro_20260914/infra/run_robolab_smoke.sh" "$output" "${ROBO_LAB_SIM_PORT:-19500}"
