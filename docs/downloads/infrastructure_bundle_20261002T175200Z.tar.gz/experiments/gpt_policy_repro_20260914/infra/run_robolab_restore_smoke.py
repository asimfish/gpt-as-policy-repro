"""Verify recorded initial-state restoration without policy or physical control steps."""
import argparse,json
from pathlib import Path
import numpy as np
from PIL import Image
from hybrid_rollout.robolab.robolab_server.protocol import RPCClient
from hybrid_rollout.robolab.robolab_server.scene_recording import load_snapshot,compare_snapshots

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--port',type=int,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
 (a.output/'reproduction.json').write_text(json.dumps(dict(method='robolab_initial_state_restore_smoke',benchmark_eligible=False,controller='none',teacher_invoked=False),indent=2)+'\n')
 (a.output/'run.json').write_text(json.dumps(dict(task='BlocksInBinTask',scope='initial physical state restoration only'),indent=2)+'\n')
 sim=RPCClient('127.0.0.1',a.port,timeout=600)
 try:
  assert sim.request('metadata')['scene_recording']
  first=sim.request('reset',seed=0,source='student',policy_version='infrastructure-restore-smoke',fixture_id='blocks-debug-seed0',split='debug')
  def save(reset,label):
   assert reset['step_id']==0
   obs=sim.request('teacher_observation',episode_id=reset['episode_id'],step_id=0)
   folder=a.output/label;folder.mkdir()
   (folder/'reset.json').write_text(json.dumps({k:v for k,v in reset.items() if k!='obs'},indent=2)+'\n')
   for name in ('main_rgb','wrist_rgb'):
    arr=np.asarray(obs[name]);assert arr.ndim==3 and arr.std()>2;Image.fromarray(arr).save(folder/(name+'.png'))
   return load_snapshot(a.output.parent/'sim'/reset['episode_id']/'initial_scene.json')
  initial=save(first,'initial')
  second=sim.request('reset',seed=1,source='student',policy_version='infrastructure-restore-smoke',initial_state_id=first['episode_id'])
  restored=save(second,'restored');comparison=compare_snapshots(initial,restored)
  assert comparison['passed'],comparison
  assert second['metadata']['reset_mode']=='recorded_initial'
  sim.request('finish_pilot',episode_id=second['episode_id'],step_id=0,reason='initial_state_restore_smoke')
  result=dict(verified=True,complete=False,benchmark_eligible=False,native_controls_executed=0,first_episode=first['episode_id'],restored_episode=second['episode_id'],initial_state_sha256=initial['state_sha256'],restored_state_sha256=restored['state_sha256'],physical_comparison=comparison,rng_restored=False,future_trajectory_determinism_validated=False)
  (a.output/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='physical_comparison'}))
 finally:sim.close()
if __name__=='__main__':main()
