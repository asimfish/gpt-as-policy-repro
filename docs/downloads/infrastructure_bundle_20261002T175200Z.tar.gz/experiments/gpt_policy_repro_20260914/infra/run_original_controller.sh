#!/usr/bin/env bash
# Launch the unchanged upstream persistent Codex controller against ready services.
set -euo pipefail
source "$(dirname "$0")/env.sh"
method="${1:?pi05_plus_gpt or gpt_only required}"
output="${2:?fresh output path required}"
task="${3:?runtime task required}"
case "${method}" in pi05_plus_gpt|gpt_only) ;; *) echo 'Unknown evaluation method' >&2; exit 2;; esac
if [[ "${ROLLOUT_USE_CURRENT_CODEX_HOME:-0}" == 1 ]]; then
  # User explicitly authorized the current CLI login on 2026-09-16.
  # Authentication stays inside Codex; credentials are never copied or printed.
  export CODEX_HOME="${CODEX_HOME:-$HOME/.codex}"
  export ROLLOUT_AUTH_PROFILE=codex_a  # Upstream routing label: provider=openai.
else
  : "${ROLLOUT_ISOLATED_CODEX_HOME:?Select an experiment home or authorize current CLI use}"
  : "${ROLLOUT_AUTH_PROFILE:?Select upstream profile matching the isolated config}"
  if [[ "$(realpath "$ROLLOUT_ISOLATED_CODEX_HOME")" == "$(realpath "$HOME/.codex")" ]]; then
    echo 'Current home requires explicit ROLLOUT_USE_CURRENT_CODEX_HOME=1' >&2; exit 2
  fi
  export CODEX_HOME="$ROLLOUT_ISOLATED_CODEX_HOME"
fi
[[ -f "$CODEX_HOME/config.toml" ]] || { echo 'Selected config.toml is missing' >&2; exit 2; }
if [[ -e "$output" ]]; then echo 'Output already exists; use a fresh attempt directory' >&2; exit 2; fi
codex_bin="${CODEX_BIN:-$(command -v codex)}"
# Codex SQLite state must live on a local filesystem: this NAS rejects its
# initialization. Keep a distinct private directory for each controller run.
export ROLLOUT_CODEX_STATE_DIR="${ROLLOUT_CODEX_STATE_DIR:-$(mktemp -d /tmp/gpt-policy-codex-state.XXXXXXXX)}"
# Native Codex tools invoke `python`, which is absent from the host's base PATH.
export PATH="$(dirname "$ROBO_PYTHON"):$PATH"
args=(--output "$output" --task "$task" --evaluation-method "$method" --codex "$codex_bin"
      --sim-port "${SIM_PORT:-19300}" --student-port "${POLICY_PORT:-19301}"
      --seed "${LAYOUT_ID:-0}" --max-decisions "${MAX_DECISIONS:-0}")
if [[ "$method" == pi05_plus_gpt ]]; then args+=(--checkpoint "$PI05_CHECKPOINT"); fi
exec "$ROBO_PYTHON" -m hybrid_rollout.robodojo.skill.run "${args[@]}"
