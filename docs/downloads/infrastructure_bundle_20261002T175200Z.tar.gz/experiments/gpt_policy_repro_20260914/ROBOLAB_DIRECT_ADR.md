# RoboLab Direct 接入决策（2026-10-02）

状态：Accepted，适配器实现与原生运行验证仍待完成。

公开仓库的 RoboLab 只有 Hybrid 持久控制器，报告另给出了 Direct 成绩，却未发布足以恢复该历史 Direct 接口与完整 prompt 的源码。当前复现需要一个明确不调用 π0.5 的观测到动作策略，保留单臂原生控制、完整录像、模型身份、决策来源和原生终止。

候选 A：在项目 infra 下增加独立 Direct 服务与工具适配器，复用上游持久 Codex 传输、RGB/proprio 观测、EEF 校验、每个实际 ACK 后更新 IK 的控制器与原生记录器。服务新增 begin_direct，动作仅 EEF；所有 π0.5 字段明确禁用，不填虚构的权重身份。优点是上游 Hybrid 不受修改；缺点是 prompt 和启动协议是我们自己的适配，不能宣称恢复历史源码。

候选 B：复用 Hybrid，伪造 student 身份或让 GPT 每次选择 EEF。这样仍要求新 π0.5 推理或伪造提议，违反 Direct 无 student 的方法定义，拒绝。

候选 C：直接重写上游 RoboLab 全部模块并加入方法分支。可统一入口，但扩大对正在运行 Hybrid 的影响和审计面，拒绝。

选择 A。依赖方向为 infra 适配器 → 上游只读模块 → 原生 RoboLab；不修改上游文件和正在运行回合。

接口：原版 JSON-RPC 动态工具 robolab_start / robolab_execute；MSGPack+zlib 原生仿真 RPC，另有 begin_direct。Direct 从观测生成 1–5 步固定绝对 EEF 位姿，沿用 5 cm / 0.35 rad 目标边界、阻尼 IK 和 8 维原生关节动作。每次动作持有当前 episode/request/step 身份，记录成功 ACK，不重试不确定的物理动作。只允许一次 fresh reset，不允许 rollback 或 student/fk-preview 工具。

SQLite 与模型认证继续留在本机；mainskill 只运行仿真。完整审计逐步重核模型工具事件、响应、EEF→关节记录、独立原生 chunk、初态与终止。先验证禁止 student、陈旧请求、越界动作和提前终止，再做真实首回合；之后才纳入冻结新种子队列与主板。公开报告必须标明 Direct 为当前上游上的自有 EEF 适配器，历史源码、prompt 与初态等价性未获证明。
