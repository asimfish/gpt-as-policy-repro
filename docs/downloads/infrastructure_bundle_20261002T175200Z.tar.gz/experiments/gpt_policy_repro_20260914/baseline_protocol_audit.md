# Pi0.5 基线执行协议核对

当前独立结果的方法为 `pi05_prefix15`：每次推理得到 50×14 动作，只执行前 15 步后重新推理。它不是原论文 Pi0.5 基线的严格复现，必须单独报告。

证据：
- `upstream/RoboDojo/XPolicyLab/policy/Pi_05/deploy.py:eval_one_episode` 遍历 `actions` 中全部动作，仅在原生 episode 终止或整块结束时停止。
- `gpt-as-policy/hybrid_rollout/robodojo/pi05_server/client.py:Pi05Client.infer` 强制输出 50×14，并保存原始动作及裁剪后的夹爪开度。
- `gpt-as-policy/hybrid_rollout/robodojo/robodojo_server/session.py:chunk_step` 每个 RPC 限制 1–15 步。
- `infra/run_one_episode.py:student_response` 固定接受前 15 步；下一轮会重新推理。

后续全块执行对照应缓存一次预测的 50 步，按 15+15+15+5 分段传输而不重新推理；episode 中途终止时立即停止。此方式仍需验证观测、模型状态和动作转换与上游部署一致，验证前只能称为独立 chunk-50 对照，不能声称逐轨迹等价。不得将 prefix-15 与 chunk-50 混合统计。

续跑故障：原实现先按 --limit 截取案例再过滤已完成；--limit 1 反复命中已完成案例而空跑。现已先过滤再截取，新增回归测试由失败转为通过，并在启动时输出所选案例。此前空跑不算实验失败或完成。

## RoboLab 独立协议核对（2026-09-15）

RoboLab 与 RoboDojo 的动作长度不能混为一谈。固定 OpenPI 版本 `aa64205615295931141608226e5ad155792b272f3` 的 `pi05_droid_jointpos` 配置原生 `action_horizon=15`；固定 RoboLab 版本的 `policies/pi0_family/client.py` 对 π0.5 默认也执行 15 步。输入为左外部相机、腕部相机（原生 RGB 等比例填充到 224×224）、7 维关节位置和 1 维夹爪位置。输出为绝对关节位置，夹爪按 `>0.5` 二值化。

新增执行器 `infra/run_robolab_pi05_episode.py` 使用以上协议，每次保存原始预测、执行动作、输入图像和状态、原生执行回执及预测文件 SHA256。要求完整 15×8 有限输出；原生终止后立即结束，末块 padding 不计控制步。当前使用 fresh reset，没有验证论文配对初始状态重放，方法独立标记为 `robolab_pi05_native15_fresh`，暂不纳入正式论文复现成功率。

## Additional baseline input/action contracts (pinned RoboLab ad45d4f)

Do not reuse the Pi05-only RPC adapter blindly for other policies. Source review found distinct native contracts:

- Cosmos3 (`upstream/RoboLab/policies/cosmos3/client.py`): three native views, including **over_shoulder_right_camera**, each 360x640; wrist plus half-sized left/right composition; default open-loop horizon 32. The current GPT RPC server config records left/wrist/egocentric cameras, so a right-camera registration path is required before Cosmos native evaluation. Execute a cached 32-step output without reinference between transport slices if using RPC.
- DreamZero (`upstream/RoboLab/policies/dreamzero/client.py` and `run.py`): native default horizon 24, 180x320 area resize, second exterior slot defaults to **black**, and gripper binarization defaults **off**. The DreamZero repository example uses a different horizon (8); these must not be conflated. Current GPT RPC `chunk_step` always thresholds the gripper, so it is not a faithful DreamZero backend without a separately validated native action path. Prefer the pinned RoboLab policy client/runner for its defaults and preserve session history.
- DreamZero pinned `pyproject.toml` requires torch 2.8.0 / torchvision 0.23.0 / torchaudio 2.8.0. README's optional 2.9.1 upgrade belongs to the sim-evals client example. Do not silently treat it as the pinned model environment. Native A100 inference remains unverified.

The full asset bundle's `source.tar.gz` currently contains `robolab/` and `pyproject.toml`; native Cosmos/DreamZero clients also need the pinned `policies/` directory staged before launch. None of the above source review is evidence of model inference or task success.
