# GPT-as-Policy 两种方法复现目标

## Outcome

按用户 2026-09-16 的范围修正，主要复现报告自己的两种方法：GPT Direct 与 π0.5 + GPT（Hybrid）。交付我们自己运行生成的在线报告、完整轨迹和可复用基础设施。

## In scope

- GPT Direct：使用原仓库的持久 GPT 控制器与 GPTOnlyTools，观察图像和状态，直接生成并执行短段末端控制，不调用 π0.5。
- Hybrid：使用原仓库 RoboDojoTools；π0.5 提议动作，GPT 根据观测与反馈接受前缀、修改或接管，保留完整闭环历史。
- 优先 RoboDojo 主实验：同一冻结面板50个案例，每个案例分别运行两方法，共100条轨迹。
- RoboLab 补充实验：10任务×5种子×两方法，共100条新固定种子轨迹；不扩展其他模型基线。
- 保留原生终止条件、输入输出、prompt、工具调用、模型身份、token、初态、视频与失败证据。

## Out of scope for active work

Cosmos、DreamZero、独立 π0.5 全量基线、prefix/chunk 对照扩展。已获得的结果和资产保留为历史辅助材料，不能当作 Direct/Hybrid 复现成绩。π0.5 推理服务继续保留，作为 Hybrid 必需组件。

## Acceptance

- [x] 原生仿真与 π0.5 推理链路验证。
- [x] 原仓库持久控制器启动入口已准备；2026-09-16两方法真实app-server握手/工具注册及原生工具预检通过（零模型调用）。
- [x] 用户授权当前Codex CLI后，gpt-6-astra/xhigh真实模型响应验证通过；证据astra_live_probe_20260916。
- [x] 同一个冻结案例完成 Direct 与 Hybrid 两条完整轨迹并审计；2026-10-06 有效主实验已配齐50对，RoboLab已有35个完整配对。
- [x] RoboDojo 有效50对两方法100条轨迹完成并逐条动作审计，失败与基础设施中断区分；原99条已审计结果和无效布局记录另行保留。
- [x] 在线报告以两方法自己的结果为主；公开数字与已有基线分开（v2 自动生成主板已发布、字节与浏览器验收通过）。
- [ ] 完成两方法 RoboLab 补充评测并明确历史环境等价性限制。
- [ ] 所选200个完整回合及保留原回合通过原始证据、完整视频、线上文件和同一提交CI最终验收。

## Current frontier

2026-10-06 14:41 UTC：有效RoboDojo100/100、50/50配对已完成并整组核验；Direct成功13/50、Hybrid成功21/50，完整失败均计入分母。原面板99/100、49/50配对及原无效布局单独保留。
有效主组100条及保留原Direct layout4共101条原证据、153167项输入SHA、原始与导出视频完整解码、404个公开文件及同一提交CI通过；50对原始布局和机器人proprio指纹匹配。证书publication_checks/robodojo_completed_20261006/certificate.json；cohort_verified=true、full_reproduction_complete=false。
RoboLab已完整审计73/100、35/50配对，73份原归档已验证、积压零。上次48条以后新增25条原回合、13613项输入、整份原归档、原始和导出视频完整解码、100份公开文件及提交ed1aa1ed3f1e981352c0c12e51a3573df52d380c的CI37479633067独立核验通过；35对70份原始initial_scene记录逐对state_sha256相同，不声称完整checkpoint或历史初态逐位等价。
v3边界切换与三路真实运行已验证。发现原Direct ReorientRedMug seed4在归档锁占用后留下过时remote_archive_verified字段，后台原归档随后成功；清理恢复在确认所属本机及远端进程/进程组已退出、1759个原归档文件全部SHA正确后回写派生状态。原793步成功结果、完整动作审计、清单和回执哈希均不变，原归档错误保留。冻结队列自行于14:34:26 UTC释放slot1并启动CannedFood seed0 Direct；另两条Hybrid继续运行。
恢复逻辑已接入原归档维护服务，13项新增与18项既有相关回归通过。原冻结v3/v2、监督器、资格/首完整失败/最大重试规则、物理控制器和最终验收脚本不改写；不回放动作或改分。
下一前沿是完成剩余RoboLab27条回合，再验所选200条及保留原回合的全部原始证据与公开文件。最终联合验收保持pending_native_episodes/full_reproduction_complete=false。最新证据publication_checks/cleanup_recovery_20261006。

用户在上次可审阅的layout5补齐方案之后再次要求“继续推进”。本轮按此续推进指令执行该方案，
记录为user_continue_20261006_after_reviewable_replacement_proposal：另建有效50对清单，
只将imitate_sorting_sequence layout4整对替换成同一原60案例面板中预冻结的下一编号layout5，
补跑Direct和Hybrid两条新原生回合。原50案例清单、全部旧结果、完整失败与无效布局尝试均保留；
原面板与有效面板分别报告，不能相加为独立样本，也不选择两方法中更好的结果。

layout4已有五次Hybrid完整1600步原生排除。保持初态、零模型/零π推理的独立诊断，
同样于432步得到原辅助臂验证失败（aim2手表不在basket1），走满1600步仍无效。
layout5通过相同冻结原生配置的553步演示检查，并走满1600步诊断。
两条诊断3200条动作全部核对为保持初态，各1601帧原视频；诊断不计作模型实验。
底层抓取/物理重放原因尚未完全证明，未修改原生判定、轨迹、prompt、模型或时域。

v6有界原生无效重试队列已于2026-10-05T14:28:01.696574+00:00在物理回合边界切换成功；
原资格函数与最早有效原生失败/审计缺口优先级保留。原v6及RoboLab v2冻结源码不改写。
新补齐队列独立状态、使用相同执行锁，只负责layout5两方法，完整失败和审计缺口仍阻止物理替代。
不可变有效清单及原文件/诊断SHA核验见fixtures/robodojo_valid_cohort_v2.json，
显式选择指针为fixtures/robodojo_active_cohort.json；layout5两方法已原生终止并完整审计，独立页面上线验收通过；RoboLab及最终联合验收仍在进行。

旧RoboLab归档积压已经清零：截至2026-10-05T12:59:08.758233+00:00，最早原生完整回合18条全部完成原归档与完整动作审计，
summary为verified18/requires_repair0/pending0。ClutterPumpkinTask seed0/1 Hybrid原生成功801/632步，seed2原生失败1350步，三条完整结果均保留。
新验收器再次核对三条原回合的3015个审计输入、整份原归档manifest与原传感视频帧数，均通过。

RoboDojo build_tower standard layout3 Direct已原生完整失败1050步/210决策，完整审计通过并按原失败计分。
旧启动超时缺项已全部完成原生回合及完整审计；唯一未完成项为上述原生演示无效布局。后续启动等待保持1200秒。
修复了报告把invalid_native_layout当作audit_pending候选而永久挡住有效重试的问题：
仅原生eligibility=false、success/score=null且冻结身份匹配的无效布局排除。
有效完整失败和最早有效完整审计缺口继续保留。实站漏掉的新原因标签也已补齐，34项站点回归与真实构建通过。

新增verify_reproduction_completion.py及14项验收边界回归，gpt-policy-final-verification.timer已enabled。
覆盖未满时只记录pending_native_episodes，不启动模型或仿真；两套均100/100与50/50后才扫描全部原审计输入、
最早有效原生回合、每一步传感视频、全视频解码及所选200回合、保留原面板回合与面板元数据全部公开文件的字节/hash，并核对同一提交CI。
完成证明按提交存入final_verification/<commit>/certificate.json，保留原验收时间；full_reproduction_complete当前false。
两条真实已停止原回合共3400个审计输入已用新验收器复核，完整原视频帧数1051/557通过，不代替200条最终验收。

RoboLab后续监督器在慢归档前保存原生结果和完整控制器输出、同步controller_finished阶段；
复制中断先保留原结果，冻结v2会标成audit_failed并禁止新的物理替代，原完整失败不能被后续成功覆盖。
旧监督器的seed4原归档已完成，新ClutterPumpkin进程已实际加载新保存逻辑并核对源码SHA一致；不重连或重放不确定动作。
RoboLab v2切换、2228文件完整资产和独立空闲GPU选择已实际验证，两个冻结调度器SHA保持不变。
活动SQLite继续位于本机/tmp；已封存工作区与状态自动转存私有NAS，报告与归档恢复timer继续运行。

下一前沿是继续RoboLab矩阵至100/100和50/50，再执行所选200回合及保留原回合的最终全量在线验收。
RoboLab Direct为本项目EEF适配器；历史源码/完整初态未公开，不声称逐位环境等价或独立重算IK。
详细证据见RUNBOOK.md、ROBOLAB_ARCHIVE_DIAGNOSIS.md及publication_checks/remediation_20261005。

## Decisions

- 2026-10-06：在可审阅的layout5整对补齐提案之后，按用户“继续推进”执行独立有效50对面板；原50对结果与失败统计保留并分别发布，原冻结文件不改写。

- 2026-09-16：用户明确“主要复现这个文档自己的两种方法就行”；优先级覆盖此前全模型扩展范围。
- 停止继续运行独立π0.5基线队列和额外模型传输；不删除已下载资产和历史结果。
- 2026-09-16追加授权：用户明确要求直接使用当前Codex CLI的GPT-6 Astra。通过CLI自身认证复用当前登录态，不复制、不输出凭据；SQLite运行状态保持每次实验独立。该决定覆盖此前要求单独实验账号的限制。
- 既有历史目标保存在 GOAL_before_scope_correction_20260916.md，仅供追溯。

## Evidence

report_interpretation_zh.md、infra/run_original_controller.sh、现有仿真与π0.5审计记录。在线报告：https://asimfish.github.io/gpt-as-policy-repro/scenes.html 。当前在线报告已以两种主方法的自有结果为主；有效RoboDojo 50个配对已完成并整组复核，RoboLab补充与最终联合验收仍未完成。


2026-10-06补齐执行进展：独立清单SHA256为d0b76047a1f570f964b6987550538982f49182ba321a07c568f7ba1d2c7473cd。`gpt-policy-robodojo-supplement-v2.service`已enabled并于22:43:13UTC启动；Direct layout5新物理回合运行中，Hybrid随后执行。真实构建与页面验证：原面板99/100、49对，独立有效面板98/100、49对，RoboLab21/100、6对；桌面与390px手机验证通过，两面板筛选、深链接与完整视频实际播放均通过。已停止回合的自动私有状态转存已支持新增案例，仍执行同一哈希固定的v5完整资格检查并拒绝活动worker；六项回归通过。验收器16项回归通过，当前记录pending_native_episodes，不生成完成证书。页面及新基建包的线上精确字节验证另行记录，尚未完成时不得声称发布完成。


2026-10-06发布验收完成：提交419ca6f17982d498194dc5661de263c6d2183bdb，GitHub Pages工作流37385101951成功；14个网页/JSON/资源/包的提交字节与线上SHA全部匹配。原面板99/100、独立有效面板98/100（两者均49对，互有重叠），RoboLab21/100、6对。新页面为https://asimfish.github.io/gpt-as-policy-repro/gpt-methods-valid.html 。基建包`deliverables/infrastructure_bundle_20261006T065300Z.tar.gz`含832个文件，SHA256=5f5b05d2cf1296556f22c3c637aa17c52b87da7fc36ccd3caf878ce26a1c79c4；公开下载后逐个核对832成员和7个核心源码/冻结清单，全部通过。旧基建包与全部原回合保留。发布、归档、磁盘维护与最终验收timer恢复运行；layout5两方法补齐服务和RoboLab v2队列持续执行。全量验收仍为pending_native_episodes/full_reproduction_complete=false。证据目录publication_checks/valid_cohort_20261006。

线上桌面/手机最终浏览器复核也已通过（提交419ca6f17982d498194dc5661de263c6d2183bdb）：原99回合、独立有效98回合、RoboLab21回合分别与JSON一致；两面板50行、筛选、深链接、390px宽度和真实视频播放通过，页面错误为零。补齐Direct已核对gpt-6-astra/xhigh真实worker和执行动作；旧v5、v6及RoboLab v2的三个源码SHA保持完全一致。


2026-10-06 RoboLab有界并行推进：在不改写冻结100条身份、原模型/prompt/原生时域和首次完整失败/审计缺口规则的前提下，实现最多3个独立原生回合。设计与两种方案权衡见ROBOLAB_PARALLEL_ADR.md；v3直接装载SHA固定的v2资格/选择函数，原v2、原监督器与服务源码不改写。独立锁、端口、GPU预约、Linux boot/start身份、先持久化后单次启动及不确定ACK保留预约均有回归；退出只排空已启动回合。22项相关基建测试、40项报告测试和16项最终验收边界测试通过。远端新管理器已原子部署且读回SHA=18a33b59f78b6effefcb7b839beabcfd92575cdbce931fbeef69f435ed0cfefe。`gpt-policy-robolab-parallel-handover-20261006.service`已enabled，当前等待v2回合物理/清理/归档锁释放，尚未启动并行模型回合。报告已实现多个活动回合的脱敏进度，运行中回合不计入成绩。证据publication_checks/parallel_queue_20261006；调度源码及冻结SHA见robolab_queue_scheduler_v3_manifest.json。

本轮独立再核验ClutterPumpkin seed3 Hybrid原生失败1350步、seed4 Hybrid成功871步、seed0 Direct成功766步共4303份原审计输入、整份原归档及原视频逐步帧数，全部通过，失败保持。全量结果仍为有效RoboDojo98/100、49/50对，原面板99/100、49/50对，RoboLab21/100、6/50对；full_reproduction_complete=false。并行队列切换与新版报告/包发布应分别核对实际运行、提交和在线字节证据，不能以部署准备当作回合完成。


2026-10-06有界并行基建发布验收：源码提交e00aa7430d22122c2a3efd789435bca368084927，实际网页提交1fdd2e2865a07c54ff9db34a2dcd3daeb625135f，Pages CI37392587664成功；14个公开文件精确字节核验完成，本地与线上桌面/390px手机检查均通过，原面板99、有效面板98及RoboLab21条回放/JSON分别一致、页面错误为零。新不可变基建包deliverables/infrastructure_bundle_20261006T081000Z.tar.gz含844文件、938483字节、SHA256=26fe9bd81285ff00db5e3b2e3a8513845e5306d6d233053f2b3596156f897cb8；公开下载后逐个成员复核通过，包含新ADR、v3清单、部署凭证及去私有环境的服务模板。此前832文件包与全部原回合保留。证据publication_checks/parallel_queue_20261006/checkpoint.json。切换服务仍在等当前原生回合/清理/归档边界，不能宣称已运行三个并行回合；完整实验验收保持pending_native_episodes/full_reproduction_complete=false。


2026-10-06 08:22 UTC交付验收：提交a67cfc7187f1981b5b5d3c590b1fdb048addf0c1，Pages CI37435364490成功，14个公开文件精确字节一致。基建包deliverables/infrastructure_bundle_20261006T082000Z.tar.gz含851文件、983162字节，SHA256=0917f686b2a08c3d0fbfb546beff00ebe3e2b9a806966b886b911df315bc0fd6；公开下载逐成员核对通过，RoboDojo里程碑证书原件一致，旧包保留。新增Direct ReorientRedMug seed0完整成功760步，1993份原输入、整份原归档及原视频逐步帧数再核验通过；本轮新增原证据合计27条/20897项。最终联合验收已刷新为所选RoboDojo100/50对、RoboLab48/23对，pending_native_episodes/full_reproduction_complete=false；三个原生worker继续执行，全部维护timer活动。详细证据publication_checks/robodojo_completed_20261006/checkpoint.json。


## 2026-10-06 14:59 UTC：后续回合转用第二块本地SSD

系统ext4盘可用空间从14:25的9.3GiB降至14:45约5.9GiB，全部73个已审计停止工作区已按原字节验证转存NAS。另一块本地ext4 SSD约867GiB可用；选项与边界见ROBOLAB_LOCAL_STORAGE_ADR.md。新v4仅将后续新回合local_workspace配置为固定私有目录/data/liyufeng/agentic_robot_runtime/gpt_policy_repro_20260914，不搬移活动SQLite，不修改原控制器/原prompt/模型/原生时域/GPU/端口/资格规则。原v3两入口、远端管理器、v2 Oracle与全部原结果保留且SHA不变；v4 JSON清单robolab_queue_scheduler_v4_manifest.json绑定完整新源码与原出处。

第二SSD实际SQLite WAL和双独立连接读写成功，零模型/仿真调用；7项存储根拒绝边界、7项原停止工作区维护与14项原并行预约/接管测试在v4上通过。原选取与清理的7个函数AST一致。只停止旧协调PID，三个原生监督器、控制器、SSH隧道及工作目录在切换前后boot/start身份保持，动作进度不回退；v4已enabled并接管同一flock和durable leases。首次启动被公开模板的EnvironmentFile占位路径阻挡，ExecStart未执行；复用既有部署环境后启动正常，未复制认证。v3服务disable，源码和单元保留，v4服务活动。

原三回合仍使用/tmp；下一原生回合才创建新SSD工作区，尚未观察到新盘实际模型回合，不能将预检等同于回合完成。归档维护已支持两个明确根，仍要求停止/完整审计/每文件SHA与NAS保留，拒绝任意外部路径。证据publication_checks/local_ssd_20261006。剩余RoboLab由队列继续，整体验收false。
