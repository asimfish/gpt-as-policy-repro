"""Repair only the earliest native-complete artifacts; never launch or replay a rollout."""
from datetime import datetime, timezone
import fcntl
import json
from pathlib import Path
import traceback
from archive_robolab_attempt import archive_attempt
from queue_robolab_two_methods import key, native_complete, qualified, read, write

ARTIFACTS=Path(__file__).resolve().parents[1]


def main():
    with Path('/tmp/gpt-policy-robolab-archive-recovery.lock').open('a') as lock:
        try:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:
            return
        frozen=read(ARTIFACTS/'fixtures/robolab_two_methods_frozen.json')['entries']
        identities={key(row):row for row in frozen}
        groups={identity:[] for identity in identities}
        for path in (ARTIFACTS/'robolab_gpt_campaign').iterdir():
            record=read(path/'attempt.json') if path.is_dir() else None
            if record and key(record) in groups and native_complete(path):
                groups[key(record)].append((record['started_utc'],path))
        results=[]
        def persist():
            write(ARTIFACTS/'robolab_archive_recovery.json',dict(
                schema='gpt_policy_robolab_archive_recovery.v1',
                updated_utc=datetime.now(timezone.utc).isoformat(),
                scope='Earliest native-complete episodes only; artifact transfers and original audits; no model or simulator calls',
                results=results))
        for identity,attempts in groups.items():
            if not attempts:
                continue
            path=min(attempts,key=lambda pair:pair[0])[1]
            result=dict(attempt=path.name,**identities[identity])
            try:
                if not (path/'complete_action_audit.json').exists() and not (path/'remote_archive_receipt.json').exists():
                    archive_attempt(path)
                outcome=qualified(path,identities[identity])
                result.update(status='verified',success=outcome['success'],control_steps=outcome['step_id'])
            except Exception as error:
                result.update(status='preserved_requires_repair',error_type=type(error).__name__,
                              diagnostic=traceback.format_exc(limit=5)[-2500:])
            results.append(result);persist()
            print(json.dumps({k:v for k,v in result.items() if k!='diagnostic'}),flush=True)
        persist()


if __name__=='__main__':main()
