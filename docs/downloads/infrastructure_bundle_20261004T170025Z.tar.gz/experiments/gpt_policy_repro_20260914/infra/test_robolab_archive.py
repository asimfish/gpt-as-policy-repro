"""Partial copies and same-size corruption must never become verified archives."""
import hashlib
import json
from pathlib import Path
import tempfile
import subprocess
import sys
import unittest
import archive_robolab_attempt as archive
from archive_robolab_attempt import verify_archive, REMOTE_MANIFEST


class ArchiveIntegrity(unittest.TestCase):
    def manifest(self, name='episode/initial_scene.json', data=b'known bytes'):
        return dict(schema='gpt_policy_robolab_remote_archive.v1', files={name:dict(size=len(data), sha256=hashlib.sha256(data).hexdigest())})

    def test_resumed_exact_bytes_pass_and_missing_or_corrupt_bytes_fail(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); path = root/'episode/initial_scene.json'
            with self.assertRaises(AssertionError):verify_archive(root, self.manifest())
            path.parent.mkdir();path.write_bytes(b'known bytes')
            self.assertTrue(verify_archive(root, self.manifest())['verified'])
            path.write_bytes(b'other bytes')
            with self.assertRaisesRegex(AssertionError, 'bytes differ'):verify_archive(root, self.manifest())

    def test_path_escape_and_symlinks_are_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for name in ('../outside', '/tmp/outside', 'episode/../outside'):
                with self.subTest(name=name), self.assertRaises(AssertionError):verify_archive(root, self.manifest(name))
            (root/'real').write_bytes(b'known bytes');(root/'alias').symlink_to(root/'real')
            with self.assertRaises(AssertionError):verify_archive(root, self.manifest('alias'))

    def test_live_or_unflushed_recorder_cannot_be_archived(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            for state in (dict(status='starting'),dict(status='ready'),dict(status='service_failed'),dict(status='stopped',finished_utc='sealed')):
                with self.subTest(state=state):
                    (root/'services.json').write_text(json.dumps(state))
                    result=subprocess.run([sys.executable,'-c',REMOTE_MANIFEST,str(root)],capture_output=True,text=True)
                    if state.get('finished_utc'):
                        self.assertEqual(result.returncode,0)
                        self.assertTrue(verify_archive(root,json.loads(result.stdout))['verified'])
                    else:self.assertNotEqual(result.returncode,0)

    def test_dead_owner_with_stop_request_recovers_stale_ready_metadata(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)/'attempt';root.mkdir();proc=Path(tmp)/'proc';proc.mkdir()
            (root/'STOP').touch()
            state=dict(status='ready',attempt=root.name,manager_pid=101,simulator_pid=102)
            guard=archive.cleanup_guard(root,state,proc)
            self.assertEqual(guard['source'],'dead_owner_after_stop')
            self.assertEqual(state['status'],'ready')
            (proc/'102').mkdir()
            with self.assertRaisesRegex(AssertionError,'alive'):
                archive.cleanup_guard(root,state,proc)

    def test_surviving_process_group_blocks_recovery_and_stop_is_required(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)/'attempt';root.mkdir();proc=Path(tmp)/'proc';proc.mkdir()
            state=dict(status='ready',attempt=root.name,manager_pid=101,simulator_pid=102)
            with self.assertRaises(AssertionError):archive.cleanup_guard(root,state,proc)
            (root/'STOP').touch();child=proc/'103';child.mkdir()
            (child/'stat').write_text('103 (owned child) S 1 102 102 0')
            with self.assertRaisesRegex(AssertionError,'group'):
                archive.cleanup_guard(root,state,proc)

    def test_parallel_file_lists_copy_exact_bytes_and_never_overlap(self):
        with tempfile.TemporaryDirectory() as tmp:
            source=Path(tmp)/'source';target=Path(tmp)/'target';source.mkdir();target.mkdir()
            files={}
            for i,name in enumerate(['scene/initial.json','scene/chunk0.npz','scene/chunk1.npz','scene/receipts/000.json','scene/odd name\n.json']):
                data=bytes([i])*((i+1)*1024);p=source/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
                files[name]=dict(size=len(data),sha256=hashlib.sha256(data).hexdigest())
            manifest=dict(schema='gpt_policy_robolab_remote_archive.v1',files=files)
            groups=archive.partitions(manifest);flat=[name for group in groups for name in group]
            self.assertEqual(set(flat),set(files));self.assertEqual(len(flat),len(set(flat)))
            self.assertEqual(archive.transfer_archive(str(source)+'/',target,manifest,['ssh']),4)
            self.assertTrue(archive.verify_archive(target,manifest)['verified'])
            for bad in ['../escape','/absolute','scene/../escape']:
                with self.assertRaises(AssertionError):archive.partitions(self.manifest(bad))


if __name__ == '__main__':unittest.main()
