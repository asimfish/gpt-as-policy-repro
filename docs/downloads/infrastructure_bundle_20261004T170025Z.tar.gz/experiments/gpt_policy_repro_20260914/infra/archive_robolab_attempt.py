"""Resume only stopped RoboLab artifacts; verify every archived byte, without RPC or actions."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import shlex
import subprocess
import tempfile
import time

from transfer_checkpoint_chunks import SSH

ARTIFACTS = Path(__file__).resolve().parents[1]
REMOTE_CAMPAIGN = '/home/dataset-assist-0/liyufeng/agentic_robot/experiments/gpt_policy_repro_20260914/robolab_gpt_campaign'
_CLEANUP_GUARD = '''def cleanup_guard(root, services, proc_root=Path('/proc')):
    if services['status'] not in ('starting', 'ready') and services.get('finished_utc'):
        return {'source': 'recorded_cleanup', 'finished_utc': services['finished_utc']}
    assert services.get('attempt') == root.name and (root/'STOP').is_file(), 'Stop request and owned attempt required'
    pids = [services.get('manager_pid'), services.get('simulator_pid')]
    if services.get('policy_pid') is not None:
        pids.append(services['policy_pid'])
    assert all(type(pid) is int and pid > 0 for pid in pids), 'Owned process identities required'
    assert all(not (proc_root/str(pid)).exists() for pid in pids), 'Owned process is still alive'
    for entry in proc_root.iterdir():
        if not entry.name.isdecimal():
            continue
        try:
            fields = (entry/'stat').read_text().rsplit(')', 1)[1].split()
        except FileNotFoundError:
            continue
        assert int(fields[2]) not in pids, 'Owned process group is still alive'
    return {'source': 'dead_owner_after_stop', 'absent_process_ids': pids}
'''
exec(_CLEANUP_GUARD)

REMOTE_MANIFEST = '''from pathlib import Path
import hashlib,json,sys
''' + _CLEANUP_GUARD + '''
root=Path(sys.argv[1]);services=json.loads((root/'services.json').read_text())
cleanup=cleanup_guard(root,services)
files={}
for path in sorted(root.rglob('*')):
 assert not path.is_symlink(), 'Do not archive symbolic links'
 if path.is_file():
  before=path.stat();h=hashlib.sha256()
  with path.open('rb') as stream:
   for block in iter(lambda:stream.read(8*1024*1024),b''):h.update(block)
  after=path.stat()
  assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns), 'Artifact changed during hashing'
  files[path.relative_to(root).as_posix()]={'size':after.st_size,'sha256':h.hexdigest()}
print(json.dumps({'schema':'gpt_policy_robolab_remote_archive.v1','cleanup':cleanup,'files':files}))
'''


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(8*1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def verify_archive(root, manifest):
    assert manifest['schema'] == 'gpt_policy_robolab_remote_archive.v1'
    assert manifest['files'], 'An empty transfer cannot qualify'
    total = 0
    for name, expected in manifest['files'].items():
        relative = PurePosixPath(name)
        assert relative.parts and not relative.is_absolute() and '..' not in relative.parts
        assert relative.as_posix() == name
        path = root.joinpath(*relative.parts)
        assert not any(part.is_symlink() for part in [path, *path.parents]), 'Archive paths must not follow links'
        assert path.is_file(), 'Missing archived file: '+name
        assert path.stat().st_size == expected['size'], 'Archived size differs: '+name
        assert digest(path) == expected['sha256'], 'Archived bytes differ: '+name
        total += expected['size']
    return dict(verified=True, files=len(manifest['files']), bytes=total)


def partitions(manifest, workers=4):
    """Disjoint byte-balanced lists bound each read-only transfer independently."""
    groups=[[] for _ in range(min(workers,len(manifest['files'])))];sizes=[0]*len(groups)
    assert groups, 'An empty transfer cannot qualify'
    for name,row in sorted(manifest['files'].items(),key=lambda pair:(-pair[1]['size'],pair[0])):
        relative=PurePosixPath(name)
        assert relative.parts and not relative.is_absolute() and '..' not in relative.parts
        assert relative.as_posix()==name and '\0' not in name
        assert type(row['size']) is int and row['size']>=0
        index=min(range(len(groups)),key=lambda i:sizes[i])
        groups[index].append(name);sizes[index]+=row['size']
    return groups


def transfer_archive(source,target,manifest,ssh):
    groups=partitions(manifest)
    with tempfile.TemporaryDirectory(prefix='gpt-policy-robolab-archive-plan.') as tmp:
        lists=[]
        for index,names in enumerate(groups):
            path=Path(tmp)/str(index);path.write_bytes(b''.join(name.encode()+b'\0' for name in sorted(names)));lists.append(path)
        def transfer(path):
            for attempt in range(3):
                try:
                    subprocess.run(['rsync','-az','--checksum','--partial','--timeout=90',
                        '--from0','--files-from='+str(path),'-e',shlex.join(ssh),source,str(target)+'/'],check=True,timeout=1200)
                    return
                except (subprocess.TimeoutExpired,subprocess.CalledProcessError):
                    if attempt==2:raise
                    time.sleep(3)
        with ThreadPoolExecutor(max_workers=len(groups)) as pool:
            futures=[pool.submit(transfer,path) for path in lists]
            errors=[]
            for future in futures:
                try:future.result()
                except Exception as error:errors.append(error)
            if errors:raise errors[0]
    return len(groups)


def archive_attempt(path, cipher=None):
    record = json.loads((path/'attempt.json').read_text())
    assert path.name == record['attempt'] and Path(path.name).name == path.name
    assert record['remote_output'] == REMOTE_CAMPAIGN+'/'+path.name
    cipher = cipher or record.get('ssh_cipher', 'default')
    assert cipher in ('default', 'aes128-gcm@openssh.com')
    ssh = [*SSH[:-1], *(['-o', 'Ciphers='+cipher] if cipher != 'default' else [])]
    source = subprocess.run([*ssh, SSH[-1], shlex.join(['python3', '-c', REMOTE_MANIFEST, record['remote_output']])],
                            capture_output=True, text=True, check=True, timeout=180)
    manifest = json.loads(source.stdout)
    target = path/'remote'
    target.mkdir(exist_ok=True)
    # Multiple SSH flows mitigate the observed per-flow throughput variability.
    # Each file belongs to one worker; no simulator connection or action is retried.
    workers=transfer_archive(SSH[-1]+':'+record['remote_output']+'/',target,manifest,ssh)
    receipt=verify_archive(target,manifest)
    (path/'remote_archive_manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
    receipt.update(schema='gpt_policy_robolab_archive_receipt.v1', ssh_cipher=cipher,
                   transfer_workers=workers,
                   cleanup=manifest['cleanup'],
                   manifest_sha256=digest(path/'remote_archive_manifest.json'),
                   verified_utc=datetime.now(timezone.utc).isoformat())
    (path/'remote_archive_receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
    return receipt


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('attempt')
    args = parser.parse_args()
    assert Path(args.attempt).name == args.attempt and args.attempt.startswith(('direct_', 'hybrid_'))
    print(json.dumps(archive_attempt(ARTIFACTS/'robolab_gpt_campaign'/args.attempt)))
