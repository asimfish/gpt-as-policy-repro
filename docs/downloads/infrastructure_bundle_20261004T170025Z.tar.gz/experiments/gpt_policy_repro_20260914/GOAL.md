# GPT-as-Policy 两种方法复现目标

## Outcome

按用户 2026-09-16 的范围修正，主要复现报告自己的两种方法：GPT Direct 与 π0.5 + GPT（Hybrid）。交付我们自己运行生成的在线报告、完整轨迹和可复用基础设施。

## In scope

- GPT Direct：使用原仓库的持久 GPT 控制器与 GPTOnlyTools，观察图像和状态，直接生成并执行短段末端控制，不调用 π0.5。
- Hybrid：使用原仓库 RoboDojoTools；π0.5 提议动作，GPT 根据观测与反馈接受前缀、修改或接管，保留完整闭环历史。
- 优先 RoboDojo 主实验：同一冻结面板50个案例，每个案例分别运行两方法，共100条轨迹。
- RoboLab 补充实验：10任务×5种子×两方法，共100条新固定种子轨迹；不扩展其他模型基线。
- 保留原生终止条件、输入输出、prompt、工具调用、模型身份、token、初态、视频与失败证据。

## Out of scope for active work

Cosmos、DreamZero、独立 π0.5 全量基线、prefix/chunk 对照扩展。已获得的结果和资产保留为历史辅助材料，不能当作 Direct/Hybrid 复现成绩。π0.5 推理服务继续保留，作为 Hybrid 必需组件。

## Acceptance

- [x] 原生仿真与 π0.5 推理链路验证。
- [x] 原仓库持久控制器启动入口已准备；2026-09-16两方法真实app-server握手/工具注册及原生工具预检通过（零模型调用）。
- [x] 用户授权当前Codex CLI后，gpt-6-astra/xhigh真实模型响应验证通过；证据astra_live_probe_20260916。
- [x] 同一个冻结案例完成 Direct 与 Hybrid 两条完整轨迹并审计；截至 2026-10-05 已有 36 个主实验完整配对，另有 1 个 RoboLab 补充配对。
- [ ] RoboDojo 两方法100条配对轨迹完成，失败和基础设施中断区分。
- [x] 在线报告以两方法自己的结果为主；公开数字与已有基线分开（v2 自动生成主板已发布、字节与浏览器验收通过）。
- [ ] 完成两方法 RoboLab 补充评测并明确历史环境等价性限制。

## Current frontier

2026-10-04 16:31 UTC / 2026-10-05 00:31 CST：主板提交
72cfd2775fec30bc07f43f9ae7c97c51cfe08373 已完成线上精确字节核验。
RoboDojo 为 78/100 完整审计回合、36/50 配对；Direct 9/40，Hybrid 13/38。
已配齐子集分别 9/36、12/36。RoboLab 为 3/100、1/50 配对，Direct 1/1、Hybrid 2/2。
这些是当前完成子集，不能代替两个全量分母；完整原生失败保留为成绩。

两套200条轨迹尚未全量完成。当前主实验继续 pack_objects_into_box / standard / layout0 Hybrid；
RoboLab 继续 BlockStackingSpecifiedOrderTask / seed2 Direct。不停止当前物理回合。

本轮发现并修复发布事务超时：自动发布在第47条结果提交时超时，留下9个自有暂存文件和空index.lock。
锁已确认无持有者后保存在 publication_checks/recovery_20261005，暂存内容按原结果恢复提交；
发布器新增绑定HEAD与Git索引树的事务回执，遇到用户修改暂存仍拒绝提交。20项发布/计分测试通过。
发布已恢复至78条，10分钟timer继续运行，push与线上部署仍分别验证。

RoboLab部分原生成功回合清理超时，所有自有进程已退出但services.json仍为ready，故归档未发生。
archive_robolab_attempt.py新增只读恢复证明：必须有原attempt STOP、原manager/simulator/policy PID全部不存在，
且无对应进程组存活；原services.json不改写，补传后仍用原完整审计器。9项审计缺口正在修复同一批原回合，
不能重新跑物理实验绕过审计。recover_robolab_archives.py及10分钟timer持续补传与审计。

后续远端启动使用已核验的完整RoboLab资产目录RoboLab-ad45-full-assets（2228文件）；
它与旧runtime目录的全部Python源码逐文件一致。旧目录部分USD仅为LFS指针，导致场景初始化失败。
只在显存满足原门槛时选取独立GPU，保留原优先设备，不停止其他任务。
RubiksCubeTask零动作重置与主/腕相机图像检查已通过，step_id=0，不计分。后端47项相关回归通过。

v2冻结调度器及SHA256见robolab_queue_scheduler_v2_manifest.json；修复前的全部尝试保留，
修复后最多3次新基础设施尝试。native_complete与qualified函数AST与v1完全相同：
首次原生完整回合（包括失败）跨全部历史保留，审计缺口继续阻止新跑。
gpt-policy-robolab-queue-handover-20261005.service正等待当前控制器和归档锁释放，
再停止旧调度并启用gpt-policy-robolab-two-methods-v2.service，不中断当前回合。

下一前沿：完成旧回合归档/原审计、在真实空闲边界验证v2接管，
继续两套冻结矩阵和定时发布，直到各100/100且各50/50配齐并全部上线。
活动SQLite留在本机；两套已审计冷归档与10分钟容量维护保留。认证只由已授权CLI读取。
RoboLab Direct仍为本项目EEF适配器，历史实现/完整初态未公开；不声称历史环境逐位等价，也未独立重算IK。
旧运行与SSH AES-GCM缓解的证据见PROGRESS_20261002.md、ROBOLAB_RPC_DIAGNOSIS.md和ROBOLAB_ARCHIVE_DIAGNOSIS.md。

## Decisions

- 2026-09-16：用户明确“主要复现这个文档自己的两种方法就行”；优先级覆盖此前全模型扩展范围。
- 停止继续运行独立π0.5基线队列和额外模型传输；不删除已下载资产和历史结果。
- 2026-09-16追加授权：用户明确要求直接使用当前Codex CLI的GPT-6 Astra。通过CLI自身认证复用当前登录态，不复制、不输出凭据；SQLite运行状态保持每次实验独立。该决定覆盖此前要求单独实验账号的限制。
- 既有历史目标保存在 GOAL_before_scope_correction_20260916.md，仅供追溯。

## Evidence

report_interpretation_zh.md、infra/run_original_controller.sh、现有仿真与π0.5审计记录。在线报告：https://asimfish.github.io/gpt-as-policy-repro/scenes.html 。当前在线报告已以两种主方法的自有结果为主；50 个配对与 RoboLab 补充仍未全量完成。
