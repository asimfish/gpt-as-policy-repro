# GPT-as-Policy 两种方法复现目标

## Outcome

按用户 2026-09-16 的范围修正，主要复现报告自己的两种方法：GPT Direct 与 π0.5 + GPT（Hybrid）。交付我们自己运行生成的在线报告、完整轨迹和可复用基础设施。

## In scope

- GPT Direct：使用原仓库的持久 GPT 控制器与 GPTOnlyTools，观察图像和状态，直接生成并执行短段末端控制，不调用 π0.5。
- Hybrid：使用原仓库 RoboDojoTools；π0.5 提议动作，GPT 根据观测与反馈接受前缀、修改或接管，保留完整闭环历史。
- 优先 RoboDojo 主实验：同一冻结面板50个案例，每个案例分别运行两方法，共100条轨迹。
- RoboLab 补充实验：10任务×5种子×两方法，共100条新固定种子轨迹；不扩展其他模型基线。
- 保留原生终止条件、输入输出、prompt、工具调用、模型身份、token、初态、视频与失败证据。

## Out of scope for active work

Cosmos、DreamZero、独立 π0.5 全量基线、prefix/chunk 对照扩展。已获得的结果和资产保留为历史辅助材料，不能当作 Direct/Hybrid 复现成绩。π0.5 推理服务继续保留，作为 Hybrid 必需组件。

## Acceptance

- [x] 原生仿真与 π0.5 推理链路验证。
- [x] 原仓库持久控制器启动入口已准备；2026-09-16两方法真实app-server握手/工具注册及原生工具预检通过（零模型调用）。
- [x] 用户授权当前Codex CLI后，gpt-6-astra/xhigh真实模型响应验证通过；证据astra_live_probe_20260916。
- [x] 同一个冻结案例完成 Direct 与 Hybrid 两条完整轨迹并审计；2026-10-07 两套所选实验均配齐50对。
- [x] RoboDojo 有效50对两方法100条轨迹完成并逐条动作审计，失败与基础设施中断区分；原99条已审计结果和无效布局记录另行保留。
- [x] 在线报告以两方法自己的结果为主；公开数字与已有基线分开（v2 自动生成主板已发布、字节与浏览器验收通过）。
- [x] 完成两方法 RoboLab 补充评测并明确历史环境等价性限制。
- [x] 所选200个完整回合及保留原回合通过原始证据、完整视频、线上文件和同一提交CI最终验收。

## Current frontier

2026-10-08 原始公开档案恢复：已从固定版本的公共数据集取回100个核心ZIP（7,864,111,231字节），逐包SHA与原报告100条目录匹配。独立核验80,971步动作及执行后关节状态，原Direct13/50、平均Score×100=37.8125（n=48），Hybrid24/50、62.6（n=50），纠错6174步及累计Token均重算一致。原Direct含48条原生完整轨迹和2条RPC超时前缀裁定失败；本次Direct50条均原生完整，两者口径明确分列。

共同98条回合的布局、解析配置、原生时域、控制步长、决策上限和context版本全部一致。初始关节和四元数哈希均不相同，但实测最大绝对数值差仅3.2526065174565133e-18和1.4901164746561335e-08；末端位置完全相同。全部98条归档prompt仅替换一行工作目录后，其余字节完全一致。归档导出规范化了私有路径，不能把原运行prompt哈希与归档文本的差异当作语义更改。此证据只覆盖记录的机器人字段和限定文本，不能证明完整物理状态、原模型输入或闭源服务状态等价，也不能解释成功率差异。

RoboLab20个任务/方法组合的原生控制时域全部与作者视频目录相同；最终槽位不代表同seed，逐槽决策上限/重试及历史Direct实现仍缺证据。原Dojo档案提供42种源码路径，其中10个路径有多个已归档哈希，不能将最新公开源码当作所有历史回合的唯一实现。下一前沿是对这些冻结控制源码做函数级比较，并继续追溯原RoboLab Direct及逐槽预算证据；不改变现有200条回合凑原表数值。

完整RGB档案约126.7GB未取回，隐藏物理/模型状态也未恢复。本轮未调用模型或仿真，未执行任何下载源码。详见 `publication_checks/historical_protocol_20261008/original_record_recount.json`、`recovered_comparison.json`、`initial_difference_inspection.json` 和 `ORIGINAL_ARTIFACT_RECOVERY_ADR.md`；新元数据592项与初始NPZ/prompt196项另行绑定，不改写原终验证明。历史严格等价与整篇blog全部复现仍未证明。

## Completed native milestone

2026-10-07 最终完成状态：

所选两套固定范围评测已全部完成：RoboDojo 100/100 回合、50/50 对；RoboLab 100/100 回合、50/50 对。RoboLab 队列于 2026-10-07 08:24 UTC 自然结束，全部100份原归档verified，requires_repair=0、pending=0、活动保留槽为0。

联合终验于 2026-10-07 09:34:13 UTC 完成，status=complete、full_reproduction_complete=true。原始证明绑定报告提交 `5d7a430557ba91da93a16b5b174305ded275bf39`，同提交 CI `37594282741` 成功；覆盖所选200条及另存原布局1条，共232427项原审计输入、整份RoboLab归档、原始及导出完整视频，并核验815个公开文件。证明封存于 `final_verification/5d7a430557ba91da93a16b5b174305ded275bf39/certificate.json`，SHA256 `cc38b42cfcf0c098c2ad58a3af9a2e265fc1bd3b6e92ddeeae7208f18e4b3ee9`。后续交付不覆盖原证明或刷新原验收时间。

最终成功数：RoboDojo Direct 13/50（平均score 0.395）、Hybrid 21/50（平均score 0.548）；RoboLab Direct 49/50、Hybrid 46/50。所有原生完整失败保留并计入分母。原RoboDojo面板99/100和49对另行报告，与有效面板共享49对，不能相加作为独立样本；无效layout4按已批准方案整对改为预冻结layout5。

本轮只读重核200条所选及1条保留原审计证明的SHA、815个当前发布文件的SHA、19份冻结v5源码和精确提交CI，均与封存证明一致。证据：`publication_checks/completion_delivery_20261007/evidence_binding.json`。完成队列已禁用自启动；模型文字探测、周期发布和周期联合验收已停用，原归档恢复及私有冷归档维护仍启用。只停用已无活动进程的单元，未中断任何物理回合。

RoboLab Direct 使用本项目EEF适配器；历史Direct源码、prompt及完整物理初态不可得，未独立重算IK。本次完成指上述冻结范围的执行、审计和交付，不声称与历史实验逐位环境等价。最终交付说明见 `COMPLETION_20261007.md`。

最终公开交付已于 2026-10-07 11:08 UTC 核验：提交 `69b9902ec6a84adec64a667607abfe28cb790ebc` 的 CI `37611841778` 成功，15个在线文件与提交字节一致；公开下载包 `downloads/infrastructure_bundle_20261007T110456Z.tar.gz` 的905份文件SHA逐项通过，归档SHA256 `0c70bdc83a89440cd4ac8e0540196dde813e2170a29417c2ffb8b6fd3a3a083d`。公开 `data/reproduction-completion.json` 与封存原件逐字节一致；原终验提交和时间保持不变。具体证明：`publication_checks/completion_delivery_20261007/public_bundle_verified.json`、`exact_commit_ci.json`、`publication_http.json`。本次约定范围无剩余原生回合、审计或发布阻塞。

## Historical frontier（2026-10-07 05:23 UTC，保留过程）

2026-10-07 05:23 UTC：所选RoboDojo100/100、50/50配对已整组核验，原面板99/100另行保留；Direct成功13/50、Hybrid成功21/50，完整失败计入分母。
RoboLab完整审计78/100、35/50配对，首组三条新盘回合均已独立验收；新完成回合继续由归档计时器核对。新SSD首组三条RubiksCube原生回合均成功（Hybrid129/130步，Direct132步），均已归档并完整动作审计。尚余22条原生回合与最终联合验收，full_reproduction_complete=false。上次新增25条证书和Dojo101条原证据证书保持原样。
最新新增CannedFood seed3 Hybrid成功529步已独立重核549项原审计输入、整份原归档、原始及导出视频完整解码、4个公开文件和提交1459b34f36edb2289ead08998187f511c7ecc408的CI37572550806；35对原始初始场景指纹一致，不声称完整checkpoint或历史逐位等价。
发现连接停止后的TIME_WAIT使v4本机端口检查报errno98，三个监督器在创建输出前退出，三槽因此被保守保留。已按原启动身份、哈希固定v4源码顺序、本机工作/输出目录及远端目录/管理日志/进程均不存在的证明，封存三份明确标为重建的非物理失败元数据；不伪造原归档、不计原生成绩，也不绕过重试预算。
新的v5协调器于04:49 UTC自行释放三槽，04:51:12 UTC在第二ext4 SSD启动RubiksCube seed3/4 Hybrid与seed0 Direct。原v4源码/manifest及所有原生失败和中断证据保留。控制器、模型、π0.5、原生时域、资格/最早完整失败/最大3次基础设施规则不变；7个核心函数AST相同，37项相关测试通过。
策略服务的独立GPT-6-astra/xhigh文字READY探测通过，沿用原已授权登录；每10分钟检查、900秒过期，失败只阻止新启动，不消耗尝试、不干预活动物理回合。报告正常推送与线上字节验证已恢复。三条新回合的实际worker均为gpt-6-astra/xhigh，私有工作目录、SQLite及WAL全部位于第二SSD；已观察新原生控制步进，见runtime_verified.json，未计入尚未终止的回合成绩。
新SSD首组三条完整回合又独立核验537项原审计输入、整份原归档、原始及导出视频完整解码、12个公开文件、35对原始初始场景指纹及同提交071b6b0的CI37575094467；证书publication_checks/ssd_native_complete_20261007/new_native_certificate.json。
证据：publication_checks/launch_recovery_20261007；运行决定：ROBOLAB_LAUNCH_GUARD_ADR.md。下一前沿是持续完成剩余RoboLab回合，再核验所选200条和保留原回合的全量原始证据、公开视频、同一提交CI，不能据此提前宣称全部复现完成。

用户在上次可审阅的layout5补齐方案之后再次要求“继续推进”。本轮按此续推进指令执行该方案，
记录为user_continue_20261006_after_reviewable_replacement_proposal：另建有效50对清单，
只将imitate_sorting_sequence layout4整对替换成同一原60案例面板中预冻结的下一编号layout5，
补跑Direct和Hybrid两条新原生回合。原50案例清单、全部旧结果、完整失败与无效布局尝试均保留；
原面板与有效面板分别报告，不能相加为独立样本，也不选择两方法中更好的结果。

layout4已有五次Hybrid完整1600步原生排除。保持初态、零模型/零π推理的独立诊断，
同样于432步得到原辅助臂验证失败（aim2手表不在basket1），走满1600步仍无效。
layout5通过相同冻结原生配置的553步演示检查，并走满1600步诊断。
两条诊断3200条动作全部核对为保持初态，各1601帧原视频；诊断不计作模型实验。
底层抓取/物理重放原因尚未完全证明，未修改原生判定、轨迹、prompt、模型或时域。

v6有界原生无效重试队列已于2026-10-05T14:28:01.696574+00:00在物理回合边界切换成功；
原资格函数与最早有效原生失败/审计缺口优先级保留。原v6及RoboLab v2冻结源码不改写。
新补齐队列独立状态、使用相同执行锁，只负责layout5两方法，完整失败和审计缺口仍阻止物理替代。
不可变有效清单及原文件/诊断SHA核验见fixtures/robodojo_valid_cohort_v2.json，
显式选择指针为fixtures/robodojo_active_cohort.json；layout5两方法已原生终止并完整审计，独立页面上线验收通过；RoboLab及最终联合验收仍在进行。

旧RoboLab归档积压已经清零：截至2026-10-05T12:59:08.758233+00:00，最早原生完整回合18条全部完成原归档与完整动作审计，
summary为verified18/requires_repair0/pending0。ClutterPumpkinTask seed0/1 Hybrid原生成功801/632步，seed2原生失败1350步，三条完整结果均保留。
新验收器再次核对三条原回合的3015个审计输入、整份原归档manifest与原传感视频帧数，均通过。

RoboDojo build_tower standard layout3 Direct已原生完整失败1050步/210决策，完整审计通过并按原失败计分。
旧启动超时缺项已全部完成原生回合及完整审计；唯一未完成项为上述原生演示无效布局。后续启动等待保持1200秒。
修复了报告把invalid_native_layout当作audit_pending候选而永久挡住有效重试的问题：
仅原生eligibility=false、success/score=null且冻结身份匹配的无效布局排除。
有效完整失败和最早有效完整审计缺口继续保留。实站漏掉的新原因标签也已补齐，34项站点回归与真实构建通过。

新增verify_reproduction_completion.py及14项验收边界回归，gpt-policy-final-verification.timer已enabled。
覆盖未满时只记录pending_native_episodes，不启动模型或仿真；两套均100/100与50/50后才扫描全部原审计输入、
最早有效原生回合、每一步传感视频、全视频解码及所选200回合、保留原面板回合与面板元数据全部公开文件的字节/hash，并核对同一提交CI。
完成证明按提交存入final_verification/<commit>/certificate.json，保留原验收时间；full_reproduction_complete当前false。
两条真实已停止原回合共3400个审计输入已用新验收器复核，完整原视频帧数1051/557通过，不代替200条最终验收。

RoboLab后续监督器在慢归档前保存原生结果和完整控制器输出、同步controller_finished阶段；
复制中断先保留原结果，冻结v2会标成audit_failed并禁止新的物理替代，原完整失败不能被后续成功覆盖。
旧监督器的seed4原归档已完成，新ClutterPumpkin进程已实际加载新保存逻辑并核对源码SHA一致；不重连或重放不确定动作。
RoboLab v2切换、2228文件完整资产和独立空闲GPU选择已实际验证，两个冻结调度器SHA保持不变。
活动SQLite继续位于本机/tmp；已封存工作区与状态自动转存私有NAS，报告与归档恢复timer继续运行。

下一前沿是继续RoboLab矩阵至100/100和50/50，再执行所选200回合及保留原回合的最终全量在线验收。
RoboLab Direct为本项目EEF适配器；历史源码/完整初态未公开，不声称逐位环境等价或独立重算IK。
详细证据见RUNBOOK.md、ROBOLAB_ARCHIVE_DIAGNOSIS.md及publication_checks/remediation_20261005。

## Decisions

- 2026-10-06：在可审阅的layout5整对补齐提案之后，按用户“继续推进”执行独立有效50对面板；原50对结果与失败统计保留并分别发布，原冻结文件不改写。

- 2026-09-16：用户明确“主要复现这个文档自己的两种方法就行”；优先级覆盖此前全模型扩展范围。
- 停止继续运行独立π0.5基线队列和额外模型传输；不删除已下载资产和历史结果。
- 2026-09-16追加授权：用户明确要求直接使用当前Codex CLI的GPT-6 Astra。通过CLI自身认证复用当前登录态，不复制、不输出凭据；SQLite运行状态保持每次实验独立。该决定覆盖此前要求单独实验账号的限制。
- 既有历史目标保存在 GOAL_before_scope_correction_20260916.md，仅供追溯。

## Evidence

report_interpretation_zh.md、infra/run_original_controller.sh、现有仿真与π0.5审计记录。在线报告：https://asimfish.github.io/gpt-as-policy-repro/scenes.html 。当前在线报告已以两种主方法的自有结果为主；有效RoboDojo 50个配对已完成并整组复核，RoboLab补充与最终联合验收仍未完成。


2026-10-06补齐执行进展：独立清单SHA256为d0b76047a1f570f964b6987550538982f49182ba321a07c568f7ba1d2c7473cd。`gpt-policy-robodojo-supplement-v2.service`已enabled并于22:43:13UTC启动；Direct layout5新物理回合运行中，Hybrid随后执行。真实构建与页面验证：原面板99/100、49对，独立有效面板98/100、49对，RoboLab21/100、6对；桌面与390px手机验证通过，两面板筛选、深链接与完整视频实际播放均通过。已停止回合的自动私有状态转存已支持新增案例，仍执行同一哈希固定的v5完整资格检查并拒绝活动worker；六项回归通过。验收器16项回归通过，当前记录pending_native_episodes，不生成完成证书。页面及新基建包的线上精确字节验证另行记录，尚未完成时不得声称发布完成。


2026-10-06发布验收完成：提交419ca6f17982d498194dc5661de263c6d2183bdb，GitHub Pages工作流37385101951成功；14个网页/JSON/资源/包的提交字节与线上SHA全部匹配。原面板99/100、独立有效面板98/100（两者均49对，互有重叠），RoboLab21/100、6对。新页面为https://asimfish.github.io/gpt-as-policy-repro/gpt-methods-valid.html 。基建包`deliverables/infrastructure_bundle_20261006T065300Z.tar.gz`含832个文件，SHA256=5f5b05d2cf1296556f22c3c637aa17c52b87da7fc36ccd3caf878ce26a1c79c4；公开下载后逐个核对832成员和7个核心源码/冻结清单，全部通过。旧基建包与全部原回合保留。发布、归档、磁盘维护与最终验收timer恢复运行；layout5两方法补齐服务和RoboLab v2队列持续执行。全量验收仍为pending_native_episodes/full_reproduction_complete=false。证据目录publication_checks/valid_cohort_20261006。

线上桌面/手机最终浏览器复核也已通过（提交419ca6f17982d498194dc5661de263c6d2183bdb）：原99回合、独立有效98回合、RoboLab21回合分别与JSON一致；两面板50行、筛选、深链接、390px宽度和真实视频播放通过，页面错误为零。补齐Direct已核对gpt-6-astra/xhigh真实worker和执行动作；旧v5、v6及RoboLab v2的三个源码SHA保持完全一致。


2026-10-06 RoboLab有界并行推进：在不改写冻结100条身份、原模型/prompt/原生时域和首次完整失败/审计缺口规则的前提下，实现最多3个独立原生回合。设计与两种方案权衡见ROBOLAB_PARALLEL_ADR.md；v3直接装载SHA固定的v2资格/选择函数，原v2、原监督器与服务源码不改写。独立锁、端口、GPU预约、Linux boot/start身份、先持久化后单次启动及不确定ACK保留预约均有回归；退出只排空已启动回合。22项相关基建测试、40项报告测试和16项最终验收边界测试通过。远端新管理器已原子部署且读回SHA=18a33b59f78b6effefcb7b839beabcfd92575cdbce931fbeef69f435ed0cfefe。`gpt-policy-robolab-parallel-handover-20261006.service`已enabled，当前等待v2回合物理/清理/归档锁释放，尚未启动并行模型回合。报告已实现多个活动回合的脱敏进度，运行中回合不计入成绩。证据publication_checks/parallel_queue_20261006；调度源码及冻结SHA见robolab_queue_scheduler_v3_manifest.json。

本轮独立再核验ClutterPumpkin seed3 Hybrid原生失败1350步、seed4 Hybrid成功871步、seed0 Direct成功766步共4303份原审计输入、整份原归档及原视频逐步帧数，全部通过，失败保持。全量结果仍为有效RoboDojo98/100、49/50对，原面板99/100、49/50对，RoboLab21/100、6/50对；full_reproduction_complete=false。并行队列切换与新版报告/包发布应分别核对实际运行、提交和在线字节证据，不能以部署准备当作回合完成。


2026-10-06有界并行基建发布验收：源码提交e00aa7430d22122c2a3efd789435bca368084927，实际网页提交1fdd2e2865a07c54ff9db34a2dcd3daeb625135f，Pages CI37392587664成功；14个公开文件精确字节核验完成，本地与线上桌面/390px手机检查均通过，原面板99、有效面板98及RoboLab21条回放/JSON分别一致、页面错误为零。新不可变基建包deliverables/infrastructure_bundle_20261006T081000Z.tar.gz含844文件、938483字节、SHA256=26fe9bd81285ff00db5e3b2e3a8513845e5306d6d233053f2b3596156f897cb8；公开下载后逐个成员复核通过，包含新ADR、v3清单、部署凭证及去私有环境的服务模板。此前832文件包与全部原回合保留。证据publication_checks/parallel_queue_20261006/checkpoint.json。切换服务仍在等当前原生回合/清理/归档边界，不能宣称已运行三个并行回合；完整实验验收保持pending_native_episodes/full_reproduction_complete=false。


2026-10-06 08:22 UTC交付验收：提交a67cfc7187f1981b5b5d3c590b1fdb048addf0c1，Pages CI37435364490成功，14个公开文件精确字节一致。基建包deliverables/infrastructure_bundle_20261006T082000Z.tar.gz含851文件、983162字节，SHA256=0917f686b2a08c3d0fbfb546beff00ebe3e2b9a806966b886b911df315bc0fd6；公开下载逐成员核对通过，RoboDojo里程碑证书原件一致，旧包保留。新增Direct ReorientRedMug seed0完整成功760步，1993份原输入、整份原归档及原视频逐步帧数再核验通过；本轮新增原证据合计27条/20897项。最终联合验收已刷新为所选RoboDojo100/50对、RoboLab48/23对，pending_native_episodes/full_reproduction_complete=false；三个原生worker继续执行，全部维护timer活动。详细证据publication_checks/robodojo_completed_20261006/checkpoint.json。


## 2026-10-06 14:59 UTC：后续回合转用第二块本地SSD

系统ext4盘可用空间从14:25的9.3GiB降至14:45约5.9GiB，全部73个已审计停止工作区已按原字节验证转存NAS。另一块本地ext4 SSD约867GiB可用；选项与边界见ROBOLAB_LOCAL_STORAGE_ADR.md。新v4仅将后续新回合local_workspace配置为固定私有目录/data/liyufeng/agentic_robot_runtime/gpt_policy_repro_20260914，不搬移活动SQLite，不修改原控制器/原prompt/模型/原生时域/GPU/端口/资格规则。原v3两入口、远端管理器、v2 Oracle与全部原结果保留且SHA不变；v4 JSON清单robolab_queue_scheduler_v4_manifest.json绑定完整新源码与原出处。

第二SSD实际SQLite WAL和双独立连接读写成功，零模型/仿真调用；7项存储根拒绝边界、7项原停止工作区维护与14项原并行预约/接管测试在v4上通过。原选取与清理的7个函数AST一致。只停止旧协调PID，三个原生监督器、控制器、SSH隧道及工作目录在切换前后boot/start身份保持，动作进度不回退；v4已enabled并接管同一flock和durable leases。首次启动被公开模板的EnvironmentFile占位路径阻挡，ExecStart未执行；复用既有部署环境后启动正常，未复制认证。v3服务disable，源码和单元保留，v4服务活动。

原三回合仍使用/tmp；下一原生回合才创建新SSD工作区，尚未观察到新盘实际模型回合，不能将预检等同于回合完成。归档维护已支持两个明确根，仍要求停止/完整审计/每文件SHA与NAS保留，拒绝任意外部路径。证据publication_checks/local_ssd_20261006。剩余RoboLab由队列继续，整体验收false。


2026-10-06 15:12 UTC最终本轮交付检查：提交f8f54b668155af9153f1ca5749093496feed18dc的Pages CI37484663997成功，14份网页/数据/包精确字节一致；公开包deliverables/infrastructure_bundle_20261006T150154Z.tar.gz含869文件、1016908字节，SHA256=7996f09c46ad8f0246c686efb2f82f6e060b85ce50b4a2ae8432050fd702b855；公开下载逐成员及新增原生核验证书、v4清单、接管证明字节一致。原860、851及更早包保留。线上桌面/390px手机筛选、深链接、真实Direct/Hybrid视频播放无错误；原99、有效100、RoboLab73/35对分开一致。64次相关边界/兼容/公开包检查执行通过，不代替完整实验。终验刷新为RoboDojo100/50对、RoboLab73/35对，pending_native_episodes/full_reproduction_complete=false。v4三worker实际控制计数497/399/140，身份均存活，当前仍为原/tmp目录；新盘实际模型回合尚待自然释放槽位后观察。原归档verified73/repair0/pending0；全部维护timer活动。证据publication_checks/local_ssd_20261006/checkpoint.json。

2026-10-07 05:22 UTC交付核验：最新报告提交26be905581bb339754e6dafc9b33b40a53adfcbe、Pages CI37575665886及14份公开文件逐字节一致；基建包infrastructure_bundle_20261007T051618Z.tar.gz共898文件、1055991字节，SHA256 6e4a885624509f8ff2e870e7677c707fbe236c7d777345bb8e394b7d5491a2f6，在线下载后逐成员SHA核验通过。新SSD首组三条原回合均通过独立全证据/双视频/12HTTP文件/同CI验收；下一组三条Direct持续推进，完整失败与历史中断保留。整体最终验收仍待剩余原生回合完成。

2026-10-07 05:23 UTC运行增量：RoboLab已完整动作审计78/100，剩余22条；RubiksCube seed2 Direct已完成并进入自动发布，当前已验证线上快照仍为77条（26be905）。三槽接续seed1/3/4 Direct，完整成绩不重跑。原归档维护与报告/最终验收计时器均持续运行，首次归档维护遇到其他监督器持有的归档锁时保留原证据，下次维护重核，不是新的物理失败。

2026-10-08 02:40 UTC原blog对照实际交付：提交`f5585f035dfc601663877813d6f4df421689b514`、同提交CI`37718766832`成功，17个线上文件精确字节一致；927文件新包`downloads/infrastructure_bundle_20261008T023323Z.tar.gz`公开下载逐成员SHA通过，归档SHA256`720891491cfb0d66642d4ab17275788dae27caca8a2a0f5b789933c1ecd582e2`。统计JSON与包内原件同SHA；公开原终验证明与封存cc38b42c...原件逐字节一致。线上桌面/390px浏览器通过，截图与本地同SHA，Git工作树干净。comparison_delivery=PASS；historical_equivalence_verified=false、whole_blog_full_reproduction_complete=false。原200回合完成状态保留，所有完成队列/模型健康/周期发布/周期终验单元继续inactive，timer继续disabled。证明`publication_checks/blog_alignment_20261008/checkpoint.json`。
