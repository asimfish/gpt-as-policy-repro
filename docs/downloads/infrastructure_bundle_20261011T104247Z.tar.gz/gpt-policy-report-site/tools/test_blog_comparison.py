"""Denominator, alignment and public-data drift oracles for blog comparison."""
import hashlib,json,shutil,tempfile,unittest
from pathlib import Path
from blog_comparison import budget_observation,compare_cases,indexed,metrics,task_comparison,verify_public,recovered_summary,worker_fidelity_summary,validate_worker_fidelity,validate_historical_execution,load_historical_execution


def row(case='shared',success=False,score=None):
    return dict(case_id=case,method='gpt_only',task='task',success=success,score=score,
                steps=10,chunks=2,corrected_steps=0,tokens=None,seeds={'layout_id':0},evidence='data/evidence.json')

class HistoricalResultAlignmentTest(unittest.TestCase):
    def fixture(self):
        episodes=[];originals=[];hashes={}
        for i,(own_complete,original_complete,own_success,original_success,own_score,original_score) in enumerate([
                (True,True,True,True,1.0,1.0),
                (True,True,False,True,.3,1.0),
                (False,True,None,True,None,1.0),
                (True,False,False,False,.5,None),
                (False,False,None,False,None,None)]):
            episode='direct__case_'+str(i)
            episodes.append(dict(episode_id=episode,method='gpt_only',
                status='native_complete_audited' if own_complete else 'infrastructure_failed',
                native_success=own_success,native_score=own_score,
                native_actions=886 if own_complete else None,decisions=60 if own_complete else None))
            originals.append(dict(episode_id=episode,method='direct',native_complete=original_complete,
                evaluation_success=original_success,native_score=original_score,
                control_steps=867,decision_count=61,core_sha256='a'*64))
            hashes[episode]='b'*64
        return episodes,originals,hashes

    def test_alignment_preserves_incomplete_denominators_and_actual_differences(self):
        from blog_comparison import historical_result_alignment
        episodes,originals,hashes=self.fixture()
        result=historical_result_alignment(episodes,originals,hashes)
        self.assertEqual(result['summary'],dict(audited_attempts=5,own_complete_native=3,both_native_complete=2,
            own_incomplete_unscored=2,original_incomplete_excluded=1,both_incomplete_unscored=1,
            success_matches=1,success_differences=1,score_matches=1,score_differences=1,
            control_step_matches=0,control_step_differences=2))
        self.assertEqual([r['comparison_status'] for r in result['records']],
            ['same_result','different_result','own_incomplete','original_incomplete','both_incomplete'])
        for row in result['records'][2:]:
            self.assertIsNone(row['success_match']);self.assertIsNone(row['score_match'])
        self.assertIsNone(result['records'][3]['original_native_success'])
        self.assertFalse(result['records'][3]['original_evaluation_success'])

    def test_duplicate_or_missing_original_identity_is_rejected(self):
        from blog_comparison import historical_result_alignment
        episodes,originals,hashes=self.fixture()
        with self.assertRaises(AssertionError):historical_result_alignment(episodes,originals+[originals[0]],hashes)
        with self.assertRaises(AssertionError):historical_result_alignment(episodes,originals[1:],hashes)

    def test_mismatched_method_or_invalid_score_or_source_digest_is_rejected(self):
        from blog_comparison import historical_result_alignment
        for field,value in [('method','hybrid'),('native_score',True),('native_score',float('nan')),('core_sha256','wrong')]:
            episodes,originals,hashes=self.fixture();originals[0][field]=value
            with self.subTest(field=field,value=value),self.assertRaises(AssertionError):
                historical_result_alignment(episodes,originals,hashes)

    def test_incomplete_attempt_cannot_become_a_scored_difference(self):
        from blog_comparison import historical_result_alignment
        episodes,originals,hashes=self.fixture();episodes[2]['native_score']=0
        with self.assertRaises(AssertionError):historical_result_alignment(episodes,originals,hashes)

    def test_matching_control_step_count_does_not_claim_matching_trajectory(self):
        from blog_comparison import historical_result_alignment
        episodes,originals,hashes=self.fixture();originals[0]['control_steps']=886
        result=historical_result_alignment(episodes,originals,hashes)
        self.assertEqual(result['summary']['control_step_matches'],1)
        self.assertNotIn('trajectory_verified',result)
        self.assertFalse(result['historical_protocol_equivalence'])

    def test_alignment_summary_or_gate_binding_cannot_be_changed(self):
        from blog_comparison import historical_result_alignment
        episodes,originals,hashes=self.fixture()
        for row in episodes:
            row.update(automatic_physical_retries=0,first_attempt_retained=True,
                source_video=dict(frames=887,complete_decode_passed=True))
        execution=BlogComparisonTest().physical_pilot();queue=execution['remaining_cohort']
        queue.update(first_attempts_audited=5,native_complete_audited=3,episode_results=episodes,
            status_counts={'native_complete_audited':3,'infrastructure_failed':2})
        alignment=historical_result_alignment(episodes,originals,hashes)
        alignment['original_record_recount_sha256']='c'*64
        queue['original_result_alignment']=alignment
        execution['evidence_sha256']={'historical_protocol_20261008/original_record_recount.json':'c'*64,
            **{'historical_cohort_20261010/episode_evidence/'+episode+'/evidence_gate.json':digest for episode,digest in hashes.items()}}
        validate_historical_execution(execution)
        alignment['summary']['score_differences']=0
        with self.assertRaises(AssertionError):validate_historical_execution(execution)
        alignment['summary']['score_differences']=1
        alignment['records'][0]['own_gate_sha256']='d'*64
        with self.assertRaises(AssertionError):validate_historical_execution(execution)

    def test_panel_discloses_both_incomplete_and_differing_results(self):
        from blog_comparison import historical_result_alignment,historical_alignment_panel
        episodes,originals,hashes=self.fixture()
        panel=historical_alignment_panel(historical_result_alignment(episodes,originals,hashes))
        self.assertIn('双方原生完整 2条',panel)
        self.assertIn('分数 1条一致、1条不同',panel)
        self.assertIn('本次未完整 2条不计成绩',panel)
        self.assertIn('另 1条本次完整而原记录未原生完整',panel)
        self.assertIn('控制步数相同不证明动作轨迹相同',panel)
        self.assertEqual(panel.count('<tr data-episode-id='),5)
        self.assertIn('双方未完整',panel)

    def test_author_values_cannot_be_forged_while_retaining_the_record_digest(self):
        from blog_comparison import historical_result_alignment,validate_historical_author_alignment
        episodes,originals,hashes=self.fixture()
        alignment=historical_result_alignment(episodes,originals,hashes)
        alignment['original_record_recount_sha256']='c'*64
        public=[dict(case_id=r['episode_id'].split('__',1)[1],method='gpt_only',
            native_complete=r['native_complete'],success=r['evaluation_success'],
            score=r['native_score'],steps=r['control_steps']) for r in originals]
        recovery=dict(original_record_recount_sha256='c'*64,original_archives=[
            dict(case_id=r['case_id'],method=r['method'],core_sha256='a'*64) for r in public])
        validate_historical_author_alignment(alignment,public,recovery)
        alignment['records'][0]['original_native_score']=.8
        with self.assertRaises(AssertionError):validate_historical_author_alignment(alignment,public,recovery)


class BlogComparisonTest(unittest.TestCase):
    def physical_pilot(self):
        rows=[dict(method=m,status='native_complete_audited',benchmark_eligible=False,native_success=False,
                   native_score=.3,native_actions=1050,decisions=n,
                   source_video=dict(frames=1051,complete_decode_passed=True),
                   historical_protocol_equivalence=False,full_blog_reproduction_complete=False)
              for m,n in [('gpt_only',210),('pi05_plus_gpt',127)]]
        value=dict(verified=True,historical_protocol_equivalence=False,full_blog_reproduction_complete=False,
                   pilot_included_in_benchmark=False,automatic_physical_retries=0,canary_results=rows,
                   remaining_cohort=dict(pairs_planned=49,episodes_planned=98,pilot_reused_for_grading=False,
                                        native_complete_audited=0,first_attempts_audited=0,automatic_physical_retries=0,
                                        historical_protocol_equivalence=False,full_blog_reproduction_complete=False))
        return value

    def test_physical_pilot_cannot_become_historical_or_benchmark_completion(self):
        value=self.physical_pilot();validate_historical_execution(value)
        value['pilot_included_in_benchmark']=True
        with self.assertRaises(AssertionError):validate_historical_execution(value)
        value['pilot_included_in_benchmark']=False;value['full_blog_reproduction_complete']=True
        with self.assertRaises(AssertionError):validate_historical_execution(value)

    def continuation_fixture(self,root):
        def put(name,value):
            path=root/name;path.parent.mkdir(parents=True,exist_ok=True)
            data=(json.dumps(value)+'\n').encode();path.write_bytes(data)
            return hashlib.sha256(data).hexdigest()
        q='publication_checks/worker_fidelity_20261008/'
        out='publication_checks/historical_cohort_20261010/'
        pilot='historical_worker_campaign/pilot'
        pair={'pilot':True};pair_sha=put(pilot+'/pair_plan.json',pair)
        put(q+'historical_pair_preflight.json',pair)
        admission_sha=put(q+'historical_canary_admission.json',dict(plan_sha256=pair_sha))
        rows=[];records=[]
        for method,decisions in [('gpt_only',210),('pi05_plus_gpt',127)]:
            proof_sha=put(pilot+'/'+method+'/complete_action_audit.json',dict(verified=True,complete_episode=True,native_actions=1050,decisions=decisions,files_sha256={}))
            video=root/pilot/method/'sim/sensors.mp4';video.parent.mkdir();video.write_bytes(b'fixture-video')
            put(pilot+'/'+method+'/sim/evaluation_outcome.json',dict(native_success=False,native_score=.3))
            rows.append(dict(self.physical_pilot()['canary_results'][len(rows)],episode_id=method,
                             complete_action_audit_sha256=proof_sha,source_video=dict(frames=1051,complete_decode_passed=True,sha256=hashlib.sha256(video.read_bytes()).hexdigest())))
            records.append(dict(episode_id=method,native_score=.3,evaluation_success=False,decision_count=decisions))
        put(q+'historical_canary_evidence_gate.json',dict(verified=True,complete_native_audited=2,admission_sha256=admission_sha,plan_sha256=pair_sha,cohort=pilot,results=rows))
        manifest_sha=put(q+'historical_worker_manifest.json',{})
        source_sha=put('controller.json',{'source':'distinct-from-plan'})
        plan_sha=put(out+'cohort_plan.json',dict(episodes_planned=98,pairs=[{} for _ in range(49)],physical_retry_limit=0,
                     pilot=dict(reused_for_grading=False),source_sha256={'controller.json':source_sha},
                     receipt_sha256={'historical_worker_manifest.json':manifest_sha},model='gpt-6-astra',cli_version='codex-cli 0.153.4'))
        self.assertNotEqual(source_sha,plan_sha)
        put(out+'activation.json',dict(plan_sha256=plan_sha));put(out+'implementation_checks.json',{})
        prefix='continuation_evidence/20261010T095831Z/'
        available=dict(verified=True,model_available=True,reply_exact_ok=True,model='gpt-6-astra',cli_version='codex-cli 0.153.4',
                       checked_utc='2026-10-10T09:30:47Z',model_turn_start_calls=1,service_tools_registered=0,simulator_steps=0,authentication_copied=False)
        available_sha=put(out+prefix+'availability.json',available)
        resumed=dict(plan_sha256=plan_sha,availability_sha256=available_sha,physical_retry_limit=0,original_execution_source_unchanged=True,source_sha256={'controller.json':source_sha})
        resumed_sha=put(out+prefix+'admission.json',resumed)
        snapshot=dict(plan_sha256=plan_sha,captured_utc='2026-10-10T11:03:39Z',observed_native_steps=0,
                      episode_evidence_sha256={},progress=dict(episodes_planned=98,first_attempts_audited=0,results=[],native_complete_audited=0,phase='running',current_episode=None),
                      continuation=dict(admission_path=prefix+'admission.json',admission_sha256=resumed_sha,availability_path=prefix+'availability.json',availability_sha256=available_sha))
        put(out+'runtime_snapshot.json',snapshot)
        record_sha=put('publication_checks/historical_protocol_20261008/original_record_recount.json',dict(verified=True,records=records))
        put('publication_checks/historical_protocol_20261008/recovered_comparison.json',
            dict(verified=True,original_record_recount_sha256=record_sha))
        for name in ['current_service_probe.json','failure_contract.json','implementation_checks.json','activation.json']:
            put('publication_checks/historical_resume_20261010/'+name,{})
        return put,snapshot,resumed,out,prefix

    def test_continuation_matches_plan_after_distinct_controller_source_hash(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);self.continuation_fixture(root)
            value=load_historical_execution(root)
            self.assertEqual(value['remaining_cohort']['first_attempts_audited'],0)
            self.assertTrue(value['service_availability_at_continuation']['model_available'])

    def test_continuation_rejects_wrong_plan_even_with_valid_document_hash(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);put,snapshot,resumed,out,prefix=self.continuation_fixture(root)
            resumed['plan_sha256']='another-plan'
            snapshot['continuation']['admission_sha256']=put(out+prefix+'admission.json',resumed)
            put(out+'runtime_snapshot.json',snapshot)
            with self.assertRaises(AssertionError):load_historical_execution(root)

    def test_historical_alignment_rejects_changed_author_record_bytes(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);self.continuation_fixture(root)
            path=root/'publication_checks/historical_protocol_20261008/original_record_recount.json'
            value=json.loads(path.read_text());value['records'][0]['native_score']=.5
            path.write_text(json.dumps(value)+'\n')
            with self.assertRaises(AssertionError):load_historical_execution(root)

    def test_remaining_cohort_cannot_count_prefix_as_complete(self):
        value=self.physical_pilot();value['remaining_cohort']['native_complete_audited']=1
        with self.assertRaises(AssertionError):validate_historical_execution(value)

    def test_startup_or_prefix_failures_cannot_acquire_native_scores(self):
        value=self.physical_pilot();queue=value['remaining_cohort']
        prefix=dict(episode_id='hybrid__case',method='pi05_plus_gpt',status='controller_incomplete',
                    automatic_physical_retries=0,first_attempt_retained=True,native_success=None,native_score=None)
        startup=dict(prefix,episode_id='direct__case',method='gpt_only',status='startup_failed_no_execution',
                     stopped_prefix_actions=0,runtime_identity_verified=False,failure_reason='usageLimitExceeded')
        queue.update(first_attempts_audited=2,episode_results=[prefix,startup],
                     status_counts={'controller_incomplete':1,'startup_failed_no_execution':1})
        validate_historical_execution(value)
        for row in queue['episode_results']:
            row['native_score']=0
            with self.assertRaises(AssertionError):validate_historical_execution(value)
            row['native_score']=None
        startup['runtime_identity_verified']=True
        with self.assertRaises(AssertionError):validate_historical_execution(value)

    def test_historical_attempt_duplicates_and_inconsistent_complete_counts_fail(self):
        value=self.physical_pilot();queue=value['remaining_cohort']
        row=dict(episode_id='direct__case',method='gpt_only',status='controller_incomplete',
                 automatic_physical_retries=0,first_attempt_retained=True,native_success=None,native_score=None)
        queue.update(first_attempts_audited=2,episode_results=[row,dict(row)],status_counts={'controller_incomplete':2})
        with self.assertRaises(AssertionError):validate_historical_execution(value)
        queue.update(first_attempts_audited=1,episode_results=[row],status_counts={'controller_incomplete':1},native_complete_audited=1)
        with self.assertRaises(AssertionError):validate_historical_execution(value)

    def test_report_discloses_infrastructure_failure_with_other_unscored_attempts(self):
        from blog_comparison import worker_fidelity_panel
        execution=self.physical_pilot()
        for result in execution['canary_results']:
            result['original_native_score']=.05
        execution['remaining_cohort'].update(captured_utc='2026-10-11T04:45:20Z',
            current_episode_at_snapshot='hybrid__case',observed_native_steps=0,
            phase_at_snapshot='blocked_infrastructure_requires_review',first_attempts_audited=3,
            episode_results=[dict(status='controller_incomplete',stopped_prefix_actions=656),
                dict(status='startup_failed_no_execution'),dict(status='infrastructure_failed')])
        panel=worker_fidelity_panel(dict(historical_worker_fidelity=dict(
            common_summary=dict(crosses_original_five_rejection_stop=11),
            initial_model_rgb_difference_summary={'camera':dict(mean_absolute_channel_difference_mean=1)},
            original_version_execution=execution)))
        self.assertIn('1次基础设施失败',panel)
        self.assertIn('1次中断前缀（656个控制步）',panel)
        self.assertIn('1次零动作启动失败',panel)
        self.assertIn('上述未完成尝试均无完整成绩',panel)

    def test_recorded_fifth_stop_claim_is_recomputed(self):
        docs=Path(__file__).resolve().parents[1]/'docs'
        value=json.loads((docs/'data/blog-comparison.json').read_text()).get('historical_worker_fidelity')
        if value is None:self.skipTest('Worker reconstruction page not built yet')
        validate_worker_fidelity(value)
        rows=value['common_cases'];rows[0]['crosses_original_five_rejection_stop']=not rows[0]['crosses_original_five_rejection_stop']
        with self.assertRaises(AssertionError):worker_fidelity_summary(rows)

    def test_source_compatibility_gate_cannot_claim_historical_equivalence(self):
        docs=Path(__file__).resolve().parents[1]/'docs'
        value=json.loads((docs/'data/blog-comparison.json').read_text()).get('historical_worker_fidelity')
        if value is None:self.skipTest('Worker reconstruction page not built yet')
        value['historical_protocol_equivalence']=True
        with self.assertRaises(AssertionError):validate_worker_fidelity(value)

    def test_native_completion_coverage_does_not_impute_unknown_or_adjudicated_score(self):
        a=dict(row(success=True,score=1),native_complete=True)
        b=dict(row(),native_complete=False)
        result=metrics([a,b]);self.assertEqual(result['native_complete'],1)
        self.assertEqual(result['adjudicated_failures'],1);self.assertEqual(result['score_samples'],1)
        self.assertIsNone(metrics([row()])['native_complete'])
        self.assertIsNone(metrics([a,row()])['adjudicated_failures'])

    def test_recovered_summary_rejects_false_match_claim(self):
        docs=Path(__file__).resolve().parents[1]/'docs'
        value=json.loads((docs/'data/blog-comparison.json').read_text())
        recovery=value.get('original_record_recovery')
        if recovery is None:self.skipTest('Recovery page not built yet')
        rows=recovery['configuration_comparison']['robodojo']['cases']
        recovered_summary(rows)
        rows[0]['recorded_field_matches']['states']=not rows[0]['recorded_field_matches']['states']
        with self.assertRaises(AssertionError):recovered_summary(rows)

    def test_missing_scores_keep_success_denominator_and_are_not_zero_imputed(self):
        result=metrics([row(success=True,score=1),row(score=None)])
        self.assertEqual(result['episodes'],2);self.assertEqual(result['success_rate'],.5)
        self.assertEqual(result['score_samples'],1);self.assertEqual(result['mean_score'],1)
        self.assertIsNone(result['tokens']);self.assertEqual(result['token_samples'],0)

    def test_unknown_tokens_stay_unknown_and_cached_input_is_not_added_twice(self):
        a=row();a['tokens']=dict(totalTokens=100,inputTokens=90,cachedInputTokens=80,
             cacheWriteInputTokens=0,outputTokens=10,reasoningOutputTokens=5)
        result=metrics([a,row()]);self.assertEqual(result['tokens']['totalTokens'],100)
        self.assertEqual(result['token_samples'],1)

    def test_correction_fraction_uses_executed_control_steps(self):
        a=row();a.update(steps=100,chunks=7,corrected_steps=15)
        self.assertEqual(metrics([a])['correction_fraction'],.15)
        a['corrected_steps']=101
        with self.assertRaises(AssertionError):metrics([a])

    def test_replacement_stays_outside_common_case_denominator(self):
        old=[row(),row('layout4')];new=[row(success=True),row('layout5')]
        value=compare_cases(old,new)
        self.assertEqual(value['common_method_runs'],1)
        self.assertEqual(value['methods']['gpt_only']['changed_success_outcomes'],1)
        self.assertEqual(value['original_only'],[dict(case_id='layout4',method='gpt_only')])
        self.assertEqual(value['reproduction_only'],[dict(case_id='layout5',method='gpt_only')])

    def test_duplicate_or_different_seed_identity_is_rejected(self):
        with self.assertRaises(AssertionError):indexed([row(),row()])
        other=row();other['seeds']['layout_id']=1
        with self.assertRaises(AssertionError):compare_cases([row()],[other])

    def test_equal_total_successes_do_not_erase_task_differences(self):
        old=[row('a',True),row('b',False)];new=[row('a',False),row('b',True)]
        for rows in (old,new):
            rows[0]['task']='A';rows[1]['task']='B'
            rows.extend([dict(rows[0],method='pi05_plus_gpt'),dict(rows[1],method='pi05_plus_gpt')])
        compared=task_comparison(old,new)
        a=next(t for t in compared if t['task']=='A' and t['method']=='gpt_only')
        self.assertEqual(a['original']['successes'],1);self.assertEqual(a['reproduction']['successes'],0)
        self.assertEqual(sum(r['success'] for r in old),sum(r['success'] for r in new))

    def test_task_denominator_and_boolean_counter_corruption_rejected(self):
        with self.assertRaises(AssertionError):task_comparison([row()],[])
        a=row();a['steps']=True
        with self.assertRaises(AssertionError):metrics([a])

    def test_budget_prefix_keeps_unfinished_unknown_and_includes_boundary(self):
        records=[dict(row(success=True),decision_events=180),dict(row(),decision_events=170),
                 dict(row(success=True),decision_events=181),dict(row(),decision_events=600)]
        observed=budget_observation(records,180)
        self.assertEqual(observed['success_already_observed'],1)
        self.assertEqual(observed['native_failure_already_observed'],1)
        self.assertEqual(observed['still_unfinished_in_recorded_prefix'],2)
        self.assertEqual(budget_observation(records,500)['still_unfinished_in_recorded_prefix'],1)

    def test_board_rerender_keeps_one_comparison_panel(self):
        from render_gpt_progress import render
        docs=Path(__file__).resolve().parents[1]/'docs'
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);(root/'data').mkdir()
            for name in ['index.html','scenes.html','data/gpt-methods-progress.json',
                         'data/gpt-methods-valid-progress.json','data/blog-comparison.json']:
                shutil.copyfile(docs/name,root/name)
            render(root);render(root)
            for name in ['index.html','scenes.html','gpt-methods.html']:
                self.assertEqual((root/name).read_text().count('id="blog-comparison-summary"'),1)

    def test_real_public_comparison_rejects_changed_native_outcome(self):
        docs=Path(__file__).resolve().parents[1]/'docs'
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);(root/'data').mkdir()
            for name in ['data/blog-comparison.json','data/gpt-methods-valid-progress.json',
                         'data/robolab-methods-progress.json','data/reproduction-completion.json',
                         'blog-comparison.html','scenes.html']:
                shutil.copyfile(docs/name,root/name)
            verify_public(root)
            path=root/'data/blog-comparison.json';value=json.loads(path.read_text())
            value['reproduction_episodes'][0]['success']=not value['reproduction_episodes'][0]['success']
            path.write_text(json.dumps(value))
            with self.assertRaises(AssertionError):verify_public(root)

    def test_lab_task_outcome_drift_is_rejected(self):
        docs=Path(__file__).resolve().parents[1]/'docs'
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);(root/'data').mkdir()
            for name in ['data/blog-comparison.json','data/gpt-methods-valid-progress.json',
                         'data/robolab-methods-progress.json','data/reproduction-completion.json',
                         'blog-comparison.html','scenes.html']:
                shutil.copyfile(docs/name,root/name)
            path=root/'data/blog-comparison.json';value=json.loads(path.read_text())
            value['robolab']['tasks'][0]['reproduction_successes']=0
            path.write_text(json.dumps(value))
            with self.assertRaises(AssertionError):verify_public(root)

if __name__=='__main__':unittest.main()
