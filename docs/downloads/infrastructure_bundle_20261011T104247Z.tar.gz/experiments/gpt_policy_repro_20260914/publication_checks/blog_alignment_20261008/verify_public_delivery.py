"""Verify the new comparison delivery without changing the original native gate."""
import datetime,hashlib,io,json,subprocess,sys,tarfile,time,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[4]
ART=ROOT/'experiments/gpt_policy_repro_20260914';REPO=ROOT/'gpt-policy-report-site';OUT=Path(__file__).resolve().parent
sys.path[:0]=[str(ART/'infra'),str(REPO/'tools')]
from verify_reproduction_completion import verify_ci
from export_infra_bundle import SECRET,validate_completion_certificate
from blog_comparison import verify_public

def get(name,commit):
    url='https://asimfish.github.io/gpt-as-policy-repro/'+name+'?commit='+commit+'&verify='+str(time.time_ns())
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'gpt-policy-blog-comparison-verifier'}),timeout=45) as response:
        assert response.status==200
        return response.read()

def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def sha(data):return hashlib.sha256(data).hexdigest()

commit=subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip()
receipt=json.loads((ART/'online_publication.json').read_text())
assert receipt['status']=='published_and_http_verified' and receipt['commit']==commit
ci=verify_ci(commit)
for row in receipt['files']:
    assert row['matches'] is True and row['local_sha256']==row['online_sha256']
    expected=subprocess.check_output(['git','-C',str(REPO),'show',commit+':docs/'+row['file']])
    assert sha(expected)==row['online_sha256']
assert len(receipt['files'])==17
comparison=get('data/blog-comparison.json',commit)
assert comparison==(REPO/'docs/data/blog-comparison.json').read_bytes()
value=json.loads(comparison);assert value['historical_equivalence_verified'] is False
verify_public(REPO/'docs')
public_bundle=json.loads(get('data/infrastructure-bundle.json',commit))
assert public_bundle['full_reproduction_complete'] is True and public_bundle['contents_verified'] is True
archive=get(public_bundle['archive'],commit)
assert len(archive)==public_bundle['bytes'] and sha(archive)==public_bundle['sha256']
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
    members=tar.getmembers();names=[m.name for m in members]
    manifest=json.loads(tar.extractfile('manifest.json').read())
    assert len(names)==len(set(names)) and all(m.isfile() for m in members)
    assert set(names)=={'manifest.json'}|{r['path'] for r in manifest['files']}
    assert len(manifest['files'])==public_bundle['files'] and manifest['full_reproduction_complete'] is True
    for row in manifest['files']:
        name=Path(row['path']);assert not name.is_absolute() and '..' not in name.parts
        data=tar.extractfile(row['path']).read()
        assert len(data)==row['size'] and sha(data)==row['sha256'] and not SECRET.search(data),row['path']
    alignment=manifest['blog_comparison'];assert alignment['historical_equivalence_verified'] is False
    assert tar.extractfile(alignment['path']).read()==comparison and alignment['sha256']==sha(comparison)
    statistics=json.loads(tar.extractfile(str(OUT.relative_to(ROOT))+'/statistics_audit.json').read())
    assert statistics['verified'] is True and statistics['comparison_sha256']==sha(comparison)
    binding=manifest['completion_certificate'];sealed=tar.extractfile(binding['path']).read()
    proof=validate_completion_certificate(sealed,binding)
    assert sealed==(ROOT/binding['path']).read_bytes()==get('data/reproduction-completion.json',commit)
    assert proof['published_commit']=='5d7a430557ba91da93a16b5b174305ded275bf39'
    source_commit=manifest['source_commits']['report_site']
    for name in ('blog_comparison.py','test_blog_comparison.py','render_gpt_progress.py','publish_gpt_progress.py','verify_site.py'):
        published_source=subprocess.check_output(['git','-C',str(REPO),'show',source_commit+':tools/'+name])
        assert tar.extractfile('gpt-policy-report-site/tools/'+name).read()==published_source
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
save('exact_commit_ci.json',dict(verified=True,commit=commit,runs=ci,verified_utc=now))
save('publication_http.json',dict(verified=True,commit=commit,files=receipt['files'],verified_utc=receipt['verified_utc']))
result=dict(schema='gpt_policy_blog_alignment_public_delivery.v1',verified=True,commit=commit,verified_utc=now,
 independent_evaluation_complete=True,historical_equivalence_verified=False,
 archive=public_bundle['archive'],archive_sha256=public_bundle['sha256'],archive_bytes=len(archive),
 manifested_files=len(manifest['files']),all_payload_member_hashes_verified=True,published_files_verified=len(receipt['files']),
 native_completion_commit=proof['published_commit'],certificate_sha256=binding['sha256'],public_certificate_exact_bytes=True,
 comparison_sha256=sha(comparison),statistics_inputs=len(statistics['files_sha256']),source_commit=source_commit,exact_commit_ci=ci)
save('public_bundle_verified.json',result);print(json.dumps(result),flush=True)
