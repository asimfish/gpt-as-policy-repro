"""Publication admission reacts to audited gates, never unfinished control steps."""
import copy
from pathlib import Path
import tempfile
import unittest

from run_historical_cohort import sha
from watch_historical_incremental_publication import should_publish, check_guards


class IncrementalPublicationTests(unittest.TestCase):
    def fixture(self):
        row = dict(episode_id='hybrid__case', status='native_complete_audited',
                   native_success=False, native_score=0.3)
        progress = dict(episodes_planned=98, first_attempts_audited=1,
            native_complete_audited=1, results=[row], phase='running',
            continuation_admission='continuations/admission.json', automatic_physical_retries=0,
            historical_protocol_equivalence=False, full_blog_reproduction_complete=False)
        delivered = dict(first_attempts_audited=1, phase_at_snapshot='running')
        return progress, delivered

    def test_running_steps_do_not_trigger_a_publication(self):
        progress, delivered = self.fixture()
        progress.update(current_episode='another_case', observed_native_steps=900)
        self.assertFalse(should_publish(progress, delivered, progress['continuation_admission']))

    def test_new_audited_gate_triggers_a_publication(self):
        progress, delivered = self.fixture()
        delivered['first_attempts_audited'] = 0
        self.assertTrue(should_publish(progress, delivered, progress['continuation_admission']))

    def test_incomplete_scored_attempt_is_rejected(self):
        progress, delivered = self.fixture()
        progress['results'][0]['status'] = 'controller_incomplete'
        progress['native_complete_audited'] = 0
        for field in ('native_score', 'native_success'):
            candidate = copy.deepcopy(progress)
            candidate['results'][0]['native_score'] = None
            candidate['results'][0]['native_success'] = None
            candidate['results'][0][field] = 0 if field == 'native_score' else False
            with self.subTest(field=field), self.assertRaisesRegex(ValueError, 'incomplete'):
                should_publish(candidate, delivered, progress['continuation_admission'])

    def test_changed_admission_requires_local_review(self):
        progress, delivered = self.fixture()
        with self.assertRaisesRegex(ValueError, 'different continuation'):
            should_publish(progress, delivered, 'continuations/different.json')

    def test_duplicate_count_mismatch_or_rollback_is_rejected(self):
        progress, delivered = self.fixture()
        duplicate = copy.deepcopy(progress)
        duplicate['results'] *= 2
        duplicate['first_attempts_audited'] = duplicate['native_complete_audited'] = 2
        count_mismatch = dict(progress, first_attempts_audited=2)
        for candidate in (duplicate, count_mismatch):
            with self.assertRaises(ValueError):
                should_publish(candidate, delivered, progress['continuation_admission'])
        delivered['first_attempts_audited'] = 2
        with self.assertRaisesRegex(ValueError, 'disappear'):
            should_publish(progress, delivered, progress['continuation_admission'])

    def test_terminal_phase_change_is_published_once(self):
        progress, delivered = self.fixture()
        progress['phase'] = 'blocked_service_capacity'
        self.assertTrue(should_publish(progress, delivered, progress['continuation_admission']))
        delivered['phase_at_snapshot'] = 'blocked_service_capacity'
        self.assertFalse(should_publish(progress, delivered, progress['continuation_admission']))

    def test_all_attempts_requires_98_distinct_results_and_preserves_blog_boundary(self):
        progress, delivered = self.fixture()
        progress['phase'] = 'all_first_attempts_audited'
        with self.assertRaisesRegex(ValueError, 'exactly 98'):
            should_publish(progress, delivered, progress['continuation_admission'])
        progress['results'] = [dict(progress['results'][0], episode_id='case_' + str(i)) for i in range(98)]
        progress['first_attempts_audited'] = progress['native_complete_audited'] = 98
        self.assertTrue(should_publish(progress, delivered, progress['continuation_admission']))
        progress['full_blog_reproduction_complete'] = True
        with self.assertRaisesRegex(ValueError, 'boundaries'):
            should_publish(progress, delivered, progress['continuation_admission'])

    def test_source_tampering_or_symlink_stops_before_publication(self):
        with tempfile.TemporaryDirectory() as temporary:
            source = Path(temporary) / 'source.py'
            source.write_text('original')
            guards = {source: sha(source.read_bytes())}
            check_guards(guards)
            source.write_text('changed')
            with self.assertRaises(ValueError):
                check_guards(guards)
            target = Path(temporary) / 'target.py'
            target.write_text('original')
            source.unlink()
            source.symlink_to(target)
            with self.assertRaises(ValueError):
                check_guards(guards)


if __name__ == '__main__':
    unittest.main()
