"""Audit a reviewed zero-action CUDA reset failure; never replay its claim."""
import argparse
import fcntl
import json
from pathlib import Path

import run_historical_cohort as original
from reconcile_historical_startup_failure import stopped_processes


def audit_reset_failure(root, run, row, plan):
    if (run / 'evidence_gate.json').exists():
        raise ValueError('Existing evidence gate is immutable')
    attempt = original.read(run / 'attempt.json')
    claim = original.read(run / 'launch_claim.json')
    stopped_processes(attempt)
    digest = original.sha((root / 'cohort_plan.json').read_bytes())
    if (attempt['episode_id'] != row['episode_id'] or attempt['method'] != row['method']
            or attempt['profile_id'] != row['profile_id'] or attempt['first_attempt'] is not True
            or attempt['status'] != 'controller_incomplete' or attempt['controller_returncode'] != 1
            or attempt['native_complete'] is not False or claim['episode_id'] != row['episode_id']
            or claim['plan_sha256'] != digest or claim['automatic_physical_retries'] != 0):
        raise ValueError('Stopped reset does not bind the frozen first attempt')
    launch = original.read(run / 'historical_launch.json')
    worker = original.read(run / 'rollout/codex_workspace/worker.json')
    if (launch['episode'] != row['episode_id'] or launch['profile_id'] != row['profile_id']
            or launch['manifest_sha256'] != plan['receipt_sha256']['historical_worker_manifest.json']
            or worker['codex_version'] != plan['cli_version'] or worker['model'] != plan['model']
            or worker['reasoning_effort'] != plan['reasoning_effort']
            or worker['evaluation_method'] != row['method']):
        raise ValueError('Reset worker/CLI/source identity differs')
    outcome = original.read(run / 'sim/evaluation_outcome.json')
    if (outcome.get('evaluation_case') != row['identity'] or outcome.get('complete') is not False
            or outcome.get('valid_for_success_rate') is not False or outcome.get('status') != 'reset_error'
            or outcome.get('error_type') != 'ValueError'
            or outcome.get('error') != 'Invalid device identifier: cuda:0'):
        raise ValueError('Native outcome is not the reviewed unscored CUDA reset failure')
    forbidden = ('rollout/run.json', 'rollout/result.json', 'rollout/history.json',
                 'complete_action_audit.json', 'stopped_prefix_audit.json')
    if any((run / name).exists() for name in forbidden):
        raise ValueError('Native execution or run metadata requires regular auditing')
    paths = sorted(run.rglob('*'))
    if any(path.is_symlink() for path in paths):
        raise ValueError('Reset evidence contains a symlink')
    if any(path.name.startswith(('action_', 'execution_', 'response_', 'initial_observation'))
           for path in paths if path.is_file()):
        raise ValueError('A native observation/action exists; zero-action audit denied')
    failure = original.read(run / 'rollout/failure.json')
    if failure['episode_id'] is not None or failure['step_id'] != 0 or failure['completed'] is not False:
        raise ValueError('Controller failure has a native episode or completion')
    events = [json.loads(line) for line in
              (run / 'rollout/codex_workspace/rpc_out.jsonl').read_text().splitlines()]
    calls = [event['params'] for event in events if event.get('method') == 'item/tool/call']
    if (len(calls) != 1 or calls[0].get('threadId') != worker['thread_id']
            or calls[0].get('tool') != 'robodojo_start'
            or calls[0].get('arguments', {}).get('task') != row['case']['runtime_task']):
        raise ValueError('Expected one matching native start request without control calls')
    return dict(schema='gpt_policy_historical_cohort_episode_gate.v1', verified=True,
        verified_utc=original.utc(), episode_id=row['episode_id'], method=row['method'],
        profile_id=row['profile_id'], status='infrastructure_failed',
        original_attempt_status=attempt['status'], failure_reason='native_cuda_reset_error',
        first_attempt_retained=True, automatic_physical_retries=0, plan_sha256=digest,
        native_success=None, native_score=None, worker_identity_verified=True,
        controller_source_launch_verified=True, runtime_identity_verified=False,
        native_case_metadata_verified=True, stopped_prefix_decisions=0, stopped_prefix_actions=0,
        service_tool_calls=1, native_reset_observed=True, run_metadata_fabricated=False,
        evidence_inputs_sha256={str(path.relative_to(run)):original.sha(path.read_bytes())
                               for path in paths if path.is_file()},
        recovery_scope='Only the joined first native start and zero-action CUDA reset failure are audited. '
                       'No completed run identity is inferred. The claim remains unscored and cannot be replayed.',
        historical_protocol_equivalence=False, full_blog_reproduction_complete=False)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cohort', type=Path, required=True)
    parser.add_argument('--episode', required=True)
    args = parser.parse_args()
    root = args.cohort.absolute()
    lock = Path('/tmp/gpt-historical-worker-campaign.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    plan = original.verify_plan(root)
    row = next(row for pair in plan['pairs'] for row in pair['cases'] if row['episode_id'] == args.episode)
    proof = audit_reset_failure(root, root / 'episodes' / args.episode, row, plan)
    original.new_json(root / 'episodes' / args.episode / 'evidence_gate.json', proof)
    print(json.dumps({key:proof[key] for key in ('verified', 'episode_id', 'status', 'stopped_prefix_actions',
                                               'native_success', 'native_score', 'automatic_physical_retries')}))


if __name__ == '__main__':
    main()
