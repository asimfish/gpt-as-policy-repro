import json
import os
from pathlib import Path
import tempfile
import unittest

import run_historical_cohort as original
from reconcile_historical_reset_failure import audit_reset_failure


class ResetFailureTests(unittest.TestCase):
    def fixture(self, root):
        def put(name, data):
            path = root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(data))
        plan = dict(model='gpt-6-astra', reasoning_effort='xhigh', cli_version='codex-cli 0.153.4',
                    receipt_sha256={'historical_worker_manifest.json':'manifest'})
        row = dict(episode_id='direct__case', method='gpt_only', profile_id='profile',
                   identity={'case_id':'case'}, case={'runtime_task':'classify_objects'})
        put('cohort_plan.json', plan)
        digest = original.sha((root / 'cohort_plan.json').read_bytes())
        put('episodes/direct__case/launch_claim.json',dict(episode_id='direct__case',plan_sha256=digest,automatic_physical_retries=0))
        put('episodes/direct__case/attempt.json',dict(episode_id='direct__case',method='gpt_only',profile_id='profile',
            first_attempt=True,status='controller_incomplete',controller_returncode=1,native_complete=False,owned_processes=[]))
        put('episodes/direct__case/historical_launch.json',dict(episode='direct__case',profile_id='profile',manifest_sha256='manifest'))
        put('episodes/direct__case/rollout/codex_workspace/worker.json',dict(codex_version=plan['cli_version'],
            model=plan['model'],reasoning_effort=plan['reasoning_effort'],evaluation_method='gpt_only',thread_id='thread'))
        put('episodes/direct__case/sim/evaluation_outcome.json',dict(evaluation_case=row['identity'],complete=False,
            valid_for_success_rate=False,status='reset_error',error_type='ValueError',error='Invalid device identifier: cuda:0'))
        put('episodes/direct__case/rollout/failure.json',dict(episode_id=None,step_id=0,completed=False))
        put('episodes/direct__case/rollout/codex_workspace/rpc_out.jsonl',dict(method='item/tool/call',
            params=dict(threadId='thread',tool='robodojo_start',arguments=dict(task='classify_objects'))))
        return root / 'episodes/direct__case', row, plan

    def test_retained_reset_is_unscored_without_fabricated_run(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);run,row,plan=self.fixture(root)
            proof=audit_reset_failure(root,run,row,plan)
            self.assertEqual(proof['status'],'infrastructure_failed')
            self.assertIsNone(proof['native_score'])
            self.assertFalse(proof['runtime_identity_verified'])
            self.assertTrue(proof['native_reset_observed'])
            self.assertEqual(proof['stopped_prefix_actions'],0)
            self.assertFalse((run/'rollout/run.json').exists())

    def test_native_actions_observation_or_run_metadata_prevent_zero_action_audit(self):
        for name in ['sim/action_000001.json','sim/initial_observation.npz','rollout/run.json','rollout/history.json']:
            with self.subTest(name=name),tempfile.TemporaryDirectory() as directory:
                root=Path(directory);run,row,plan=self.fixture(root);(run/name).write_text('{}')
                with self.assertRaises(ValueError):audit_reset_failure(root,run,row,plan)

    def test_mismatched_reset_case_or_control_tool_is_rejected(self):
        for name,field,value in [('sim/evaluation_outcome.json','evaluation_case',{'case_id':'other'}),
                                 ('rollout/codex_workspace/rpc_out.jsonl','params',dict(threadId='thread',tool='robodojo_execute',arguments={}))]:
            with self.subTest(name=name),tempfile.TemporaryDirectory() as directory:
                root=Path(directory);run,row,plan=self.fixture(root);path=run/name;data=json.loads(path.read_text());data[field]=value;path.write_text(json.dumps(data))
                with self.assertRaises(ValueError):audit_reset_failure(root,run,row,plan)

    def test_live_owned_process_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);run,row,plan=self.fixture(root);path=run/'attempt.json';data=json.loads(path.read_text())
            ticks=Path('/proc',str(os.getpid()),'stat').read_text().rsplit(')',1)[1].split()[19]
            data['owned_processes']=[dict(pid=os.getpid(),start_ticks=ticks)];path.write_text(json.dumps(data))
            with self.assertRaises(ValueError):audit_reset_failure(root,run,row,plan)

    def test_existing_gate_or_symlink_is_rejected(self):
        for symlink in [False,True]:
            with self.subTest(symlink=symlink),tempfile.TemporaryDirectory() as directory:
                root=Path(directory);run,row,plan=self.fixture(root)
                if symlink:(run/'alias').symlink_to(run/'attempt.json')
                else:(run/'evidence_gate.json').write_text('{}')
                with self.assertRaises(ValueError):audit_reset_failure(root,run,row,plan)


if __name__ == '__main__':unittest.main()
