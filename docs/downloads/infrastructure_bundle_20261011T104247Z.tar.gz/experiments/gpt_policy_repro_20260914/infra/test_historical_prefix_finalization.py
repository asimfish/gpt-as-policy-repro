"""Exercise the frozen finalizer with a real, minimal Hybrid action chain.

These fixtures call the existing action auditor and continuation entrypoint;
they never start a model, student server, or simulator. A stopped prefix must
remain unscored, while mismatched actions, identities, or ownership are denied.
"""
import json
import os
from pathlib import Path
import tempfile
import unittest

import numpy as np

import run_historical_cohort as original
from continue_historical_parallel_admission_v3 import finalize_first_attempt


class HistoricalPrefixFinalizationTests(unittest.TestCase):
    def fixture(self, root):
        run = root / 'episodes' / 'hybrid__fixture'

        def put(name, value):
            path = run / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(value) + '\n')

        plan = dict(cli_version='codex-cli 0.153.4', model='gpt-6-astra',
                    reasoning_effort='xhigh',
                    receipt_sha256={'historical_worker_manifest.json': 'manifest'})
        row = dict(episode_id='hybrid__fixture', method='pi05_plus_gpt',
                   profile_id='profile', identity={'case_id': 'fixture'},
                   case=dict(max_decisions=0, max_episode_steps=1100,
                             control_dt=0.05, student_identity_sha256='student'))
        (root / 'cohort_plan.json').write_text(json.dumps(plan))
        put('launch_claim.json', dict(episode_id=row['episode_id'],
            plan_sha256=original.sha((root / 'cohort_plan.json').read_bytes())))
        put('attempt.json', dict(episode_id=row['episode_id'], profile_id='profile',
            method='pi05_plus_gpt', status='controller_incomplete', first_attempt=True,
            native_complete=False, owned_processes=[]))
        put('historical_launch.json', dict(profile_id='profile', manifest_sha256='manifest'))
        put('rollout/run.json', dict(evaluation_case=row['identity'], **row['case'],
            teacher_model='gpt-6-astra', teacher_reasoning_effort='xhigh', initial_state_hash='initial'))
        put('rollout/codex_workspace/worker.json', dict(evaluation_method='pi05_plus_gpt',
            codex_version='codex-cli 0.153.4', model='gpt-6-astra',
            reasoning_effort='xhigh', model_provider='openai', thread_id='thread'))
        response = dict(request_id='request', mode='student', steps=3)
        arguments = dict(response=response)
        put('rollout/request_000.json', dict(request_id='request', step_id=0,
            prediction_id='prediction', episode_id='native'))
        put('rollout/response_000.json', response)
        put('rollout/history.json', [dict(decision=0, start_tick=0, end_tick=3,
            executed_steps=3, prediction_id='prediction', response=response)])
        put('rollout/codex_workspace/call_000_request.json', dict(
            tool='robodojo_execute', call_id='call', arguments=arguments))
        put('rollout/codex_workspace/call_000_result.json', dict(no_execution=False))
        put('rollout/codex_workspace/rpc_out.jsonl', dict(method='item/tool/call',
            params=dict(tool='robodojo_execute', callId='call', threadId='thread', arguments=arguments)))
        put('sim/native/codex_decisions/000.json', dict(response=response, step_id=0,
            prediction_id='prediction', episode_id='native'))
        actions = np.arange(700, dtype=np.float64).reshape(50, 14) / 1000
        states = np.arange(42, dtype=np.float64).reshape(3, 14) / 100
        np.savez(run / 'rollout/proposal_000.npz', actions=actions)
        np.savez(run / 'rollout/execution_000.npz', actions=actions[:3], states=states)
        for index in range(3):
            put(f'sim/native/action_{index:06d}.json', dict(valid=True, step_id=index+1,
                source='student', student_prediction_id='prediction',
                executed_action=actions[index].tolist(), obs={'states': states[index].tolist()},
                terminated=False, truncated=False, success=False))
        put('sim/evaluation_outcome.json', dict(complete=False, valid_for_success_rate=False))
        return run, row, plan

    def change(self, path, field, value):
        data = json.loads(path.read_text())
        data[field] = value
        path.write_text(json.dumps(data) + '\n')

    def test_real_stopped_hybrid_chain_has_no_score_and_preserves_first_claim(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            run, row, plan = self.fixture(root)
            claim = (run / 'launch_claim.json').read_bytes()
            gate = finalize_first_attempt(root, run, row, plan)
            self.assertEqual(gate['status'], 'controller_incomplete')
            self.assertEqual(gate['stopped_prefix_decisions'], 1)
            self.assertEqual(gate['stopped_prefix_actions'], 3)
            self.assertEqual(original.gate_score(gate), (None, None))
            self.assertTrue(gate['runtime_identity_verified'])
            self.assertEqual((run / 'launch_claim.json').read_bytes(), claim)
            self.assertFalse((run / 'complete_action_audit.json').exists())
            self.assertFalse(json.loads((run / 'stopped_prefix_audit.json').read_text())['complete_episode'])
            self.assertEqual(original.verify_retained(run, root, row), gate)

    def test_native_action_or_state_tampering_is_rejected(self):
        for field in ('executed_action', 'obs'):
            with self.subTest(field=field), tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary)
                run, row, plan = self.fixture(root)
                value = [9.0] * 14 if field == 'executed_action' else {'states': [9.0] * 14}
                self.change(run / 'sim/native/action_000001.json', field, value)
                with self.assertRaises(AssertionError):
                    finalize_first_attempt(root, run, row, plan)
                self.assertFalse((run / 'evidence_gate.json').exists())

    def test_rpc_thread_mismatch_is_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            run, row, plan = self.fixture(root)
            path = run / 'rollout/codex_workspace/rpc_out.jsonl'
            data = json.loads(path.read_text())
            data['params']['threadId'] = 'another-thread'
            path.write_text(json.dumps(data) + '\n')
            with self.assertRaises(AssertionError):
                finalize_first_attempt(root, run, row, plan)
            self.assertFalse((run / 'evidence_gate.json').exists())

    def test_wrong_checkpoint_or_budget_is_rejected(self):
        for field, value in [('student_identity_sha256', 'different'), ('max_episode_steps', 500)]:
            with self.subTest(field=field), tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary)
                run, row, plan = self.fixture(root)
                self.change(run / 'rollout/run.json', field, value)
                with self.assertRaisesRegex(ValueError, 'identity'):
                    finalize_first_attempt(root, run, row, plan)
                self.assertFalse((run / 'evidence_gate.json').exists())

    def test_live_owned_process_cannot_be_finalized(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            run, row, plan = self.fixture(root)
            ticks = Path('/proc', str(os.getpid()), 'stat').read_text().rsplit(')', 1)[1].split()[19]
            self.change(run / 'attempt.json', 'owned_processes', [dict(pid=os.getpid(), start_ticks=ticks)])
            with self.assertRaisesRegex(ValueError, 'live owned'):
                finalize_first_attempt(root, run, row, plan)
            self.assertFalse((run / 'evidence_gate.json').exists())

    def test_existing_gate_is_never_replaced(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            run, row, plan = self.fixture(root)
            finalize_first_attempt(root, run, row, plan)
            gate = (run / 'evidence_gate.json').read_bytes()
            with self.assertRaisesRegex(ValueError, 'cannot be replaced'):
                finalize_first_attempt(root, run, row, plan)
            self.assertEqual((run / 'evidence_gate.json').read_bytes(), gate)

    def test_symlinked_evidence_cannot_receive_a_gate(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            run, row, plan = self.fixture(root)
            (run / 'alias').symlink_to(run / 'attempt.json')
            with self.assertRaisesRegex(ValueError, 'symlink'):
                finalize_first_attempt(root, run, row, plan)
            self.assertFalse((run / 'evidence_gate.json').exists())

    def test_prefix_cannot_be_promoted_to_complete_native_episode(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            run, row, plan = self.fixture(root)
            self.change(run / 'attempt.json', 'status', 'native_complete_pending_audit')
            with self.assertRaises((AssertionError, FileNotFoundError)):
                finalize_first_attempt(root, run, row, plan)
            self.assertFalse((run / 'evidence_gate.json').exists())


if __name__ == '__main__':
    unittest.main()
