import hashlib
import os
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import driver570_loader_aliases as loader


class LoaderBoundaryTests(unittest.TestCase):
    def fixture(self, directory):
        data=b'fixture executable dependency'
        digest=hashlib.sha256(data).hexdigest()
        lines=[digest+'  /usr/lib/x86_64-linux-gnu/'+name for name in loader.ALIASES]
        pins=Path(directory)/'pins.txt';pins.write_text('\n'.join(lines)+'\n')
        return pins,data,lines

    def mocked_libraries(self, data, writable=False, symlink=False):
        from contextlib import ExitStack
        stack=ExitStack()
        stack.enter_context(patch.object(Path,'is_file',return_value=True))
        stack.enter_context(patch.object(Path,'is_symlink',return_value=symlink))
        stack.enter_context(patch.object(Path,'stat',return_value=SimpleNamespace(
            st_uid=0,st_mode=0o100666 if writable else 0o100644)))
        stack.enter_context(patch.object(Path,'read_bytes',return_value=data))
        return stack

    def test_private_aliases_use_only_verified_fixed_library_targets(self):
        with tempfile.TemporaryDirectory() as directory:
            pins,data,_=self.fixture(directory)
            with self.mocked_libraries(data):root=loader.make_overlay(pins)
            try:
                self.assertEqual(os.stat(root).st_mode&0o777,0o700)
                expected={alias:Path('/usr/lib/x86_64-linux-gnu')/name
                          for name,aliases in loader.ALIASES.items() for alias in aliases}
                self.assertEqual({p.name:p.readlink() for p in root.iterdir()},expected)
            finally:
                for p in root.iterdir():p.unlink()
                root.rmdir()

    def assert_denied_without_directory_creation(self, pins, data, **options):
        with self.mocked_libraries(data,**options),patch.object(loader.tempfile,'mkdtemp') as create:
            with self.assertRaises(ValueError):loader.make_overlay(pins)
            create.assert_not_called()

    def test_external_path_or_unreviewed_library_name_is_denied(self):
        for old,new in [('/usr/lib/x86_64-linux-gnu/','/tmp/'),('libcuda.so.570.124.06','libcuda.so.580.178.04')]:
            with self.subTest(new=new),tempfile.TemporaryDirectory() as directory:
                pins,data,lines=self.fixture(directory);lines[0]=lines[0].replace(old,new);pins.write_text('\n'.join(lines)+'\n')
                self.assert_denied_without_directory_creation(pins,data)

    def test_digest_mismatch_is_denied(self):
        with tempfile.TemporaryDirectory() as directory:
            pins,data,lines=self.fixture(directory);lines[0]='0'*64+lines[0][64:];pins.write_text('\n'.join(lines)+'\n')
            self.assert_denied_without_directory_creation(pins,data)

    def test_symlink_or_writable_dependency_is_denied(self):
        for options in [dict(symlink=True),dict(writable=True)]:
            with self.subTest(options=options),tempfile.TemporaryDirectory() as directory:
                pins,data,_=self.fixture(directory);self.assert_denied_without_directory_creation(pins,data,**options)

    def test_duplicate_or_missing_pinned_library_is_denied(self):
        for duplicate in [True,False]:
            with self.subTest(duplicate=duplicate),tempfile.TemporaryDirectory() as directory:
                pins,data,lines=self.fixture(directory);lines=lines+[lines[0]] if duplicate else lines[:-1];pins.write_text('\n'.join(lines)+'\n')
                self.assert_denied_without_directory_creation(pins,data)


if __name__=='__main__':unittest.main()
