"""Provide private loader names for the six already SHA-pinned host libraries."""
import argparse
import hashlib
from pathlib import Path
import tempfile

ALIASES = {
    'libcuda.so.570.124.06': ('libcuda.so', 'libcuda.so.1'),
    'libnvidia-ml.so.570.124.06': ('libnvidia-ml.so', 'libnvidia-ml.so.1'),
    'libEGL_nvidia.so.570.124.06': ('libEGL_nvidia.so', 'libEGL_nvidia.so.0'),
    'libGLX_nvidia.so.570.124.06': ('libGLX_nvidia.so', 'libGLX_nvidia.so.0'),
    'libnvidia-ptxjitcompiler.so.570.124.06': ('libnvidia-ptxjitcompiler.so', 'libnvidia-ptxjitcompiler.so.1'),
    'libnvidia-gpucomp.so.570.124.06': ('libnvidia-gpucomp.so', 'libnvidia-gpucomp.so.1'),
}


def make_overlay(pins):
    entries = [line.split(maxsplit=1) for line in pins.read_text().splitlines()]
    targets = {}
    for digest, name in entries:
        path = Path(name.strip())
        if (path.parent != Path('/usr/lib/x86_64-linux-gnu') or path.name not in ALIASES
                or path.is_symlink() or not path.is_file() or path.stat().st_uid != 0
                or path.stat().st_mode & 0o022
                or hashlib.sha256(path.read_bytes()).hexdigest() != digest):
            raise ValueError('Reviewed root-owned driver library differs')
        if path.name in targets:
            raise ValueError('Duplicate pinned driver library')
        targets[path.name] = path
    if set(targets) != set(ALIASES):
        raise ValueError('Exactly six reviewed driver libraries are required')
    root = Path(tempfile.mkdtemp(prefix='gpt-policy-driver570-loader-'))
    root.chmod(0o700)
    for name, aliases in ALIASES.items():
        for alias in aliases:
            (root / alias).symlink_to(targets[name])
    return root


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pins', type=Path, required=True)
    print(make_overlay(parser.parse_args().pins))
