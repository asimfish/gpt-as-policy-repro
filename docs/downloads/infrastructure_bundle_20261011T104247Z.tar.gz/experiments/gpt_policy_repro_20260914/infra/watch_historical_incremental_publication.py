"""Publish new audited first attempts without touching the native execution queue.

The previous terminal-only observer waited for all 98 attempts or a stop. This
observer uses the already verified incremental statistics path at each new gate,
then checks the exact published commit, all bundle members, and the online views.
Any source drift or delivery failure stops publication for explicit local review.
"""
import argparse
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import uuid

from run_historical_cohort import ART, read, sha, utc, write, new_json, verify_plan
from capture_historical_cohort import capture, copy_immutable
from build_historical_execution_delta import prepare
from publish_verified_historical_snapshot import publish
from watch_historical_publication import SOURCE_NAMES, TERMINAL

ROOT = ART.parents[1]
REPO = ROOT / 'gpt-policy-report-site'
RESUME = ART / 'publication_checks/historical_resume_20261010'
COHORT_EVIDENCE = ART / 'publication_checks/historical_cohort_20261010'
STATE = ART / 'infra/historical_incremental_publication_receipt.json'
ADDITIONAL_SOURCES = (
    'infra/capture_historical_cohort.py', 'infra/package_reproduction_infra.py',
    'infra/build_historical_execution_delta.py', 'infra/publish_verified_historical_snapshot.py',
    'infra/watch_historical_publication.py', 'infra/test_historical_prefix_finalization.py',
    'infra/test_historical_incremental_publication.py', 'infra/historical_prefix_dispatch_correction.json',
    'infra/historical_case22_prefix50_audit.json',
    'publication_checks/historical_resume_20261010/verify_public_delivery.py',
    'publication_checks/historical_resume_20261010/verify_browser.cjs',
)


def should_publish(progress, delivered, admission):
    if progress.get('continuation_admission') != admission:
        raise ValueError('A different continuation requires a new observer admission')
    results = progress['results']
    if (progress.get('episodes_planned') != 98
            or progress['first_attempts_audited'] != len(results)
            or len({row['episode_id'] for row in results}) != len(results)
            or not 0 <= len(results) <= 98
            or progress['native_complete_audited'] != sum(
                row['status'] == 'native_complete_audited' for row in results)
            or progress.get('automatic_physical_retries') != 0
            or progress.get('historical_protocol_equivalence') is not False
            or progress.get('full_blog_reproduction_complete') is not False):
        raise ValueError('First-attempt count or completion boundaries differ')
    for row in results:
        if row['status'] != 'native_complete_audited' and (
                row.get('native_score') is not None or row.get('native_success') is not None):
            raise ValueError('An incomplete attempt cannot have a native score')
    if progress['phase'] == 'all_first_attempts_audited' and len(results) != 98:
        raise ValueError('All-first-attempt completion requires exactly 98 distinct gates')
    if len(results) < delivered['first_attempts_audited']:
        raise ValueError('A published first attempt cannot disappear')
    return (len(results) > delivered['first_attempts_audited'] or (
        progress['phase'] in TERMINAL
        and progress['phase'] != delivered['phase_at_snapshot']))


def check_guards(guards):
    for path, digest in guards.items():
        if path.is_symlink() or sha(path.read_bytes()) != digest:
            raise ValueError('Reviewed publication or admitted execution source changed')


def current_delivery():
    commit = subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', 'HEAD'], text=True).strip()
    proof = read(RESUME / 'public_bundle_verified.json')
    comparison = REPO / 'docs/data/blog-comparison.json'
    if (proof.get('verified') is not True or proof.get('commit') != commit
            or proof.get('comparison_sha256') != sha(comparison.read_bytes())
            or proof.get('historical_equivalence_verified') is not False
            or proof.get('all_payload_member_hashes_verified') is not True
            or proof.get('continuation_no_physical_retries_verified') is not True):
        raise ValueError('Observer requires the exact previously verified public delivery')
    return read(comparison)['historical_worker_fidelity']['original_version_execution']['remaining_cohort']


def snapshot(root, admission, guards, state, node):
    with Path('/tmp/gpt-policy-report-publish.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        check_guards(guards)
        delivered = current_delivery()
        if not should_publish(read(root / 'progress.json'), delivered, str(admission.relative_to(root))):
            return False
        stamp = time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())
        directory = ART / 'publication_checks/historical_incremental_20261011' / (stamp + '_' + uuid.uuid4().hex[:8])
        directory.mkdir(parents=True, exist_ok=False)
        value = capture(root, COHORT_EVIDENCE, admission.parent / 'availability.json')
        if read(admission).get('retained_review_sha256'):
            source = admission.parent / 'retained_review.json'
            if sha(source.read_bytes()) != read(admission)['retained_review_sha256']:
                raise ValueError('Retained admission review changed')
            copy_immutable(source, COHORT_EVIDENCE / 'continuation_evidence' / admission.parent.name / source.name)
        state.update(status='preparing_audited_snapshot', updated_utc=utc(),
                     snapshot_directory=str(directory.relative_to(ART)),
                     captured_utc=value['captured_utc'],
                     first_attempts_audited=value['progress']['first_attempts_audited'],
                     native_complete_audited=value['progress']['native_complete_audited'],
                     native_phase_at_snapshot=value['progress']['phase'])
        write(STATE, state)
        new_json(directory / 'runtime_snapshot.json', value)
        prepare(directory / 'execution_delta')
        check_guards(guards)
        subprocess.run([sys.executable, str(ART / 'infra/package_reproduction_infra.py'), '--date', stamp], check=True)
        state.update(status='publishing_audited_snapshot', updated_utc=utc())
        write(STATE, state)
        publish(REPO, ART, ROOT / 'astra-control-dashboard')
        check_guards(guards)
        subprocess.run([sys.executable, str(RESUME / 'verify_public_delivery.py')], check=True)
        browser = subprocess.run([str(node), str(RESUME / 'verify_browser.cjs')],
            env={**os.environ, 'BASE_URL': 'https://asimfish.github.io/gpt-as-policy-repro'}, check=True)
        delivery = read(RESUME / 'public_bundle_verified.json')
        if delivery['historical_first_attempts_audited'] != value['progress']['first_attempts_audited']:
            raise ValueError('Published delivery does not bind the captured first-attempt count')
        copy_immutable(RESUME / 'public_bundle_verified.json', directory / 'public_bundle_verified.json')
        copy_immutable(RESUME / 'browser_online.json', directory / 'browser_online.json')
        state.update(status='watching_after_verified_delivery', updated_utc=utc(),
                     published_commit=delivery['commit'], source_commit=delivery['source_commit'],
                     archive_sha256=delivery['archive_sha256'],
                     manifested_files=delivery['manifested_files'], published_files_verified=20,
                     online_browser_verified=browser.returncode == 0,
                     last_verified_snapshot=str(directory.relative_to(ART)))
        write(STATE, state)
        print(json.dumps({key: state[key] for key in ('status', 'published_commit',
            'first_attempts_audited', 'native_complete_audited')}), flush=True)
        return True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cohort', type=Path, required=True)
    parser.add_argument('--admission', required=True)
    parser.add_argument('--node', type=Path, required=True)
    parser.add_argument('--once', action='store_true')
    args = parser.parse_args()
    root = args.cohort.absolute()
    relative = Path(args.admission)
    if relative.is_absolute() or '..' in relative.parts:
        raise ValueError('Continuation admission must be relative to the canonical cohort')
    admission = root / relative
    if root.resolve() != root or admission.resolve() != admission.absolute():
        raise ValueError('Cohort or admission cannot follow a symlink')
    observer_lock = Path('/tmp/gpt-historical-incremental-publication.lock').open('a')
    fcntl.flock(observer_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    plan = verify_plan(root)
    proof = read(admission)
    if (proof.get('verified') is not True or proof.get('physical_retry_limit') != 0
            or proof.get('plan_sha256') != sha((root / 'cohort_plan.json').read_bytes())):
        raise ValueError('A verified no-retry continuation admission is required')
    guards = {REPO / name: sha((REPO / name).read_bytes()) for name in SOURCE_NAMES}
    guards.update({ART / name: sha((ART / name).read_bytes()) for name in ADDITIONAL_SOURCES})
    guards.update({ART / name: digest for name, digest in plan['source_sha256'].items()})
    guards.update({ART / name: digest for name, digest in proof['source_sha256'].items()})
    for path in (Path(__file__), admission, root / 'cohort_plan.json',
                 ART / 'full_reproduction_verification.json', RESUME / 'prior_statistics_audit.json',
                 RESUME / 'execution_delta_gate.json'):
        guards[path] = sha(path.read_bytes())
    check_guards(guards)
    delivered = current_delivery()
    state = dict(schema='gpt_policy_historical_incremental_publication_watch.v1',
                 started_utc=utc(), status='waiting_for_next_audited_gate',
                 continuation_admission=args.admission,
                 initial_first_attempts_audited=delivered['first_attempts_audited'],
                 initial_native_complete_audited=delivered['native_complete_audited'],
                 source_sha256={str(path.relative_to(ROOT)): digest for path, digest in guards.items()},
                 model_calls=0, simulator_steps=0, physical_retries=0,
                 historical_protocol_equivalence=False, full_blog_reproduction_complete=False)
    write(STATE, state)
    try:
        while True:
            check_guards(guards)
            progress = read(root / 'progress.json')
            completion_ready = progress['phase'] != 'all_first_attempts_audited' or (root / 'completion.json').exists()
            if should_publish(progress, current_delivery(), args.admission):
                if completion_ready:
                    snapshot(root, admission, guards, state, args.node)
            if args.once or (progress['phase'] in TERMINAL and completion_ready):
                state.update(status='finished_after_delivery_check', updated_utc=utc())
                write(STATE, state)
                return
            time.sleep(30)
    except Exception as error:
        state.update(status='blocked_publication_requires_review', updated_utc=utc(), exception_type=type(error).__name__)
        private = STATE.with_suffix('.private_error')
        private.write_text(str(error))
        private.chmod(0o600)
        write(STATE, state)
        print(json.dumps({'status': state['status'], 'exception_type': type(error).__name__}), flush=True)
        raise SystemExit(1)


if __name__ == '__main__':
    main()
