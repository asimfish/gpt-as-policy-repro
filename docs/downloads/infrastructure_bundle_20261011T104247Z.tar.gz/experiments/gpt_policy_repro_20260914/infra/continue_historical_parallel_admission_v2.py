"""Review retained inputs concurrently, then probe once and run frozen cases serially.

Only admission I/O is parallel. Original execution, grading, first-claim guards,
capacity handling and stopped-attempt audit functions are reused unchanged.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import datetime
import fcntl
import os
from pathlib import Path
import signal
import time

import run_historical_cohort as original
import continue_historical_cohort as continuation
from probe_historical_service import probe


def retained_prefix(root, plan, workers=8):
    retained_rows = []; pending = []; gap = False
    for pair in plan['pairs']:
        for row in pair['cases']:
            action = original.next_action(root/'episodes'/row['episode_id'])
            if action == 'retain' and not gap:
                retained_rows.append(row)
            elif action == 'launch':
                gap = True; pending.append(row)
            else:
                raise ValueError('Existing first attempt or out-of-order gate requires review; no replay')
    def verify(row):
        return original.verify_retained(root/'episodes'/row['episode_id'], root, row)
    with ThreadPoolExecutor(max_workers=workers) as pool:
        retained = list(pool.map(verify, retained_rows))
    return retained, pending


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cohort', type=Path, required=True)
    args = parser.parse_args(); root = args.cohort.absolute()
    if (os.environ.get('ROLLOUT_USE_CURRENT_CODEX_HOME') != '1'
            or os.environ.get('ROLLOUT_AUTH_PROFILE') != 'codex_a'):
        raise ValueError('Existing authorized route must be explicitly selected')
    lock = Path('/tmp/gpt-historical-worker-campaign.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    plan = original.verify_plan(root)
    directory = root/'continuations'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    directory.mkdir(parents=True, mode=0o700, exist_ok=False)
    start = time.monotonic()
    retained, pending = retained_prefix(root, plan)
    input_count = sum(len(g['evidence_inputs_sha256']) for g in retained)
    original.new_json(directory/'retained_review.json', dict(verified=True,
        verified_utc=original.utc(), retained_first_attempts=len(retained),
        input_bindings_verified=input_count, concurrency=8,
        elapsed_seconds=time.monotonic()-start, verifier='run_historical_cohort.verify_retained',
        physical_retries=0, simulator_steps=0, model_calls=0))
    print('{"event":"retained_inputs_verified","inputs":'+str(input_count)+'}', flush=True)
    # The availability clock starts after slow filesystem review, never before it.
    probe_path = directory/'availability.json'
    proof = probe(probe_path, model_turn=True)
    continuation.validate_probe(proof, plan)
    sources = {'infra/'+name:original.sha((original.ART/'infra'/name).read_bytes())
               for name in continuation.SOURCE_NAMES}
    for name in ('continue_historical_parallel_admission.py', 'continue_historical_parallel_admission_v2.py',
                 'continue_historical_driver570.sh', 'driver570_library_pins.txt',
                 'continue_historical_driver570_jit.sh', 'driver570_jit_library_pins.txt'):
        sources['infra/'+name] = original.sha((original.ART/'infra'/name).read_bytes())
    admission = directory/'admission.json'
    original.new_json(admission, dict(schema='gpt_policy_historical_continuation_admission.v1',
        verified=True, admitted_utc=original.utc(), plan_sha256=original.sha((root/'cohort_plan.json').read_bytes()),
        availability_sha256=original.sha(probe_path.read_bytes()), source_sha256=sources,
        prior_episode_gate_sha256={g['episode_id']:original.sha((root/'episodes'/g['episode_id']/'evidence_gate.json').read_bytes()) for g in retained},
        retained_first_attempts=len(retained), unclaimed_episodes=len(pending), physical_retry_limit=0,
        retained_review_sha256=original.sha((directory/'retained_review.json').read_bytes()),
        admission_io_concurrency=8, original_execution_source_unchanged=True, authentication_copied=False,
        stop_after_service_capacity_failure=True, historical_protocol_equivalence=False,
        full_blog_reproduction_complete=False))
    def interrupted(signum, frame):
        signal.signal(signum, signal.SIG_IGN)
        raise KeyboardInterrupt('Owned continuation interrupted')
    signal.signal(signal.SIGTERM, interrupted)
    continuation.save_progress(root, retained, 'running', admission)
    print('{"event":"continuation_admitted","retained":'+str(len(retained))+',"physical_retries":0}', flush=True)
    for row in pending:
        run = root/'episodes'/row['episode_id']
        if original.next_action(run) != 'launch':
            continuation.save_progress(root, retained, 'blocked_existing_attempt_requires_review', admission, row['episode_id'])
            raise SystemExit(1)
        continuation.save_progress(root, retained, 'waiting_for_available_gpu_and_ports', admission, row['episode_id'])
        while not original.available(plan):
            time.sleep(30)
        original.verify_plan(root)
        for name, digest in sources.items():
            if original.sha((original.ART/name).read_bytes()) != digest:
                raise ValueError('Admitted continuation source changed')
        if len(retained) == original.read(admission)['retained_first_attempts']:
            continuation.validate_probe(proof, plan)
        continuation.save_progress(root, retained, 'running', admission, row['episode_id'])
        original.execute(root, row, plan)
        try:
            errors = continuation.capacity_errors(run)
            gate = continuation.finalize_first_attempt(root, run, row, plan); retained.append(gate)
        except Exception as error:
            private = run/'private_continuation_audit_error.txt'
            private.write_text(str(error)); private.chmod(0o600)
            continuation.save_progress(root, retained, 'blocked_audit_requires_review', admission, row['episode_id'])
            print('{"event":"audit_failed","exception_type":"'+type(error).__name__+'"}', flush=True)
            raise SystemExit(1)
        print('{"event":"first_attempt_audited","episode":"'+row['episode_id']+'","status":"'+gate['status']+'"}', flush=True)
        if errors:
            continuation.save_progress(root, retained, 'blocked_service_capacity', admission, row['episode_id'], errors)
            raise SystemExit(1)
        if original.read(run/'attempt.json').get('interrupted') is True:
            continuation.save_progress(root, retained, 'interrupted', admission); raise SystemExit(1)
        if gate['status'] in ('infrastructure_failed', 'incomplete_pending_review'):
            continuation.save_progress(root, retained, 'blocked_infrastructure_requires_review', admission, row['episode_id'])
            raise SystemExit(1)
        continuation.save_progress(root, retained, 'running', admission)
    continuation.save_progress(root, retained, 'all_first_attempts_audited', admission)
    expected = {g['episode_id']:original.sha((root/'episodes'/g['episode_id']/'evidence_gate.json').read_bytes()) for g in retained}
    if (root/'completion.json').exists():
        existing = original.read(root/'completion.json')
        if existing.get('verified') is not True or existing.get('episode_gate_sha256') != expected:
            raise ValueError('Existing completion receipt differs')
        return
    original.new_json(root/'completion.json', dict(verified=True, completed_utc=original.utc(), episodes=98,
        episode_gate_sha256=expected, complete_native_audited=sum(g['status']=='native_complete_audited' for g in retained),
        all_first_attempts_retained=True, automatic_physical_retries=0,
        historical_protocol_equivalence=False, full_blog_reproduction_complete=False))


if __name__ == '__main__':
    main()
