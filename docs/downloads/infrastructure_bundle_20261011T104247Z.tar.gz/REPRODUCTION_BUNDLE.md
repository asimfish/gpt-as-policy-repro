# 复现实验基建快照

包含运行脚本、调度器、逐步动作审计、回归测试、冻结案例与依赖锁、报告解读、运行手册和 GPT-as-Policy 源码补丁。按归档中的相对路径解压到工作区；先按 RUNBOOK.md 准备固定版本上游仓库与环境，再应用源码补丁。

运行入口：experiments/gpt_policy_repro_20260914/RUNBOOK.md。

环境配置保留本项目工作区与 mainskill 部署路径；迁移到其他机器时需调整 infra/env.sh 和部署脚本中的根路径、Python 路径及 SSH alias。模型权重、大型资产、SSH 密钥、API 凭据不在包内，下载清单和校验逻辑保留。用户已授权复用现有 Codex CLI 登录态：配置 CODEX_HOME/CODEX_BIN 与 ROLLOUT_USE_CURRENT_CODEX_HOME=1，由 CLI 自身读取认证，禁止复制或公开 auth.json。unit_templates 提供去掉私有环境的 systemd 模板，runtime.env 由部署者自行在本机以0600权限创建。所选两套评测的200回合和100对已通过原始证据、完整视频、815个线上文件及同提交CI终验。包内封存原始完成证明 experiments/gpt_policy_repro_20260914/final_verification/5d7a430557ba91da93a16b5b174305ded275bf39/certificate.json；验收绑定原报告提交 5d7a430557ba91da93a16b5b174305ded275bf39，保留原验收时间。后续交付提交只发布该证明与基础设施，不能改写历史完成证明或声称历史逐位环境等价。详细结果和限制见 COMPLETION_20261007.md。

当前有效范围只包含 GPT Direct 与 π0.5 + GPT Hybrid。遗留基线辅助脚本仅用于追溯，不应据此启动额外方法。RoboLab Direct 是本项目 EEF 适配器，历史实现未公开；当前完整结果、验证门和队列状态见GOAL.md。SSH传输缓解、只读归档补传及完整审计说明均在包内，前缀或连接中断不得计入完整成绩。

包含两种环境的SSD容量维护脚本与定时服务：完整审计后，对RoboLab整工作区、RoboDojo封存Codex状态逐文件SHA256核验，归档到私有NAS，活动SQLite只使用本机ext4（早期/tmp，新RoboLab回合使用第二SSD）；不得放入NAS；运行数据库和日志冷归档不在公开包内。主实验维护使用哈希固定的v5原资格函数，安装和恢复边界见RUNBOOK.md。

manifest.json 给出每个文件的 SHA256 与固定源码提交（包括在线报告源码版本）。大型实验轨迹和在线站点源码留在工作区及报告 GitHub 仓库。

原blog逐任务与共同案例对照见BLOG_ALIGNMENT_20261008.md和包内gpt-policy-report-site/docs/blog-comparison.html。所选200回合执行完成不代表严格历史等价；manifest.blog_comparison.historical_equivalence_verified保持false。RoboLab决策预算和Direct实现差异、缺失历史证据及900项统计输入SHA均分列。预算前缀只记录已终止/尚未终止，不补失败，也不是新的限预算评测。

原始公开记录恢复：YuMoool/astra-robodojo-rollouts 固定版本的100个核心档案、80971步动作/执行后关节状态已独立核验，原结果重算一致；原作者署名及CC BY 4.0数据许可见包内hf_LICENSE-DATA.md与公开对照JSON。档案下载/校验入口为infra/recover_original_robodojo.py、verify_original_robodojo_records.py；大型ZIP、RGB和模型文字未放入本包。98条共同回合的布局/配置/时域一致；关节/姿态哈希差异仅约3.3e-18/1.5e-8，归档prompt仅工作目录行不同，其余字节一致。这个限定比较不证明原始模型输入、完整物理初态或服务状态等价，也不能定位结果差异原因。

历史控制器恢复：包内包含5套41/42文件的原始冻结源码及两份明确标记的当前授权运行环境桥接文件。原CLI安装器仅从官方npm固定0.153.4并验证SHA512 SRI；大型二进制、auth和私有运行日志不在包内。5套原源码通过30项离线协议场景与5次零推理临时线程初始化；原网关代码、服务快照和持久历史未恢复。独立历史版本试跑仅保留首次尝试，输入错误阈值退出保持未完成，不替换封存200回合。入口为infra/run_historical_pair.sh，具体边界见ADR_HISTORICAL_WORKER_RECONSTRUCTION.md。

原版本试跑两方法均1050步原生完整失败，分数0.3，动作及1051帧原视频审计通过。试跑Hybrid与原记录0.05不同，不声称结果一致；试跑不混入基准。其余49对/98次首次尝试已另行冻结并启动，入口infra/run_historical_cohort.sh，逐回合启动凭据禁止自动物理重试，未完成前缀和无效布局不计成绩。本包含完成动作审计的SHA清单及队列准入快照；大型原视频、原动作文件和私有模型运行内容仍在独立实验输出，未装入此基建包。具体限定见HISTORICAL_REMAINING_COHORT_20261010.md，全部历史复现仍未完成。

模型用量上限曾中断一条656步前缀和一次零动作启动。后者缺少run.json，独立审计器只验证原CLI/源码/model失败链，保留无成绩，不编造运行身份。恢复入口infra/continue_historical_cohort.sh验证新近同模型最小探测、全部已审计证据和独立恢复源码，再跳过既有启动凭据继续尚未启动案例；再次出现容量错误立即停止下一次启动。原计划及执行器保持冻结。详见包内historical_resume_20261010准入、探测和回归证明。
