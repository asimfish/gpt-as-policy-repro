# GPT-as-Policy 两种方法复现目标

## Outcome

按用户 2026-09-16 的范围修正，主要复现报告自己的两种方法：GPT Direct 与 π0.5 + GPT（Hybrid）。交付我们自己运行生成的在线报告、完整轨迹和可复用基础设施。

## In scope

- GPT Direct：使用原仓库的持久 GPT 控制器与 GPTOnlyTools，观察图像和状态，直接生成并执行短段末端控制，不调用 π0.5。
- Hybrid：使用原仓库 RoboDojoTools；π0.5 提议动作，GPT 根据观测与反馈接受前缀、修改或接管，保留完整闭环历史。
- 优先 RoboDojo 主实验：同一冻结面板50个案例，每个案例分别运行两方法，共100条轨迹。
- RoboLab 补充实验：10任务×5种子×两方法，共100条新固定种子轨迹；不扩展其他模型基线。
- 保留原生终止条件、输入输出、prompt、工具调用、模型身份、token、初态、视频与失败证据。

## Out of scope for active work

Cosmos、DreamZero、独立 π0.5 全量基线、prefix/chunk 对照扩展。已获得的结果和资产保留为历史辅助材料，不能当作 Direct/Hybrid 复现成绩。π0.5 推理服务继续保留，作为 Hybrid 必需组件。

## Acceptance

- [x] 原生仿真与 π0.5 推理链路验证。
- [x] 原仓库持久控制器启动入口已准备；2026-09-16两方法真实app-server握手/工具注册及原生工具预检通过（零模型调用）。
- [x] 用户授权当前Codex CLI后，gpt-6-astra/xhigh真实模型响应验证通过；证据astra_live_probe_20260916。
- [x] 同一个冻结案例完成 Direct 与 Hybrid 两条完整轨迹并审计；截至 2026-10-05 已有 37 个主实验完整配对，另有 3 个 RoboLab 补充配对。
- [ ] RoboDojo 两方法100条配对轨迹完成，失败和基础设施中断区分。
- [x] 在线报告以两方法自己的结果为主；公开数字与已有基线分开（v2 自动生成主板已发布、字节与浏览器验收通过）。
- [ ] 完成两方法 RoboLab 补充评测并明确历史环境等价性限制。

## Current frontier

2026-10-04T18:02:36.994638+00:00：本机完整审计RoboDojo79/100、37/50配对；RoboLab6/100、3/50配对。
新seed2结果和基建修复将随本轮快照与报告发布；线上精确值以online_publication.json为准。
全量两套200回合尚未完成。主实验继续pack_objects_into_box / standard / layout1 Direct。

RoboLab已于17:40 UTC在原回合及归档边界切换到哈希固定的v2队列，旧服务disabled，新服务enabled且运行。
新Hybrid BlocksInBinTask seed3已ready并实际执行，GPU4/6独立，真实simulator_argv使用2228文件完整资产目录，
实际部署管理器SHA与本机一致。上一条BlockStackingSpecifiedOrderTask seed2 Direct已原生成功502步，
归档及完整审计待完成；它仍不计入当前6项。

本轮识别只杀死超时rsync父进程的清理缺口；隔离本机复现证实子进程仍可写入partial文件。
seed2坏动作块81912/259884字节已从同一静止源恢复，2217文件/276371285字节完整核验及原审计通过：
1001步、201决策、π调用0、原生成功。归档恢复现有完整plan/active/summary，分组传输阶段与只读manifest封存。
每attempt本机锁互斥；每次rsync独立进程组，全部写入者退出后才重试，清理失败则停，变更静止源清单则拒绝覆盖。
53项RoboLab回归通过，包括12项归档恢复重点检查。成绩资格与原生时域不变，最早完整失败跨历史保留。

此前已恢复发布事务、旧元数据只读归档、完整资产与空闲GPU选择、NAS服务就绪等待，并通过桌面/手机浏览器验收。
自动发布与容量维护timer继续运行，活动SQLite留本机，未通过审计的前缀/中断不计分。
当前最早原生完整回合共13条，6条通过审计、7条待归档审计；原恢复进程继续，新进度逻辑用于后续恢复轮次。
下一前沿为完成这些原回合归档与审计，继续两套冻结矩阵直到各100/100与各50/50配齐并最终上线。
RoboLab Direct为本项目EEF适配器；历史源码/完整初态未公开，不声称逐位环境等价或独立重算IK。
详细证据见RUNBOOK.md、ROBOLAB_ARCHIVE_DIAGNOSIS.md及publication_checks/remediation_20261005。

## Decisions

- 2026-09-16：用户明确“主要复现这个文档自己的两种方法就行”；优先级覆盖此前全模型扩展范围。
- 停止继续运行独立π0.5基线队列和额外模型传输；不删除已下载资产和历史结果。
- 2026-09-16追加授权：用户明确要求直接使用当前Codex CLI的GPT-6 Astra。通过CLI自身认证复用当前登录态，不复制、不输出凭据；SQLite运行状态保持每次实验独立。该决定覆盖此前要求单独实验账号的限制。
- 既有历史目标保存在 GOAL_before_scope_correction_20260916.md，仅供追溯。

## Evidence

report_interpretation_zh.md、infra/run_original_controller.sh、现有仿真与π0.5审计记录。在线报告：https://asimfish.github.io/gpt-as-policy-repro/scenes.html 。当前在线报告已以两种主方法的自有结果为主；50 个配对与 RoboLab 补充仍未全量完成。
