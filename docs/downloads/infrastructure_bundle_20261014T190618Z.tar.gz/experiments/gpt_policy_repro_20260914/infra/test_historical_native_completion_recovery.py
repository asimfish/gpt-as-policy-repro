"""Recover an audited native terminal record without rewriting supervision bytes."""
import json
import os
import subprocess

import pytest

import run_historical_cohort as original
from test_direct_complete_audit import complete_fixture
from test_gpt_direct_audit import write
from reconcile_historical_native_completion import finalize_recovered_direct


def fixture(root, success=False):
    run = root / 'episodes/direct__fixture'
    run.mkdir(parents=True)
    complete_fixture(run, success)
    plan = dict(cli_version='codex-cli 0.153.4', model='gpt-6-astra',
                reasoning_effort='xhigh',
                receipt_sha256={'historical_worker_manifest.json': 'manifest'})
    row = dict(episode_id='direct__fixture', method='gpt_only', profile_id='profile',
               identity={'case_id': 'fixture'},
               case=dict(max_episode_steps=1, max_decisions=0, control_dt=0.04))
    write(root / 'cohort_plan.json', plan)
    write(run / 'launch_claim.json', dict(episode_id=row['episode_id'],
        plan_sha256=original.sha((root / 'cohort_plan.json').read_bytes()),
        automatic_physical_retries=0))
    write(run / 'attempt.json', dict(episode_id=row['episode_id'], method='gpt_only',
        profile_id='profile', status='running', first_attempt=True, owned_processes=[]))
    write(run / 'historical_launch.json', dict(episode=row['episode_id'],
        profile_id='profile', manifest_sha256='manifest'))
    path = run / 'rollout/run.json'
    config = original.read(path)
    config.update(evaluation_case=row['identity'], **row['case'])
    write(path, config)
    path = run / 'rollout/codex_workspace/worker.json'
    worker = original.read(path)
    worker.update(codex_version=plan['cli_version'], evaluation_method='gpt_only')
    write(path, worker)
    subprocess.run(['ffmpeg', '-v', 'error', '-f', 'lavfi', '-i',
        'color=c=black:s=16x16:r=1', '-frames:v', '2', '-c:v', 'libx264',
        str(run / 'sim/sensors.mp4')], check=True, capture_output=True, timeout=20)
    return run, row, plan


def change(path, key, value):
    data = original.read(path)
    data[key] = value
    write(path, data)


@pytest.mark.parametrize('success', [False, True])
def test_complete_native_failure_and_success_keep_original_attempt_and_claim(tmp_path, success):
    run, row, plan = fixture(tmp_path, success)
    before = {name: (run / name).read_bytes() for name in ['attempt.json', 'launch_claim.json']}
    gate = finalize_recovered_direct(tmp_path, run, row, plan)
    assert gate['status'] == 'native_complete_audited'
    assert gate['native_success'] is success and gate['native_score'] == int(success)
    assert gate['native_actions'] == gate['decisions'] == 1
    assert gate['supervisor_exit_status_observed'] is False
    assert gate['source_video']['frames'] == 2
    assert before == {name: (run / name).read_bytes() for name in before}
    assert original.verify_retained(run, tmp_path, row) == gate
    assert original.next_action(run) == 'retain'
    assert not (run / 'stopped_prefix_audit.json').exists()


@pytest.mark.parametrize('name,key,value', [
    ('attempt.json', 'status', 'controller_incomplete'),
    ('attempt.json', 'first_attempt', False),
    ('attempt.json', 'controller_returncode', 0),
    ('launch_claim.json', 'automatic_physical_retries', 1),
    ('launch_claim.json', 'plan_sha256', 'other'),
    ('historical_launch.json', 'profile_id', 'other'),
    ('rollout/run.json', 'max_episode_steps', 500),
    ('rollout/codex_workspace/worker.json', 'model', 'other'),
    ('sim/evaluation_outcome.json', 'native_score', float('nan')),
    ('sim/evaluation_outcome.json', 'native_success', 1),
    ('sim/evaluation_outcome.json', 'complete', False),
])
def test_ambiguous_supervision_identity_or_grade_does_not_get_a_gate(tmp_path, name, key, value):
    run, row, plan = fixture(tmp_path)
    change(run / name, key, value)
    with pytest.raises((ValueError, AssertionError)):
        finalize_recovered_direct(tmp_path, run, row, plan)
    assert not (run / 'evidence_gate.json').exists()


def test_foreign_case_cannot_pass_by_changing_both_terminal_metadata_files(tmp_path):
    run, row, plan = fixture(tmp_path)
    for name in ['sim/evaluation_outcome.json', 'rollout/result.json']:
        change(run / name, 'evaluation_case', {'case_id': 'foreign'})
    with pytest.raises(ValueError):
        finalize_recovered_direct(tmp_path, run, row, plan)
    assert not (run / 'evidence_gate.json').exists()


@pytest.mark.parametrize('corruption', ['action', 'thread', 'terminal', 'video'])
def test_real_action_thread_terminal_and_video_corruption_prevent_recovery(tmp_path, corruption):
    run, row, plan = fixture(tmp_path)
    if corruption == 'action':
        change(run / 'sim/episode/action_000000.json', 'executed_action', [3.0] * 14)
    elif corruption == 'thread':
        path = run / 'rollout/codex_workspace/rpc_out.jsonl'
        event = json.loads(path.read_text())
        event['params']['threadId'] = 'foreign'
        write(path, event)
    elif corruption == 'terminal':
        change(run / 'sim/episode/action_000000.json', 'truncated', False)
    else:
        (run / 'sim/sensors.mp4').write_bytes(b'invalid')
    with pytest.raises((AssertionError, subprocess.CalledProcessError, ValueError)):
        finalize_recovered_direct(tmp_path, run, row, plan)
    assert not (run / 'evidence_gate.json').exists()


def test_live_owned_process_prevents_terminal_recovery(tmp_path):
    run, row, plan = fixture(tmp_path)
    from pathlib import Path
    ticks = Path('/proc', str(os.getpid()), 'stat').read_text().rsplit(')', 1)[1].split()[19]
    change(run / 'attempt.json', 'owned_processes', [dict(pid=os.getpid(), start_ticks=ticks)])
    with pytest.raises(ValueError):
        finalize_recovered_direct(tmp_path, run, row, plan)
    assert not (run / 'evidence_gate.json').exists()


@pytest.mark.parametrize('existing', ['evidence_gate.json', 'complete_action_audit.json',
                                       'native_completion_recovery.json'])
def test_existing_receipts_are_never_replaced(tmp_path, existing):
    run, row, plan = fixture(tmp_path)
    (run / existing).write_bytes(b'original')
    with pytest.raises(ValueError):
        finalize_recovered_direct(tmp_path, run, row, plan)
    assert (run / existing).read_bytes() == b'original'


def test_symlinked_evidence_is_rejected_before_creating_receipts(tmp_path):
    run, row, plan = fixture(tmp_path)
    (run / 'alias').symlink_to(run / 'attempt.json')
    with pytest.raises(ValueError):
        finalize_recovered_direct(tmp_path, run, row, plan)
    assert not (run / 'evidence_gate.json').exists()
