"""Retain a stopped first attempt with a joined 429 stream failure and no actions.

This separate auditor leaves the frozen quota auditor and execution code unchanged.
It never requests model inference, resets a simulator, or releases a launch claim.
"""
import argparse
import fcntl
import json
from pathlib import Path

from run_historical_cohort import read, utc, sha, new_json, verify_plan
from reconcile_historical_startup_failure import stopped_processes


STREAM_FAILURE = {'responseTooManyFailedAttempts': {'httpStatusCode': 429}}


def audit_stream_startup_failure(root, run, row, plan):
    if (run.absolute() != root.absolute() / 'episodes' / row['episode_id']
            or root.resolve() != root.absolute() or run.resolve() != run.absolute()):
        raise ValueError('Only the canonical selected first attempt can be audited')
    if (run / 'evidence_gate.json').exists():
        raise ValueError('Existing evidence gate is immutable')
    paths = sorted(run.rglob('*'))
    if any(path.is_symlink() for path in paths):
        raise ValueError('Evidence contains a symlink')
    attempt = read(run / 'attempt.json')
    claim = read(run / 'launch_claim.json')
    stopped_processes(attempt)
    plan_digest = sha((root / 'cohort_plan.json').read_bytes())
    if (attempt['episode_id'] != row['episode_id'] or attempt['method'] != row['method']
            or attempt['profile_id'] != row['profile_id'] or attempt['first_attempt'] is not True
            or attempt['status'] != 'controller_incomplete'
            or type(attempt['controller_returncode']) is not int
            or attempt['controller_returncode'] != 1 or attempt['native_complete'] is not False
            or claim['episode_id'] != row['episode_id'] or claim['plan_sha256'] != plan_digest
            or type(claim['automatic_physical_retries']) is not int
            or claim['automatic_physical_retries'] != 0):
        raise ValueError('Stopped first-attempt identity or no-retry contract differs')
    launch = read(run / 'historical_launch.json')
    worker = read(run / 'rollout/codex_workspace/worker.json')
    if (launch['episode'] != row['episode_id'] or launch['profile_id'] != row['profile_id']
            or launch['manifest_sha256'] != plan['receipt_sha256']['historical_worker_manifest.json']
            or worker['codex_version'] != plan['cli_version'] or worker['model'] != plan['model']
            or worker['reasoning_effort'] != plan['reasoning_effort']
            or worker['evaluation_method'] != row['method']):
        raise ValueError('Original CLI/model/source identity differs')
    forbidden = ('rollout/run.json', 'rollout/result.json', 'rollout/history.json',
                 'sim/evaluation_outcome.json', 'complete_action_audit.json',
                 'stopped_prefix_audit.json', 'stream_startup_recovery.json')
    if any((run / name).exists() for name in forbidden):
        raise ValueError('Started, scored, or already recovered work requires another audit')
    if any(path.name.startswith(('action_', 'execution_', 'response_'))
           or path.name == 'initial_observation.npz' for path in paths if path.is_file()):
        raise ValueError('Native reset or action evidence exists')
    failure = read(run / 'rollout/failure.json')
    if (failure['episode_id'] is not None or type(failure['step_id']) is not int
            or failure['step_id'] != 0 or failure['completed'] is not False):
        raise ValueError('Controller failure contains an episode, action, or completion')
    thread = worker['thread_id']
    if not isinstance(thread, str) or not thread:
        raise ValueError('A worker thread identity is required')
    events = [json.loads(line) for line in
              (run / 'rollout/codex_workspace/rpc_out.jsonl').read_text().splitlines()]
    errors = []; terminals = []
    for index, event in enumerate(events):
        method = event.get('method'); params = event.get('params', {})
        if method == 'item/tool/call':
            raise ValueError('An execution service was requested')
        if method in ('item/started', 'item/completed'):
            if params.get('item', {}).get('type') not in (
                    'agentMessage', 'reasoning', 'userMessage', 'systemMessage'):
                raise ValueError('An execution item or unknown item was observed')
        if params.get('threadId') != thread:
            continue
        if method == 'error' and params.get('willRetry') is False:
            errors.append((index, params))
        if method == 'turn/completed':
            terminals.append((index, params.get('turn', {})))
    if len(errors) != 1 or len(terminals) != 1:
        raise ValueError('A unique stopped error and terminal turn are required')
    error_index, error = errors[0]; terminal_index, terminal = terminals[0]
    terminal_code = (terminal.get('error') or {}).get('codexErrorInfo')
    error_code = (error.get('error') or {}).get('codexErrorInfo')
    if (error_code != STREAM_FAILURE or terminal_code != STREAM_FAILURE
            or terminal.get('status') != 'failed'
            or not isinstance(error.get('turnId'), str) or not error['turnId']
            or error['turnId'] != terminal.get('id') or error_index >= terminal_index):
        raise ValueError('The exact 429 stream error and failed turn do not join')
    hashes = {str(path.relative_to(run)): sha(path.read_bytes())
              for path in paths if path.is_file()}
    stopped_processes(attempt)
    return dict(schema='gpt_policy_historical_cohort_episode_gate.v1', verified=True,
        verified_utc=utc(), episode_id=row['episode_id'], method=row['method'],
        profile_id=row['profile_id'], status='infrastructure_failed',
        original_attempt_status=attempt['status'],
        failure_reason='responseTooManyFailedAttempts', service_http_status=429,
        first_attempt_retained=True, automatic_physical_retries=0,
        plan_sha256=plan_digest, native_success=None, native_score=None,
        worker_identity_verified=True, controller_source_launch_verified=True,
        runtime_identity_verified=False, stopped_prefix_decisions=0,
        stopped_prefix_actions=0, service_tool_calls=0, native_reset_observed=False,
        run_metadata_fabricated=False, matched_failed_terminal_turn_verified=True,
        recovery_source_sha256=sha(Path(__file__).read_bytes()),
        evidence_inputs_sha256=hashes,
        recovery_scope='Original first attempt retained without replay. Joined stream retry '
                       'failure is infrastructure evidence, not a native task failure or quota diagnosis.',
        historical_protocol_equivalence=False, full_blog_reproduction_complete=False)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cohort', type=Path, required=True)
    parser.add_argument('--episode', required=True)
    args = parser.parse_args(); root = args.cohort.absolute()
    with Path('/tmp/gpt-historical-worker-campaign.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        plan = verify_plan(root)
        row = next(row for pair in plan['pairs'] for row in pair['cases']
                   if row['episode_id'] == args.episode)
        run = root / 'episodes' / row['episode_id']
        proof = audit_stream_startup_failure(root, run, row, plan)
        new_json(run / 'evidence_gate.json', proof)
        print(json.dumps({key: proof[key] for key in (
            'verified', 'episode_id', 'status', 'failure_reason', 'service_http_status',
            'stopped_prefix_actions', 'native_score', 'automatic_physical_retries')}), flush=True)


if __name__ == '__main__':
    main()
