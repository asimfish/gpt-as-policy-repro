"""The public recovery chain retains hashes and denies private/forged metadata."""
import pytest

import run_historical_cohort as original
from capture_historical_cohort import recovery_evidence_names
from reconcile_historical_native_completion import finalize_recovered_direct
from test_historical_native_completion_recovery import fixture, change
from test_gpt_direct_audit import write


def completed(root):
    run, row, plan = fixture(root)
    return run, finalize_recovered_direct(root, run, row, plan)


def test_recovered_completion_exports_joined_receipt_and_original_bytes(tmp_path):
    run, gate = completed(tmp_path)
    assert recovery_evidence_names(run, gate) == [
        'native_completion_recovery.json', 'attempt.json', 'launch_claim.json']


@pytest.mark.parametrize('name', ['attempt.json', 'launch_claim.json'])
def test_changed_original_supervision_is_rejected(tmp_path, name):
    run, gate = completed(tmp_path)
    change(run / name, 'episode_id', 'another')
    with pytest.raises(ValueError):
        recovery_evidence_names(run, gate)


def test_updated_receipt_hash_cannot_hide_a_forged_native_score(tmp_path):
    run, gate = completed(tmp_path)
    (run / 'native_completion_recovery.json').chmod(0o600)
    change(run / 'native_completion_recovery.json', 'native_score', 1)
    digest = original.sha((run / 'native_completion_recovery.json').read_bytes())
    gate['native_completion_recovery_sha256'] = digest
    gate['evidence_inputs_sha256']['native_completion_recovery.json'] = digest
    with pytest.raises(ValueError):
        recovery_evidence_names(run, gate)


def test_unexpected_private_supervision_fields_are_not_exported_even_when_hashes_match(tmp_path):
    run, gate = completed(tmp_path)
    change(run / 'attempt.json', 'private_configuration', 'must not be published')
    digest = original.sha((run / 'attempt.json').read_bytes())
    receipt = original.read(run / 'native_completion_recovery.json')
    receipt['original_metadata_sha256']['attempt.json'] = digest
    (run / 'native_completion_recovery.json').chmod(0o600)
    write(run / 'native_completion_recovery.json', receipt)
    updated = original.sha((run / 'native_completion_recovery.json').read_bytes())
    gate['evidence_inputs_sha256']['attempt.json'] = digest
    gate['native_completion_recovery_sha256'] = updated
    gate['evidence_inputs_sha256']['native_completion_recovery.json'] = updated
    with pytest.raises(ValueError):
        recovery_evidence_names(run, gate)


def test_symlinked_recovery_receipt_is_rejected(tmp_path):
    run, gate = completed(tmp_path)
    path = run / 'native_completion_recovery.json'
    target = run / 'original_receipt.json'
    target.write_bytes(path.read_bytes())
    path.unlink()
    path.symlink_to(target)
    with pytest.raises(ValueError):
        recovery_evidence_names(run, gate)


def test_regular_native_gates_have_no_added_supervision_exports():
    assert recovery_evidence_names(None, {'status': 'native_complete_audited'}) == []
