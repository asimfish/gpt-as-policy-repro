"""Give new historical workers an empty catalog without moving old sessions.

The same credential, configuration, skills, plugins and per-run SQLite paths
remain in use. A private mount namespace hides only accumulated session files.
Temporary namespace capabilities are dropped before any CLI or worker starts.
"""
import argparse
import ctypes
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

INFRA = Path(__file__).absolute().parent
PUBLIC_FIELDS = {
    'schema', 'verified', 'checked_utc', 'source_sha256',
    'original_home_paths_retained', 'credential_and_config_references_preserved',
    'private_session_catalog_only', 'parent_namespace_distinct',
    'user_identity_preserved', 'namespace_capabilities_dropped',
    'session_catalog_entries_at_start', 'authentication_copied',
    'original_cli_model_profile_and_timeout_unchanged', 'physical_retries',
    'historical_protocol_equivalence', 'full_blog_reproduction_complete'}
SOURCES = ('isolate_historical_session_catalog.py',
           'continue_historical_session_catalog.sh',
           'continue_historical_parallel_admission_v4.py')


def validate_runtime_view(path):
    if path.is_symlink() or not path.is_file():
        raise ValueError('Runtime view receipt must be regular')
    proof = json.loads(path.read_text())
    true_fields = ('verified', 'original_home_paths_retained',
        'credential_and_config_references_preserved', 'private_session_catalog_only',
        'parent_namespace_distinct', 'user_identity_preserved',
        'namespace_capabilities_dropped', 'original_cli_model_profile_and_timeout_unchanged')
    if (set(proof) != PUBLIC_FIELDS
            or proof['schema'] != 'gpt_policy_historical_private_session_catalog.v1'
            or any(proof[key] is not True for key in true_fields)
            or any(proof[key] is not False for key in ('authentication_copied',
                'historical_protocol_equivalence', 'full_blog_reproduction_complete'))
            or any(type(proof[key]) is not int or proof[key] != 0 for key in (
                'physical_retries', 'session_catalog_entries_at_start'))
            or set(proof['source_sha256']) != {'infra/'+name for name in SOURCES}):
        raise ValueError('Runtime view truth or privacy boundaries differ')
    if datetime.datetime.fromisoformat(proof['checked_utc']).tzinfo is None:
        raise ValueError('Runtime view requires an explicit UTC clock')
    for name, digest in proof['source_sha256'].items():
        if hashlib.sha256((INFRA.parent/name).read_bytes()).hexdigest() != digest:
            raise ValueError('Runtime view source differs from its immutable receipt')
    return proof


def reference_identities(home):
    if home.is_symlink() or not home.is_dir() or home.stat().st_uid != os.getuid():
        raise ValueError('Existing private runtime home must be owned and regular')
    refs = {}
    for name in ('auth.json', 'config.toml', 'sessions', 'skills', 'plugins'):
        path = home / name
        if name in ('skills', 'plugins') and not path.exists():
            continue
        if path.is_symlink() or not path.exists():
            raise ValueError('Existing runtime reference is missing or symlinked')
        stat = path.stat()
        if stat.st_uid != os.getuid():
            raise ValueError('Runtime reference owner differs')
        if name.endswith(('.json', '.toml')) and not path.is_file():
            raise ValueError('Credential/config reference is not a file')
        if name in ('sessions', 'skills', 'plugins') and not path.is_dir():
            raise ValueError('Runtime catalog reference is not a directory')
        refs[name] = dict(device=stat.st_dev, inode=stat.st_ino,
                          size=stat.st_size, modified_ns=stat.st_mtime_ns)
    return refs


def make_state(home, receipt, mode, target, model_turn):
    return dict(home=str(home), receipt=str(receipt), mode=mode, target=target,
        model_turn=model_turn, uid=os.getuid(), gid=os.getgid(),
        parent_mount_namespace=os.readlink('/proc/self/ns/mnt'),
        parent_user_namespace=os.readlink('/proc/self/ns/user'),
        references=reference_identities(home),
        sources={'infra/'+name: hashlib.sha256((INFRA/name).read_bytes()).hexdigest()
                 for name in SOURCES})


def verify_references(state):
    actual = reference_identities(Path(state['home']))
    for name, expected in state['references'].items():
        # Session/skill catalogs can gain unrelated files while admission starts.
        fields = ('device', 'inode', 'size', 'modified_ns') if name in (
            'auth.json', 'config.toml') else ('device', 'inode')
        if any(actual[name][key] != expected[key] for key in fields):
            raise ValueError('Authorized runtime reference changed before isolation')
    for name, digest in state['sources'].items():
        if hashlib.sha256((INFRA.parent/name).read_bytes()).hexdigest() != digest:
            raise ValueError('Session isolation source changed')


def bind_session_catalog(source, target, libc=None):
    libc = libc or ctypes.CDLL(None, use_errno=True)
    if libc.mount(os.fsencode(source), os.fsencode(target), None, 4096, None) != 0:
        raise OSError(ctypes.get_errno(), 'Private session bind mount failed')


def drop_namespace_capabilities(libc=None):
    libc = libc or ctypes.CDLL(None, use_errno=True)
    class Header(ctypes.Structure):
        _fields_ = [('version', ctypes.c_uint32), ('pid', ctypes.c_int)]
    class Data(ctypes.Structure):
        _fields_ = [('effective', ctypes.c_uint32), ('permitted', ctypes.c_uint32),
                    ('inheritable', ctypes.c_uint32)]
    header = Header(0x20080522, 0); data = (Data * 2)()
    if libc.prctl(47, 4, 0, 0, 0) != 0:
        raise OSError(ctypes.get_errno(), 'Ambient capability removal failed')
    if libc.capset(ctypes.byref(header), ctypes.byref(data)) != 0:
        raise OSError(ctypes.get_errno(), 'Namespace capability removal failed')
    status = Path('/proc/self/status').read_text().splitlines()
    caps = [line.split(':', 1)[1].strip() for line in status
            if line.startswith(('CapInh:', 'CapPrm:', 'CapEff:', 'CapAmb:'))]
    if len(caps) != 4 or any(int(value, 16) != 0 for value in caps):
        raise ValueError('Namespace capabilities remain active')


def inside_namespace(path):
    if (path.is_symlink() or not path.is_file() or path.stat().st_uid != os.getuid()
            or path.stat().st_mode & 0o077 or path.parent.stat().st_mode & 0o077):
        raise ValueError('Private namespace state must be owned and mode 0600')
    state = json.loads(path.read_text()); home = Path(state['home'])
    if str(home) != str(Path(os.environ['CODEX_HOME']).absolute()):
        raise ValueError('The existing authorized runtime home must remain selected')
    if os.getuid() != state['uid'] or os.getgid() != state['gid']:
        raise ValueError('Namespace changed the runtime user identity')
    if (os.readlink('/proc/self/ns/mnt') == state['parent_mount_namespace']
            or os.readlink('/proc/self/ns/user') == state['parent_user_namespace']):
        raise ValueError('Both mount and user namespaces must be private')
    if any(' shared:' in line for line in Path('/proc/self/mountinfo').read_text().splitlines()):
        raise ValueError('Private mount propagation is required')
    verify_references(state)
    source = path.parent/'sessions'
    if source.is_symlink() or not source.is_dir() or any(source.iterdir()):
        raise ValueError('Private session catalog must start empty')
    bind_session_catalog(source, home/'sessions')
    if any((home/'sessions').iterdir()):
        raise ValueError('Session catalog isolation did not take effect')
    for name in state['references']:
        if name != 'sessions':
            stat = (home/name).stat(); expected = state['references'][name]
            if (stat.st_dev, stat.st_ino) != (expected['device'], expected['inode']):
                raise ValueError('Isolation changed an authorized runtime reference')
    drop_namespace_capabilities()
    proof = dict(schema='gpt_policy_historical_private_session_catalog.v1', verified=True,
        checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        source_sha256=state['sources'], original_home_paths_retained=True,
        credential_and_config_references_preserved=True, private_session_catalog_only=True,
        parent_namespace_distinct=True, user_identity_preserved=True,
        namespace_capabilities_dropped=True, session_catalog_entries_at_start=0,
        authentication_copied=False, original_cli_model_profile_and_timeout_unchanged=True,
        physical_retries=0, historical_protocol_equivalence=False,
        full_blog_reproduction_complete=False)
    assert set(proof) == PUBLIC_FIELDS
    receipt = Path(state['receipt'])
    with receipt.open('x') as stream:
        json.dump(proof, stream, indent=2); stream.write('\n')
    receipt.chmod(0o444)
    if state['mode'] == 'verify':
        return
    if state['mode'] == 'probe':
        from probe_historical_service import probe
        result = probe(Path(state['target']), model_turn=state['model_turn'])
        print(json.dumps({k:result.get(k) for k in ('verified', 'exception_type',
            'model_available', 'model_turn_start_calls', 'simulator_steps')}), flush=True)
        if result['verified'] is not True:
            raise SystemExit(1)
    elif state['mode'] == 'cohort':
        from continue_historical_parallel_admission_v4 import main
        sys.argv = [str(INFRA/'continue_historical_parallel_admission_v4.py'),
                    '--cohort', state['target'], '--runtime-view', str(receipt)]
        main()
    else:
        raise ValueError('Unknown isolated historical action')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--namespace-state', type=Path)
    parser.add_argument('--receipt', type=Path)
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument('--verify-only', action='store_true')
    modes.add_argument('--probe-output', type=Path)
    modes.add_argument('--cohort', type=Path)
    parser.add_argument('--probe-model', action='store_true')
    args = parser.parse_args()
    if args.namespace_state:
        inside_namespace(args.namespace_state.absolute()); return
    if args.receipt is None or args.receipt.exists() or args.receipt.is_symlink():
        raise ValueError('A fresh immutable runtime view receipt is required')
    mode = 'verify' if args.verify_only else 'probe' if args.probe_output else 'cohort'
    target = args.probe_output or args.cohort
    if mode != 'verify' and (target is None
            or os.environ.get('ROLLOUT_USE_CURRENT_CODEX_HOME') != '1'
            or os.environ.get('ROLLOUT_AUTH_PROFILE') != 'codex_a'):
        raise ValueError('Existing authorized route must be explicitly selected')
    if args.probe_model and mode != 'probe':
        raise ValueError('Only an explicit text-only availability probe permits this flag')
    home = Path(os.environ['CODEX_HOME']).absolute()
    private = Path(tempfile.mkdtemp(prefix='gpt-historical-private-session-view-'))
    private.chmod(0o700); (private/'sessions').mkdir(mode=0o700)
    state = make_state(home, args.receipt.absolute(), mode,
                       str(target.absolute()) if target else None, args.probe_model)
    path = private/'state.json'
    with path.open('x') as stream: json.dump(state, stream)
    path.chmod(0o600)
    os.execvp('unshare', ['unshare', '--user', '--map-current-user', '--keep-caps',
        '--mount', '--propagation', 'private', sys.executable, str(Path(__file__).absolute()),
        '--namespace-state', str(path)])


if __name__ == '__main__': main()
