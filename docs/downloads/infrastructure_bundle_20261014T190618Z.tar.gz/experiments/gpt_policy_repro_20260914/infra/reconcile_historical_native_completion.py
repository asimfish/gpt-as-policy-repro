"""Seal a stopped Direct first attempt whose native terminal evidence is complete.

The original supervisor metadata is retained byte for byte, including its stale
running status. No process exit code is inferred. The frozen complete action
auditor and full video decoder establish completion and the original grade.
"""
import argparse
import fcntl
import json
import math
from pathlib import Path

import run_historical_cohort as original
from reconcile_historical_startup_failure import stopped_processes


def finalize_recovered_direct(root, run, row, plan):
    if (run.absolute() != root.absolute() / 'episodes' / row['episode_id']
            or run.resolve() != run.absolute() or row['method'] != 'gpt_only'):
        raise ValueError('Only a canonical selected Direct first attempt can be recovered')
    for name in ('evidence_gate.json', 'complete_action_audit.json',
                 'native_completion_recovery.json', 'stopped_prefix_audit.json'):
        if (run / name).exists():
            raise ValueError('Existing evidence receipts are immutable')
    paths = sorted(run.rglob('*'))
    if any(path.is_symlink() for path in paths):
        raise ValueError('Retained evidence contains a symlink')
    metadata_names = ('attempt.json', 'launch_claim.json', 'historical_launch.json',
                      'rollout/run.json', 'rollout/codex_workspace/worker.json',
                      'rollout/result.json', 'sim/evaluation_outcome.json')
    before = {name: original.sha((run / name).read_bytes()) for name in metadata_names}
    attempt = original.read(run / 'attempt.json')
    claim = original.read(run / 'launch_claim.json')
    stopped_processes(attempt)
    plan_digest = original.sha((root / 'cohort_plan.json').read_bytes())
    if (attempt['episode_id'] != row['episode_id'] or attempt['method'] != row['method']
            or attempt['profile_id'] != row['profile_id'] or attempt['first_attempt'] is not True
            or attempt['status'] != 'running'
            or any(key in attempt for key in ('controller_returncode', 'finished_utc', 'native_complete'))
            or claim['episode_id'] != row['episode_id'] or claim['plan_sha256'] != plan_digest
            or claim['automatic_physical_retries'] != 0):
        raise ValueError('Unfinalized supervision does not bind the original first attempt')
    launch = original.read(run / 'historical_launch.json')
    worker = original.read(run / 'rollout/codex_workspace/worker.json')
    config = original.read(run / 'rollout/run.json')
    if (launch['episode'] != row['episode_id'] or launch['profile_id'] != row['profile_id']
            or launch['manifest_sha256'] != plan['receipt_sha256']['historical_worker_manifest.json']
            or worker['codex_version'] != plan['cli_version'] or worker['model'] != plan['model']
            or worker['reasoning_effort'] != plan['reasoning_effort']
            or worker['evaluation_method'] != row['method']
            or config['evaluation_case'] != row['identity']
            or any(config[key] != row['case'][key]
                   for key in ('max_episode_steps', 'max_decisions', 'control_dt'))):
        raise ValueError('Runtime CLI/model/source/case/budget identity differs')
    outcome = original.read(run / 'sim/evaluation_outcome.json')
    score = outcome.get('native_score')
    count = outcome.get('native_control_steps')
    if (outcome.get('evaluation_case') != row['identity'] or outcome.get('complete') is not True
            or outcome.get('valid_for_success_rate') is not True
            or type(outcome.get('native_success')) is not bool
            or type(score) not in (int, float) or not math.isfinite(score) or not 0 <= score <= 1
            or type(count) is not int or not 0 < count <= row['case']['max_episode_steps']):
        raise ValueError('Native terminal grade or frozen case identity is invalid')
    proof = original.audit_direct(run)
    if (proof.get('verified') is not True or proof.get('complete_episode') is not True
            or proof['native_actions'] != count or proof.get('pi05_inference_calls') != 0):
        raise ValueError('A complete original Direct action chain is required')
    video = original.video_coverage(run / 'sim/sensors.mp4', count + 1)
    for name, digest in proof['files_sha256'].items():
        if original.sha((run / name).read_bytes()) != digest:
            raise ValueError('Action evidence changed during recovery')
    if before != {name: original.sha((run / name).read_bytes()) for name in metadata_names}:
        raise ValueError('Original supervision or terminal metadata changed')
    stopped_processes(attempt)
    source_digest = original.sha(Path(__file__).read_bytes())
    receipt = dict(schema='gpt_policy_historical_native_completion_recovery.v1',
        verified=True, verified_utc=original.utc(), episode_id=row['episode_id'],
        original_attempt_status=attempt['status'], original_metadata_sha256=before,
        plan_sha256=plan_digest, recovery_source_sha256=source_digest,
        supervisor_exit_status_observed=False, supervisor_stop_cause='unknown',
        controller_returncode=None, original_attempt_bytes_preserved=True,
        original_claim_bytes_preserved=True, native_completion_proven_by_action_audit=True,
        native_actions=count, native_success=outcome['native_success'], native_score=score,
        model_calls=0, simulator_steps=0, physical_retries=0,
        historical_protocol_equivalence=False, full_blog_reproduction_complete=False)
    original.new_json(run / 'complete_action_audit.json', proof)
    original.new_json(run / 'native_completion_recovery.json', receipt)
    gate = dict(schema='gpt_policy_historical_cohort_episode_gate.v1', verified=True,
        verified_utc=original.utc(), episode_id=row['episode_id'], method=row['method'],
        profile_id=row['profile_id'], status='native_complete_audited',
        original_attempt_status=attempt['status'], first_attempt_retained=True,
        automatic_physical_retries=0, plan_sha256=plan_digest,
        native_success=outcome['native_success'], native_score=score,
        native_actions=count, decisions=proof['decisions'], runtime_identity_verified=True,
        complete_action_audit_sha256=original.sha((run / 'complete_action_audit.json').read_bytes()),
        source_video=video, native_completion_recovery_sha256=original.sha(
            (run / 'native_completion_recovery.json').read_bytes()),
        recovery_source_sha256=source_digest, supervisor_exit_status_observed=False,
        historical_protocol_equivalence=False, full_blog_reproduction_complete=False)
    paths = sorted(run.rglob('*'))
    if any(path.is_symlink() for path in paths):
        raise ValueError('Retained evidence contains a symlink')
    gate['evidence_inputs_sha256'] = {str(path.relative_to(run)): original.sha(path.read_bytes())
                                    for path in paths if path.is_file()}
    original.new_json(run / 'evidence_gate.json', gate)
    return gate


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cohort', type=Path, required=True)
    parser.add_argument('--episode', required=True)
    args = parser.parse_args()
    root = args.cohort.absolute()
    lock = Path('/tmp/gpt-historical-worker-campaign.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    plan = original.verify_plan(root)
    row = next(row for pair in plan['pairs'] for row in pair['cases']
               if row['episode_id'] == args.episode)
    gate = finalize_recovered_direct(root, root / 'episodes' / row['episode_id'], row, plan)
    print(json.dumps({key: gate[key] for key in ('verified', 'episode_id', 'status',
        'native_actions', 'decisions', 'native_success', 'native_score',
        'automatic_physical_retries', 'supervisor_exit_status_observed')}), flush=True)


if __name__ == '__main__':
    main()
