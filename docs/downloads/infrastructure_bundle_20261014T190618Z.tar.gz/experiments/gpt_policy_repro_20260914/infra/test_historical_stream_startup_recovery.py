"""Regression coverage for the recorded non-executing 429 stream failure."""
import copy
import json
from pathlib import Path
import tempfile
import unittest

from test_historical_startup_recovery import HistoricalStartupRecoveryTests
from reconcile_historical_startup_failure import audit_startup_failure
from reconcile_historical_stream_startup_failure import audit_stream_startup_failure, STREAM_FAILURE


class HistoricalStreamStartupRecoveryTests(unittest.TestCase):
    def fixture(self, temporary):
        root, run, row, plan, put = HistoricalStartupRecoveryTests().fixture(temporary)
        path = run / 'rollout/codex_workspace/rpc_out.jsonl'
        events = [json.loads(line) for line in path.read_text().splitlines()]
        events[0]['params']['error']['codexErrorInfo'] = copy.deepcopy(STREAM_FAILURE)
        events[1]['params']['turn']['error']['codexErrorInfo'] = copy.deepcopy(STREAM_FAILURE)
        self.write_events(path, events)
        return root, run, row, plan, put, path, events

    @staticmethod
    def write_events(path, events):
        path.write_text(''.join(json.dumps(event) + '\n' for event in events))

    def test_original_auditor_reproduces_recorded_missing_quota_join(self):
        with tempfile.TemporaryDirectory() as temporary:
            root, run, row, plan, *_ = self.fixture(temporary)
            with self.assertRaisesRegex(ValueError, 'No uniquely joined quota failure'):
                audit_startup_failure(root, run, row, plan)

    def test_joined_429_is_unscored_infrastructure_and_preserves_original_bytes(self):
        with tempfile.TemporaryDirectory() as temporary:
            root, run, row, plan, *_ = self.fixture(temporary)
            before = {p: p.read_bytes() for p in run.rglob('*') if p.is_file()}
            gate = audit_stream_startup_failure(root, run, row, plan)
            self.assertEqual(gate['status'], 'infrastructure_failed')
            self.assertEqual(gate['failure_reason'], 'responseTooManyFailedAttempts')
            self.assertIsNone(gate['native_score']); self.assertIsNone(gate['native_success'])
            self.assertEqual(gate['stopped_prefix_actions'], 0)
            self.assertFalse(gate['runtime_identity_verified'])
            self.assertTrue(gate['matched_failed_terminal_turn_verified'])
            self.assertEqual(before, {p: p.read_bytes() for p in run.rglob('*') if p.is_file()})

    def test_foreign_mismatched_duplicate_and_reordered_failures_are_rejected(self):
        for variant in ('foreign', 'different_turn', 'duplicate', 'reordered', 'completed'):
            with self.subTest(variant=variant), tempfile.TemporaryDirectory() as temporary:
                root, run, row, plan, _, path, events = self.fixture(temporary)
                if variant == 'foreign': events[0]['params']['threadId'] = 'foreign'
                elif variant == 'different_turn': events[1]['params']['turn']['id'] = 'another'
                elif variant == 'duplicate': events.append(copy.deepcopy(events[0]))
                elif variant == 'reordered': events.reverse()
                elif variant == 'completed': events[1]['params']['turn']['status'] = 'completed'
                self.write_events(path, events)
                with self.assertRaises(ValueError): audit_stream_startup_failure(root, run, row, plan)

    def test_quota_other_http_status_and_retryable_errors_are_rejected(self):
        for code in ('usageLimitExceeded', {'responseTooManyFailedAttempts': {'httpStatusCode': 503}},
                     {'responseStreamDisconnected': {'httpStatusCode': 429}}):
            with self.subTest(code=code), tempfile.TemporaryDirectory() as temporary:
                root, run, row, plan, _, path, events = self.fixture(temporary)
                events[0]['params']['error']['codexErrorInfo'] = code
                events[1]['params']['turn']['error']['codexErrorInfo'] = code
                self.write_events(path, events)
                with self.assertRaises(ValueError): audit_stream_startup_failure(root, run, row, plan)
        with tempfile.TemporaryDirectory() as temporary:
            root, run, row, plan, _, path, events = self.fixture(temporary)
            events[0]['params']['willRetry'] = True
            self.write_events(path, events)
            with self.assertRaises(ValueError): audit_stream_startup_failure(root, run, row, plan)

    def test_retrying_503_before_joined_terminal_429_does_not_fabricate_quota(self):
        with tempfile.TemporaryDirectory() as temporary:
            root, run, row, plan, _, path, events = self.fixture(temporary)
            retry = copy.deepcopy(events[0]); retry['params']['willRetry'] = True
            retry['params']['error']['codexErrorInfo'] = {'responseStreamDisconnected': {'httpStatusCode': 503}}
            self.write_events(path, [retry, *events])
            self.assertEqual(audit_stream_startup_failure(root, run, row, plan)['service_http_status'], 429)

    def test_native_reset_action_or_tool_even_on_foreign_thread_is_rejected(self):
        for variant in ('run', 'observation', 'action', 'tool', 'unknown_item'):
            with self.subTest(variant=variant), tempfile.TemporaryDirectory() as temporary:
                root, run, row, plan, put, path, events = self.fixture(temporary)
                if variant == 'run': put('rollout/run.json', {})
                elif variant == 'observation': put('sim/initial_observation.npz', {})
                elif variant == 'action': put('sim/native/action_000000.json', {})
                elif variant == 'tool':
                    events.append({'method': 'item/tool/call', 'params': {'threadId': 'foreign'}})
                else:
                    events.append({'method': 'item/started', 'params': {'item': {'type': 'futureUnknown'}}})
                self.write_events(path, events)
                with self.assertRaises(ValueError): audit_stream_startup_failure(root, run, row, plan)

    def test_changed_model_completed_failure_or_existing_gate_is_rejected(self):
        for variant in ('model', 'completed', 'gate', 'native_identity'):
            with self.subTest(variant=variant), tempfile.TemporaryDirectory() as temporary:
                root, run, row, plan, put, *_ = self.fixture(temporary)
                if variant == 'model':
                    p = run / 'rollout/codex_workspace/worker.json'; d = json.loads(p.read_text())
                    d['model'] = 'other'; p.write_text(json.dumps(d))
                elif variant == 'completed': put('rollout/failure.json', {'episode_id': None, 'step_id': 0, 'completed': True})
                elif variant == 'gate': put('evidence_gate.json', {'verified': True})
                else: put('rollout/failure.json', {'episode_id': 'native', 'step_id': 0, 'completed': False})
                with self.assertRaises(ValueError): audit_stream_startup_failure(root, run, row, plan)

    def test_noncanonical_run_and_symlink_are_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            root, run, row, plan, *_ = self.fixture(temporary)
            with self.assertRaises(ValueError): audit_stream_startup_failure(root, run, {**row, 'episode_id': 'other'}, plan)
            (run / 'linked').symlink_to(run / 'attempt.json')
            with self.assertRaises(ValueError): audit_stream_startup_failure(root, run, row, plan)


if __name__ == '__main__':
    unittest.main()
