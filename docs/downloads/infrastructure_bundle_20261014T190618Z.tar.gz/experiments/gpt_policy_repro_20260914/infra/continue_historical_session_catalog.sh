#!/usr/bin/env bash
set -euo pipefail
task_infra="$(cd "$(dirname "$0")" && pwd)"
source "$task_infra/env.sh"
"$ROBO_PYTHON" - <<'PY'
from pathlib import Path
assert '570.124.06' in Path('/proc/driver/nvidia/version').read_text(), 'Reviewed kernel driver changed'
PY
sha256sum --check --status "$task_infra/driver570_jit_library_pins.txt"
# Root ownership is verified in the original host user namespace, before isolation.
task_loader_dir="$("$ROBO_PYTHON" "$task_infra/driver570_loader_aliases.py" --pins "$task_infra/driver570_jit_library_pins.txt")"
export LD_LIBRARY_PATH="$task_loader_dir${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export LD_PRELOAD="/usr/lib/x86_64-linux-gnu/libcuda.so.570.124.06:/usr/lib/x86_64-linux-gnu/libnvidia-ml.so.570.124.06:/usr/lib/x86_64-linux-gnu/libEGL_nvidia.so.570.124.06:/usr/lib/x86_64-linux-gnu/libGLX_nvidia.so.570.124.06:/usr/lib/x86_64-linux-gnu/libnvidia-ptxjitcompiler.so.570.124.06:/usr/lib/x86_64-linux-gnu/libnvidia-gpucomp.so.570.124.06${LD_PRELOAD:+:$LD_PRELOAD}"
export PYTHONDONTWRITEBYTECODE=1
export PATH="$(dirname "$ROBO_PYTHON"):$PATH"
exec "$ROBO_PYTHON" "$task_infra/isolate_historical_session_catalog.py" "$@"
