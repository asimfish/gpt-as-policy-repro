import ast
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import isolate_historical_session_catalog as view


class SessionCatalogTests(unittest.TestCase):
    def fixture(self, directory):
        home = Path(directory) / 'home'
        home.mkdir(mode=0o700)
        for name in ('auth.json', 'config.toml'):
            (home / name).write_text('fixture reference only\n')
            (home / name).chmod(0o600)
        (home / 'sessions').mkdir(mode=0o700)
        (home / 'sessions' / 'previous.jsonl').write_text('retained original history\n')
        for name in ('skills', 'plugins'):
            (home / name).mkdir()
        return home

    def test_private_mount_keeps_uid_credentials_and_source_history(self):
        with tempfile.TemporaryDirectory() as directory:
            home = self.fixture(directory)
            before = {p.name: p.read_bytes() for p in home.iterdir() if p.is_file()}
            output = Path(directory) / 'receipt.json'
            env = dict(os.environ, CODEX_HOME=str(home))
            result = subprocess.run([sys.executable, view.__file__, '--verify-only',
                                     '--receipt', str(output)], env=env,
                                    capture_output=True, timeout=20)
            self.assertEqual(result.returncode, 0, result.stderr.decode())
            proof = json.loads(output.read_text())
            self.assertTrue(proof['verified'])
            self.assertTrue(proof['user_identity_preserved'])
            self.assertTrue(proof['namespace_capabilities_dropped'])
            self.assertTrue(proof['parent_namespace_distinct'])
            self.assertTrue(proof['credential_and_config_references_preserved'])
            self.assertEqual(proof['session_catalog_entries_at_start'], 0)
            self.assertFalse(proof['authentication_copied'])
            self.assertEqual((home / 'sessions' / 'previous.jsonl').read_text(),
                             'retained original history\n')
            self.assertEqual(before, {p.name:p.read_bytes() for p in home.iterdir() if p.is_file()})
            self.assertNotIn(str(home), output.read_text())
            self.assertEqual(view.validate_runtime_view(output), proof)
            for key, value in [('private_home', str(home)),
                    ('namespace_capabilities_dropped', False),
                    ('authentication_copied', True),
                    ('historical_protocol_equivalence', True),
                    ('physical_retries', True)]:
                with self.subTest(key=key):
                    changed = dict(proof); changed[key] = value
                    candidate = Path(directory) / 'changed.json'
                    candidate.write_text(json.dumps(changed))
                    with self.assertRaises(ValueError): view.validate_runtime_view(candidate)

    def test_existing_receipt_cannot_be_overwritten(self):
        with tempfile.TemporaryDirectory() as directory:
            home = self.fixture(directory); output = Path(directory) / 'receipt.json'
            output.write_text('preserved')
            result = subprocess.run([sys.executable, view.__file__, '--verify-only',
                                     '--receipt', str(output)], env=dict(os.environ, CODEX_HOME=str(home)),
                                    capture_output=True, timeout=10)
            self.assertNotEqual(result.returncode, 0)
            self.assertEqual(output.read_text(), 'preserved')

    def test_symlinked_sensitive_reference_is_rejected(self):
        for name in ('auth.json', 'config.toml', 'sessions'):
            with self.subTest(name=name), tempfile.TemporaryDirectory() as directory:
                home = self.fixture(directory); source = home / name
                saved = home / ('saved_' + name); source.rename(saved)
                source.symlink_to(saved, target_is_directory=saved.is_dir())
                with self.assertRaises(ValueError): view.reference_identities(home)

    def test_missing_required_reference_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            home = self.fixture(directory); (home / 'auth.json').unlink()
            with self.assertRaises(ValueError): view.reference_identities(home)

    def test_mount_failure_is_not_accepted(self):
        class Denied:
            def mount(self, *args): return -1
        with self.assertRaises(OSError):
            view.bind_session_catalog(Path('/source'), Path('/target'), libc=Denied())

    def test_capability_drop_failure_is_not_accepted(self):
        class Denied:
            def prctl(self, *args): return -1
        with self.assertRaises(OSError): view.drop_namespace_capabilities(libc=Denied())

    def test_namespace_state_rejects_changed_private_bytes(self):
        with tempfile.TemporaryDirectory() as directory:
            home = self.fixture(directory)
            state = view.make_state(home, Path(directory) / 'receipt.json', 'verify', None, False)
            (home / 'config.toml').write_text('changed after outer validation')
            with self.assertRaises(ValueError): view.verify_references(state)

    def test_privacy_receipt_has_only_declared_fields(self):
        self.assertEqual(view.PUBLIC_FIELDS, {
            'schema', 'verified', 'checked_utc', 'source_sha256',
            'original_home_paths_retained', 'credential_and_config_references_preserved',
            'private_session_catalog_only', 'parent_namespace_distinct',
            'user_identity_preserved', 'namespace_capabilities_dropped',
            'session_catalog_entries_at_start', 'authentication_copied',
            'original_cli_model_profile_and_timeout_unchanged',
            'physical_retries', 'historical_protocol_equivalence',
            'full_blog_reproduction_complete'})

    def test_v4_retains_the_original_execution_and_stopping_loop(self):
        directory = Path(view.__file__).parent
        loops = []
        for name in ('continue_historical_parallel_admission_v3.py',
                     'continue_historical_parallel_admission_v4.py'):
            tree = ast.parse((directory / name).read_text())
            main = next(node for node in tree.body if isinstance(node, ast.FunctionDef)
                        and node.name == 'main')
            loop = next(node for node in main.body if isinstance(node, ast.For)
                        and isinstance(node.iter, ast.Name) and node.iter.id == 'pending')
            loops.append(ast.dump(loop, include_attributes=False))
        self.assertEqual(*loops)

    def test_root_library_validation_happens_before_namespace_entry(self):
        directory = Path(view.__file__).parent
        original = (directory / 'continue_historical_driver570_loader.sh').read_text()
        current = (directory / 'continue_historical_session_catalog.sh').read_text()
        meaningful = lambda text:[line for line in text.splitlines()
                                  if line.strip() and not line.startswith('#')
                                  and not line.startswith('exec ')]
        self.assertEqual(meaningful(original), meaningful(current))


if __name__ == '__main__': unittest.main()
