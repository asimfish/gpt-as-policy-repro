const fs=require('fs'),path=require('path'),crypto=require('crypto');
const root=path.resolve(__dirname,'../../../..');
const {chromium}=require(path.join(root,'gpt-policy-report-site/node_modules/playwright'));
const base=(process.env.BASE_URL||'http://127.0.0.1:20880').replace(/\/$/,'');
const online=base.startsWith('https:');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/google-chrome',headless:true,args:['--no-sandbox'],...(online?{proxy:{server:'http://127.0.0.1:7897'}}:{})});
 const page=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[],views=[],screens=[];
 let alignmentRows=0,comparableComplete=0,scoreDifferences=0;
 page.on('pageerror',e=>errors.push(String(e)));
 page.on('response',r=>{if(r.status()>=400)errors.push(r.status()+' '+r.url())});
 for(const width of [1440,390]){
  await page.setViewportSize({width,height:width===390?844:1000});
  await page.goto(base+'/scenes.html',{waitUntil:'networkidle'});
  if(await page.locator('#blog-comparison-summary').count()!==1)throw Error('Duplicated comparison entry');
  await page.locator('#blog-comparison-summary a[href="blog-comparison.html"]').click();
  await page.waitForURL('**/blog-comparison.html');
  const value=await page.evaluate(async()=>await(await fetch('data/blog-comparison.json')).json());
  if(value.historical_equivalence_verified!==false||value.reproduction_episodes.length!==200||value.robodojo.case_alignment.common_method_runs!==98)throw Error('Comparison identity');
  if(value.original_record_recovery.core_archives_verified!==100||value.original_record_recovery.original_control_steps_verified!==80971)throw Error('Original record recovery');
  if(await page.locator('#original-record-recovery').count()!==1)throw Error('Recovery panel missing');
  if(await page.locator('#historical-worker-fidelity').count()!==1||value.historical_worker_fidelity.common_summary.crosses_original_five_rejection_stop!==11||value.historical_worker_fidelity.compatibility_probe_model_calls!==0)throw Error('Historical worker boundary');
  if(await page.locator('#historical-native-execution').count()!==1||value.historical_worker_fidelity.original_version_execution.canary_results.length!==2||value.historical_worker_fidelity.original_version_execution.remaining_cohort.episodes_planned!==98)throw Error('Original-version physical evidence');
  const cohort=value.historical_worker_fidelity.original_version_execution.remaining_cohort;
  if(cohort.episode_results.length!==cohort.first_attempts_audited||cohort.episode_results.filter(r=>r.status==='native_complete_audited').length!==cohort.native_complete_audited)throw Error('Historical completion counts');
  for(const r of cohort.episode_results.filter(r=>r.status!=='native_complete_audited')){
   if(r.native_score!==null||r.native_success!==null)throw Error('Incomplete first attempt falsely scored: '+r.episode_id);
  }
  const startup=cohort.episode_results.find(r=>r.status==='startup_failed_no_execution');
  if(!startup||startup.stopped_prefix_actions!==0||startup.native_score!==null||startup.native_success!==null||startup.runtime_identity_verified!==false)throw Error('Startup failure falsely scored');
  if(await page.locator('#historical-cohort-results').count()!==1)throw Error('Historical retained-attempt panel missing');
  const alignment=cohort.original_result_alignment;
  if(!alignment||alignment.records.length!==cohort.first_attempts_audited||alignment.summary.audited_attempts!==cohort.first_attempts_audited||alignment.summary.own_complete_native!==cohort.native_complete_audited)throw Error('Historical author alignment denominators');
  if(alignment.original_record_recount_sha256!==value.original_record_recovery.original_record_recount_sha256)throw Error('Historical author record identity');
  alignmentRows=alignment.records.length;comparableComplete=alignment.summary.both_native_complete;scoreDifferences=alignment.summary.score_differences;
  if(alignment.summary.score_matches+scoreDifferences!==comparableComplete)throw Error('Historical author score sample count');
  if(await page.locator('table').count()!==6||await page.locator('tbody tr').count()!==144+alignmentRows)throw Error('Comparison denominators');
  const text=await page.locator('main').innerText();
  for(const expected of ['次基础设施失败','上述未完成尝试均无完整成绩','原版本配对试跑已完成','同案例原Hybrid分数为0.05','其余49对 / 98次首次尝试','自动物理重试0','累计5次','30项离线','0.153.4','0.969–1.130','100000','180','500','尚未终止不计为失败','RoboLab缺少独立用量汇总','13/49','11/49','80,971','48条原生完整','初始关节状态哈希0/98','末端位置98/98','姿态四元数哈希0/98','prompt哈希0/98','3.253e-18','1.490e-08','98/98条归档prompt'])if(!text.includes(expected))throw Error('Missing boundary label: '+expected);
  await page.locator('#historical-original-alignment summary').click();
  const historicalRows=page.locator('#historical-original-alignment tbody tr');
  if(await historicalRows.count()!==alignmentRows)throw Error('Missing historical author rows');
  for(const r of alignment.records){
   const rendered=historicalRows.filter({has:page.locator('td:first-child',{hasText:r.episode_id})});
   if(await rendered.count()!==1||(await rendered.getAttribute('data-comparison-status'))!==r.comparison_status)throw Error('Historical author classification drift: '+r.episode_id);
   if(!r.both_native_complete&&(r.score_match!==null||r.success_match!==null))throw Error('Incomplete historical author pair scored');
   if(!r.own_complete_native&&(await rendered.locator('td').nth(3).innerText())!=='原生未完整')throw Error('Incomplete own row rendered as a score');
   if(!r.original_complete_native&&(await rendered.locator('td').nth(2).innerText())!=='原生未完整')throw Error('Incomplete author row rendered as a score');
  }
  await page.locator('#comparison-cases details summary').click();
  if(await page.locator('#comparison-cases details tbody tr').count()!==98||await page.locator('#comparison-cases details a').count()!==98)throw Error('Common case evidence links');
  const first=value.robodojo.case_alignment.cases[0];
  const response=await page.request.get(base+'/'+first.evidence);if(!response.ok())throw Error('Case evidence unavailable');
  const evidence=await response.json();
  if(evidence.case_id!==first.case_id||evidence.method!==first.method||evidence.success!==first.reproduction_success)throw Error('Case evidence drift');
  const dims=await page.evaluate(()=>({viewport:innerWidth,scroll:document.documentElement.scrollWidth,tableScrollable:[...document.querySelectorAll('.scroll')].map(e=>e.scrollWidth>e.clientWidth)}));
  if(dims.scroll>dims.viewport)throw Error('Page overflow');
  if(width===390&&!dims.tableScrollable.every(Boolean))throw Error('Mobile comparison tables not scrollable');
  const image=path.join(__dirname,(online?'online':'local')+'_'+width+'.png');
  await page.evaluate(()=>window.scrollTo(0,0));
  await page.screenshot({path:image});screens.push({file:path.basename(image),sha256:crypto.createHash('sha256').update(fs.readFileSync(image)).digest('hex')});
  views.push({width,...dims,case_evidence_verified:true});
 }
 for(const name of ['gpt-methods.html','gpt-methods-valid.html']){
  await page.goto(base+'/'+name,{waitUntil:'domcontentloaded'});
  await page.locator('#blog-comparison-summary a[href="blog-comparison.html"]').waitFor({state:'visible'});
  if(await page.locator('#blog-comparison-summary').count()!==1||await page.locator('#blog-comparison-summary a[href="blog-comparison.html"]').count()!==1)throw Error('Method page entry: '+name);
 }
 if(errors.length)throw Error(errors.join('\n'));
 const result={verified:true,base,verified_utc:new Date().toISOString(),comparison_methods:2,native_episodes:200,original_core_archives:100,original_control_steps:80971,common_method_runs:98,table_rows:144+alignmentRows,historical_alignment_rows:alignmentRows,historical_comparable_complete:comparableComplete,historical_score_differences:scoreDifferences,views,screens,errors};
 fs.writeFileSync(path.join(__dirname,'browser_'+(online?'online':'local')+'.json'),JSON.stringify(result,null,2)+'\n');
 console.log(JSON.stringify(result));await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
