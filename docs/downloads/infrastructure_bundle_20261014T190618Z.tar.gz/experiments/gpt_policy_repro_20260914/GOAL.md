# GPT-as-Policy 两种方法复现目标

## Outcome

按用户 2026-09-16 的范围修正，主要复现报告自己的两种方法：GPT Direct 与 π0.5 + GPT（Hybrid）。交付我们自己运行生成的在线报告、完整轨迹和可复用基础设施。

## In scope

- GPT Direct：使用原仓库的持久 GPT 控制器与 GPTOnlyTools，观察图像和状态，直接生成并执行短段末端控制，不调用 π0.5。
- Hybrid：使用原仓库 RoboDojoTools；π0.5 提议动作，GPT 根据观测与反馈接受前缀、修改或接管，保留完整闭环历史。
- 优先 RoboDojo 主实验：同一冻结面板50个案例，每个案例分别运行两方法，共100条轨迹。
- RoboLab 补充实验：10任务×5种子×两方法，共100条新固定种子轨迹；不扩展其他模型基线。
- 保留原生终止条件、输入输出、prompt、工具调用、模型身份、token、初态、视频与失败证据。

## Out of scope for active work

Cosmos、DreamZero、独立 π0.5 全量基线、prefix/chunk 对照扩展。已获得的结果和资产保留为历史辅助材料，不能当作 Direct/Hybrid 复现成绩。π0.5 推理服务继续保留，作为 Hybrid 必需组件。

## Acceptance

- [x] 原生仿真与 π0.5 推理链路验证。
- [x] 原仓库持久控制器启动入口已准备；2026-09-16两方法真实app-server握手/工具注册及原生工具预检通过（零模型调用）。
- [x] 用户授权当前Codex CLI后，gpt-6-astra/xhigh真实模型响应验证通过；证据astra_live_probe_20260916。
- [x] 同一个冻结案例完成 Direct 与 Hybrid 两条完整轨迹并审计；2026-10-07 两套所选实验均配齐50对。
- [x] RoboDojo 有效50对两方法100条轨迹完成并逐条动作审计，失败与基础设施中断区分；原99条已审计结果和无效布局记录另行保留。
- [x] 在线报告以两方法自己的结果为主；公开数字与已有基线分开（v2 自动生成主板已发布、字节与浏览器验收通过）。
- [x] 完成两方法 RoboLab 补充评测并明确历史环境等价性限制。
- [x] 所选200个完整回合及保留原回合通过原始证据、完整视频、线上文件和同一提交CI最终验收。

## Current frontier

<!-- CURRENT_HISTORICAL_FRONTIER -->
2026-10-14 18:15 UTC（本地10-15）当前前沿：历史原版本39/98首次尝试已审计，32条原生完整（14成功/18失败）、7条无成绩保留；所有137759项原始输入已由原审计器重核（2334.34秒）。新准入20261014T170654Z、SHAd5df4ac697eba78a28ad95b7f7ac127195baaae24df13bf5b99b6fd022f70b25及同gpt-6-astra/xhigh/CLI0.153.4单次exact-OK探测通过，17续进来源字节不变、认证复制0、物理重试0。第40 Hybrid fold_clothes random layout0已真实执行；三owned进程身份与仅6个570库映射核对通过，前2决策/20步（student15/eef5）原RPC→接受请求→原生动作/关节状态逐项独立审计，误差0；这是运行前缀，不计完成成绩。后续按冻结顺序接续未声明案例。
39次快照990427605f5480ed161b00cb939ebe95e2a74960已上线：CI38610460311成功，20线上文件/1449个TAR成员、原200封存cc38b42c…和作者100条/80971步来源保持；包SHA0a1d94066ca9a6df2bdb705892a1371c385af318038e3f9c80004f0e41022b0c。39作者对照中31双方原生完整、成功21一致/10不同、得分15一致/16不同；7无成绩和1作者原生未完整不混入一致率。
发布观察器新增同提交CI最多900秒等待后已通过原完整核验；末尾回放页入口检查因52个缩略图请求尚未结束触发networkidle超时，已真实重现DOM交互态且目标入口可见。仅将该入口检查改为DOMContentLoaded加可见链接断言，完整39次桌面1440/手机390检查、6表/183行、39作者分类与未计分语义均通过，页面错误0。原浏览器断言及HTTP/TAR检查不放宽。新增一次性--once --refresh-current-snapshot用于将审阅的发布器修复同步到同计数下载包；18门禁检查通过，仍拒绝分数伪造、回退、换准入及whole-blog完成声称。原服务源码、首次尝试与完整失败不改写。
原生常驻service gpt-policy-historical-session-catalog-proxy-20261015.service继续，增量发布service因浏览器超时已停止；目前进行只读修复材料刷新与完整交付，随后恢复绑定新守卫的常驻发布器。模型探测后实际不需要延长启动等待。RoboLab历史Direct/prompt/逐槽180/500预算和尝试选择、历史服务/隐藏物理快照缺口仍未闭合，whole_blog_full_reproduction_complete仍false。证据publication_checks/historical_resume_20261015/checkpoint.json。
<!-- END_CURRENT_HISTORICAL_FRONTIER -->

### Earlier snapshots（保留）

2026-10-11 07:12 UTC交付验收：原作者与本次历史原版本逐案例对照已上线，共22次首次尝试，18条原生完整（9成功/9失败）、4条本次未完成无成绩；17条双方原生完整中成功判定12一致/5不同、得分8一致/9不同、控制步数7一致/10不同，另1条作者仅裁定而无原生完整记录不参与成绩一致率。22行各自绑定作者核心档案SHA及本次审计门SHA，整份原作者100条来源SHA711c0bc1...保持。新增9项报告回归，78报告/73基建测试通过；线上1440/390px验证6表/166行、22条分类与缺成绩语义及手机横向滚动，页面错误0。发布8940685d04d2a0d7a5f360fe5e3bc91627cf8645，包源码99c5ae7d578425b1bc775616a15ebee0f02b0109，CI38120233223成功，20线上文件与1377全包成员SHA通过；包downloads/infrastructure_bundle_20261011T070048Z.tar.gz，SHAf5c84fb2574201b3d490a60e7691d5e288ff5b0c9732f75ccefb8ff648a3e63d，comparison SHA318d9efd...。原200回合/900统计输入、cc38b42c...封存证明、旧父凭据与增量门保持原字节。只读增量观察器v2已恢复，同一20261011T051055Z准入，60源码守卫漂移0；原生scope和观察器scope均active，旧观察器inactive，执行串行、物理重试0。第23项Direct classify_objects standard layout1继续，07:10只读观察640动作，前106决策/530动作独立审计通过，当前两owned进程均仅映射6个570库；该回合未完成无成绩。剩余75次未启动，后续新已审计门自动触发增量发布。RoboLab历史Direct/prompt/逐槽180/500预算与尝试选择、历史模型服务与隐藏物理快照尚未恢复；全部blog复现与严格历史等价仍未完成。证据publication_checks/historical_alignment_20261011/checkpoint.json。

2026-10-11 07:00 UTC报告对照推进：历史原版本49对队列仍22/98次已审计、18条原生完整（9成功/9失败），4条本次未完成无成绩；第23项Direct classify_objects standard layout1继续执行，前106决策/530控制步真实模型RPC→接受请求→关节动作/状态逐项及文件SHA只读审计通过，pi05调用0、未结算成绩。现将历史版本新回合与作者同案例逐项对照加入报告，22条均有作者核心档案SHA和本次原审计门SHA；双方原生完整17条，成功判定12一致/5不同、分数8一致/9不同、控制步数7一致/10不同；另1条本次完整而作者仅裁定失败/原生未完整，不纳入成绩一致率，4条本次未完成不计成绩，试跑独立不参与。同成绩不代表同轨迹，也不据此解释模型或物理差异。新增9项报告回归，78报告/73基建测试通过；本地1440/390px实页验证6表/166行、22条分类/缺成绩语义、98条封存共同案例链接及每表手机横向滚动通过，页面错误0。新对照源码提交99c5ae7d578425b1bc775616a15ebee0f02b0109，增量comparison SHA318d9efd37f2be4a9206d9103edbf2334fa9e40f6a7317f2dc6ef77a0d25f0d9；900旧统计输入、200封存原生回合、cc38b42c...证明及旧父凭据保持原字节。原运行器及已准入v1/v2/v3不改动，只暂停只读发布观察器供来源审核；原生scope继续。新的线上包/CI及浏览器验收尚待完成，已验收公开快照仍f065b77fae001ae94a488c508f6c93a4a0267b25。验收后恢复源守卫绑定新报告代码的增量观察器。整篇blog复现与历史服务/隐藏物理等价仍未完成，RoboLab历史Direct/prompt/逐槽180/500及尝试选择仍未恢复。证据publication_checks/historical_alignment_20261011。

2026-10-11 05:59 UTC交付验收：原版本49对队列22/98次首次尝试已审计，18条原生完整（9成功、9失败），另4条中断尝试保留无成绩、自动物理重试0。新增Hybrid classify_objects standard layout0原生成功、得分1.00，60决策/886动作与887帧视频审计通过，2970份输入SHA绑定；作者同案例成功且同为1.00，但867动作/61决策，与本次轨迹不同。22次快照中17条双方原生完整可比，成功判定12条一致/5条不同，分数8条一致/9条不同；另1条本次完整而作者所选记录不原生完整，4条本次未完成，均不混入配对差异计分。对照证据publication_checks/historical_frontier_20261011/original_result_alignment22.json。原200回合/900旧统计输入、旧父凭据/增量门及cc38b42c...封存证明保持原字节。冻结finalize已正确调用audit_hybrid(run,count)，旧missing-alias备注更正，原执行器及v1/v2/v3已准入源码不改动。新增16项边界回归，73基建/69报告测试通过。增量观察器已完成首个真实发布：f065b77fae001ae94a488c508f6c93a4a0267b25，包源码提交5cd500a80a7e5997a5dc2e2df6d3e89ea2a02885，CI38116228709成功；20份线上文件、1374全包成员SHA、1440/390px浏览器验证通过、页面错误0。包downloads/infrastructure_bundle_20261011T054956Z.tar.gz，SHAffd33912bdc6936e8a1fa3d2bd9a44a58d74ca251f6e7c0d4612f67ffc2f8cc9。60个观察器/报告/原计划与准入源码守卫通过，独立记录每次execution_delta/父凭据，后续新已审计门自动更新报告，出版任务无模型调用/仿真动作。旧v12观察器停止并已标记接替；原生scope和gpt-policy-historical-incremental-publication-20261011.scope均继续。第23项direct__classify_objects__standard__g0__l1仍运行、最新观察140动作，CLI/模型/profile/1100步预算/dt0.04身份和owned进程六库仅570映射通过；尚未完成不计成绩。剩余75次未启动；RoboLab历史Direct/prompt/逐槽180/500预算与重试选择、历史服务/隐藏物理等价仍未恢复，全部blog复现未完成。最新检查点publication_checks/historical_frontier_20261011/checkpoint.json。

2026-10-11 05:49 UTC执行进展：原版本49对队列22/98次首次尝试已审计，18条原生完整（9成功、9失败），另4条无成绩首次尝试保持。新增第22项Hybrid classify_objects standard layout0原生成功，得分1.00，60决策/886控制动作、887帧原视频完整解码与动作审计通过，2970份输入SHA绑定；原首次claim、失败及封存200回合不改写。实际前50决策/740动作另行只读前缀审计通过，不作为额外回合或成绩。冻结源码SHA d6c219e5...与计划一致，原finalize已正确调用audit_hybrid(run, count)，旧“missing alias”排查备注属于错误临时导入推断，已保留并更正，未修改原执行器。新增8项真实最小动作链边界及8项增量发布边界回归，73项相关基建/69项报告测试通过。现新增只读增量发布观察器，逐次已审计证据门触发报告更新，沿900旧统计输入与封存证明复用，核验新增门及既有源码守卫后通过普通发布、精确提交CI、20份HTTP文件、全包成员SHA和桌面/手机浏览器；v12终止观察器已停止并标记接替，原生v3执行scope继续。新22次快照尚待完成实际发布验收，当前已验收公开报告仍为5cd500a80a7e5997a5dc2e2df6d3e89ea2a02885的21次快照。当前队列阶段running，下一项direct__classify_objects__standard__g0__l1。全部blog复现与历史严格等价仍未完成。证据publication_checks/historical_frontier_20261011及infra/historical_incremental_publication_receipt.json。

2026-10-11 05:26 UTC交付验收：原版本49对队列21/98次首次尝试已审计，17条原生完整（8成功、9失败），另4条无成绩（656动作容量中断前缀、零动作容量启动失败、Hybrid搭塔layout4初始化崩溃、Direct分类layout0零动作reset失败）。新增7条完整回合动作/原视频SHA通过，所有失败与原claim保留；原200回合、900旧统计输入、旧父凭据/增量门及cc38b42c...封存证明保持原字节。570内核/580用户库、PTX JIT混用及Warp显式dlopen库名边界均由本任务6库SHA与12个私有别名修复，系统库不改动；CUDA JIT/Warp红绿对照、原仿真器完整零控制动作reset通过。v1/v2已准入源码保留；v3完整核验21次/69,459输入并通过同模型探测，20261011T051055Z新准入绑定14个续进源文件。第22条Hybrid classify_objects layout0实际reset、原CLI0.153.4/gpt-6-astra xhigh/profile/学生checkpoint/时域dt身份通过，三owned进程仅570映射，首次3决策45动作独立前缀审计通过；当前观察490动作，尚未完整不计成绩。原生scope gpt-policy-historical-driver570-loader-20261011.scope及终止后只读发布scope v12继续，初始交付fence与12报告/15额外源码守卫核验通过，物理执行串行、自动重试0。网页发布5cd500a80a7e5997a5dc2e2df6d3e89ea2a02885，源码08368174d753392ebc1008af206441907b005522，CI38114591037成功；20份线上文件、1364全包成员SHA、1440/390px浏览器通过，页面错误0。包downloads/infrastructure_bundle_20261011T051945Z.tar.gz，SHA5c025b8d4ec6e520562fdd30d22ffb24a037f170b59827434910dd3acccfc51f，57基建/69报告测试通过。报告保留研究报告版式并补列基础设施失败。未发布19及20运行中候选、旧候选包和诊断失败均保留。剩余历史首次尝试、RoboLab历史Direct/prompt/逐槽180/500预算与重试选择仍待完成；历史服务/隐藏物理等价未证实，全部blog复现未完成。具体检查点publication_checks/driver_resume_20261011/checkpoint.json。

2026-10-10 15:37 UTC快照已交付：原版本49对队列12/98次首次尝试已审计，10条原生完整（7成功、3失败），另保留656步无成绩前缀及一次零动作启动失败。新增build_tower standard layout0配对：Direct1050步/210决策失败、得分0.30；Hybrid716步/48决策成功、得分1.00。原视频1051/717帧完整解码和动作审计通过；作者同案例两方法均失败、得分0.10，差异保留。报告发布提交0ac79352249c15bbad0a4ed1b0462ce6d03b7f0c，同提交CI38065427667成功，20份线上文件、1314份下载包成员SHA、1440/390px浏览器通过，页面错误0；新包SHAbfc2087c8812c64d14092f78e987905ef26ef05cf6773fd329c54ce3d5f9f4ab。68项报告、15项相关基建测试通过；原200回合统计及900份已验收输入绑定复用，旧父凭据/增量门与封存证明保持原字节。报告改版保持。最新只读观察：direct__build_tower__standard__g0__l1已290步，尚未终止不计成绩；原版本执行scope与终止后只读发布scope v7均继续，自动物理重试0。原版本剩余案例、RoboLab历史Direct/prompt/逐槽180/500预算及尝试选择仍待完成；原模型网关和隐藏物理等价未证实，全部blog复现未完成。证据publication_checks/historical_updates_20261010T152810Z/checkpoint.json。

2026-10-10 15:37 UTC已核验快照：原版本49对队列已保留12/98次首次尝试，10条原生完整（7成功、3失败），另有656步无成绩前缀和一次零动作启动失败。新搭塔standard layout0配对完成：Direct1050步/210决策原生失败、得分0.30，Hybrid716步/48决策原生成功、得分1.00；原视频分别1051/717帧，完整动作审计通过。作者同案例两方法均原生失败、得分0.10，结果差异保留。下条Direct build_tower standard layout1已启动，快照观察10步。当前任务为交付12次首次尝试的日期快照；11次候选及首包保留为未发布阶段凭据。原200回合统计/900输入绑定、旧增量门及封存证明均保留。队列继续，终止后只读发布scope v7已恢复，零物理重试；RoboLab历史Direct/prompt/逐槽预算、原模型与隐藏物理等价证据仍未齐全，全部blog复现未完成。证据publication_checks/historical_updates_20261010T152810Z。

2026-10-10 11:03 UTC发布快照：原版本正式队列10/98次首次尝试已审计，8条原生完整（6成功、2失败），另保留656步未完成前缀与一次零动作启动失败，两者成绩均为空。恢复后的Hybrid arrange_largest_number standard layout0以544动作、41决策原生成功，545帧视频及原动作审计通过；当前Direct build_tower standard layout0仍在执行，未作为成绩。首次尝试保留，自动物理重试0。恢复与发布相关35项基建测试、65项报告测试通过。报告新增每条已审计尝试的状态/成绩/证据绑定及恢复准入；此次仅更新original_version_execution，原200回合统计和900份已验收输入哈希沿已发布提交复用，父统计凭据及独立execution_delta_gate随包交付，不声称重新扫描全部旧输入。封存200回合证明保持原SHA。原版本队列及终止后只读发布检查继续运行；严格历史等价与整篇blog全部复现仍未完成。

2026-10-10 09:58 UTC恢复执行：历史剩余49对队列已保留并审计9次首次尝试，其中7条原生完整（5成功、2失败）、1条656步未完成前缀及1次零动作启动失败。两次未完成均遇usageLimitExceeded，保留无成绩；冻结执行器读取缺失run.json的审计错误已由独立无执行审计器修复，不补写运行元数据。9条已保留尝试的27758份输入逐文件SHA核验通过。同一授权模型/CLI的最小纯文本探测成功，恢复scope gpt-policy-historical-continuation-20261010.scope已准入继续剩余89次未启动案例；已有尝试不重跑。再次遇容量错误时立即停止后续新启动。恢复准入与回归凭据publication_checks/historical_resume_20261010；原计划与执行源码、200回合封存证明、原失败均保持原字节。28项相关基建和63项报告回归通过。已另查作者公开分支与RoboLab目录历史，只见既有主分支和一次源码提交，未恢复RoboLab历史Direct、逐槽180/500预算与尝试选择。全部历史复现仍未完成。



2026-10-10继续推进：原版本试跑两方法已于10-08自然完成并于12:31 UTC通过完整动作和原视频审计，Direct1050步/210决策、Hybrid1050步/127决策，二者原生失败、分数0.3。原Hybrid同案例为0.05，不能据控制链审计通过声称结果一致。完整原始首次尝试与失败保留，自动物理重试0；试跑benchmark_eligible=false保持，不混入封存200回合。

其余49对/98次首次尝试已独立冻结为historical_worker_campaign/remaining49_20261010，准入SHA d564c1e7cde3d1bfb7aabe80b247100bf31f8b849fdb7789f264692ece30345d，19项相关边界回归和零调用真实预检通过。执行scope gpt-policy-historical-remaining49-20261010.scope于10-09 16:31 UTC启动；首对arrange_largest_number standard layout1 Direct已进入真实运行。排程只依据冻结身份覆盖源码版本；保留第一尝试，已有启动凭据缺审计时停止恢复，禁止自动物理重试。输入错误上限前缀和原生无效布局不计成绩，基础设施/审计失败停止排查。逐回合将完整审计原动作和视频。执行约定HISTORICAL_REMAINING_COHORT_20261010.md；进展以队列progress.json及独立证据门为准。

剩余前沿为实际完成并审计这98次尝试，继续恢复RoboLab Direct源码/prompt、逐槽180/500预算及重试选择，并核查layout4辅助臂有效性差异。原网关/模型快照和隐藏物理仍缺证据；历史严格等价与整篇blog全部复现保持false。封存200回合和cc38b42c...原验收证明不改写。

### 10-08源码恢复阶段历史状态（保留）

2026-10-08 历史控制器恢复推进：100条原记录均使用Codex CLI0.153.4，本次封存100条Dojo中96条为0.159.2、4条为0.153.4。恢复5套完整源码组合（41/42文件，合计42条路径），包含4个工作进程版本。78条原回合对应累计5次输入拒绝即终止的旧规则；98个共同方法案例中有11条本次记录超过该阈值，这是记录与停止规则差异，不是反事实成功率。

已独立安装官方CLI0.153.4，核验SHA512 SRI和重用文件字节；5套源码保持原字节并只读隔离。原网关模块不在公开冻结文件中，两份单独哈希的适配文件桥接现有授权运行环境，不能声称历史服务等价。5套源码的30项离线协议场景与5次真实临时线程初始化均通过，兼容性检查模型推理0次；新增12项边界/资格回归通过。临时线程检查不验证原持久历史行为。初始RGB的三个相机均0/98逐像素相同，跨案例平均每通道绝对差0.969–1.130（0..255），不据此归因成绩变化。

独立试跑已于09:43 UTC启动原面板首对arrange_largest_number随机layout0，固定原Direct/Hybrid各自源码、CLI0.153.4、种子、1050步原生时域和max_decisions=0。首批原生控制ACK已观察，成绩尚待完整动作审计。unit为gpt-policy-historical-worker-canary-20261008.scope；输出historical_worker_campaign/canary_20261008T094400Z_arrange_largest_number_random_g0_l0，自动物理重试0。首次尝试无论结果均保留，错误阈值或基础设施退出保持未完成；现有200回合、失败与封存证明不改变。

下一前沿：完成这对原版本真实动作链路与完整审计，再判断新的历史版本面板如何继续；继续恢复RoboLab Direct源码/prompt、逐槽180/500预算与重试选择。已向用户请求这些材料链接，仍待答复。布局4的原辅助臂物理差异、历史网关/模型服务与隐藏物理快照仍缺证据；历史严格等价与整篇blog全部复现保持false。执行边界见ADR_HISTORICAL_WORKER_RECONSTRUCTION.md，身份/兼容性凭据见publication_checks/worker_fidelity_20261008。

### 03:29 UTC已完成档案恢复阶段（保留）

2026-10-08 原始公开档案恢复：已从固定版本的公共数据集取回100个核心ZIP（7,864,111,231字节），逐包SHA与原报告100条目录匹配。独立核验80,971步动作及执行后关节状态，原Direct13/50、平均Score×100=37.8125（n=48），Hybrid24/50、62.6（n=50），纠错6174步及累计Token均重算一致。原Direct含48条原生完整轨迹和2条RPC超时前缀裁定失败；本次Direct50条均原生完整，两者口径明确分列。

共同98条回合的布局、解析配置、原生时域、控制步长、决策上限和context版本全部一致。初始关节和四元数哈希均不相同，但实测最大绝对数值差仅3.2526065174565133e-18和1.4901164746561335e-08；末端位置完全相同。全部98条归档prompt仅替换一行工作目录后，其余字节完全一致。归档导出规范化了私有路径，不能把原运行prompt哈希与归档文本的差异当作语义更改。此证据只覆盖记录的机器人字段和限定文本，不能证明完整物理状态、原模型输入或闭源服务状态等价，也不能解释成功率差异。

RoboLab20个任务/方法组合的原生控制时域全部与作者视频目录相同；最终槽位不代表同seed，逐槽决策上限/重试及历史Direct实现仍缺证据。原Dojo档案提供42种源码路径，其中10个路径有多个已归档哈希，不能将最新公开源码当作所有历史回合的唯一实现。下一前沿是对这些冻结控制源码做函数级比较，并继续追溯原RoboLab Direct及逐槽预算证据；不改变现有200条回合凑原表数值。

完整RGB档案约126.7GB未取回，隐藏物理/模型状态也未恢复。本轮未调用模型或仿真，未执行任何下载源码。详见 `publication_checks/historical_protocol_20261008/original_record_recount.json`、`recovered_comparison.json`、`initial_difference_inspection.json` 和 `ORIGINAL_ARTIFACT_RECOVERY_ADR.md`；新元数据592项与初始NPZ/prompt196项另行绑定，不改写原终验证明。历史严格等价与整篇blog全部复现仍未证明。

2026-10-08 03:29 UTC原档案恢复交付验收：网页提交`14661b3a3170158f16b03ab2dff61aacfadab5fd`、源码提交`705d379362f7ec5d6776fd9d09228c54e24c77d7`；同提交CI`37722698545`成功，17个在线文件与提交字节一致。新包`downloads/infrastructure_bundle_20261008T032400Z.tar.gz`的957份文件公开下载逐成员SHA通过，归档SHA256`a5c0e359436e4481cbc482ec1f56937b1fc489ebde6cc2abdd32bbd8a423bcdf`，原终验证明仍逐字节等于封存cc38b42c...原件。57项报告与13项新增工具回归、全站检查、桌面/390px浏览器通过，线上截图与本地SHA相同。Git工作树干净，单次发布已自然退出；周期发布和终验timer仍disabled。原始100条/80971步记录恢复及其交付阶段PASS；严格历史等价与整篇blog全部复现保持false。证据`publication_checks/historical_protocol_20261008/checkpoint.json`。

只读源码试查已保存`source_comparison_pilot.json`：8个路径中，session、kinematics、client、validation、prompt_context、settings的全部100份原冻结AST均与当前本地checkout相同；原Direct实际采用的gpt_only_client在50条Direct中均相同。Hybrid档案中旧gpt_only_client的区别涉及另一方法，不能直接归因到Hybrid。skill/run存在四个版本，22条Direct AST相同，28条Direct和50条Hybrid尚有CodexPolicy/main/tool_specs等候选差异。这里只比较当前checkout，不证明每个历史部署进程都用了这些字节。下一具体动作是核对这些工作进程的实际执行分支、工具注册及记录身份，继续查找RoboLab历史Direct/逐槽预算。公开数据发布者的当前数据集目录只找到RoboDojo集合，未找到同发布者的RoboLab集合；该有界查询不等于全网不存在此材料。

## Completed native milestone

2026-10-07 最终完成状态：

所选两套固定范围评测已全部完成：RoboDojo 100/100 回合、50/50 对；RoboLab 100/100 回合、50/50 对。RoboLab 队列于 2026-10-07 08:24 UTC 自然结束，全部100份原归档verified，requires_repair=0、pending=0、活动保留槽为0。

联合终验于 2026-10-07 09:34:13 UTC 完成，status=complete、full_reproduction_complete=true。原始证明绑定报告提交 `5d7a430557ba91da93a16b5b174305ded275bf39`，同提交 CI `37594282741` 成功；覆盖所选200条及另存原布局1条，共232427项原审计输入、整份RoboLab归档、原始及导出完整视频，并核验815个公开文件。证明封存于 `final_verification/5d7a430557ba91da93a16b5b174305ded275bf39/certificate.json`，SHA256 `cc38b42cfcf0c098c2ad58a3af9a2e265fc1bd3b6e92ddeeae7208f18e4b3ee9`。后续交付不覆盖原证明或刷新原验收时间。

最终成功数：RoboDojo Direct 13/50（平均score 0.395）、Hybrid 21/50（平均score 0.548）；RoboLab Direct 49/50、Hybrid 46/50。所有原生完整失败保留并计入分母。原RoboDojo面板99/100和49对另行报告，与有效面板共享49对，不能相加作为独立样本；无效layout4按已批准方案整对改为预冻结layout5。

本轮只读重核200条所选及1条保留原审计证明的SHA、815个当前发布文件的SHA、19份冻结v5源码和精确提交CI，均与封存证明一致。证据：`publication_checks/completion_delivery_20261007/evidence_binding.json`。完成队列已禁用自启动；模型文字探测、周期发布和周期联合验收已停用，原归档恢复及私有冷归档维护仍启用。只停用已无活动进程的单元，未中断任何物理回合。

RoboLab Direct 使用本项目EEF适配器；历史Direct源码、prompt及完整物理初态不可得，未独立重算IK。本次完成指上述冻结范围的执行、审计和交付，不声称与历史实验逐位环境等价。最终交付说明见 `COMPLETION_20261007.md`。

最终公开交付已于 2026-10-07 11:08 UTC 核验：提交 `69b9902ec6a84adec64a667607abfe28cb790ebc` 的 CI `37611841778` 成功，15个在线文件与提交字节一致；公开下载包 `downloads/infrastructure_bundle_20261007T110456Z.tar.gz` 的905份文件SHA逐项通过，归档SHA256 `0c70bdc83a89440cd4ac8e0540196dde813e2170a29417c2ffb8b6fd3a3a083d`。公开 `data/reproduction-completion.json` 与封存原件逐字节一致；原终验提交和时间保持不变。具体证明：`publication_checks/completion_delivery_20261007/public_bundle_verified.json`、`exact_commit_ci.json`、`publication_http.json`。本次约定范围无剩余原生回合、审计或发布阻塞。

## Historical frontier（2026-10-07 05:23 UTC，保留过程）

2026-10-07 05:23 UTC：所选RoboDojo100/100、50/50配对已整组核验，原面板99/100另行保留；Direct成功13/50、Hybrid成功21/50，完整失败计入分母。
RoboLab完整审计78/100、35/50配对，首组三条新盘回合均已独立验收；新完成回合继续由归档计时器核对。新SSD首组三条RubiksCube原生回合均成功（Hybrid129/130步，Direct132步），均已归档并完整动作审计。尚余22条原生回合与最终联合验收，full_reproduction_complete=false。上次新增25条证书和Dojo101条原证据证书保持原样。
最新新增CannedFood seed3 Hybrid成功529步已独立重核549项原审计输入、整份原归档、原始及导出视频完整解码、4个公开文件和提交1459b34f36edb2289ead08998187f511c7ecc408的CI37572550806；35对原始初始场景指纹一致，不声称完整checkpoint或历史逐位等价。
发现连接停止后的TIME_WAIT使v4本机端口检查报errno98，三个监督器在创建输出前退出，三槽因此被保守保留。已按原启动身份、哈希固定v4源码顺序、本机工作/输出目录及远端目录/管理日志/进程均不存在的证明，封存三份明确标为重建的非物理失败元数据；不伪造原归档、不计原生成绩，也不绕过重试预算。
新的v5协调器于04:49 UTC自行释放三槽，04:51:12 UTC在第二ext4 SSD启动RubiksCube seed3/4 Hybrid与seed0 Direct。原v4源码/manifest及所有原生失败和中断证据保留。控制器、模型、π0.5、原生时域、资格/最早完整失败/最大3次基础设施规则不变；7个核心函数AST相同，37项相关测试通过。
策略服务的独立GPT-6-astra/xhigh文字READY探测通过，沿用原已授权登录；每10分钟检查、900秒过期，失败只阻止新启动，不消耗尝试、不干预活动物理回合。报告正常推送与线上字节验证已恢复。三条新回合的实际worker均为gpt-6-astra/xhigh，私有工作目录、SQLite及WAL全部位于第二SSD；已观察新原生控制步进，见runtime_verified.json，未计入尚未终止的回合成绩。
新SSD首组三条完整回合又独立核验537项原审计输入、整份原归档、原始及导出视频完整解码、12个公开文件、35对原始初始场景指纹及同提交071b6b0的CI37575094467；证书publication_checks/ssd_native_complete_20261007/new_native_certificate.json。
证据：publication_checks/launch_recovery_20261007；运行决定：ROBOLAB_LAUNCH_GUARD_ADR.md。下一前沿是持续完成剩余RoboLab回合，再核验所选200条和保留原回合的全量原始证据、公开视频、同一提交CI，不能据此提前宣称全部复现完成。

用户在上次可审阅的layout5补齐方案之后再次要求“继续推进”。本轮按此续推进指令执行该方案，
记录为user_continue_20261006_after_reviewable_replacement_proposal：另建有效50对清单，
只将imitate_sorting_sequence layout4整对替换成同一原60案例面板中预冻结的下一编号layout5，
补跑Direct和Hybrid两条新原生回合。原50案例清单、全部旧结果、完整失败与无效布局尝试均保留；
原面板与有效面板分别报告，不能相加为独立样本，也不选择两方法中更好的结果。

layout4已有五次Hybrid完整1600步原生排除。保持初态、零模型/零π推理的独立诊断，
同样于432步得到原辅助臂验证失败（aim2手表不在basket1），走满1600步仍无效。
layout5通过相同冻结原生配置的553步演示检查，并走满1600步诊断。
两条诊断3200条动作全部核对为保持初态，各1601帧原视频；诊断不计作模型实验。
底层抓取/物理重放原因尚未完全证明，未修改原生判定、轨迹、prompt、模型或时域。

v6有界原生无效重试队列已于2026-10-05T14:28:01.696574+00:00在物理回合边界切换成功；
原资格函数与最早有效原生失败/审计缺口优先级保留。原v6及RoboLab v2冻结源码不改写。
新补齐队列独立状态、使用相同执行锁，只负责layout5两方法，完整失败和审计缺口仍阻止物理替代。
不可变有效清单及原文件/诊断SHA核验见fixtures/robodojo_valid_cohort_v2.json，
显式选择指针为fixtures/robodojo_active_cohort.json；layout5两方法已原生终止并完整审计，独立页面上线验收通过；RoboLab及最终联合验收仍在进行。

旧RoboLab归档积压已经清零：截至2026-10-05T12:59:08.758233+00:00，最早原生完整回合18条全部完成原归档与完整动作审计，
summary为verified18/requires_repair0/pending0。ClutterPumpkinTask seed0/1 Hybrid原生成功801/632步，seed2原生失败1350步，三条完整结果均保留。
新验收器再次核对三条原回合的3015个审计输入、整份原归档manifest与原传感视频帧数，均通过。

RoboDojo build_tower standard layout3 Direct已原生完整失败1050步/210决策，完整审计通过并按原失败计分。
旧启动超时缺项已全部完成原生回合及完整审计；唯一未完成项为上述原生演示无效布局。后续启动等待保持1200秒。
修复了报告把invalid_native_layout当作audit_pending候选而永久挡住有效重试的问题：
仅原生eligibility=false、success/score=null且冻结身份匹配的无效布局排除。
有效完整失败和最早有效完整审计缺口继续保留。实站漏掉的新原因标签也已补齐，34项站点回归与真实构建通过。

新增verify_reproduction_completion.py及14项验收边界回归，gpt-policy-final-verification.timer已enabled。
覆盖未满时只记录pending_native_episodes，不启动模型或仿真；两套均100/100与50/50后才扫描全部原审计输入、
最早有效原生回合、每一步传感视频、全视频解码及所选200回合、保留原面板回合与面板元数据全部公开文件的字节/hash，并核对同一提交CI。
完成证明按提交存入final_verification/<commit>/certificate.json，保留原验收时间；full_reproduction_complete当前false。
两条真实已停止原回合共3400个审计输入已用新验收器复核，完整原视频帧数1051/557通过，不代替200条最终验收。

RoboLab后续监督器在慢归档前保存原生结果和完整控制器输出、同步controller_finished阶段；
复制中断先保留原结果，冻结v2会标成audit_failed并禁止新的物理替代，原完整失败不能被后续成功覆盖。
旧监督器的seed4原归档已完成，新ClutterPumpkin进程已实际加载新保存逻辑并核对源码SHA一致；不重连或重放不确定动作。
RoboLab v2切换、2228文件完整资产和独立空闲GPU选择已实际验证，两个冻结调度器SHA保持不变。
活动SQLite继续位于本机/tmp；已封存工作区与状态自动转存私有NAS，报告与归档恢复timer继续运行。

下一前沿是继续RoboLab矩阵至100/100和50/50，再执行所选200回合及保留原回合的最终全量在线验收。
RoboLab Direct为本项目EEF适配器；历史源码/完整初态未公开，不声称逐位环境等价或独立重算IK。
详细证据见RUNBOOK.md、ROBOLAB_ARCHIVE_DIAGNOSIS.md及publication_checks/remediation_20261005。

## Decisions

- 2026-10-06：在可审阅的layout5整对补齐提案之后，按用户“继续推进”执行独立有效50对面板；原50对结果与失败统计保留并分别发布，原冻结文件不改写。

- 2026-09-16：用户明确“主要复现这个文档自己的两种方法就行”；优先级覆盖此前全模型扩展范围。
- 停止继续运行独立π0.5基线队列和额外模型传输；不删除已下载资产和历史结果。
- 2026-09-16追加授权：用户明确要求直接使用当前Codex CLI的GPT-6 Astra。通过CLI自身认证复用当前登录态，不复制、不输出凭据；SQLite运行状态保持每次实验独立。该决定覆盖此前要求单独实验账号的限制。
- 既有历史目标保存在 GOAL_before_scope_correction_20260916.md，仅供追溯。

## Evidence

report_interpretation_zh.md、infra/run_original_controller.sh、现有仿真与π0.5审计记录。在线报告：https://asimfish.github.io/gpt-as-policy-repro/scenes.html 。当前在线报告已以两种主方法的自有结果为主；有效RoboDojo 50个配对已完成并整组复核，RoboLab补充与最终联合验收仍未完成。


2026-10-06补齐执行进展：独立清单SHA256为d0b76047a1f570f964b6987550538982f49182ba321a07c568f7ba1d2c7473cd。`gpt-policy-robodojo-supplement-v2.service`已enabled并于22:43:13UTC启动；Direct layout5新物理回合运行中，Hybrid随后执行。真实构建与页面验证：原面板99/100、49对，独立有效面板98/100、49对，RoboLab21/100、6对；桌面与390px手机验证通过，两面板筛选、深链接与完整视频实际播放均通过。已停止回合的自动私有状态转存已支持新增案例，仍执行同一哈希固定的v5完整资格检查并拒绝活动worker；六项回归通过。验收器16项回归通过，当前记录pending_native_episodes，不生成完成证书。页面及新基建包的线上精确字节验证另行记录，尚未完成时不得声称发布完成。


2026-10-06发布验收完成：提交419ca6f17982d498194dc5661de263c6d2183bdb，GitHub Pages工作流37385101951成功；14个网页/JSON/资源/包的提交字节与线上SHA全部匹配。原面板99/100、独立有效面板98/100（两者均49对，互有重叠），RoboLab21/100、6对。新页面为https://asimfish.github.io/gpt-as-policy-repro/gpt-methods-valid.html 。基建包`deliverables/infrastructure_bundle_20261006T065300Z.tar.gz`含832个文件，SHA256=5f5b05d2cf1296556f22c3c637aa17c52b87da7fc36ccd3caf878ce26a1c79c4；公开下载后逐个核对832成员和7个核心源码/冻结清单，全部通过。旧基建包与全部原回合保留。发布、归档、磁盘维护与最终验收timer恢复运行；layout5两方法补齐服务和RoboLab v2队列持续执行。全量验收仍为pending_native_episodes/full_reproduction_complete=false。证据目录publication_checks/valid_cohort_20261006。

线上桌面/手机最终浏览器复核也已通过（提交419ca6f17982d498194dc5661de263c6d2183bdb）：原99回合、独立有效98回合、RoboLab21回合分别与JSON一致；两面板50行、筛选、深链接、390px宽度和真实视频播放通过，页面错误为零。补齐Direct已核对gpt-6-astra/xhigh真实worker和执行动作；旧v5、v6及RoboLab v2的三个源码SHA保持完全一致。


2026-10-06 RoboLab有界并行推进：在不改写冻结100条身份、原模型/prompt/原生时域和首次完整失败/审计缺口规则的前提下，实现最多3个独立原生回合。设计与两种方案权衡见ROBOLAB_PARALLEL_ADR.md；v3直接装载SHA固定的v2资格/选择函数，原v2、原监督器与服务源码不改写。独立锁、端口、GPU预约、Linux boot/start身份、先持久化后单次启动及不确定ACK保留预约均有回归；退出只排空已启动回合。22项相关基建测试、40项报告测试和16项最终验收边界测试通过。远端新管理器已原子部署且读回SHA=18a33b59f78b6effefcb7b839beabcfd92575cdbce931fbeef69f435ed0cfefe。`gpt-policy-robolab-parallel-handover-20261006.service`已enabled，当前等待v2回合物理/清理/归档锁释放，尚未启动并行模型回合。报告已实现多个活动回合的脱敏进度，运行中回合不计入成绩。证据publication_checks/parallel_queue_20261006；调度源码及冻结SHA见robolab_queue_scheduler_v3_manifest.json。

本轮独立再核验ClutterPumpkin seed3 Hybrid原生失败1350步、seed4 Hybrid成功871步、seed0 Direct成功766步共4303份原审计输入、整份原归档及原视频逐步帧数，全部通过，失败保持。全量结果仍为有效RoboDojo98/100、49/50对，原面板99/100、49/50对，RoboLab21/100、6/50对；full_reproduction_complete=false。并行队列切换与新版报告/包发布应分别核对实际运行、提交和在线字节证据，不能以部署准备当作回合完成。


2026-10-06有界并行基建发布验收：源码提交e00aa7430d22122c2a3efd789435bca368084927，实际网页提交1fdd2e2865a07c54ff9db34a2dcd3daeb625135f，Pages CI37392587664成功；14个公开文件精确字节核验完成，本地与线上桌面/390px手机检查均通过，原面板99、有效面板98及RoboLab21条回放/JSON分别一致、页面错误为零。新不可变基建包deliverables/infrastructure_bundle_20261006T081000Z.tar.gz含844文件、938483字节、SHA256=26fe9bd81285ff00db5e3b2e3a8513845e5306d6d233053f2b3596156f897cb8；公开下载后逐个成员复核通过，包含新ADR、v3清单、部署凭证及去私有环境的服务模板。此前832文件包与全部原回合保留。证据publication_checks/parallel_queue_20261006/checkpoint.json。切换服务仍在等当前原生回合/清理/归档边界，不能宣称已运行三个并行回合；完整实验验收保持pending_native_episodes/full_reproduction_complete=false。


2026-10-06 08:22 UTC交付验收：提交a67cfc7187f1981b5b5d3c590b1fdb048addf0c1，Pages CI37435364490成功，14个公开文件精确字节一致。基建包deliverables/infrastructure_bundle_20261006T082000Z.tar.gz含851文件、983162字节，SHA256=0917f686b2a08c3d0fbfb546beff00ebe3e2b9a806966b886b911df315bc0fd6；公开下载逐成员核对通过，RoboDojo里程碑证书原件一致，旧包保留。新增Direct ReorientRedMug seed0完整成功760步，1993份原输入、整份原归档及原视频逐步帧数再核验通过；本轮新增原证据合计27条/20897项。最终联合验收已刷新为所选RoboDojo100/50对、RoboLab48/23对，pending_native_episodes/full_reproduction_complete=false；三个原生worker继续执行，全部维护timer活动。详细证据publication_checks/robodojo_completed_20261006/checkpoint.json。


## 2026-10-06 14:59 UTC：后续回合转用第二块本地SSD

系统ext4盘可用空间从14:25的9.3GiB降至14:45约5.9GiB，全部73个已审计停止工作区已按原字节验证转存NAS。另一块本地ext4 SSD约867GiB可用；选项与边界见ROBOLAB_LOCAL_STORAGE_ADR.md。新v4仅将后续新回合local_workspace配置为固定私有目录/data/liyufeng/agentic_robot_runtime/gpt_policy_repro_20260914，不搬移活动SQLite，不修改原控制器/原prompt/模型/原生时域/GPU/端口/资格规则。原v3两入口、远端管理器、v2 Oracle与全部原结果保留且SHA不变；v4 JSON清单robolab_queue_scheduler_v4_manifest.json绑定完整新源码与原出处。

第二SSD实际SQLite WAL和双独立连接读写成功，零模型/仿真调用；7项存储根拒绝边界、7项原停止工作区维护与14项原并行预约/接管测试在v4上通过。原选取与清理的7个函数AST一致。只停止旧协调PID，三个原生监督器、控制器、SSH隧道及工作目录在切换前后boot/start身份保持，动作进度不回退；v4已enabled并接管同一flock和durable leases。首次启动被公开模板的EnvironmentFile占位路径阻挡，ExecStart未执行；复用既有部署环境后启动正常，未复制认证。v3服务disable，源码和单元保留，v4服务活动。

原三回合仍使用/tmp；下一原生回合才创建新SSD工作区，尚未观察到新盘实际模型回合，不能将预检等同于回合完成。归档维护已支持两个明确根，仍要求停止/完整审计/每文件SHA与NAS保留，拒绝任意外部路径。证据publication_checks/local_ssd_20261006。剩余RoboLab由队列继续，整体验收false。


2026-10-06 15:12 UTC最终本轮交付检查：提交f8f54b668155af9153f1ca5749093496feed18dc的Pages CI37484663997成功，14份网页/数据/包精确字节一致；公开包deliverables/infrastructure_bundle_20261006T150154Z.tar.gz含869文件、1016908字节，SHA256=7996f09c46ad8f0246c686efb2f82f6e060b85ce50b4a2ae8432050fd702b855；公开下载逐成员及新增原生核验证书、v4清单、接管证明字节一致。原860、851及更早包保留。线上桌面/390px手机筛选、深链接、真实Direct/Hybrid视频播放无错误；原99、有效100、RoboLab73/35对分开一致。64次相关边界/兼容/公开包检查执行通过，不代替完整实验。终验刷新为RoboDojo100/50对、RoboLab73/35对，pending_native_episodes/full_reproduction_complete=false。v4三worker实际控制计数497/399/140，身份均存活，当前仍为原/tmp目录；新盘实际模型回合尚待自然释放槽位后观察。原归档verified73/repair0/pending0；全部维护timer活动。证据publication_checks/local_ssd_20261006/checkpoint.json。

2026-10-07 05:22 UTC交付核验：最新报告提交26be905581bb339754e6dafc9b33b40a53adfcbe、Pages CI37575665886及14份公开文件逐字节一致；基建包infrastructure_bundle_20261007T051618Z.tar.gz共898文件、1055991字节，SHA256 6e4a885624509f8ff2e870e7677c707fbe236c7d777345bb8e394b7d5491a2f6，在线下载后逐成员SHA核验通过。新SSD首组三条原回合均通过独立全证据/双视频/12HTTP文件/同CI验收；下一组三条Direct持续推进，完整失败与历史中断保留。整体最终验收仍待剩余原生回合完成。

2026-10-07 05:23 UTC运行增量：RoboLab已完整动作审计78/100，剩余22条；RubiksCube seed2 Direct已完成并进入自动发布，当前已验证线上快照仍为77条（26be905）。三槽接续seed1/3/4 Direct，完整成绩不重跑。原归档维护与报告/最终验收计时器均持续运行，首次归档维护遇到其他监督器持有的归档锁时保留原证据，下次维护重核，不是新的物理失败。

2026-10-08 02:40 UTC原blog对照实际交付：提交`f5585f035dfc601663877813d6f4df421689b514`、同提交CI`37718766832`成功，17个线上文件精确字节一致；927文件新包`downloads/infrastructure_bundle_20261008T023323Z.tar.gz`公开下载逐成员SHA通过，归档SHA256`720891491cfb0d66642d4ab17275788dae27caca8a2a0f5b789933c1ecd582e2`。统计JSON与包内原件同SHA；公开原终验证明与封存cc38b42c...原件逐字节一致。线上桌面/390px浏览器通过，截图与本地同SHA，Git工作树干净。comparison_delivery=PASS；historical_equivalence_verified=false、whole_blog_full_reproduction_complete=false。原200回合完成状态保留，所有完成队列/模型健康/周期发布/周期终验单元继续inactive，timer继续disabled。证明`publication_checks/blog_alignment_20261008/checkpoint.json`。


历史工作进程恢复交付已于2026-10-08 10:11 UTC验收：源码提交`bb07bec81d59076d15bb5167cc32489c7f117d8e`，发布提交`9f4bd3fefb863d00165ced436d175355d4c07674`，CI`37761496246`成功，17份在线文件和1207份公开下载包成员逐字节/SHA一致，包SHA`7e27acfffb8904d207e4c65d0cf0197906e4763b703bc7b9f7160b7ede1c7375`。59项报告+12项工具回归全部通过；桌面与390px线上截图与本地SHA一致、页面错误0；旧原生证明cc38b42c...不改写。新原版本Direct真实试跑已观察445/1050步，前5次决策25步通过独立原动作审计，仍不是完整成绩。两方法完成后，独立只读gpt-policy-historical-canary-audit-20261008.scope将执行完整动作/原视频检查；没有模型或物理重试。正在运行的试跑和检查不因本次网页交付结束而停止。具体状态publication_checks/worker_fidelity_20261008/checkpoint.json；历史严格等价和整篇blog全部复现仍为false。


2026-10-09 17:00 UTC（本地10-10）交付验收：源码提交9f534de812e3955c81dd060d5e2eb4b260e0ab53，发布提交cce63bcb0bec77efd2d586aa3193d8848f3e1a08，同提交CI 37962792996成功。17份在线文件、1236份公开下载包成员、原封存证明逐字节/SHA通过，包SHA 6c43569d16fc1c02e1642e9c5b0a20489a3a1261013f26de8f78c7e971e964c5。61项报告与19项相关基建回归、桌面/390px浏览器通过，线上截图SHA与本地一致。原版本正式队列第一条Direct已354步/71决策原生成功、分数1.0，355帧原视频和完整动作审计通过，Hybrid配对正在执行。公开页面保留16:37 UTC的有日期快照；实时队列状态及后续证据在独立输出，不能把旧快照当实时进度。当前1/98首次尝试完整审计，单独试跑另2条完整失败保留。队列继续运行，旧完成评测和发布/终验timer不重启；全部历史复现仍未完成。新状态publication_checks/historical_cohort_20261010/checkpoint.json。


2026-10-10 11:15 UTC恢复交付验收：源码提交991b434fb3c56a82700bcfc0574de7b185516691，发布提交4d4f22ef6de217c810f4e683901b2a2cdc92c15c，同提交CI 38047620929成功。17份线上文件与1291份新包成员逐字节/SHA通过；包downloads/infrastructure_bundle_20261010T111000Z.tar.gz，SHA e85d957821c8bc7ac2b1682e18c1b89ef4d1853e710b607acb89be421c9aa797。原200回合统计保护子树和900份已交付输入哈希保持一致，父统计/增量核验凭据随包交付；封存证明cc38b42c...保持原字节。35项基建、65项报告回归通过；1440/390px本地与线上截图SHA一致、页面错误0。公开快照为11:03 UTC的10次首次尝试、8条完整（6成功、2失败）、1条656步前缀和1次零动作启动失败，后两项均无成绩。原版本Direct build_tower standard layout0仍运行；独立终止后发布scope v5等待队列本次准入终止后更新报告，无模型或物理重试。严格历史等价和全部blog复现仍未完成，RoboLab历史Direct/prompt/逐槽预算材料尚缺。检查点publication_checks/historical_resume_20261010/checkpoint.json。


2026-10-10 12:05 UTC报告改版交付：参考用户给定的原研究报告、RoboDojo官方评测报告及Awesome社区索引，现有报告统一为浅色研究报告版式、居中摘要、胶囊导航、目录、原生指标图表及响应式回放卡片。源提交50e06604bff86db751ad18bb3f6050ee7af5f795；发布提交9a194e6343200e88e94d4ec7d4ab9a17aac6d4dc，同提交CI 38050207336成功。68项报告回归与4项终止后发布边界测试通过；4页面×4宽度（320/390/768/1440px）的本地与线上检查通过，完整视频、筛选、深链接、主题持久性和键盘焦点通过，页面错误0。20份线上文件逐字节相同，1305份包成员SHA通过；新包downloads/infrastructure_bundle_20261010T115241Z.tar.gz，SHA c2d7071bbddbc81afd7e43ca7f2c3deecfd7bc0ce5e9b3788adf80ffaf0cd824。原200回合统计与动作证据、完整对照JSON及封存证明均保留；进度JSON仅更新下载包和快照元数据。历史49对队列仍以首次尝试推进：当前10次已审计，其中8条原生完整，direct__build_tower__standard__g0__l0仍在执行（观察585动作），不计分。只读终止后发布scope恢复为v6，零模型调用、零物理重试。历史严格等价和整篇blog全部复现仍未完成。验收凭据publication_checks/report_design_20261010/checkpoint.json。
