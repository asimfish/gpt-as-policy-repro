"""Publish one terminal historical-cohort snapshot without invoking a policy.

Wait for this admitted continuation to finish or stop, then use the existing
authorized report publisher. This observer cannot start/retry a robot episode,
probe a model, change an account, or change grading. Source drift stops delivery.
"""
import argparse
import fcntl
import json
from pathlib import Path
import subprocess
import sys
import time

from run_historical_cohort import ART, read, sha, utc, write
from capture_historical_cohort import capture

ROOT=ART.parents[1];REPO=ROOT/'gpt-policy-report-site'
TERMINAL={'all_first_attempts_audited','blocked_service_capacity','blocked_audit_requires_review',
          'blocked_infrastructure_requires_review','blocked_existing_attempt_requires_review','interrupted'}
SOURCE_NAMES=('tools/blog_comparison.py','tools/test_blog_comparison.py','tools/publish_gpt_progress.py',
              'tools/build_gpt_site.py','tools/verify_site.py','tools/export_infra_bundle.py')


def ready(progress, admission):
    if progress.get('continuation_admission')!=admission:
        return False
    if progress.get('phase') not in TERMINAL:
        return False
    if (progress['first_attempts_audited']!=len(progress['results'])
            or progress['native_complete_audited']!=sum(r['status']=='native_complete_audited' for r in progress['results'])
            or progress['automatic_physical_retries']!=0
            or progress['historical_protocol_equivalence'] is not False
            or progress['full_blog_reproduction_complete'] is not False):
        raise ValueError('Terminal progress does not preserve audit/completion boundaries')
    if progress['phase']=='all_first_attempts_audited' and progress['first_attempts_audited']!=98:
        raise ValueError('All-first-attempt status requires 98 distinct retained attempts')
    if len({r['episode_id'] for r in progress['results']})!=len(progress['results']):
        raise ValueError('Duplicate first-attempt results')
    return True


def initial_delivery_ready(path, source_commit):
    if path is None:return True
    if not path.exists():return False
    proof=read(path)
    return (proof.get('verified') is True and proof.get('source_commit')==source_commit
            and proof.get('continuation_no_physical_retries_verified') is True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cohort',type=Path,required=True);parser.add_argument('--admission',required=True)
    parser.add_argument('--availability',type=Path,required=True)
    parser.add_argument('--initial-delivery',type=Path);args=parser.parse_args()
    root=args.cohort.absolute();out=ART/'publication_checks/historical_cohort_20261010'
    receipt=ART/'publication_checks/historical_resume_20261010/terminal_publication_watch.json'
    source_sha={name:sha((REPO/name).read_bytes()) for name in SOURCE_NAMES}
    additional_sources=('infra/capture_historical_cohort.py','infra/package_reproduction_infra.py',
                        'infra/publish_verified_historical_snapshot.py',
                        'publication_checks/historical_resume_20261010/verify_public_delivery.py')
    additional_sha={name:sha((ART/name).read_bytes()) for name in additional_sources}
    source_commit=subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip()
    own_sha=sha(Path(__file__).read_bytes())
    state=dict(schema='gpt_policy_historical_terminal_publication_watch.v1',started_utc=utc(),
        status='waiting_for_terminal_phase',continuation_admission=args.admission,
        source_sha256=source_sha,additional_source_sha256=additional_sha,
        source_commit=source_commit,observer_sha256=own_sha,model_calls=0,simulator_steps=0,
        physical_retries=0,historical_protocol_equivalence=False,full_blog_reproduction_complete=False)
    write(receipt,state)
    try:
        while True:
            progress=read(root/'progress.json')
            if (initial_delivery_ready(args.initial_delivery,source_commit) and ready(progress,args.admission)
                    and (progress['phase']!='all_first_attempts_audited' or (root/'completion.json').exists())):
                break
            time.sleep(30)
        lock=Path('/tmp/gpt-policy-report-publish.lock').open('a')
        fcntl.flock(lock,fcntl.LOCK_EX)
        for name,digest in source_sha.items():
            if sha((REPO/name).read_bytes())!=digest:
                raise ValueError('Reviewed report source changed; terminal publication requires review')
        for name,digest in additional_sha.items():
            if sha((ART/name).read_bytes())!=digest:
                raise ValueError('Reviewed capture/package/delivery source changed; publication requires review')
        if sha(Path(__file__).read_bytes())!=own_sha:raise ValueError('Observer source changed')
        sys.path.insert(0,str(REPO/'tools'))
        from publish_gpt_progress import check_worktree
        from publish_verified_historical_snapshot import publish
        from blog_comparison import build
        check_worktree(REPO)
        value=capture(root,out,args.availability)
        state.update(status='building_terminal_snapshot',terminal_phase=value['progress']['phase'],updated_utc=utc())
        write(receipt,state)
        build(ART,REPO/'docs')
        stamp=time.strftime('%Y%m%dT%H%M%SZ',time.gmtime())
        subprocess.run([sys.executable,str(ART/'infra/package_reproduction_infra.py'),'--date',stamp],check=True)
        publish(REPO,ART,ROOT/'astra-control-dashboard','http://127.0.0.1:7897')
        publication=read(ART/'online_publication.json')
        commit=subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip()
        if publication.get('commit')!=commit or publication.get('status')!='published_and_http_verified':
            raise ValueError('Terminal snapshot is not yet HTTP verified')
        subprocess.run([sys.executable,str(ART/'publication_checks/historical_resume_20261010/verify_public_delivery.py')],check=True)
        state.update(status='published_ci_http_bundle_verified',commit=commit,updated_utc=utc(),
                     first_attempts_audited=value['progress']['first_attempts_audited'],
                     native_complete_audited=value['progress']['native_complete_audited'])
        write(receipt,state)
        print(json.dumps({k:state[k] for k in ('status','commit','terminal_phase','first_attempts_audited','native_complete_audited')}),flush=True)
    except Exception as error:
        state.update(status='blocked_publication_requires_review',exception_type=type(error).__name__,updated_utc=utc())
        private=receipt.with_suffix('.private_error');private.write_text(str(error));private.chmod(0o600)
        write(receipt,state);print(json.dumps(dict(status=state['status'],exception_type=type(error).__name__)),flush=True)
        raise SystemExit(1)


if __name__=='__main__':main()
