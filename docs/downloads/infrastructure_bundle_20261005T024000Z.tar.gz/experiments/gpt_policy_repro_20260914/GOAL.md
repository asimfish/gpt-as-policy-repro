# GPT-as-Policy 两种方法复现目标

## Outcome

按用户 2026-09-16 的范围修正，主要复现报告自己的两种方法：GPT Direct 与 π0.5 + GPT（Hybrid）。交付我们自己运行生成的在线报告、完整轨迹和可复用基础设施。

## In scope

- GPT Direct：使用原仓库的持久 GPT 控制器与 GPTOnlyTools，观察图像和状态，直接生成并执行短段末端控制，不调用 π0.5。
- Hybrid：使用原仓库 RoboDojoTools；π0.5 提议动作，GPT 根据观测与反馈接受前缀、修改或接管，保留完整闭环历史。
- 优先 RoboDojo 主实验：同一冻结面板50个案例，每个案例分别运行两方法，共100条轨迹。
- RoboLab 补充实验：10任务×5种子×两方法，共100条新固定种子轨迹；不扩展其他模型基线。
- 保留原生终止条件、输入输出、prompt、工具调用、模型身份、token、初态、视频与失败证据。

## Out of scope for active work

Cosmos、DreamZero、独立 π0.5 全量基线、prefix/chunk 对照扩展。已获得的结果和资产保留为历史辅助材料，不能当作 Direct/Hybrid 复现成绩。π0.5 推理服务继续保留，作为 Hybrid 必需组件。

## Acceptance

- [x] 原生仿真与 π0.5 推理链路验证。
- [x] 原仓库持久控制器启动入口已准备；2026-09-16两方法真实app-server握手/工具注册及原生工具预检通过（零模型调用）。
- [x] 用户授权当前Codex CLI后，gpt-6-astra/xhigh真实模型响应验证通过；证据astra_live_probe_20260916。
- [x] 同一个冻结案例完成 Direct 与 Hybrid 两条完整轨迹并审计；截至 2026-10-05 已有 44 个主实验完整配对，另有 4 个 RoboLab 补充配对。
- [ ] RoboDojo 两方法100条配对轨迹完成，失败和基础设施中断区分。
- [x] 在线报告以两方法自己的结果为主；公开数字与已有基线分开（v2 自动生成主板已发布、字节与浏览器验收通过）。
- [ ] 完成两方法 RoboLab 补充评测并明确历史环境等价性限制。

## Current frontier

2026-10-05T02:35:32.766596+00:00：线上已完整审计RoboDojo92/100、44/50配对；RoboLab14/100、4/50配对。
提交7ada975f5bd1d538129399cafa8f33c127e920f2已精确HTTP/hash核验，对应GitHub Pages工作流成功。
完整两套200回合仍未完成；当前还缺主实验8项、补充86项，队列继续执行。

旧RoboLab归档积压已经清零：截至2026-10-05T02:25:29.298240+00:00，最早原生完整回合14条全部完成原归档与完整动作审计，
summary为verified14/requires_repair0/pending0。RoboLab BlocksInBinTask seed4 Hybrid刚原生成功1041步/103决策，
正在同一原回合归档，尚未计分。其后继续其余冻结任务；新完整失败同样保留。

RoboDojo当前build_tower standard layout3 Direct接近1050步原生时限。
剩余7个待重试记录为6个旧启动超时与1个原生布局无效；后续启动等待已修为1200秒。
修复了报告把invalid_native_layout当作audit_pending候选而永久挡住有效重试的问题：
仅原生eligibility=false、success/score=null且冻结身份匹配的无效布局排除。
有效完整失败和最早有效完整审计缺口继续保留。实站漏掉的新原因标签也已补齐，34项站点回归与真实构建通过。

新增verify_reproduction_completion.py及14项验收边界回归，gpt-policy-final-verification.timer已enabled。
覆盖未满时只记录pending_native_episodes，不启动模型或仿真；两套均100/100与50/50后才扫描全部原审计输入、
最早有效原生回合、每一步传感视频、全视频解码及807个公开文件的字节/hash，并核对同一提交CI。
完成证明按提交存入final_verification/<commit>/certificate.json，保留原验收时间；full_reproduction_complete当前false。
两条真实已停止原回合共3400个审计输入已用新验收器复核，完整原视频帧数1051/557通过，不代替200条最终验收。

RoboLab后续监督器在慢归档前保存原生结果和完整控制器输出、同步controller_finished阶段；
复制中断先保留原结果，冻结v2会标成audit_failed并禁止新的物理替代，原完整失败不能被后续成功覆盖。
当前归档中的旧监督器保持运行，新逻辑仅后续新进程加载；不重连或重放不确定动作。
RoboLab v2切换、2228文件完整资产和独立空闲GPU选择已实际验证，两个冻结调度器SHA保持不变。
活动SQLite继续位于本机/tmp；已封存工作区与状态自动转存私有NAS，报告与归档恢复timer继续运行。

下一前沿是完成当前两条原回合审计，继续两套矩阵至各100/100和各50/50，并执行最终全量在线验收。
RoboLab Direct为本项目EEF适配器；历史源码/完整初态未公开，不声称逐位环境等价或独立重算IK。
详细证据见RUNBOOK.md、ROBOLAB_ARCHIVE_DIAGNOSIS.md及publication_checks/remediation_20261005。

## Decisions

- 2026-09-16：用户明确“主要复现这个文档自己的两种方法就行”；优先级覆盖此前全模型扩展范围。
- 停止继续运行独立π0.5基线队列和额外模型传输；不删除已下载资产和历史结果。
- 2026-09-16追加授权：用户明确要求直接使用当前Codex CLI的GPT-6 Astra。通过CLI自身认证复用当前登录态，不复制、不输出凭据；SQLite运行状态保持每次实验独立。该决定覆盖此前要求单独实验账号的限制。
- 既有历史目标保存在 GOAL_before_scope_correction_20260916.md，仅供追溯。

## Evidence

report_interpretation_zh.md、infra/run_original_controller.sh、现有仿真与π0.5审计记录。在线报告：https://asimfish.github.io/gpt-as-policy-repro/scenes.html 。当前在线报告已以两种主方法的自有结果为主；50 个配对与 RoboLab 补充仍未全量完成。
