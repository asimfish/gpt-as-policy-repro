"""Read-only final gate for both frozen 100-run cohorts; partial progress never completes it."""
import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import importlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import time
import urllib.request

METHODS = ('gpt_only', 'pi05_plus_gpt')
PROGRESS = {'robodojo': 'data/gpt-methods-progress.json',
            'robolab': 'data/robolab-methods-progress.json'}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_text())


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(8*1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def relative(root, name):
    p = Path(name)
    require(not p.is_absolute() and '..' not in p.parts and p.as_posix() == name
            and p.parts and name != '.', 'Noncanonical artifact path')
    return root / p


def matrix(document, expected):
    """Recompute coverage and denominators from identities, never the headline count."""
    cases, episodes = document['cases'], document['episodes']
    require(len(expected) == 50 and len(cases) == 50, 'Frozen cohort must contain 50 pairs')
    require(len({c['case_id'] for c in cases}) == 50
            and {c['case_id'] for c in cases} == set(expected), 'Changed or duplicated cases')
    lookup, ids = {}, set()
    for e in episodes:
        key = e['case_id'], e['method']
        require(e['case_id'] in expected and e['method'] in METHODS, 'Foreign episode identity')
        require(key not in lookup and e['id'] not in ids, 'Duplicated episode')
        require(e['complete'] is True and e['eligible'] is True and type(e['success']) is bool,
                'Incomplete or excluded episode entered the denominator')
        require(e['terminated'] is True or e['truncated'] is True, 'Missing native terminal')
        require(type(e['control_steps']) is int and 0 < e['control_steps'] <= e['native_horizon'],
                'Invalid native horizon or action count')
        identity = expected[e['case_id']]
        if 'identity' in e:
            require(e['identity'] == identity, 'Changed frozen identity')
        else:
            require((e['task'], e['seed']) == (identity['task'], identity['seed']), 'Changed task or seed')
        lookup[key] = e
        ids.add(e['id'])
    pairs = 0
    for c in cases:
        require(set(c['methods']) == set(METHODS), 'Missing or unexpected method')
        for method in METHODS:
            row, e = c['methods'][method], lookup.get((c['case_id'], method))
            require(row['episode_id'] == (e['id'] if e else None), 'Matrix disagrees with episodes')
            require((row['status'] == 'complete') == bool(e), 'Matrix completion disagrees with episodes')
        paired = all((c['case_id'], m) in lookup for m in METHODS)
        require(c['paired_complete'] is paired, 'Incorrect paired coverage')
        if paired and 'identity' in c:
            require(c['identity'] == expected[c['case_id']] and c['scene_layout_records_equal'] is True
                    and c['robot_joint_states_equal'] is True, 'Different paired initial state or layout')
        pairs += paired
    summary = document['summary']
    require((summary['planned_pairs'], summary['planned_method_runs'], summary['completed_pairs'],
             summary['complete_method_runs']) == (50, 100, pairs, len(episodes)), 'Headline count disagrees with coverage')
    for method in METHODS:
        own = [e for (cid, m), e in lookup.items() if m == method]
        for name, rows in (('all_completed', own), ('paired_completed',
                [e for e in own if all((e['case_id'], m) in lookup for m in METHODS)])):
            stats = summary['methods'][method][name]
            wins = sum(e['success'] for e in rows)
            require((stats['evaluated'], stats['successes'], stats['failures'])
                    == (len(rows), wins, len(rows)-wins), 'Success/failure denominator changed')
            require(stats['success_rate'] == (wins/len(rows) if rows else None), 'Incorrect success rate')
    return dict(complete_method_runs=len(episodes), completed_pairs=pairs,
                remaining_method_runs=100-len(episodes), remaining_pairs=50-pairs)


def frozen_inputs(source):
    dojo = {}
    for path in sorted((source/'fixtures/cases').glob('gpt__*.json')):
        identity = read(path)['identity']
        cid = identity['case_id']
        require(path.name == 'gpt__'+cid+'.json' and cid not in dojo, 'Invalid frozen case filename')
        require(identity == read(source/'fixtures/cases'/('mix__'+cid+'.json'))['identity'], 'Unpaired frozen layout')
        dojo[cid] = identity
    frozen = source/'fixtures/robolab_two_methods_frozen.json'
    entries = read(frozen)['entries']
    tasks = {r['task'] for r in entries}
    keys = {(r['task'], r['seed'], r['method']) for r in entries}
    require(len(entries) == len(keys) == 100 and len(tasks) == 10
            and keys == {(t, s, m) for t in tasks for s in range(5) for m in METHODS}, 'Changed RoboLab cohort')
    lab = {t+'__seed'+str(s): dict(task=t, seed=s) for t in tasks for s in range(5)}
    return {'robodojo': dojo, 'robolab': lab}, digest(frozen)


def bind_publication(receipt, documents, docs):
    require(receipt['status'] == 'published_and_http_verified'
            and re.fullmatch('[a-f0-9]{40}', receipt['commit']), 'No verified publication')
    rows = {r['file']: r for r in receipt['files']}
    for name, path in PROGRESS.items():
        row = rows[path]
        require(row['matches'] is True and row['http_status'] == 200
                and row['local_sha256'] == row['online_sha256'] == digest(docs/path), 'Published snapshot changed')
        field = 'gpt_summary' if name == 'robodojo' else 'robolab_summary'
        require(receipt[field] == documents[name]['summary'], 'Publication summary changed')


def first_native_runs(campaign, dojo):
    """Preserve earliest valid native outcomes, including failures and audit gaps."""
    found = {}
    for parent in sorted(campaign.iterdir()):
        runs = [parent/m for m in METHODS] if dojo else [parent]
        for run in runs:
            if not (run/'attempt.json').is_file():
                continue
            row = read(run/'attempt.json')
            if not (run/'rollout/result.json').is_file():
                continue
            result = read(run/'rollout/result.json')
            if result.get('complete') is not True or not (result.get('terminated') is True or result.get('truncated') is True):
                continue
            if dojo:
                if not (run/'sim/evaluation_outcome.json').is_file():
                    continue
                outcome = read(run/'sim/evaluation_outcome.json')
                if outcome.get('complete') is not True or outcome.get('valid_for_success_rate') is not True:
                    continue
                cid = row['case'].removeprefix('gpt__').removeprefix('mix__')
                method = run.name
            else:
                cid, method = row['task']+'__seed'+str(row['seed']), row['method']
            key, order = (cid, method), (row['started_utc'], parent.name)
            if key not in found or order < found[key][0]:
                found[key] = order, run
    return {key: run for key, (_, run) in found.items()}


def verify_original(run, e, expected, dojo, tools):
    if dojo:
        result, _, proof = tools['dojo'].check_episode(run, expected)
        movie = run/'sim/sensors.mp4'
    else:
        result, _, proof = tools['lab'].eligible(run, dict(expected, method=e['method']))
        movie = run/'remote/sim/sensors.mp4'
        archive = importlib.import_module('archive_robolab_attempt')
        verified = archive.verify_archive(run/'remote', read(run/'remote_archive_manifest.json'))
        receipt = read(run/'remote_archive_receipt.json')
        require(receipt['verified'] is True
                and receipt['manifest_sha256'] == digest(run/'remote_archive_manifest.json')
                and receipt['files'] == verified['files'] and receipt['bytes'] == verified['bytes'], 'Unsealed RoboLab archive')
    require(all(result[k] == e[k] for k in ('success', 'terminated', 'truncated'))
            and result['step_id'] == e['control_steps'] and result['decisions'] == e['decisions'], 'Report differs from original outcome')
    for name, sha in proof['files_sha256'].items():
        require(re.fullmatch('[a-f0-9]{64}', sha) and digest(relative(run, name)) == sha, 'Changed original audit input')
    require(digest(movie) == e['source_video_sha256'], 'Original video changed')
    info = json.loads(subprocess.check_output(['ffprobe', '-v', 'error', '-select_streams', 'v:0',
        '-show_entries', 'stream=nb_frames', '-of', 'json', str(movie)], timeout=60))
    require(int(info['streams'][0]['nb_frames']) == result['video_frames'] == result['step_id']+1,
            'Original sensor video does not cover the full episode')
    return dict(run_id=e['run_id'], audit_sha256=digest(run/'complete_action_audit.json'),
                audit_inputs=len(proof['files_sha256']), original_video_sha256=e['source_video_sha256'])


def verify_http(docs, path, commit):
    local = relative(docs, path)
    url = 'https://asimfish.github.io/gpt-as-policy-repro/'+path+'?commit='+commit+'&verify='+str(time.time_ns())
    request = urllib.request.Request(url, headers={'Cache-Control': 'no-cache'})
    h, size = hashlib.sha256(), 0
    with urllib.request.urlopen(request, timeout=60) as response:
        require(response.status == 200, 'Public artifact unavailable')
        for block in iter(lambda: response.read(1024*1024), b''):
            h.update(block)
            size += len(block)
    require(size == local.stat().st_size and h.hexdigest() == digest(local), 'Public artifact differs from verified local bytes')
    return dict(path=path, sha256=h.hexdigest(), bytes=size)


def verify_ci(commit):
    url = 'https://api.github.com/repos/asimfish/gpt-as-policy-repro/actions/runs?per_page=20'
    request = urllib.request.Request(url, headers={'User-Agent': 'gpt-policy-repro-verifier',
        'Accept': 'application/vnd.github+json'})
    with urllib.request.urlopen(request, timeout=60) as response:
        rows = json.load(response)['workflow_runs']
    exact = [r for r in rows if r['head_sha'] == commit]
    require(exact and all(r['status'] == 'completed' and r['conclusion'] == 'success' for r in exact),
            'Final report workflow has not succeeded for this commit')
    return [dict(id=r['id'], url=r['html_url'], conclusion=r['conclusion']) for r in exact]


def verify(source, repo, progress=None):
    docs = repo/'docs'
    expected, frozen_sha = frozen_inputs(source)
    documents = {name: read(docs/path) for name, path in PROGRESS.items()}
    require(documents['robolab']['frozen_sha256'] == frozen_sha, 'Published RoboLab cohort changed')
    counts = {name: matrix(d, expected[name]) for name, d in documents.items()}
    state = dict(schema='gpt_policy_full_reproduction_gate.v1', updated_utc=datetime.now(timezone.utc).isoformat(),
        full_reproduction_complete=False, status='pending_native_episodes', cohorts=counts,
        original_artifacts_verified=False, public_episode_artifacts_verified=False,
        limitation='RoboLab Direct uses the owned EEF adapter; historical source and full initial physics states unavailable; no independent IK recomputation.')
    if any(c['remaining_method_runs'] for c in counts.values()):
        return state
    receipt = read(source/'online_publication.json')
    bind_publication(receipt, documents, docs)
    commit = subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True, timeout=60).strip()
    require(commit == receipt['commit'], 'Latest report still awaits publication')
    ci = verify_ci(commit)
    sys.path.insert(0, str(repo/'tools'))
    tools = {'dojo': importlib.import_module('build_gpt_site'), 'lab': importlib.import_module('build_robolab_methods')}
    original, public = [], []
    state.update(status='verifying_original_and_public_artifacts', published_commit=commit,
        verified_native_episodes=0, active=None)
    for name, document in documents.items():
        dojo = name == 'robodojo'
        campaign = source/('gpt_pair_campaign' if dojo else 'robolab_gpt_campaign')
        first = first_native_runs(campaign, dojo)
        for e in document['episodes']:
            state['active'] = dict(cohort=name, case_id=e['case_id'], method=e['method'], run_id=e['run_id'])
            if progress:
                progress(state)
            run = campaign/e['run_id']
            if dojo:
                run = run/e['method']
            require(first[(e['case_id'], e['method'])] == run, 'Later outcome replaced the first native complete run')
            original.append(dict(cohort=name, case_id=e['case_id'], method=e['method'],
                **verify_original(run, e, expected[name][e['case_id']], dojo, tools)))
            require(read(relative(docs, e['evidence'])) == e, 'Published episode evidence changed')
            for field, hash_field in (('audit', 'audit_sha256'), ('video', 'video_sha256')):
                require(digest(relative(docs, e[field])) == e[hash_field], 'Exported audit or video changed')
            subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-xerror', '-threads', '2', '-i',
                str(relative(docs, e['video'])), '-f', 'null', '-'], check=True, timeout=300,
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            public.extend(verify_http(docs, e[field], commit) for field in ('evidence', 'audit', 'video', 'poster'))
            state['verified_native_episodes'] += 1
            if progress:
                progress(state)
    bundle = read(docs/'data/infrastructure-bundle.json')
    require(bundle['contents_verified'] is True and set(bundle['active_methods']) == set(METHODS), 'Unverified infrastructure bundle')
    require(digest(relative(docs, bundle['archive'])) == bundle['sha256'], 'Infrastructure bundle changed')
    public.extend(verify_http(docs, p, commit) for p in [*PROGRESS.values(), 'scenes.html',
        'gpt-methods.html', 'robolab-methods.html', 'data/infrastructure-bundle.json', bundle['archive']])
    state.update(status='complete', full_reproduction_complete=True, published_commit=commit,
        original_artifacts_verified=True, public_episode_artifacts_verified=True,
        original_episodes=original, public_files=public, exact_commit_ci=ci, active=None,
        finished_utc=datetime.now(timezone.utc).isoformat())
    return state


def atomic_json(path, value):
    with tempfile.NamedTemporaryFile('w', dir=path.parent, delete=False) as f:
        temporary = Path(f.name)
        json.dump(value, f, indent=2, ensure_ascii=False)
        f.write('\n')
    temporary.replace(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--repo', type=Path, default=Path(__file__).resolve().parents[3]/'gpt-policy-report-site')
    args = parser.parse_args()
    # Use the existing publication lock: never read a half-written public snapshot.
    with Path('/tmp/gpt-policy-report-publish.lock').open('a') as owner:
        try:
            fcntl.flock(owner, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print(json.dumps(dict(status='publisher_running; verification deferred')))
            return
        try:
            certificate = args.source/'full_reproduction_verification.json'
            previous = read(certificate) if certificate.exists() else {}
            if previous.get('full_reproduction_complete') is True:
                # An immutable completion receipt is evidence at finished_utc. Do
                # not repeat a multi-hour archive scan or refresh its timestamp.
                receipt = read(args.source/'online_publication.json')
                commit = subprocess.check_output(['git', '-C', str(args.repo), 'rev-parse', 'HEAD'],
                    text=True, timeout=60).strip()
                if previous['published_commit'] == receipt['commit'] == commit:
                    print(json.dumps(dict(status='completion_receipt_already_recorded',
                        commit=commit, verified_utc=previous['finished_utc'])))
                    return
            state = verify(args.source, args.repo, lambda value: atomic_json(certificate, value))
        except Exception as error:
            state = dict(schema='gpt_policy_full_reproduction_gate.v1', status='verification_failed',
                full_reproduction_complete=False, error_type=type(error).__name__,
                updated_utc=datetime.now(timezone.utc).isoformat())
            atomic_json(args.source/'full_reproduction_verification.json', state)
            raise
        if state['full_reproduction_complete']:
            evidence = args.source/'final_verification'/state['published_commit']
            evidence.mkdir(parents=True, exist_ok=True)
            immutable = evidence/'certificate.json'
            require(not immutable.exists(), 'Completion certificate already exists; preserve its original verification time')
            atomic_json(immutable, state)
        atomic_json(args.source/'full_reproduction_verification.json', state)
        print(json.dumps({k:v for k,v in state.items() if k not in ('original_episodes', 'public_files')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
