"""Main state offload must use the verified frozen qualifier and protect all live states."""
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from offload_robodojo_codex_states import offload_run, load_qualifier, active_states
from offload_robolab_workspaces import write


class RoboDojoStateOffload(unittest.TestCase):
    def fixture(self,root):
        run=root/'campaign/queue_20261002T145255Z_gpt_only_case/gpt_only'
        agent=run/'rollout/codex_workspace';agent.mkdir(parents=True)
        local=root/'local';local.mkdir();source=local/'gpt-policy-codex-state.abcdefgh'
        (source/'runtime_db').mkdir(parents=True);(source/'runtime_logs').mkdir()
        (source/'runtime_db/state.sqlite').write_bytes(b'full stopped database')
        write(agent/'launch.json',dict(config=dict(sqlite_home=str(source/'runtime_db'),log_dir=str(source/'runtime_logs'))))
        write(agent/'worker.json',dict(pid=99999999))
        cold=root/'cold';cold.mkdir()
        return run,local,source,cold

    def test_qualified_idle_state_preserved_with_original_read_paths(self):
        with tempfile.TemporaryDirectory() as tmp:
            run,local,source,cold=self.fixture(Path(tmp));calls=[]
            def qualified(parent,method):calls.append((parent,method));return True
            self.assertEqual(offload_run(run,cold,local,qualified)['status'],'offloaded')
            self.assertGreaterEqual(len(calls),2)
            self.assertEqual((source/'runtime_db/state.sqlite').read_bytes(),b'full stopped database')
            self.assertEqual(offload_run(run,cold,local,qualified)['status'],'already_offloaded')

    def test_audit_gap_live_worker_and_shared_active_state_block_mutation(self):
        for defect in ('audit','worker','shared'):
            with self.subTest(defect=defect),tempfile.TemporaryDirectory() as tmp:
                run,local,source,cold=self.fixture(Path(tmp))
                if defect=='worker':write(run/'rollout/codex_workspace/worker.json',dict(pid=os.getpid()))
                with self.assertRaises(AssertionError):
                    offload_run(run,cold,local,lambda *_:defect!='audit',lambda:{source} if defect=='shared' else set())
                self.assertFalse(source.is_symlink());self.assertEqual((source/'runtime_db/state.sqlite').read_bytes(),b'full stopped database')

    def test_unknown_sqlite_or_log_paths_are_rejected(self):
        for defect in ('outside','logs'):
            with self.subTest(defect=defect),tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp);run,local,source,cold=self.fixture(root)
                config=json.loads((run/'rollout/codex_workspace/launch.json').read_text())
                config['config']['sqlite_home' if defect=='outside' else 'log_dir']=str(root/'outside')
                write(run/'rollout/codex_workspace/launch.json',config)
                with self.assertRaises(AssertionError):offload_run(run,cold,local,lambda *_:True)
                self.assertFalse(source.is_symlink())

    def test_unpinned_source_is_rejected_before_execution(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'infra').mkdir()
            (root/'infra/run_all_gpt_pairs_v5_20261002.py').write_text('raise RuntimeError("Unverified execution")\n')
            write(root/'queue_scheduler_v5_manifest.json',dict(source_sha256='0'*64))
            with patch('offload_robodojo_codex_states.ARTIFACTS',root):
                with self.assertRaisesRegex(AssertionError,'Frozen qualifier'):load_qualifier()

    def test_live_workers_are_discovered_independently_of_candidate(self):
        with tempfile.TemporaryDirectory() as tmp:
            run,local,source,cold=self.fixture(Path(tmp))
            self.assertEqual(active_states(run.parent.parent,local),set())
            write(run/'rollout/codex_workspace/worker.json',dict(pid=os.getpid()))
            self.assertEqual(active_states(run.parent.parent,local),{source})


if __name__=='__main__':unittest.main()
