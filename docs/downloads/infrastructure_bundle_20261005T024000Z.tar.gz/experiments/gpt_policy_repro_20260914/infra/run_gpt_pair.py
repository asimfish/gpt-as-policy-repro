"""One frozen Direct/Hybrid pair using the original persistent GPT controller."""
import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

from run_batch_student import check, check_simulator, terminate, wait_log, write

ART = Path(__file__).resolve().parents[1]
# NAS-backed asset/weight loading has exceeded ten minutes before any action.
# This bounds readiness only; native horizons and the rollout watchdog stay fixed.
READINESS_TIMEOUT_SECONDS = 1200


def check_pair_simulator(proc, run, now, finalizing_since):
    # Native shutdown precedes offline video/result finalization, including errors.
    if proc.poll() == 0 and (run/'sim/evaluation_outcome.json').exists():
        if (run/'rollout/failure.json').exists() or (run/'rollout/result.json').exists():
            if finalizing_since is None:
                finalizing_since = now
            if now - finalizing_since > 600:
                raise TimeoutError('Controller finalization exceeded 600 seconds')
            return finalizing_since
    check_simulator(proc, run/'sim.log', run/'rollout/result.json')
    return finalizing_since


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--case', default='arrange_largest_number__random__g0__l0')
    p.add_argument('--gpu', default='1')
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--method', choices=('both', 'gpt_only', 'pi05_plus_gpt'), default='both',
                   help='Select an unrun method after reviewing an interrupted pair; never resume physical state')
    p.add_argument('--continue-after-failure', action='store_true',
                   help='Record a failed method and continue to the other method; each attempt remains fresh')
    p.add_argument('--lock-path', type=Path, default=Path(os.environ.get('CAMPAIGN_LOCK_PATH', str(ART/'student_native_campaign/.campaign.lock'))),
                   help='Local coordination lock; use a local filesystem for long queues')
    a = p.parse_args()
    assert os.environ.get('ROLLOUT_USE_CURRENT_CODEX_HOME') == '1'
    cases = []
    for method, prefix in [('gpt_only', 'gpt'), ('pi05_plus_gpt', 'mix')]:
        path = ART/'fixtures/cases'/f'{prefix}__{a.case}.json'
        data = json.loads(path.read_text())
        layout = Path(os.environ['ROBO_ROOT'])/data['case']['layout']['path']
        assert hashlib.sha256(layout.read_bytes()).hexdigest() == data['identity']['layout_sha256']
        cases.append((method, path, data))
    assert cases[0][2]['identity'] == cases[1][2]['identity']
    a.output = a.output.resolve()
    a.output.mkdir(parents=True, exist_ok=False)
    a.lock_path.parent.mkdir(parents=True, exist_ok=True)
    lock = a.lock_path.open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    write(a.output/'pair.json', dict(case=a.case, identity=cases[0][2]['identity'],
        model='gpt-6-astra', reasoning_effort='xhigh', controller='original_persistent_codex',
        authorization='user_20260916_current_codex_cli_login', physical_pairing_verified=False,
        requested_methods=[m for m, _, _ in cases if a.method in ('both', m)]))

    def interrupted(signum, frame):
        signal.signal(signum, signal.SIG_IGN)
        raise KeyboardInterrupt('Owned pair supervisor interrupted')

    signal.signal(signal.SIGTERM, interrupted)
    for method, path, data in cases:
        if a.method not in ('both', method):
            continue
        run = a.output/method
        run.mkdir()
        row = dict(case=path.stem, method=method, status='starting', started_utc=datetime.now(timezone.utc).isoformat())
        write(run/'attempt.json', row)
        processes, handles = [], []
        env = dict(os.environ, CUDA_VISIBLE_DEVICES=a.gpu, SIM_GPU=a.gpu,
                   EVAL_MANIFEST=str(ART/'fixtures/evaluation_manifest.json'), CASE_FILE=str(path),
                   SIM_PORT='19900', POLICY_PORT='19901', LAYOUT_ID=str(data['case']['reset_seed']), MAX_DECISIONS='0')

        def start(command, log):
            handle = log.open('x'); handles.append(handle)
            child = subprocess.Popen(command, env=env, stdout=handle, stderr=subprocess.STDOUT, start_new_session=True)
            processes.append(child)
            return child

        try:
            free = int(subprocess.check_output(['nvidia-smi', '-i', a.gpu, '--query-gpu=memory.free', '--format=csv,noheader,nounits'], text=True).strip())
            if free < 20000:
                raise RuntimeError('GPU needs 20000 MiB free; no unrelated process is stopped')
            policy = None
            if method == 'pi05_plus_gpt':
                policy = start(['bash', str(ART/'infra/run_pi05_server.sh'), '19901', str(run/'policy_identity.json')], run/'policy.log')
                wait_log(policy, run/'policy.log', 'server listening', timeout=READINESS_TIMEOUT_SECONDS)
            sim = start(['bash', str(ART/'infra/run_sim_server.sh'), data['case']['runtime_task'], str(run/'sim'), '19900', str(data['case']['eval_seed'])], run/'sim.log')
            wait_log(sim, run/'sim.log', '"event": "ready"', timeout=READINESS_TIMEOUT_SECONDS)
            controller = start(['bash', str(ART/'infra/run_original_controller.sh'), method, str(run/'rollout'), data['case']['runtime_task']], run/'controller.log')
            row.update(status='running', pids=[child.pid for child in processes]); write(run/'attempt.json', row)
            deadline = time.monotonic() + 12*3600  # Infrastructure watchdog, never a task-failure label.
            finalizing_since = None
            while controller.poll() is None:
                finalizing_since = check_pair_simulator(sim, run, time.monotonic(), finalizing_since)
                if policy is not None:
                    check(policy, run/'policy.log')
                if time.monotonic() > deadline:
                    raise TimeoutError('12-hour infrastructure watchdog; episode incomplete')
                time.sleep(2)
            result = json.loads((run/'rollout/result.json').read_text()) if (run/'rollout/result.json').exists() else {}
            native = result.get('complete') is True and (result.get('terminated') is True or result.get('truncated') is True)
            row.update(status='complete' if controller.returncode == 0 and native else 'controller_failed', returncode=controller.returncode, result=result)
        except BaseException as exc:
            row.update(status='interrupted' if isinstance(exc, KeyboardInterrupt) else 'infrastructure_failed', error=f'{type(exc).__name__}: {exc}')
        finally:
            for child in reversed(processes):
                terminate(child)
            for handle in handles:
                handle.close()
            if (run/'rollout').exists():
                write(run/'rollout/reproduction.json', dict(method=method, controller='original_persistent_codex',
                    model='gpt-6-astra', reasoning_effort='xhigh', benchmark_eligible=False,
                    exclusion_reason='first paired run pending model/action/initial-state audit',
                    authorization='user_20260916_current_codex_cli_login'))
            row['finished_utc'] = datetime.now(timezone.utc).isoformat()
            write(run/'attempt.json', row)
            print(json.dumps(row), flush=True)
        if row['status'] != 'complete' and not a.continue_after_failure:
            raise RuntimeError('Stop for review; no automatic physical retry')


if __name__ == '__main__':
    main()
