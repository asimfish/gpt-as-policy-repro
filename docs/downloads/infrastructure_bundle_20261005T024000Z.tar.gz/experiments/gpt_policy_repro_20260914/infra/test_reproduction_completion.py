"""Final acceptance cannot be obtained from duplicate rows, headlines, prefixes, or later wins."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from types import SimpleNamespace

import verify_reproduction_completion as gate


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data)+'\n')


def cohort(count=100):
    expected = {f'task__seed{i}': dict(task='task', seed=i) for i in range(50)}
    episodes, cases = [], []
    for i, (cid, identity) in enumerate(expected.items()):
        methods = {}
        for j, method in enumerate(gate.METHODS):
            present, uid = i*2+j < count, cid+'__'+method
            methods[method] = dict(status='complete' if present else 'pending', episode_id=uid if present else None)
            if present:
                episodes.append(dict(id=uid, case_id=cid, method=method, task='task', seed=i,
                    complete=True, eligible=True, success=False, terminated=False, truncated=True,
                    control_steps=3, native_horizon=3))
        cases.append(dict(case_id=cid, methods=methods, paired_complete=all(r['episode_id'] for r in methods.values())))
    pairs = {c['case_id'] for c in cases if c['paired_complete']}
    stats = {}
    for method in gate.METHODS:
        stats[method] = {}
        for name, rows in [('all_completed', [e for e in episodes if e['method'] == method]),
                ('paired_completed', [e for e in episodes if e['method'] == method and e['case_id'] in pairs])]:
            n = len(rows)
            stats[method][name] = dict(evaluated=n, successes=0, failures=n, success_rate=0.0 if n else None)
    return dict(cases=cases, episodes=episodes, summary=dict(planned_pairs=50, planned_method_runs=100,
        complete_method_runs=count, completed_pairs=len(pairs), methods=stats)), expected


class MatrixAcceptance(unittest.TestCase):
    def test_full_matrix_includes_all_native_failures(self):
        document, expected = cohort()
        self.assertEqual(gate.matrix(document, expected), dict(complete_method_runs=100,
            completed_pairs=50, remaining_method_runs=0, remaining_pairs=0))

    def test_headline_cannot_hide_missing_episodes(self):
        document, expected = cohort(92)
        document['summary']['complete_method_runs'] = 100
        with self.assertRaisesRegex(ValueError, 'Headline'):
            gate.matrix(document, expected)

    def test_duplicate_episode_cannot_fill_the_last_slot(self):
        document, expected = cohort()
        document['episodes'][-1] = copy.deepcopy(document['episodes'][0])
        with self.assertRaisesRegex(ValueError, 'Duplicated'):
            gate.matrix(document, expected)

    def test_prefix_excluded_and_foreign_seed_cannot_count(self):
        for field, value in [('complete', False), ('eligible', False), ('seed', 99), ('control_steps', 4)]:
            with self.subTest(field=field):
                document, expected = cohort()
                document['episodes'][0][field] = value
                with self.assertRaises(ValueError):
                    gate.matrix(document, expected)

    def test_success_denominator_cannot_drop_native_failures(self):
        document, expected = cohort()
        document['summary']['methods']['gpt_only']['all_completed']['failures'] = 0
        with self.assertRaisesRegex(ValueError, 'denominator'):
            gate.matrix(document, expected)

    def test_unpaired_or_duplicate_case_cannot_complete(self):
        for defect in ('method', 'case'):
            with self.subTest(defect=defect):
                document, expected = cohort()
                if defect == 'method':
                    del document['cases'][0]['methods']['pi05_plus_gpt']
                else:
                    document['cases'][-1] = copy.deepcopy(document['cases'][0])
                with self.assertRaises(ValueError):
                    gate.matrix(document, expected)

    def test_partial_second_cohort_defers_all_expensive_final_checks(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo, source = Path(tmp)/'repo', Path(tmp)/'source'
            dojo, expected_dojo = cohort()
            lab, expected_lab = cohort(14)
            lab['frozen_sha256'] = 'f'*64
            for name, document in [('robodojo', dojo), ('robolab', lab)]:
                write(repo/'docs'/gate.PROGRESS[name], document)
            with patch.object(gate, 'frozen_inputs', return_value=({'robodojo': expected_dojo,
                'robolab': expected_lab}, 'f'*64)), patch.object(gate, 'verify_original') as original, \
                patch.object(gate, 'verify_http') as public:
                state = gate.verify(source, repo)
            self.assertFalse(state['full_reproduction_complete'])
            self.assertEqual(state['status'], 'pending_native_episodes')
            self.assertEqual(state['cohorts']['robolab']['remaining_method_runs'], 86)
            original.assert_not_called()
            public.assert_not_called()


class ArtifactAcceptance(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)

    def attempt(self, name, started, success, *, invalid=False, audited=False, dojo=False):
        run = self.root/name/'gpt_only' if dojo else self.root/name
        write(run/'attempt.json', dict(started_utc=started, case='gpt__task__seed0', task='task', seed=0,
            method='gpt_only'))
        write(run/'rollout/result.json', dict(complete=True, terminated=success, truncated=not success, success=success))
        if dojo:
            write(run/'sim/evaluation_outcome.json', dict(complete=True, valid_for_success_rate=not invalid))
        if audited:
            write(run/'complete_action_audit.json', dict(verified=True))
        return run

    def test_earlier_unaudited_native_failure_blocks_later_success_in_both_cohorts(self):
        for dojo in (False, True):
            with self.subTest(dojo=dojo):
                first = self.attempt('first', '1', False, dojo=dojo)
                self.attempt('later', '2', True, audited=True, dojo=dojo)
                selected = gate.first_native_runs(self.root, dojo)
                self.assertEqual(selected['task__seed0', 'gpt_only'], first)

    def test_native_invalid_layout_is_excluded_before_first_valid_failure(self):
        self.attempt('invalid', '1', False, invalid=True, dojo=True)
        first = self.attempt('valid_failure', '2', False, dojo=True)
        self.attempt('later_success', '3', True, audited=True, dojo=True)
        self.assertEqual(gate.first_native_runs(self.root, True)['task__seed0', 'gpt_only'], first)

    def test_receipt_cannot_certify_a_changed_report_snapshot(self):
        document, _ = cohort()
        docs = self.root/'docs'
        documents = {n: copy.deepcopy(document) for n in gate.PROGRESS}
        for name, path in gate.PROGRESS.items():
            write(docs/path, documents[name])
        receipt = dict(status='published_and_http_verified', commit='a'*40,
            gpt_summary=document['summary'], robolab_summary=document['summary'],
            files=[dict(file=p, matches=True, http_status=200, local_sha256=gate.digest(docs/p),
                online_sha256=gate.digest(docs/p)) for p in gate.PROGRESS.values()])
        gate.bind_publication(receipt, documents, docs)
        (docs/gate.PROGRESS['robolab']).write_text('{"changed":true}\n')
        with self.assertRaisesRegex(ValueError, 'snapshot changed'):
            gate.bind_publication(receipt, documents, docs)

    def test_changed_action_bytes_are_detected_even_with_an_unchanged_valid_receipt(self):
        run = self.root/'run'
        action = run/'sim/action.json'
        write(action, dict(action=[1, 2, 3]))
        proof = dict(files_sha256={'sim/action.json': gate.digest(action)})
        result = dict(success=False, terminated=False, truncated=True, step_id=3, decisions=1, video_frames=4)
        e = dict(result, control_steps=3)
        trusted_checker = SimpleNamespace(check_episode=lambda *_: (result, {}, proof))
        write(action, dict(action=[99, 2, 3]))
        with self.assertRaisesRegex(ValueError, 'audit input'):
            gate.verify_original(run, e, {}, True, {'dojo': trusted_checker})

    def test_public_path_cannot_escape_artifact_root(self):
        for name in ('../private', '/private', 'a/../private', './a', ''):
            with self.subTest(path=name), self.assertRaises(ValueError):
                gate.relative(self.root, name)

    def full_export(self):
        repo, source = self.root/'repo', self.root/'source'
        maps, documents, originals = {}, {}, {}
        for name in gate.PROGRESS:
            document, expected = cohort()
            maps[name], documents[name] = expected, document
            document['frozen_sha256'] = 'f'*64
            for e in document['episodes']:
                e.update(run_id='original_'+e['id'], audit=f'data/{name}/{e["id"]}-audit.json',
                    evidence=f'data/{name}/{e["id"]}.json', video='media/movie.mp4', poster='media/poster.jpg')
                write(repo/'docs'/e['audit'], dict(verified=True))
                e['audit_sha256'] = gate.digest(repo/'docs'/e['audit'])
                e['video_sha256'] = gate.hashlib.sha256(b'video').hexdigest()
                write(repo/'docs'/e['evidence'], e)
                run = source/('gpt_pair_campaign' if name == 'robodojo' else 'robolab_gpt_campaign')/e['run_id']
                if name == 'robodojo':
                    run = run/e['method']
                originals[name == 'robodojo', e['case_id'], e['method']] = run
            write(repo/'docs'/gate.PROGRESS[name], document)
        media = repo/'docs/media'
        media.mkdir()
        (media/'movie.mp4').write_bytes(b'video')
        (media/'poster.jpg').write_bytes(b'poster')
        (repo/'docs/bundle.tar.gz').write_bytes(b'bundle')
        write(repo/'docs/data/infrastructure-bundle.json', dict(contents_verified=True,
            active_methods=list(gate.METHODS), archive='bundle.tar.gz', sha256=gate.digest(repo/'docs/bundle.tar.gz')))
        write(source/'online_publication.json', dict(status='published_and_http_verified', commit='a'*40,
            gpt_summary=documents['robodojo']['summary'], robolab_summary=documents['robolab']['summary'],
            files=[dict(file=p, matches=True, http_status=200, local_sha256=gate.digest(repo/'docs'/p),
                online_sha256=gate.digest(repo/'docs'/p)) for p in gate.PROGRESS.values()]))
        return source, repo, maps, originals

    def test_all_200_verified_boundaries_are_required_before_completion(self):
        source, repo, maps, originals = self.full_export()
        states = []
        with patch.object(gate, 'frozen_inputs', return_value=(maps, 'f'*64)), \
            patch.object(gate.importlib, 'import_module', return_value=SimpleNamespace()), \
            patch.object(gate, 'first_native_runs', side_effect=lambda _, dojo:
                {(cid, method): run for (kind, cid, method), run in originals.items() if kind == dojo}), \
            patch.object(gate, 'verify_original', return_value=dict(audit_inputs=1)) as original, \
            patch.object(gate, 'verify_http', return_value=dict(status=200)) as public, \
            patch.object(gate, 'verify_ci', return_value=[dict(conclusion='success')]), \
            patch.object(gate.subprocess, 'check_output', return_value='a'*40), \
            patch.object(gate.subprocess, 'run'):
            state = gate.verify(source, repo, lambda value: states.append(copy.deepcopy(value)))
        self.assertTrue(state['full_reproduction_complete'])
        self.assertEqual(original.call_count, 200)
        self.assertEqual(public.call_count, 807)
        self.assertEqual(state['verified_native_episodes'], 200)
        self.assertTrue(all(s['full_reproduction_complete'] is False for s in states))

    def test_publication_failure_cannot_become_a_completion_receipt(self):
        source, repo, maps, originals = self.full_export()
        states = []
        with patch.object(gate, 'frozen_inputs', return_value=(maps, 'f'*64)), \
            patch.object(gate.importlib, 'import_module', return_value=SimpleNamespace()), \
            patch.object(gate, 'first_native_runs', side_effect=lambda _, dojo:
                {(cid, method): run for (kind, cid, method), run in originals.items() if kind == dojo}), \
            patch.object(gate, 'verify_original', return_value=dict(audit_inputs=1)), \
            patch.object(gate, 'verify_http', side_effect=OSError('public artifact unavailable')), \
            patch.object(gate, 'verify_ci', return_value=[dict(conclusion='success')]), \
            patch.object(gate.subprocess, 'check_output', return_value='a'*40), \
            patch.object(gate.subprocess, 'run'):
            with self.assertRaises(OSError):
                gate.verify(source, repo, lambda value: states.append(copy.deepcopy(value)))
        self.assertTrue(states)
        self.assertTrue(all(s['full_reproduction_complete'] is False for s in states))


if __name__ == '__main__':
    unittest.main()
